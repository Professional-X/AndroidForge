# Ruta Sevilla V3

Proyecto Android completo para Ruta Sevilla.

La aplicación ya contiene el módulo de servicios, cuentas, pedidos, clientes,
WhatsApp, respaldos/restauración y el logo suministrado.

No requiere navegador después de compilar e instalar el APK.

Para generar el APK abre el proyecto en Android Studio y usa:
Build > Build Bundle(s) / APK(s) > Build APK(s)

El entorno actual no incluye el Android SDK/Gradle necesario para producir aquí
el binario APK final.
