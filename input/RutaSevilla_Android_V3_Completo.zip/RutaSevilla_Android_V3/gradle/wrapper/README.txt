Android Studio puede generar/actualizar el Gradle Wrapper al abrir el proyecto.
