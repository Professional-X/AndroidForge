# RUTA SEVILLA — PROYECTO V3

Este proyecto queda preparado como aplicación Android nativa con una interfaz local
embebida en WebView. No necesita navegador para funcionar una vez compilado e instalado.

## Funciones incluidas
- Inicio con ingresos, gastos, ganancia y número de servicios.
- Servicios de moto: cliente, moto, trabajo, valor y estado.
- Cuentas: ingresos y gastos.
- Pedidos: cliente, descripción, valor y estado.
- Clientes: nombre, teléfono y notas.
- WhatsApp: abre WhatsApp con un mensaje preparado.
- Respaldo de datos a un archivo JSON.
- Restauración de datos desde JSON.
- Eliminación de todos los datos.
- Logo proporcionado por el usuario.
- Persistencia local en el teléfono.
- Código fuente editable y aplicación sin dependencia de Chrome/Brave.

## Para generar el APK
Abrir la carpeta raíz del proyecto en Android Studio.
Después:
Build > Build Bundle(s) / APK(s) > Build APK(s)

El APK de debug normalmente aparecerá en:
app/build/outputs/apk/debug/app-debug.apk

Para una versión distribuible, usar:
Build > Generate Signed Bundle / APK > APK
y crear/usar una clave de firma propia.

## Importante sobre el control
La app almacena los datos localmente. La copia JSON permite trasladar los datos a otro teléfono.
La función de WhatsApp abre la aplicación WhatsApp instalada; no necesita que Ruta Sevilla
tenga acceso a la cuenta de WhatsApp.

## Próximas ampliaciones posibles
- Editar registros existentes.
- Buscar y filtrar clientes.
- Botón WhatsApp por cliente.
- Botón llamar por cliente.
- Historial por cliente.
- Reportes diarios/mensuales.
- Exportación CSV/PDF.
- PIN de acceso.
- Sincronización en la nube.
