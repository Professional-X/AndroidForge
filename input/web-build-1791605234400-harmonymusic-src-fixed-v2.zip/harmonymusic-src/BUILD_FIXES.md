# Build fixes applied to Harmony Music 1.12.2 (Android)

These changes were required to make the project build a release APK on a
clean Debian/Linux machine. They are minimal and do not change app behavior.

## 1. Added `android/gradle.properties`
The file was missing entirely, which caused the Gradle JVM to thrash and the
daemon to be killed ("Gradle build daemon has been stopped: since the JVM
garbage collector is thrashing"). Added sane JVM heap settings and enabled
AndroidX:

```
org.gradle.jvmargs=-Xmx4G -XX:MaxMetaspaceSize=1G -XX:+HeapDumpOnOutOfMemoryError
org.gradle.daemon=true
org.gradle.parallel=true
org.gradle.caching=true
android.useAndroidX=true
android.enableJetifier=true
android.nonTransitiveRClass=true
kotlin.daemon.jvmargs=-Xmx2G
```

## 2. Added the JitPack repository
`android/build.gradle` uses `com.github.teamnewpipe:NewPipeExtractor:0.26.5`,
which is hosted on JitPack. The repository was not declared, so the dependency
failed to resolve. Added `maven { url 'https://jitpack.io' }` to the
`allprojects { repositories { ... } }` block.

## 3. Removed the duplicate `MainActivity.kt`
Two `MainActivity.kt` files declared the same class, causing a Kotlin
"Redeclaration" compile error:
* `android/app/src/main/java/com/anandnet/harmonymusic/MainActivity.kt` - the
  real one, containing the NewPipe `MethodChannel` bridge. KEPT.
* `android/app/src/main/kotlin/com/anandnet/harmonymusic/MainActivity.kt` - an
  empty stub. REMOVED.

## 4. Wired up ProGuard/R8 rules
`android/app/proguard-rules.pro` existed but was never referenced, so R8
failed with "Missing classes detected" from Rhino/JDK classes pulled in by
NewPipeExtractor. Referenced the file in the release build type and added the
required `-dontwarn` rules.

* `android/app/build.gradle`:
  ```gradle
  proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
  ```
* `android/app/proguard-rules.pro` now also ignores `java.beans.**`,
  `javax.script.**`, `jdk.dynalink.**`, and `java.lang.invoke.**`.

## Build environment used
* JDK 21 (Android Gradle Plugin 8.6 requires 17+)
* Flutter 3.24.2 stable / Dart 3.5.2 (matches the project's own CI workflow)
* Android SDK: platform android-35, build-tools 35.0.0, NDK 26.1.10909125

## Note
`android/local.properties` is machine-specific (SDK/Flutter paths) and is not
included. Flutter regenerates it automatically; if needed, create it with:

```
sdk.dir=/path/to/Android/sdk
flutter.sdk=/path/to/flutter
```

Build with: `flutter pub get && flutter build apk --release`
