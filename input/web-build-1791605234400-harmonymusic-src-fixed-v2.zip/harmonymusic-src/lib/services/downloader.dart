import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:audio_service/audio_service.dart';
import 'package:dio/dio.dart';
import 'package:audiotags/audiotags.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';

import '../ui/screens/Album/album_screen_controller.dart';
import '../ui/screens/Playlist/playlist_screen_controller.dart';
import '/services/stream_service.dart';
import '../ui/widgets/snackbar.dart';
import '/services/permission_service.dart';
import '../ui/screens/Settings/settings_screen_controller.dart';
import '/utils/helper.dart';
import '/models/media_Item_builder.dart';
import '../ui/screens/Library/library_controller.dart';
//import '../models/thumbnail.dart' as th;

class Downloader extends GetxService {
  final _dio = Dio();
  MediaItem? currentSong;
  RxMap<String, List<MediaItem>> playlistQueue =
      <String, List<MediaItem>>{}.obs;
  final currentPlaylistId = "".obs;
  final songDownloadingProgress = 0.obs;
  final playlistDownloadingProgress = 0.obs;
  final isJobRunning = false.obs;

  RxList<MediaItem> songQueue = <MediaItem>[].obs;
  final Map<String, Future<StreamProvider>> _prefetch = {};

  Future<bool> checkPermissionNDir() async {
    final settingsScreenController = Get.find<SettingsScreenController>();

    if (!settingsScreenController.isCurrentPathsupportDownDir &&
        !await PermissionService.getExtStoragePermission()) {
      return false;
    }

    final dirPath =
        Get.find<SettingsScreenController>().downloadLocationPath.string;
    final directory = Directory(dirPath);
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    return true;
  }

  Future<void> downloadPlaylist(
      String playlistId, List<MediaItem> songList) async {
    if (!(await checkPermissionNDir())) return;

    // for toggle between downloading request & cancelling
    if (playlistQueue.containsKey(playlistId)) {
      songQueue.removeWhere((element) => songList.contains(element));
      playlistQueue.remove(playlistId);
      return;
    }

    playlistQueue[playlistId] = songList;
    songQueue.addAll(songList);

    if (isJobRunning.isFalse) {
      await triggerDownloadingJob();
    }
  }

  Future<void> download(MediaItem? song, {List<MediaItem>? songList}) async {
    if (!(await checkPermissionNDir())) return;
    if (songList != null) {
      songQueue.addAll(songList);
    } else {
      songQueue.add(song!);
    }
    if (isJobRunning.isFalse) {
      await triggerDownloadingJob();
    }
  }

  Future<void> triggerDownloadingJob() async {
    //check if playlist download in queue => download playlistsongs else download from general songs queue
    if (playlistQueue.isNotEmpty) {
      isJobRunning.value = true;
      for (String playlistId in playlistQueue.keys.toList()) {
        //checked in case download cancel request
        if (playlistQueue.containsKey(playlistId)) {
          currentPlaylistId.value = playlistId;
          await downloadSongList((playlistQueue[playlistId]!).toList(),
              isPlaylist: true);
          if (Get.isRegistered<PlaylistScreenController>(
                  tag: Key(playlistId).hashCode.toString()) &&
              playlistQueue.containsKey(playlistId)) {
            Get.find<PlaylistScreenController>(
                    tag: Key(playlistId).hashCode.toString())
                .isDownloaded
                .value = true;
          } 
          // in case of album
          else if (Get.isRegistered<AlbumScreenController>(
                  tag: Key(playlistId).hashCode.toString()) &&
              playlistQueue.containsKey(playlistId)) {
            Get.find<AlbumScreenController>(
                    tag: Key(playlistId).hashCode.toString())
                .isDownloaded
                .value = true;
          }
          playlistQueue.remove(playlistId);
        }
        currentPlaylistId.value = "";
        playlistDownloadingProgress.value = 0;
      }
    } else {
      isJobRunning.value = true;
      await downloadSongList(songQueue.toList());
    }

    if (songQueue.isNotEmpty) {
      triggerDownloadingJob();
    } else {
      isJobRunning.value = false;
      currentSong = null;
      _prefetch.clear();
    }
  }

  Future<void> downloadSongList(List<MediaItem> jobSongList,
      {bool isPlaylist = false}) async {
    for (MediaItem song in jobSongList) {
      // intrrupt downloading task in case of playlist download cancel request
      if (isPlaylist && !playlistQueue.containsKey(currentPlaylistId.value)) {
        currentPlaylistId.value = "";
        playlistDownloadingProgress.value = 0;
        return;
      }

      if (!Hive.box("SongDownloads").containsKey(song.id)) {
        currentSong = song;
        songDownloadingProgress.value = 0;
        final pending = _prefetch.remove(song.id);
        // Resolve the NEXT song's stream URL while this one downloads, so
        // NewPipe's extraction latency is hidden instead of added per song.
        final idx = jobSongList.indexOf(song);
        for (var i = idx + 1; i < jobSongList.length && i <= idx + 1; i++) {
          final next = jobSongList[i];
          if (!Hive.box("SongDownloads").containsKey(next.id)) {
            _prefetch.putIfAbsent(next.id, () => StreamProvider.fetch(next.id));
          }
        }
        await writeFileStream(song, prefetched: pending);
      }
      songQueue.remove(song);
      //for playlist downloading counter update
      if (isPlaylist) {
        playlistDownloadingProgress.value = jobSongList.indexOf(song) + 1;
      }
    }
  }

  // googlevideo throttles a single un-ranged GET to roughly playback speed.
  // youtube_explode (what made downloads fast before) always fetched ~10MB
  // ranged chunks; NewPipe URLs need the same treatment.
  static const int _chunkSize = 9898989;

  Future<void> _downloadChunked(
    String url,
    File dest, {
    required void Function(int received, int total) onProgress,
  }) async {
    int? total = int.tryParse(Uri.parse(url).queryParameters['clen'] ?? '');
    int position = 0;
    var lastUiUpdate = DateTime.fromMillisecondsSinceEpoch(0);
    final sink = dest.openWrite();
    try {
      var failures = 0;
      while (total == null || position < total) {
        final rangeEnd = total != null
            ? math.min(position + _chunkSize, total) - 1
            : position + _chunkSize - 1;
        try {
          final response = await _dio.get<ResponseBody>(
            url,
            options: Options(
              responseType: ResponseType.stream,
              followRedirects: true,
              receiveTimeout: const Duration(seconds: 30),
              sendTimeout: const Duration(seconds: 30),
              headers: {
                "User-Agent":
                    "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/140.0 Mobile Safari/537.36",
                "Accept": "*/*",
                "Range": "bytes=$position-$rangeEnd",
              },
              validateStatus: (s) => s != null && ((s >= 200 && s < 300) || s == 416),
            ),
          );

          // 416: asked past the end of the file => we are done.
          if (response.statusCode == 416) {
            if (position == 0) throw const FileSystemException("Range not satisfiable");
            break;
          }

          // Learn the total size from "Content-Range: bytes 0-99/12345".
          final contentRange = response.headers.value('content-range');
          if (total == null && contentRange != null) {
            total = int.tryParse(contentRange.split('/').last);
          }
          final serverIgnoredRange = response.statusCode == 200;
          if (serverIgnoredRange && position != 0) {
            throw const FileSystemException("Server ignored Range header");
          }

          var gotInChunk = 0;
          await for (final data in response.data!.stream) {
            sink.add(data);
            gotInChunk += data.length;
            position += data.length;
            final now = DateTime.now();
            if (total != null &&
                now.difference(lastUiUpdate).inMilliseconds >= 250) {
              lastUiUpdate = now;
              onProgress(position, total);
            }
          }

          if (serverIgnoredRange) {
            // Whole file came back in one response.
            total = position;
            break;
          }
          if (gotInChunk == 0) break;
          // Unknown total and a short chunk => end of file.
          if (total == null && gotInChunk < _chunkSize) break;
          failures = 0;
        } catch (e) {
          // Resume from `position` (bytes already flushed to the sink).
          if (++failures > 3) rethrow;
          await Future.delayed(Duration(milliseconds: 400 * failures));
        }
      }
      if (total != null) onProgress(position, total);
    } finally {
      await sink.close();
    }
  }

  Future<void> writeFileStream(MediaItem song, {Future<StreamProvider>? prefetched}) async {
    final settings = Get.find<SettingsScreenController>();
    final requestedFormat = settings.downloadingFormat.string.toLowerCase();
    final playerResponse = await (prefetched ?? StreamProvider.fetch(song.id));

    if (!playerResponse.playable || playerResponse.audioFormats == null ||
        playerResponse.audioFormats!.isEmpty) {
      final context = Get.context;
      if (context != null) {
        ScaffoldMessenger.of(context).showSnackBar(snackbar(
          context,
          playerResponse.statusMSG == "networkError"
              ? playerResponse.statusMSG.tr
              : playerResponse.statusMSG,
          size: SanckBarSize.BIG,
          duration: const Duration(seconds: 3),
          top: !GetPlatform.isDesktop,
        ));
      }
      printINFO("Download stopped: no usable audio stream for ${song.id}");
      return;
    }

    // Pick by actual codec, not by a hard-coded itag. NewPipe and
    // youtube_explode_dart can expose different itag sets over time.
    final wantedCodec = requestedFormat == "opus" ? Codec.opus : Codec.mp4a;
    final available = playerResponse.audioFormats!;
    final matching = available.where((a) => a.audioCodec == wantedCodec).toList()
      ..sort((a, b) => a.bitrate.compareTo(b.bitrate));
    var requiredAudioStream = matching.isNotEmpty
        ? matching.last
        : (available.toList()..sort((a, b) => a.bitrate.compareTo(b.bitrate))).last;

    final dirPath = settings.downloadLocationPath.string;
    final directory = Directory(dirPath);
    await directory.create(recursive: true);

    final extension = requiredAudioStream.audioCodec == Codec.mp4a ? "m4a" : "opus";
    final invalidChar = RegExp(r'[\\/:"<>*?\[\]|%!¡]');
    final rawTitle = "${song.title.trim()} (${song.artist?.trim() ?? "Unknown artist"})"
        .replaceAll(invalidChar, "")
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    final safeTitle = rawTitle.isEmpty ? song.id : rawTitle;
    final file = File("$dirPath/$safeTitle.$extension");
    final tempFile = File("${file.path}.part");

    try {
      songDownloadingProgress.value = 0;
      // Chunked Range requests are used on purpose (see _downloadChunked);
      // an un-ranged GET gets throttled by googlevideo.
      Future<void> downloadStream(String url) async {
        // Reset the partial file before each attempt so a failed HTTP response
        // can never be mistaken for a completed song.
        if (await tempFile.exists()) await tempFile.delete();
        await _downloadChunked(
          url,
          tempFile,
          onProgress: (received, total) {
            songDownloadingProgress.value =
                ((received / total) * 100).clamp(0, 100).toInt();
          },
        );
      }

      try {
        await downloadStream(requiredAudioStream.url);
      } catch (firstError) {
        // Extraction can succeed while the returned URL is expired or blocked.
        // Re-resolve through youtube_explode_dart and try one alternate stream.
        if (await tempFile.exists()) await tempFile.delete();
        final fallbackResponse = await StreamProvider.fetchFallback(song.id);
        final fallbackFormats = fallbackResponse.audioFormats;
        if (!fallbackResponse.playable || fallbackFormats == null || fallbackFormats.isEmpty) {
          rethrow;
        }
        final fallbackMatching = fallbackFormats
            .where((a) => a.audioCodec == wantedCodec)
            .toList()
          ..sort((a, b) => a.bitrate.compareTo(b.bitrate));
        final fallbackStream = fallbackMatching.isNotEmpty
            ? fallbackMatching.last
            : (fallbackFormats.toList()..sort((a, b) => a.bitrate.compareTo(b.bitrate))).last;
        try {
          await downloadStream(fallbackStream.url);
          // Continue metadata and library updates using the stream that really worked.
          requiredAudioStream = fallbackStream;
        } catch (_) {
          rethrow;
        }
      }

      if (!await tempFile.exists() || await tempFile.length() < 512) {
        throw const FileSystemException("The downloaded audio file is empty or incomplete");
      }

      // Replace an existing same-title file only after the new file is complete.
      if (await file.exists()) await file.delete();
      await tempFile.rename(file.path);
      final filePath = file.path;

      String? year;
      try {
        year = song.extras?['year']?.toString();
      } catch (_) {}

      // Save thumbnail as a best-effort operation. A thumbnail failure must
      // never invalidate an otherwise successful audio download.
      try {
        final artUri = song.artUri;
        if (artUri != null) {
          final thumbnailDir = Directory("${settings.supportDirPath}/thumbnails");
          await thumbnailDir.create(recursive: true);
          await _dio.downloadUri(artUri, "${thumbnailDir.path}/${song.id}.png");
        }
      } catch (_) {}

      song.extras?['url'] = filePath;
      final songJson = MediaItemBuilder.toJson(song);
      final streamInfoJson = requiredAudioStream.toJson();
      streamInfoJson['url'] = filePath;
      songJson["streamInfo"] = [true, streamInfoJson];
      await Hive.box("SongDownloads").put(song.id, songJson);

      final library = Get.find<LibrarySongsController>().librarySongsList;
      if (!library.any((item) => item.id == song.id)) library.add(song);
      songDownloadingProgress.value = 100;
      printINFO("Downloaded successfully: $filePath");

      // Metadata tagging is optional; don't fail the download if artwork or
      // a tag writer is unavailable on a device.
      try {
        final trackDetails = (song.extras?['trackDetails'])?.split("/");
        final imageUrl = song.artUri?.toString();
        final pictures = <Picture>[];
        if (imageUrl != null && imageUrl.isNotEmpty) {
          final thumbFile = File("${settings.supportDirPath}/thumbnails/${song.id}.png");
          final bytes = await thumbFile.exists()
              ? await thumbFile.readAsBytes()
              : (await NetworkAssetBundle(Uri.parse(imageUrl)).load(imageUrl))
                  .buffer
                  .asUint8List();
          pictures.add(Picture(
            bytes: bytes,
            mimeType: MimeType.png,
            pictureType: PictureType.coverFront,
          ));
        }
        final tag = Tag(
          title: song.title,
          trackArtist: song.artist,
          album: song.album,
          year: int.tryParse(year ?? ""),
          trackNumber: int.tryParse(trackDetails != null && trackDetails.isNotEmpty ? trackDetails[0] : ""),
          trackTotal: int.tryParse(trackDetails != null && trackDetails.length > 1 ? trackDetails[1] : ""),
          albumArtist: song.artist,
          genre: song.genre,
          pictures: pictures,
        );
        await AudioTags.write(filePath, tag);
      } catch (error) {
        printERROR("Could not write audio tags: $error");
      }
    } catch (error, stackTrace) {
      try {
        if (await tempFile.exists()) await tempFile.delete();
      } catch (_) {}
      printERROR("Download failed for ${song.id}: $error\n$stackTrace");
      final context = Get.context;
      if (context != null) {
        ScaffoldMessenger.of(context).showSnackBar(snackbar(
          context,
          "Downloading failed due to network/stream error. Please try again.",
          size: SanckBarSize.BIG,
          duration: const Duration(seconds: 3),
          top: !GetPlatform.isDesktop,
        ));
      }
    }
  }

}
