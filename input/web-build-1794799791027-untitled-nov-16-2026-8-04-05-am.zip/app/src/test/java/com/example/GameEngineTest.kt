package com.example

import com.example.game.AlienForm
import com.example.game.GameEngine
import com.example.game.GameMode
import com.example.game.GameScreenState
import com.example.game.InteractivePropType
import com.example.game.RunSummary
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GameEngineTest {

    @Test
    fun `all 8 alien transformations apply distinct physics and clear dash states`() {
        val engine = GameEngine()
        engine.startNewRun(GameMode.MISSION_1)

        val formsToCycle = AlienForm.entries.filter { it != AlienForm.BEN } + AlienForm.BEN
        val speeds = mutableSetOf<Float>()
        for (form in formsToCycle) {
            engine.player.dashTimer = 10
            engine.player.rollTimer = 10
            engine.transformTo(form, silent = false)
            assertEquals(form, engine.player.form)
            assertEquals(form.speed, engine.player.speed)
            assertEquals(form.canFly, engine.player.canFly)
            assertEquals(0, engine.player.dashTimer)
            assertEquals(0, engine.player.rollTimer)
            speeds.add(form.speed)
        }
        assertTrue(speeds.size >= 7)
    }

    @Test
    fun `pause and restart clear stale input and reset state`() {
        val engine = GameEngine()
        engine.startNewRun(GameMode.MISSION_1)
        engine.input.keyRight = true
        engine.input.jumpHeld = true
        engine.input.moveX = 0.8f
        engine.pause()

        assertEquals(GameScreenState.PAUSED, engine.screenState)
        assertFalse(engine.input.keyRight)
        assertFalse(engine.input.jumpHeld)
        assertEquals(0f, engine.input.moveX)

        engine.resume()
        assertEquals(GameScreenState.PLAYING, engine.screenState)

        // Advance and restart
        engine.player.x = 500f
        engine.startNewRun(GameMode.MISSION_1)
        assertEquals(80f, engine.player.x)
        assertEquals(0, engine.score)
        assertEquals(3, engine.lives)
        assertEquals(100f, engine.player.hp)
    }

    @Test
    fun `checkpoint activation and pit fall restore player cleanly`() {
        val engine = GameEngine()
        engine.startNewRun(GameMode.MISSION_1)
        val cp = engine.checkpoints.first()
        engine.player.x = cp.x + 2f
        engine.player.y = cp.y + 4f
        engine.stepFrame()
        assertTrue(cp.active)
        assertEquals(cp.x, engine.player.checkpointX)

        // Simulate falling in pit
        engine.player.invulnTimer = 0
        engine.player.y = GameEngine.LOGICAL_HEIGHT + 120f
        engine.stepFrame()
        assertEquals(cp.x, engine.player.x)
        assertEquals(66f, engine.player.hp)
        assertEquals(3, engine.lives)
    }

    @Test
    fun `mission 1 boss defeat triggers victory with stars and medals`() {
        var finishedSummary: RunSummary? = null
        val engine = GameEngine(onRunFinished = { finishedSummary = it })
        engine.startNewRun(GameMode.MISSION_1)

        // Collect all shards
        engine.props.filter { it.type == InteractivePropType.SHARD }.forEach { it.activated = true }

        // Enter boss arena & defeat boss
        val boss = engine.boss!!
        engine.player.x = boss.arenaStartX + 60f
        engine.stepFrame()
        boss.hp = 1f
        engine.transformTo(AlienForm.FOURARMS, silent = true)
        engine.player.x = boss.x - 20f
        engine.player.y = boss.y + 20f
        engine.player.facing = 1
        engine.triggerPunch()
        repeat(8) { engine.stepFrame() }

        assertEquals(GameScreenState.VICTORY, engine.screenState)
        val summary = finishedSummary
        assertTrue(summary != null && summary.victory)
        assertEquals(3, summary!!.stars)
        assertTrue(summary.noDamageMedal)
        assertTrue(summary.allShardsMedal)
    }

    @Test
    fun `game over occurs after losing all 3 lives`() {
        var finishedSummary: RunSummary? = null
        val engine = GameEngine(onRunFinished = { finishedSummary = it })
        engine.startNewRun(GameMode.ENDLESS)

        repeat(3) {
            engine.player.invulnTimer = 0
            engine.damagePlayer(120f, 0f)
        }
        assertEquals(GameScreenState.GAME_OVER, engine.screenState)
        assertFalse(finishedSummary!!.victory)
        assertTrue(finishedSummary!!.stars in 1..3)
    }

    @Test
    fun `reduced motion suppresses flash and scales screen shake`() {
        val engine = GameEngine()
        engine.reducedMotion = true
        engine.triggerFlash(0xFFFFFFFF.toInt(), 0.5f)
        assertEquals(0f, engine.screenFlash)

        engine.addScreenShake(8f, 10)
        assertEquals(2f, engine.shakeIntensity)
    }

    @Test
    fun `radial dial slow motion and selection update`() {
        val engine = GameEngine()
        engine.startNewRun(GameMode.MISSION_1)
        engine.openRadialDial(400f, 270f, byTouch = true)
        assertTrue(engine.radialDial.open)

        engine.updateDialHover(500f, 270f) // East = index 2 (XLR8)
        assertEquals(2, engine.radialDial.selectedIdx)
        engine.confirmDialSelection(commit = true)
        assertFalse(engine.radialDial.open)
        assertEquals(AlienForm.XLR8, engine.player.form)
    }

    @Test
    fun `hud snapshot scales cleanly across narrow and wide viewports`() {
        val engine = GameEngine()
        engine.startNewRun(GameMode.MISSION_2)
        engine.viewWidth = 640f
        val narrowHud = engine.snapshotHud()
        assertNotEquals("", narrowHud.objectiveText)
        assertEquals(GameMode.MISSION_2, narrowHud.mode)

        engine.viewWidth = 1120f
        val wideHud = engine.snapshotHud()
        assertEquals(narrowHud.objectiveText, wideHud.objectiveText)
    }
}
