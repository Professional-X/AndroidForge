package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "omniverse_rush_prefs"
)

data class UserPreferences(
    val musicVolume: Float = 0.55f,
    val sfxVolume: Float = 0.85f,
    val isMuted: Boolean = false,
    val reducedMotion: Boolean = false,
    val selectedInkPaletteId: String = "CLASSIC_INK"
)

class GameRepository(
    private val context: Context,
    private val dao: GameStatsDao
) {
    private object Keys {
        val MUSIC_VOLUME = floatPreferencesKey("music_volume")
        val SFX_VOLUME = floatPreferencesKey("sfx_volume")
        val IS_MUTED = booleanPreferencesKey("is_muted")
        val REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        val INK_PALETTE = stringPreferencesKey("selected_ink_palette")
    }

    val preferences: Flow<UserPreferences> = context.settingsDataStore.data.map { prefs ->
        UserPreferences(
            musicVolume = prefs[Keys.MUSIC_VOLUME] ?: 0.55f,
            sfxVolume = prefs[Keys.SFX_VOLUME] ?: 0.85f,
            isMuted = prefs[Keys.IS_MUTED] ?: false,
            reducedMotion = prefs[Keys.REDUCED_MOTION] ?: false,
            selectedInkPaletteId = prefs[Keys.INK_PALETTE] ?: "CLASSIC_INK"
        )
    }

    val topRuns: Flow<List<RunRecordEntity>> = dao.getTopRuns()
    val recentRuns: Flow<List<RunRecordEntity>> = dao.getRecentRuns()
    val bestEndlessScore: Flow<Int> = dao.getBestEndlessScore()
    val bestEndlessDistance: Flow<Int> = dao.getBestEndlessDistance()
    val missionProgress: Flow<List<MissionProgressEntity>> = dao.getAllMissionProgress()

    suspend fun setMusicVolume(volume: Float) {
        context.settingsDataStore.edit { it[Keys.MUSIC_VOLUME] = volume.coerceIn(0f, 1f) }
    }

    suspend fun setSfxVolume(volume: Float) {
        context.settingsDataStore.edit { it[Keys.SFX_VOLUME] = volume.coerceIn(0f, 1f) }
    }

    suspend fun setMuted(muted: Boolean) {
        context.settingsDataStore.edit { it[Keys.IS_MUTED] = muted }
    }

    suspend fun setReducedMotion(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.REDUCED_MOTION] = enabled }
    }

    suspend fun setInkPalette(paletteId: String) {
        context.settingsDataStore.edit { it[Keys.INK_PALETTE] = paletteId }
    }

    suspend fun recordRunAndMission(
        modeId: String,
        score: Int,
        distanceMeters: Int,
        bossesDefeated: Int,
        starsEarned: Int,
        victory: Boolean,
        favoriteForm: String,
        durationSec: Int,
        noDamageMedal: Boolean,
        allShardsMedal: Boolean,
        speedMedal: Boolean
    ) {
        dao.insertRun(
            RunRecordEntity(
                modeId = modeId,
                score = score,
                distanceMeters = distanceMeters,
                bossesDefeated = bossesDefeated,
                starsEarned = starsEarned,
                victory = victory,
                favoriteForm = favoriteForm,
                durationSec = durationSec
            )
        )

        if (modeId.startsWith("MISSION_") && victory) {
            val prev = dao.getMissionProgressOnce(modeId)
            val bestTime = when {
                prev == null || prev.bestTimeSec == 0 -> durationSec
                else -> minOf(prev.bestTimeSec, durationSec)
            }
            dao.upsertMissionProgress(
                MissionProgressEntity(
                    missionId = modeId,
                    completed = true,
                    bestStars = maxOf(prev?.bestStars ?: 0, starsEarned),
                    bestScore = maxOf(prev?.bestScore ?: 0, score),
                    bestTimeSec = bestTime,
                    noDamageMedal = (prev?.noDamageMedal == true) || noDamageMedal,
                    allShardsMedal = (prev?.allShardsMedal == true) || allShardsMedal,
                    speedMedal = (prev?.speedMedal == true) || speedMedal
                )
            )
        }
    }
}
