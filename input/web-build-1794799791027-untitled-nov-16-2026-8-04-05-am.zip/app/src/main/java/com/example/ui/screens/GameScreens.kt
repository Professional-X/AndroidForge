package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.MissionProgressEntity
import com.example.data.local.RunRecordEntity
import com.example.data.local.UserPreferences
import com.example.game.AlienForm
import com.example.game.GameMode
import com.example.game.INK_PALETTES
import com.example.game.MISSIONS
import com.example.game.MissionMeta
import com.example.game.NOTEBOOK_STICKERS
import com.example.game.RunSummary
import com.example.ui.theme.AlertBg
import com.example.ui.theme.BluePen
import com.example.ui.theme.GoldStar
import com.example.ui.theme.GraphiteGray
import com.example.ui.theme.HighlightYellow
import com.example.ui.theme.InkBlack
import com.example.ui.theme.OmnitrixBright
import com.example.ui.theme.OmnitrixDark
import com.example.ui.theme.OmnitrixGreen
import com.example.ui.theme.PaperCream
import com.example.ui.theme.PaperDark
import com.example.ui.theme.RedPen
import com.example.ui.theme.SkyPill
import com.example.ui.theme.TapeYellow
import com.example.viewmodel.CosmeticUnlocks

@Composable
fun MissionBoardOverlay(
    missionProgress: List<MissionProgressEntity>,
    topRuns: List<RunRecordEntity>,
    bestEndlessScore: Int,
    bestEndlessDistance: Int,
    unlocks: CosmeticUnlocks,
    preferences: UserPreferences,
    onStartMode: (GameMode) -> Unit,
    onSelectPalette: (String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val progressById = remember(missionProgress) { missionProgress.associateBy { it.missionId } }
    val insets = WindowInsets.safeDrawing.asPaddingValues()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(InkBlack.copy(alpha = 0.45f))
            .padding(insets)
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = PaperCream,
            border = BorderStroke(3.dp, InkBlack),
            shadowElevation = 8.dp,
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 780.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "OMNIVERSE RUSH",
                            style = MaterialTheme.typography.displaySmall,
                            color = InkBlack
                        )
                        Text(
                            text = "SKETCHBOOK EDITION • 8 HERO FORMS",
                            style = MaterialTheme.typography.labelMedium,
                            color = BluePen
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onStartMode(GameMode.ENDLESS) },
                            colors = ButtonDefaults.buttonColors(containerColor = HighlightYellow, contentColor = InkBlack),
                            border = BorderStroke(2.5.dp, InkBlack),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("btn_endless_rush")
                        ) {
                            Text("ENDLESS RUSH", style = MaterialTheme.typography.titleMedium)
                        }

                        OutlinedButton(
                            onClick = { onStartMode(GameMode.PRACTICE) },
                            border = BorderStroke(2.dp, InkBlack),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("btn_practice_dojo")
                        ) {
                            Text("PRACTICE DOJO", style = MaterialTheme.typography.labelMedium, color = InkBlack)
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))

                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = PaperDark,
                    contentColor = InkBlack,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .border(2.dp, InkBlack, RoundedCornerShape(8.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("MISSIONS (4)", style = MaterialTheme.typography.labelMedium) },
                        modifier = Modifier.testTag("tab_missions")
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("STICKERS & INK", style = MaterialTheme.typography.labelMedium) },
                        modifier = Modifier.testTag("tab_locker")
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("TOP RUNS", style = MaterialTheme.typography.labelMedium) },
                        modifier = Modifier.testTag("tab_leaderboard")
                    )
                }

                Spacer(Modifier.height(10.dp))

                when (selectedTab) {
                    0 -> {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(MISSIONS, key = { it.mode.id }) { mission ->
                                val prog = progressById[mission.mode.id]
                                MissionCard(
                                    mission = mission,
                                    progress = prog,
                                    onPlay = { onStartMode(mission.mode) }
                                )
                            }
                            item {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = SkyPill,
                                    border = BorderStroke(2.dp, InkBlack),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("ENDLESS RUSH PERSONAL BEST", style = MaterialTheme.typography.titleMedium, color = InkBlack)
                                            Text("Best Score: $bestEndlessScore  •  Max Distance: ${bestEndlessDistance}m", style = MaterialTheme.typography.bodyMedium, color = GraphiteGray)
                                        }
                                        Button(
                                            onClick = { onStartMode(GameMode.ENDLESS) },
                                            colors = ButtonDefaults.buttonColors(containerColor = OmnitrixGreen, contentColor = OmnitrixDark),
                                            border = BorderStroke(2.dp, InkBlack),
                                            modifier = Modifier.height(48.dp)
                                        ) {
                                            Text("RUN", style = MaterialTheme.typography.titleMedium)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("INK PALETTES (COSMETIC)", style = MaterialTheme.typography.titleMedium, color = InkBlack)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(INK_PALETTES, key = { it.id }) { pal ->
                                    val unlocked = unlocks.unlockedPaletteIds.contains(pal.id)
                                    val selected = preferences.selectedInkPaletteId == pal.id
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (selected) HighlightYellow else Color.White,
                                        border = BorderStroke(if (selected) 3.dp else 2.dp, InkBlack),
                                        modifier = Modifier
                                            .width(175.dp)
                                            .clickable(enabled = unlocked) { onSelectPalette(pal.id) }
                                            .testTag("palette_${pal.id}")
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Box(Modifier.size(18.dp).clip(CircleShape).background(Color(pal.inkHex)))
                                                Box(Modifier.size(18.dp).clip(CircleShape).background(Color(pal.highlightHex)))
                                            }
                                            Text(pal.name, style = MaterialTheme.typography.labelMedium, color = InkBlack)
                                            Text(
                                                text = if (unlocked) (if (selected) "EQUIPPED" else "TAP TO EQUIP") else pal.unlockHint,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (unlocked) OmnitrixDark else GraphiteGray
                                            )
                                        }
                                    }
                                }
                            }

                            HorizontalDivider(color = InkBlack.copy(alpha = 0.2f))
                            Text("NOTEBOOK STICKERS (${unlocks.unlockedStickerIds.size}/${NOTEBOOK_STICKERS.size})", style = MaterialTheme.typography.titleMedium, color = InkBlack)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(NOTEBOOK_STICKERS, key = { it.id }) { st ->
                                    val unlocked = unlocks.unlockedStickerIds.contains(st.id)
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (unlocked) TapeYellow else PaperDark,
                                        border = BorderStroke(2.dp, InkBlack),
                                        modifier = Modifier.width(155.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(10.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(if (unlocked) st.emoji else "🔒", style = MaterialTheme.typography.headlineSmall)
                                            Text(st.title, style = MaterialTheme.typography.labelMedium, color = InkBlack, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(st.requirement, style = MaterialTheme.typography.labelSmall, color = GraphiteGray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        if (topRuns.isEmpty()) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Complete a Mission or Endless Rush run to record your scores!", style = MaterialTheme.typography.bodyMedium, color = GraphiteGray)
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(topRuns, key = { it.id }) { run ->
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color.White,
                                        border = BorderStroke(2.dp, InkBlack),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text("${run.modeId} • ${run.favoriteForm}", style = MaterialTheme.typography.labelMedium, color = InkBlack)
                                                Text("${run.distanceMeters}m • ${run.bossesDefeated} Bosses • ${run.durationSec}s", style = MaterialTheme.typography.labelSmall, color = GraphiteGray)
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Text("${run.score}", style = MaterialTheme.typography.titleMedium, color = BluePen)
                                                Row {
                                                    repeat(run.starsEarned) {
                                                        Icon(Icons.Default.Star, contentDescription = "Star", tint = GoldStar, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MissionCard(
    mission: MissionMeta,
    progress: MissionProgressEntity?,
    onPlay: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White,
        border = BorderStroke(2.5.dp, InkBlack),
        shadowElevation = 3.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("mission_card_${mission.number}")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        color = Color(mission.trimHex).copy(alpha = 0.25f),
                        border = BorderStroke(1.5.dp, InkBlack),
                        shape = RoundedCornerShape(5.dp)
                    ) {
                        Text(
                            text = "MISSION ${mission.number}",
                            style = MaterialTheme.typography.labelSmall,
                            color = InkBlack,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text(mission.title, style = MaterialTheme.typography.titleMedium, color = InkBlack)
                    if (progress != null) {
                        Row {
                            repeat(3) { idx ->
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = "Star",
                                    tint = if (idx < progress.bestStars) GoldStar else Color(0xFFD6D3D1),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(3.dp))
                Text(mission.objectiveSummary, style = MaterialTheme.typography.bodyMedium, color = GraphiteGray)
                Spacer(Modifier.height(3.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Spotlight: ${mission.spotlightForms}", style = MaterialTheme.typography.labelSmall, color = BluePen)
                    if (progress?.noDamageMedal == true) Text("🛡️ No-Dmg", style = MaterialTheme.typography.labelSmall, color = OmnitrixDark)
                    if (progress?.speedMedal == true) Text("⚡ Speed", style = MaterialTheme.typography.labelSmall, color = OmnitrixDark)
                    if (progress?.allShardsMedal == true) Text("💎 All Shards", style = MaterialTheme.typography.labelSmall, color = OmnitrixDark)
                }
            }

            Button(
                onClick = onPlay,
                colors = ButtonDefaults.buttonColors(containerColor = OmnitrixGreen, contentColor = OmnitrixDark),
                border = BorderStroke(2.5.dp, InkBlack),
                modifier = Modifier
                    .height(48.dp)
                    .testTag("btn_play_mission_${mission.number}")
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text(if (progress?.completed == true) "REPLAY" else "PLAY", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@Composable
fun PauseOverlay(
    preferences: UserPreferences,
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onReturnToMenu: () -> Unit,
    onMusicVolumeChange: (Float) -> Unit,
    onSfxVolumeChange: (Float) -> Unit,
    onToggleMute: () -> Unit,
    onToggleReducedMotion: () -> Unit
) {
    var tabIdx by remember { mutableIntStateOf(0) }
    var confirmRestart by remember { mutableStateOf(false) }
    val insets = WindowInsets.safeDrawing.asPaddingValues()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(InkBlack.copy(alpha = 0.55f))
            .padding(insets)
            .padding(14.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = PaperCream,
            border = BorderStroke(3.dp, InkBlack),
            shadowElevation = 8.dp,
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("SKETCHBOOK PAUSED", style = MaterialTheme.typography.headlineSmall, color = InkBlack)
                    IconButton(onClick = onResume, modifier = Modifier.size(48.dp).testTag("btn_pause_close")) {
                        Icon(Icons.Default.Close, contentDescription = "Resume game", tint = InkBlack)
                    }
                }

                TabRow(
                    selectedTabIndex = tabIdx,
                    containerColor = PaperDark,
                    contentColor = InkBlack,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).border(2.dp, InkBlack, RoundedCornerShape(8.dp))
                ) {
                    Tab(selected = tabIdx == 0, onClick = { tabIdx = 0 }, text = { Text("AUDIO & GAME", style = MaterialTheme.typography.labelMedium) })
                    Tab(selected = tabIdx == 1, onClick = { tabIdx = 1 }, text = { Text("CONTROLS & FORMS", style = MaterialTheme.typography.labelMedium) })
                }

                Spacer(Modifier.height(10.dp))

                if (tabIdx == 0) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Music Volume: ${(preferences.musicVolume * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = InkBlack)
                        Slider(
                            value = preferences.musicVolume,
                            onValueChange = onMusicVolumeChange,
                            colors = SliderDefaults.colors(thumbColor = OmnitrixGreen, activeTrackColor = OmnitrixGreen),
                            modifier = Modifier.testTag("slider_music_volume")
                        )

                        Text("SFX Volume: ${(preferences.sfxVolume * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = InkBlack)
                        Slider(
                            value = preferences.sfxVolume,
                            onValueChange = onSfxVolumeChange,
                            colors = SliderDefaults.colors(thumbColor = BluePen, activeTrackColor = BluePen),
                            modifier = Modifier.testTag("slider_sfx_volume")
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Mute All Audio", style = MaterialTheme.typography.bodyMedium, color = InkBlack)
                            Switch(checked = preferences.isMuted, onCheckedChange = { onToggleMute() }, modifier = Modifier.testTag("switch_mute"))
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Reduced Motion (Calmer Shake & Particles)", style = MaterialTheme.typography.bodyMedium, color = InkBlack)
                            Switch(checked = preferences.reducedMotion, onCheckedChange = { onToggleReducedMotion() }, modifier = Modifier.testTag("switch_reduced_motion"))
                        }

                        Spacer(Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = onResume,
                                colors = ButtonDefaults.buttonColors(containerColor = OmnitrixGreen, contentColor = OmnitrixDark),
                                border = BorderStroke(2.5.dp, InkBlack),
                                modifier = Modifier.weight(1f).height(48.dp).testTag("btn_resume")
                            ) {
                                Text("RESUME", style = MaterialTheme.typography.titleMedium)
                            }
                            if (!confirmRestart) {
                                Button(
                                    onClick = { confirmRestart = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = AlertBg, contentColor = RedPen),
                                    border = BorderStroke(2.dp, InkBlack),
                                    modifier = Modifier.weight(1f).height(48.dp).testTag("btn_restart_prompt")
                                ) {
                                    Text("RESTART", style = MaterialTheme.typography.titleMedium)
                                }
                            } else {
                                Button(
                                    onClick = onRestart,
                                    colors = ButtonDefaults.buttonColors(containerColor = RedPen, contentColor = Color.White),
                                    border = BorderStroke(2.dp, InkBlack),
                                    modifier = Modifier.weight(1f).height(48.dp).testTag("btn_restart_confirm")
                                ) {
                                    Text("CONFIRM?", style = MaterialTheme.typography.titleMedium)
                                }
                            }
                            OutlinedButton(
                                onClick = onReturnToMenu,
                                border = BorderStroke(2.dp, InkBlack),
                                modifier = Modifier.weight(1f).height(48.dp).testTag("btn_return_menu")
                            ) {
                                Text("MENU", style = MaterialTheme.typography.titleMedium, color = InkBlack)
                            }
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier.height(230.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("TOUCH ZONES (ZERO AMBIGUITY)", style = MaterialTheme.typography.titleMedium, color = BluePen)
                        Text("• Left Side: Floating joystick to run & steer flight.", style = MaterialTheme.typography.bodyMedium, color = InkBlack)
                        Text("• Upper-Right / Swipe ↑: Jump, Double-Jump, or Fly.", style = MaterialTheme.typography.bodyMedium, color = InkBlack)
                        Text("• Lower-Right (Left Half) / Swipe ↓: 3-Hit Melee Combo or Air Slam.", style = MaterialTheme.typography.bodyMedium, color = InkBlack)
                        Text("• Lower-Right Edge: Signature Alien Special Attack.", style = MaterialTheme.typography.bodyMedium, color = InkBlack)
                        Text("• Top-Left Watch (or Hold Right 0.25s): Slow-Mo 8-Alien Dial.", style = MaterialTheme.typography.bodyMedium, color = InkBlack)
                        HorizontalDivider(color = InkBlack.copy(alpha = 0.2f))
                        Text("KEYBOARD", style = MaterialTheme.typography.titleMedium, color = BluePen)
                        Text("WASD/Arrows Move • Space Jump • K/Z Melee • F/X/J Special • Q/E or 1-8 Transform", style = MaterialTheme.typography.bodyMedium, color = InkBlack)
                        HorizontalDivider(color = InkBlack.copy(alpha = 0.2f))
                        AlienForm.entries.forEach { form ->
                            Text("${form.badgeIcon} ${form.displayName}: ${form.roleLabel} (${form.specialName})", style = MaterialTheme.typography.labelMedium, color = form.primaryColor)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RunSummaryOverlay(
    summary: RunSummary,
    onReplay: () -> Unit,
    onNextMission: (() -> Unit)?,
    onReturnToMenu: () -> Unit
) {
    val insets = WindowInsets.safeDrawing.asPaddingValues()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(InkBlack.copy(alpha = 0.55f))
            .padding(insets)
            .padding(14.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = PaperCream,
            border = BorderStroke(3.dp, InkBlack),
            shadowElevation = 8.dp,
            modifier = Modifier.widthIn(max = 500.dp).fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = if (summary.victory) "MISSION COMPLETE!" else "OMNITRIX TIMED OUT",
                    style = MaterialTheme.typography.headlineSmall,
                    color = if (summary.victory) OmnitrixDark else RedPen
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    repeat(3) { idx ->
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Earned Star",
                            tint = if (idx < summary.stars) GoldStar else Color(0xFFD6D3D1),
                            modifier = Modifier.size(34.dp)
                        )
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryStatPill("SCORE", summary.score.toString(), Modifier.weight(1f))
                    SummaryStatPill("DIST", "${summary.distanceMeters}m", Modifier.weight(1f))
                    SummaryStatPill("TIME", "${summary.durationSec}s", Modifier.weight(1f))
                    SummaryStatPill("FORM", summary.favoriteForm.shortName, Modifier.weight(1f))
                }

                if (summary.noDamageMedal || summary.allShardsMedal || summary.speedMedal) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (summary.noDamageMedal) MedalChip("🛡️ NO-DAMAGE")
                        if (summary.allShardsMedal) MedalChip("💎 ALL SHARDS")
                        if (summary.speedMedal) MedalChip("⚡ SPEEDRUN")
                    }
                }

                if (summary.newStickerUnlocked != null || summary.newPaletteUnlocked != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = HighlightYellow,
                        border = BorderStroke(2.dp, InkBlack),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.EmojiEvents, contentDescription = "Unlock", tint = InkBlack)
                            val rewardMsg = listOfNotNull(
                                summary.newStickerUnlocked?.let { "Sticker: ${it.emoji} ${it.title}" },
                                summary.newPaletteUnlocked?.let { "Ink Palette: ${it.name}" }
                            ).joinToString(" • ")
                            Text("UNLOCKED! $rewardMsg", style = MaterialTheme.typography.labelMedium, color = InkBlack)
                        }
                    }
                }

                Spacer(Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (summary.victory && onNextMission != null) {
                        Button(
                            onClick = onNextMission,
                            colors = ButtonDefaults.buttonColors(containerColor = OmnitrixGreen, contentColor = OmnitrixDark),
                            border = BorderStroke(2.5.dp, InkBlack),
                            modifier = Modifier.weight(1f).height(48.dp).testTag("btn_next_mission")
                        ) {
                            Text("NEXT", style = MaterialTheme.typography.titleMedium)
                        }
                    }
                    Button(
                        onClick = onReplay,
                        colors = ButtonDefaults.buttonColors(containerColor = HighlightYellow, contentColor = InkBlack),
                        border = BorderStroke(2.5.dp, InkBlack),
                        modifier = Modifier.weight(1f).height(48.dp).testTag("btn_retry")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("REPLAY", style = MaterialTheme.typography.titleMedium)
                    }
                    OutlinedButton(
                        onClick = onReturnToMenu,
                        border = BorderStroke(2.dp, InkBlack),
                        modifier = Modifier.weight(1f).height(48.dp).testTag("btn_summary_menu")
                    ) {
                        Text("BOARD", style = MaterialTheme.typography.titleMedium, color = InkBlack)
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryStatPill(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color.White,
        border = BorderStroke(2.dp, InkBlack),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = GraphiteGray)
            Text(value, style = MaterialTheme.typography.titleMedium, color = InkBlack, maxLines = 1)
        }
    }
}

@Composable
private fun MedalChip(text: String) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = TapeYellow,
        border = BorderStroke(1.5.dp, InkBlack)
    ) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = InkBlack, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
    }
}
