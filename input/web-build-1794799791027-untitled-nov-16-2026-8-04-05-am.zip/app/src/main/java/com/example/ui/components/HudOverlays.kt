package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameMode
import com.example.game.HudUiState
import com.example.ui.theme.AlertBg
import com.example.ui.theme.BluePen
import com.example.ui.theme.GoldStar
import com.example.ui.theme.GraphiteGray
import com.example.ui.theme.HighlightYellow
import com.example.ui.theme.InkBlack
import com.example.ui.theme.OmnitrixBright
import com.example.ui.theme.OmnitrixDark
import com.example.ui.theme.OmnitrixGreen
import com.example.ui.theme.PaperCream
import com.example.ui.theme.RedPen
import com.example.ui.theme.SkyPill
import com.example.ui.theme.TapeYellow

@Composable
fun HudOverlays(
    hud: HudUiState,
    isMuted: Boolean,
    onWatchClick: () -> Unit,
    onMuteClick: () -> Unit,
    onPauseClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val insets = WindowInsets.safeDrawing.asPaddingValues()

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(insets)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        // TOP BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            // Left Cluster: Watch Button + Stats Card
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Dedicated Omnitrix Watch Button (>= 48dp touch target)
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .testTag("hud_watch_button")
                        .shadow(3.dp, CircleShape)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(OmnitrixBright, hud.form.primaryColor, OmnitrixDark)
                            )
                        )
                        .border(3.dp, InkBlack, CircleShape)
                        .clickable(onClick = onWatchClick),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = hud.form.badgeIcon,
                        style = MaterialTheme.typography.titleMedium,
                        color = OmnitrixDark
                    )
                }

                // Hero Stats Card
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = PaperCream.copy(alpha = 0.94f),
                    border = BorderStroke(2.5.dp, InkBlack),
                    shadowElevation = 3.dp
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = hud.form.displayName,
                                style = MaterialTheme.typography.titleMedium,
                                color = hud.form.primaryColor,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Surface(
                                shape = RoundedCornerShape(5.dp),
                                color = SkyPill,
                                border = BorderStroke(1.5.dp, InkBlack)
                            ) {
                                Text(
                                    text = hud.objectiveText,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = InkBlack,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier
                                        .widthIn(max = 220.dp)
                                        .padding(horizontal = 6.dp, vertical = 1.dp)
                                )
                            }
                            if (hud.combo > 1) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = HighlightYellow,
                                    border = BorderStroke(1.5.dp, InkBlack)
                                ) {
                                    Text(
                                        text = "${hud.combo}x",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = InkBlack,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // HP Bar (turns pulsing warning when low)
                            Box(
                                modifier = Modifier
                                    .width(104.dp)
                                    .height(11.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (hud.isLowHp) AlertBg else Color(0xFFE7E5E4))
                                    .border(2.dp, if (hud.isLowHp) RedPen else InkBlack, RoundedCornerShape(4.dp))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(hud.hpFraction)
                                        .background(if (hud.isLowHp) RedPen else OmnitrixGreen)
                                )
                            }

                            // Energy Bar
                            Box(
                                modifier = Modifier
                                    .width(64.dp)
                                    .height(9.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFFE7E5E4))
                                    .border(1.8.dp, InkBlack, RoundedCornerShape(4.dp))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(hud.energyFraction)
                                        .background(Color(0xFF06B6D4))
                                )
                            }

                            // Special Cooldown Badge
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (hud.specialReadyFraction >= 0.99f) OmnitrixBright.copy(alpha = 0.35f) else Color(0xFFE7E5E4),
                                border = BorderStroke(1.4.dp, InkBlack)
                            ) {
                                Text(
                                    text = if (hud.specialReadyFraction >= 0.99f) "SPCL READY" else "RECHARGING",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                    color = InkBlack,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Right Cluster: Distance, Score, Hearts, Mute & Pause (>= 48dp touch targets)
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = PaperCream.copy(alpha = 0.94f),
                border = BorderStroke(2.5.dp, InkBlack),
                shadowElevation = 3.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text("DIST", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = GraphiteGray)
                        Text("${hud.distanceMeters}m", style = MaterialTheme.typography.titleMedium, color = BluePen)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("SCORE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = GraphiteGray)
                        Text(hud.score.toString().padStart(5, '0'), style = MaterialTheme.typography.titleMedium, color = InkBlack)
                    }
                    if (hud.mode != GameMode.PRACTICE) {
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            repeat(3) { idx ->
                                Icon(
                                    imageVector = Icons.Default.Favorite,
                                    contentDescription = if (idx < hud.lives) "Life remaining" else "Life lost",
                                    tint = if (idx < hud.lives) RedPen else Color(0xFFD6D3D1),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = onMuteClick,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("hud_mute_button")
                    ) {
                        Icon(
                            imageVector = if (isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = if (isMuted) "Unmute audio" else "Mute audio",
                            tint = InkBlack
                        )
                    }

                    IconButton(
                        onClick = onPauseClick,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("hud_pause_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Pause,
                            contentDescription = "Pause game",
                            tint = InkBlack
                        )
                    }
                }
            }
        }

        // BOSS HEALTH BAR
        AnimatedVisibility(
            visible = hud.bossActive,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 62.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = AlertBg,
                border = BorderStroke(3.dp, InkBlack),
                shadowElevation = 4.dp,
                modifier = Modifier.widthIn(min = 240.dp, max = 380.dp)
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (hud.bossPhase2) "${hud.bossName} (PHASE 2)" else hud.bossName,
                            style = MaterialTheme.typography.labelMedium,
                            color = RedPen
                        )
                        Text(
                            text = "${(hud.bossHpFraction * 100).toInt()}%",
                            style = MaterialTheme.typography.labelMedium,
                            color = RedPen
                        )
                    }
                    Spacer(Modifier.height(3.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.White)
                            .border(2.dp, InkBlack, RoundedCornerShape(4.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(hud.bossHpFraction)
                                .background(RedPen)
                        )
                    }
                }
            }
        }

        // ZONE / MISSION BANNER
        AnimatedVisibility(
            visible = hud.bannerVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 92.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = PaperCream,
                border = BorderStroke(3.dp, InkBlack),
                shadowElevation = 5.dp
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Surface(
                        color = TapeYellow,
                        border = BorderStroke(1.5.dp, InkBlack),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = hud.bannerSub,
                            style = MaterialTheme.typography.labelSmall,
                            color = BluePen,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = hud.bannerTitle,
                        style = MaterialTheme.typography.headlineSmall,
                        color = InkBlack
                    )
                }
            }
        }

        // CONTEXTUAL ONBOARDING HINT
        AnimatedVisibility(
            visible = hud.contextualHint.isNotEmpty(),
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = HighlightYellow.copy(alpha = 0.94f),
                border = BorderStroke(2.dp, InkBlack),
                shadowElevation = 3.dp
            ) {
                Text(
                    text = hud.contextualHint,
                    style = MaterialTheme.typography.labelMedium,
                    color = InkBlack,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }
        }
    }
}
