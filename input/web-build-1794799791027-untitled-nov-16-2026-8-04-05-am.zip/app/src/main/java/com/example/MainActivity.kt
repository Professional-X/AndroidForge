package com.example

import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.game.GameMode
import com.example.game.GameScreenState
import com.example.game.MISSIONS
import com.example.ui.canvas.SketchGameCanvas
import com.example.ui.components.HudOverlays
import com.example.ui.screens.MissionBoardOverlay
import com.example.ui.screens.PauseOverlay
import com.example.ui.screens.RunSummaryOverlay
import com.example.ui.theme.OmniverseRushTheme
import com.example.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {

    private val gameViewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        configureImmersiveLandscape()

        setContent {
            OmniverseRushTheme {
                OmniverseRushApp(viewModel = gameViewModel)
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) configureImmersiveLandscape()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (gameViewModel.handleKeyDown(keyCode)) return true
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (gameViewModel.handleKeyUp(keyCode)) return true
        return super.onKeyUp(keyCode, event)
    }

    private fun configureImmersiveLandscape() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }
}

@Composable
fun OmniverseRushApp(viewModel: GameViewModel) {
    val hud by viewModel.hudState.collectAsStateWithLifecycle()
    val frameTick by viewModel.frameTick.collectAsStateWithLifecycle()
    val prefs by viewModel.preferences.collectAsStateWithLifecycle()
    val missionProgress by viewModel.missionProgress.collectAsStateWithLifecycle()
    val topRuns by viewModel.topRuns.collectAsStateWithLifecycle()
    val bestScore by viewModel.bestEndlessScore.collectAsStateWithLifecycle()
    val bestDist by viewModel.bestEndlessDistance.collectAsStateWithLifecycle()
    val unlocks by viewModel.cosmeticUnlocks.collectAsStateWithLifecycle()
    val lastSummary by viewModel.lastSummary.collectAsStateWithLifecycle()

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) {
                viewModel.pauseGame()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Drive fixed 60 Hz simulation loop
    LaunchedEffect(Unit) {
        var prevNanos = 0L
        while (true) {
            withFrameNanos { now ->
                if (prevNanos != 0L) {
                    viewModel.stepAnimationFrame(now - prevNanos)
                }
                prevNanos = now
            }
        }
    }

    // Back button behavior across game states
    BackHandler(enabled = hud.screenState != GameScreenState.MENU) {
        when (hud.screenState) {
            GameScreenState.PLAYING -> viewModel.pauseGame()
            GameScreenState.PAUSED -> viewModel.resumeGame()
            GameScreenState.VICTORY, GameScreenState.GAME_OVER -> viewModel.returnToMenu()
            GameScreenState.MENU -> Unit
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        SketchGameCanvas(
            engine = viewModel.engine,
            frameTick = frameTick,
            inkPaletteId = prefs.selectedInkPaletteId
        )

        if (hud.screenState == GameScreenState.PLAYING || hud.screenState == GameScreenState.PAUSED) {
            HudOverlays(
                hud = hud,
                isMuted = prefs.isMuted,
                onWatchClick = { viewModel.toggleWatchDial() },
                onMuteClick = { viewModel.toggleMute() },
                onPauseClick = { viewModel.pauseGame() }
            )
        }

        when (hud.screenState) {
            GameScreenState.MENU -> {
                MissionBoardOverlay(
                    missionProgress = missionProgress,
                    topRuns = topRuns,
                    bestEndlessScore = bestScore,
                    bestEndlessDistance = bestDist,
                    unlocks = unlocks,
                    preferences = prefs,
                    onStartMode = { mode -> viewModel.startRun(mode) },
                    onSelectPalette = { palId -> viewModel.selectInkPalette(palId) }
                )
            }
            GameScreenState.PAUSED -> {
                PauseOverlay(
                    preferences = prefs,
                    onResume = { viewModel.resumeGame() },
                    onRestart = { viewModel.restartCurrentRun() },
                    onReturnToMenu = { viewModel.returnToMenu() },
                    onMusicVolumeChange = { viewModel.setMusicVolume(it) },
                    onSfxVolumeChange = { viewModel.setSfxVolume(it) },
                    onToggleMute = { viewModel.toggleMute() },
                    onToggleReducedMotion = { viewModel.toggleReducedMotion() }
                )
            }
            GameScreenState.VICTORY, GameScreenState.GAME_OVER -> {
                val summary = lastSummary
                if (summary != null) {
                    val nextMissionMode: GameMode? = if (summary.victory && summary.mode.id.startsWith("MISSION_")) {
                        val curNum = MISSIONS.find { it.mode == summary.mode }?.number ?: 0
                        MISSIONS.find { it.number == curNum + 1 }?.mode
                    } else null

                    RunSummaryOverlay(
                        summary = summary,
                        onReplay = { viewModel.restartCurrentRun() },
                        onNextMission = nextMissionMode?.let { nextMode -> { viewModel.startRun(nextMode) } },
                        onReturnToMenu = { viewModel.returnToMenu() }
                    )
                }
            }
            GameScreenState.PLAYING -> Unit
        }
    }
}
