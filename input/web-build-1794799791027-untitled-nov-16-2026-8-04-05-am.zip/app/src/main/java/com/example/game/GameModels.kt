package com.example.game

import androidx.compose.ui.graphics.Color
import java.util.concurrent.atomic.AtomicInteger

enum class AlienForm(
    val displayName: String,
    val shortName: String,
    val badgeIcon: String,
    val roleLabel: String,
    val meleeName: String,
    val specialName: String,
    val primaryColor: Color,
    val accentColor: Color,
    val colorHex: Int,
    val accentHex: Int,
    val speed: Float,
    val jumpPower: Float,
    val gravity: Float,
    val width: Float,
    val height: Float,
    val maxJumps: Int,
    val canFly: Boolean
) {
    BEN(
        displayName = "BEN TENNYSON",
        shortName = "BEN",
        badgeIcon = "10",
        roleLabel = "Utility • Double Jump",
        meleeName = "Omni Kick Combo",
        specialName = "Omni Boomerang Disc",
        primaryColor = Color(0xFF10B981),
        accentColor = Color(0xFF4ADE80),
        colorHex = 0xFF10B981.toInt(),
        accentHex = 0xFF4ADE80.toInt(),
        speed = 4.9f,
        jumpPower = -12.4f,
        gravity = 0.52f,
        width = 34f,
        height = 56f,
        maxJumps = 2,
        canFly = false
    ),
    HEATBLAST(
        displayName = "HEATBLAST",
        shortName = "HEAT",
        badgeIcon = "🔥",
        roleLabel = "Flame • Ignites Switches",
        meleeName = "Magma Uppercut",
        specialName = "Roaring Flame Stream",
        primaryColor = Color(0xFFF97316),
        accentColor = Color(0xFFFDE047),
        colorHex = 0xFFF97316.toInt(),
        accentHex = 0xFFFDE047.toInt(),
        speed = 4.5f,
        jumpPower = -12.0f,
        gravity = 0.47f,
        width = 38f,
        height = 60f,
        maxJumps = 1,
        canFly = false
    ),
    XLR8(
        displayName = "XLR8",
        shortName = "XLR8",
        badgeIcon = "⚡",
        roleLabel = "Speed • Clears Gates",
        meleeName = "Mach-5 Flurry",
        specialName = "Cyclone Zoom Dash",
        primaryColor = Color(0xFF06B6D4),
        accentColor = Color(0xFF22D3EE),
        colorHex = 0xFF06B6D4.toInt(),
        accentHex = 0xFF22D3EE.toInt(),
        speed = 8.2f,
        jumpPower = -13.9f,
        gravity = 0.53f,
        width = 38f,
        height = 56f,
        maxJumps = 2,
        canFly = false
    ),
    FOURARMS(
        displayName = "FOUR ARMS",
        shortName = "4ARMS",
        badgeIcon = "💪",
        roleLabel = "Heavy • Shatters Armor",
        meleeName = "Quad Haymaker",
        specialName = "Seismic Thunder Clap",
        primaryColor = Color(0xFFEF4444),
        accentColor = Color(0xFFFACC15),
        colorHex = 0xFFEF4444.toInt(),
        accentHex = 0xFFFACC15.toInt(),
        speed = 4.1f,
        jumpPower = -12.6f,
        gravity = 0.60f,
        width = 50f,
        height = 68f,
        maxJumps = 1,
        canFly = false
    ),
    DIAMONDHEAD(
        displayName = "DIAMONDHEAD",
        shortName = "DIAMOND",
        badgeIcon = "💎",
        roleLabel = "Crystal • Reflect Shield",
        meleeName = "Crystal Cleave",
        specialName = "Prism Reflect & Spires",
        primaryColor = Color(0xFF14B8A6),
        accentColor = Color(0xFF99F6E4),
        colorHex = 0xFF14B8A6.toInt(),
        accentHex = 0xFF99F6E4.toInt(),
        speed = 4.4f,
        jumpPower = -12.2f,
        gravity = 0.54f,
        width = 42f,
        height = 62f,
        maxJumps = 1,
        canFly = false
    ),
    CANNONBOLT(
        displayName = "CANNONBOLT",
        shortName = "CANNON",
        badgeIcon = "🟡",
        roleLabel = "Rolling • Smashes Walls",
        meleeName = "Armored Shoulder Ram",
        specialName = "Pinball Ricochet Roll",
        primaryColor = Color(0xFFEAB308),
        accentColor = Color(0xFFFEF08A),
        colorHex = 0xFFEAB308.toInt(),
        accentHex = 0xFFFEF08A.toInt(),
        speed = 4.7f,
        jumpPower = -12.4f,
        gravity = 0.57f,
        width = 46f,
        height = 54f,
        maxJumps = 1,
        canFly = false
    ),
    JETRAY(
        displayName = "JETRAY",
        shortName = "JETRAY",
        badgeIcon = "🛸",
        roleLabel = "Flight • High-Speed Beams",
        meleeName = "Aerobatic Wing Slash",
        specialName = "Neuroshock Dual Beams",
        primaryColor = Color(0xFFF43F5E),
        accentColor = Color(0xFFFACC15),
        colorHex = 0xFFF43F5E.toInt(),
        accentHex = 0xFFFACC15.toInt(),
        speed = 7.1f,
        jumpPower = -9.6f,
        gravity = 0.21f,
        width = 46f,
        height = 56f,
        maxJumps = 99,
        canFly = true
    ),
    STINKFLY(
        displayName = "STINKFLY",
        shortName = "STINK",
        badgeIcon = "🐝",
        roleLabel = "Flight • Acid Crowd Control",
        meleeName = "Venom Stinger Jab",
        specialName = "Acid Slime Bombs",
        primaryColor = Color(0xFF84CC16),
        accentColor = Color(0xFFBEF264),
        colorHex = 0xFF84CC16.toInt(),
        accentHex = 0xFFBEF264.toInt(),
        speed = 5.5f,
        jumpPower = -9.2f,
        gravity = 0.23f,
        width = 44f,
        height = 56f,
        maxJumps = 99,
        canFly = true
    )
}

enum class GameMode(val id: String, val label: String, val biomeIndex: Int) {
    MISSION_1("MISSION_1", "Mission 1: Bellwood Skyline", 0),
    MISSION_2("MISSION_2", "Mission 2: Plumber Reactor", 1),
    MISSION_3("MISSION_3", "Mission 3: War-Sketch Deck", 2),
    MISSION_4("MISSION_4", "Mission 4: Null Void Core", 3),
    ENDLESS("ENDLESS", "Endless Rush", 0),
    PRACTICE("PRACTICE", "Practice Dojo", 0)
}

data class MissionMeta(
    val mode: GameMode,
    val number: Int,
    val title: String,
    val zoneName: String,
    val objectiveSummary: String,
    val spotlightForms: String,
    val parTimeSec: Int,
    val totalShards: Int,
    val bossTitle: String,
    val trimHex: Int,
    val accentHex: Int,
    val rewardStickerId: String,
    val rewardPaletteId: String?
)

val MISSIONS = listOf(
    MissionMeta(
        mode = GameMode.MISSION_1,
        number = 1,
        title = "Bellwood Rooftop Patrol",
        zoneName = "BELLWOOD NOTEBOOK SKYLINE",
        objectiveSummary = "Collect 5 Omnitrix Shards, smash barriers, and defeat the Mech Drone Commander.",
        spotlightForms = "Ben • Four Arms • Cannonbolt",
        parTimeSec = 140,
        totalShards = 5,
        bossTitle = "MECH DRONE COMMANDER",
        trimHex = 0xFF22C55E.toInt(),
        accentHex = 0xFF3B82F6.toInt(),
        rewardStickerId = "STICKER_OMNITRIX",
        rewardPaletteId = "PLUMBER_BLUEPRINT"
    ),
    MissionMeta(
        mode = GameMode.MISSION_2,
        number = 2,
        title = "Reactor Thermal Purge",
        zoneName = "PLUMBER BLUEPRINT REACTOR",
        objectiveSummary = "Ignite 2 Thermal Switches, shatter 3 Reactor Cores, and defeat Cyber-Hound Alpha.",
        spotlightForms = "Heatblast • Four Arms • XLR8",
        parTimeSec = 165,
        totalShards = 5,
        bossTitle = "CYBER-HOUND ALPHA",
        trimHex = 0xFF06B6D4.toInt(),
        accentHex = 0xFF0E7490.toInt(),
        rewardStickerId = "STICKER_HEATBLAST",
        rewardPaletteId = "CRIMSON_MANGA"
    ),
    MissionMeta(
        mode = GameMode.MISSION_3,
        number = 3,
        title = "Chimerian Gauntlet",
        zoneName = "CHIMERIAN WAR-SKETCH DECK",
        objectiveSummary = "Reflect turret lanes, sprint Speed Gates, and overthrow the Vilgax Vanguard.",
        spotlightForms = "Diamondhead • XLR8 • Cannonbolt",
        parTimeSec = 180,
        totalShards = 5,
        bossTitle = "VILGAX VANGUARD",
        trimHex = 0xFFF43F5E.toInt(),
        accentHex = 0xFFBE123C.toInt(),
        rewardStickerId = "STICKER_DIAMOND",
        rewardPaletteId = "NULL_VIOLET"
    ),
    MissionMeta(
        mode = GameMode.MISSION_4,
        number = 4,
        title = "Null Void Finale",
        zoneName = "NULL VOID DOODLE DIMENSION",
        objectiveSummary = "Rescue 3 Plumber Pods in the skies and vanquish Overlord Vilgax.",
        spotlightForms = "Jetray • Stinkfly • All Forms",
        parTimeSec = 200,
        totalShards = 5,
        bossTitle = "OVERLORD VILGAX",
        trimHex = 0xFFA855F7.toInt(),
        accentHex = 0xFF7E22CE.toInt(),
        rewardStickerId = "STICKER_VILGAX",
        rewardPaletteId = null
    )
)

data class InkPalette(
    val id: String,
    val name: String,
    val inkHex: Int,
    val highlightHex: Int,
    val unlockHint: String
)

val INK_PALETTES = listOf(
    InkPalette("CLASSIC_INK", "Classic Fountain Ink", 0xFF14161F.toInt(), 0xFF4ADE80.toInt(), "Unlocked by default"),
    InkPalette("PLUMBER_BLUEPRINT", "Plumber Blueprint Blue", 0xFF0F294A.toInt(), 0xFF22D3EE.toInt(), "Complete Mission 1"),
    InkPalette("CRIMSON_MANGA", "Crimson Manga Nib", 0xFF3A0D18.toInt(), 0xFFFB7185.toInt(), "Complete Mission 2"),
    InkPalette("NULL_VIOLET", "Null Void Violet", 0xFF2E1065.toInt(), 0xFFC084FC.toInt(), "Complete Mission 3")
)

data class NotebookSticker(
    val id: String,
    val title: String,
    val emoji: String,
    val requirement: String
)

val NOTEBOOK_STICKERS = listOf(
    NotebookSticker("STICKER_OMNITRIX", "Hero Watch Badge", "⌚", "Clear Mission 1"),
    NotebookSticker("STICKER_HEATBLAST", "Pyronite Spark", "🔥", "Clear Mission 2"),
    NotebookSticker("STICKER_DIAMOND", "Petrosapien Shard", "💎", "Clear Mission 3"),
    NotebookSticker("STICKER_VILGAX", "Conqueror Stamp", "👾", "Clear Mission 4"),
    NotebookSticker("STICKER_NODMG", "Untouchable Ink", "🛡️", "Earn any No-Damage Medal"),
    NotebookSticker("STICKER_SPEED", "Kineceleran Bolt", "⚡", "Earn any Speedrun Medal")
)

data class BiomeMeta(
    val sub: String,
    val title: String,
    val trimHex: Int,
    val accentHex: Int
)

val BIOMES = listOf(
    BiomeMeta("ZONE 1", "BELLWOOD NOTEBOOK SKYLINE", 0xFF22C55E.toInt(), 0xFF3B82F6.toInt()),
    BiomeMeta("ZONE 2", "PLUMBER BLUEPRINT REACTOR", 0xFF06B6D4.toInt(), 0xFF0E7490.toInt()),
    BiomeMeta("ZONE 3", "CHIMERIAN WAR-SKETCH DECK", 0xFFF43F5E.toInt(), 0xFFBE123C.toInt()),
    BiomeMeta("ZONE 4", "NULL VOID DOODLE DIMENSION", 0xFFA855F7.toInt(), 0xFF7E22CE.toInt())
)

enum class EnemyType { DRONE, BIOID, TURRET, HOUND }
enum class EnemyBehaviorState { PATROL, WINDUP, STRIKE, RECOVER, STUNNED }
enum class AttackPhase { IDLE, WINDUP, ACTIVE, RECOVERY }

enum class PlatformType { SOLID, TECH, BOUNCE, MOVING, COLLAPSING }

data class Platform(
    var x: Float,
    var y: Float,
    val w: Float,
    val h: Float,
    val type: PlatformType,
    val keep: Boolean = false,
    val isBossArena: Boolean = false,
    val startX: Float = x,
    val range: Float = 0f,
    val speed: Float = 0f,
    var dx: Float = 0f,
    var collapseTimer: Int = 0,
    var fallen: Boolean = false,
    var respawnTimer: Int = 0
)

enum class InteractivePropType {
    SHARD,
    THERMAL_SWITCH,
    SHIELD_CORE,
    SPEED_GATE,
    BREAKABLE_WALL,
    RESCUE_POD
}

data class InteractiveProp(
    val id: Int,
    val type: InteractivePropType,
    var x: Float,
    var y: Float,
    val w: Float,
    val h: Float,
    var hp: Float = 3f,
    val maxHp: Float = 3f,
    var activated: Boolean = false,
    var timer: Int = 0,
    var label: String = ""
)

data class Checkpoint(
    val x: Float,
    val y: Float,
    val w: Float = 28f,
    val h: Float = 64f,
    var active: Boolean = false
)

data class Crate(
    val x: Float,
    val y: Float,
    val w: Float = 36f,
    val h: Float = 36f,
    var broken: Boolean = false,
    var armored: Boolean = false
)

enum class CollectibleKind { CELL, SMOOTHIE }

data class Collectible(
    val x: Float,
    val y: Float,
    val w: Float = 24f,
    val h: Float = 24f,
    val kind: CollectibleKind,
    var collected: Boolean = false
)

data class EnemyEntity(
    val id: Int,
    val type: EnemyType,
    var x: Float,
    var y: Float,
    val width: Float,
    val height: Float,
    var vx: Float,
    var vy: Float = 0f,
    val minX: Float,
    val maxX: Float,
    var hp: Float,
    val maxHp: Float,
    var shootTimer: Int,
    var facing: Int = -1,
    var flash: Int = 0,
    var burnTimer: Int = 0,
    var slowTimer: Int = 0,
    var warn: Boolean = false,
    var state: EnemyBehaviorState = EnemyBehaviorState.PATROL,
    var stateTimer: Int = 0,
    var leapDir: Int = 1,
    var alive: Boolean = true,
    val isDummy: Boolean = false,
    val spawnX: Float = x,
    val spawnY: Float = y
)

enum class BossActionState {
    PATROL, TELEGRAPH_LEAP, LEAPING, TELEGRAPH_VOLLEY, RECOVER, PHASE_SHIFT
}

data class BossEntity(
    val title: String,
    var x: Float,
    var y: Float,
    val width: Float = 78f,
    val height: Float = 124f,
    var vx: Float,
    var vy: Float = 0f,
    var hp: Float,
    val maxHp: Float,
    val minX: Float,
    val maxX: Float,
    val arenaStartX: Float,
    val arenaEndX: Float,
    var attackTimer: Int = 85,
    var jumpTimer: Int = 140,
    var flashTimer: Int = 0,
    var phase2: Boolean = false,
    var alive: Boolean = true,
    var onGround: Boolean = true,
    val wave: Int = 1,
    var actionState: BossActionState = BossActionState.PATROL,
    var stateTimer: Int = 0,
    var hitById: Int = -1
)

enum class ProjectileKind {
    MELEE, OMNIDISC, FLAMESTREAM, FIREBALL, TORNADO, BOULDER, FISSURE, CRYSTAL, NEUROLASER, SLIMEBOMB, ENEMY_ORB
}

data class Projectile(
    val id: Int,
    val fromPlayer: Boolean,
    val kind: ProjectileKind,
    val style: String = "",
    var x: Float,
    var y: Float,
    val w: Float,
    val h: Float,
    var vx: Float,
    var vy: Float,
    val gravity: Float = 0f,
    val accelX: Float = 0f,
    var rot: Float = 0f,
    val baseY: Float = y,
    var wavePhase: Float = 0f,
    val dmg: Float,
    var life: Int,
    val maxLife: Int,
    val colorHex: Int,
    val facing: Int = 1,
    val pierce: Boolean = false,
    val burns: Boolean = false,
    val slows: Boolean = false,
    val heavyBreak: Boolean = false,
    val seed: Float = 0f,
    val hitIds: MutableSet<Int> = mutableSetOf()
)

data class SlimePuddle(
    val x: Float,
    val y: Float,
    val w: Float,
    val h: Float,
    var life: Int,
    val maxLife: Int
)

data class CrystalSpire(
    val x: Float,
    val y: Float,
    val w: Float,
    val maxH: Float,
    var curH: Float,
    var delay: Int,
    var life: Int,
    val maxLife: Int,
    val dmg: Float,
    val hitIds: MutableSet<Int> = mutableSetOf()
)

enum class DoodleType {
    TREE, BENCH, LAMP, HYDRANT, SIGN, SKETCH_NOTE, SPIRAL_CLOUD, PAPER_PLANE
}

data class AmbientDoodle(
    val type: DoodleType,
    val x: Float,
    val y: Float,
    val scale: Float,
    val flip: Int,
    val noteText: String,
    val seed: Float
)

enum class CreatureType(val isSky: Boolean) {
    BIRD(true), DOG(false), ELEPHANT(false), EAGLE(true), OWL(false),
    CAT(false), FROG(false), TURTLE(false), MAX(false), GWEN(false)
}

data class AmbientCreature(
    val id: Int,
    val type: CreatureType,
    var x: Float,
    var y: Float,
    val baseY: Float,
    var vx: Float,
    var vy: Float = 0f,
    val minX: Float,
    val maxX: Float,
    var facing: Int,
    val bw: Boolean,
    var phase: Float,
    var reactTimer: Int = 0,
    var bubbleText: String = "",
    var bubbleTimer: Int = 0,
    var hopTimer: Int = 0
)

data class HoverCar(
    var x: Float,
    val y: Float,
    val vx: Float,
    val colorHex: Int
)

data class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val size: Float,
    val colorHex: Int,
    val kind: String,
    var rot: Float,
    val vrot: Float,
    var life: Int,
    val maxLife: Int
)

data class SmokePuff(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var r: Float,
    val grow: Float,
    var rot: Float,
    val vrot: Float,
    val tintHex: Int,
    var life: Int,
    val maxLife: Int
)

data class FlameWisp(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val w: Float,
    val h: Float,
    val seed: Float,
    var life: Int,
    val maxLife: Int
)

data class Shockwave(
    val x: Float,
    val y: Float,
    var r: Float,
    val maxR: Float,
    val colorHex: Int,
    var life: Int,
    val maxLife: Int
)

data class ImpactBurst(
    val x: Float,
    val y: Float,
    val r: Float,
    val colorHex: Int,
    var life: Int,
    val maxLife: Int
)

data class FloatingText(
    var x: Float,
    var y: Float,
    val vy: Float,
    val text: String,
    val colorHex: Int,
    val size: Float,
    val tilt: Float,
    var life: Int,
    val maxLife: Int
)

data class Afterimage(
    val form: AlienForm,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val facing: Int,
    var life: Int,
    val maxLife: Int
)

data class PlayerState(
    var x: Float = 80f,
    var y: Float = 364f,
    var vx: Float = 0f,
    var vy: Float = 0f,
    var width: Float = AlienForm.BEN.width,
    var height: Float = AlienForm.BEN.height,
    var facing: Int = 1,
    var form: AlienForm = AlienForm.BEN,
    var speed: Float = AlienForm.BEN.speed,
    var jumpPower: Float = AlienForm.BEN.jumpPower,
    var gravity: Float = AlienForm.BEN.gravity,
    var maxJumps: Int = AlienForm.BEN.maxJumps,
    var jumpsLeft: Int = AlienForm.BEN.maxJumps,
    var canFly: Boolean = false,
    var onGround: Boolean = false,
    var coyoteTimer: Int = 0,
    var jumpBuffer: Int = 0,
    var hp: Float = 100f,
    var maxHp: Float = 100f,
    var energy: Float = 100f,
    var maxEnergy: Float = 100f,
    var invulnTimer: Int = 0,
    var punchCooldown: Int = 0,
    var specialCooldown: Int = 0,
    var specialMaxCooldown: Int = 22,
    var attackAnimTimer: Int = 0,
    var attackAnimDuration: Int = 14,
    var attackAnimType: String = "punch",
    var attackPhase: AttackPhase = AttackPhase.IDLE,
    var comboStep: Int = 0,
    var comboWindowTimer: Int = 0,
    var dashTimer: Int = 0,
    var rollTimer: Int = 0,
    var shieldTimer: Int = 0,
    var slamming: Boolean = false,
    var squashX: Float = 1f,
    var squashY: Float = 1f,
    var walkPhase: Float = 0f,
    var wingPhase: Float = 0f,
    var landingRecoilTimer: Int = 0,
    var damageRecoilTimer: Int = 0,
    var transformPoseTimer: Int = 0,
    var celebrationTimer: Int = 0,
    var checkpointX: Float = 80f,
    var checkpointY: Float = 364f,
    val dashHitIds: MutableSet<Int> = mutableSetOf()
)

data class InputState(
    var moveX: Float = 0f,
    var moveY: Float = 0f,
    var keyLeft: Boolean = false,
    var keyRight: Boolean = false,
    var keyUp: Boolean = false,
    var keyDown: Boolean = false,
    var jumpHeld: Boolean = false
) {
    fun clearAll() {
        moveX = 0f
        moveY = 0f
        keyLeft = false
        keyRight = false
        keyUp = false
        keyDown = false
        jumpHeld = false
    }
}

data class RadialDialState(
    var open: Boolean = false,
    var x: Float = 480f,
    var y: Float = 270f,
    var selectedIdx: Int = 0,
    var byTouch: Boolean = false
)

data class LeftJoystickState(
    var active: Boolean = false,
    var originX: Float = 0f,
    var originY: Float = 0f,
    var currX: Float = 0f,
    var currY: Float = 0f
)

enum class GameScreenState { MENU, PLAYING, PAUSED, VICTORY, GAME_OVER }

data class HudUiState(
    val screenState: GameScreenState = GameScreenState.MENU,
    val mode: GameMode = GameMode.MISSION_1,
    val form: AlienForm = AlienForm.BEN,
    val hpFraction: Float = 1f,
    val energyFraction: Float = 1f,
    val specialReadyFraction: Float = 1f,
    val isLowHp: Boolean = false,
    val isInvulnerable: Boolean = false,
    val score: Int = 0,
    val distanceMeters: Int = 0,
    val lives: Int = 3,
    val combo: Int = 0,
    val comboStep: Int = 0,
    val biomeIndex: Int = 0,
    val waveNumber: Int = 1,
    val objectiveText: String = "",
    val objectiveProgress: Float = 0f,
    val shardsCollected: Int = 0,
    val totalShards: Int = 5,
    val bossActive: Boolean = false,
    val bossName: String = "",
    val bossHpFraction: Float = 1f,
    val bossPhase2: Boolean = false,
    val bannerVisible: Boolean = false,
    val bannerSub: String = "",
    val bannerTitle: String = "",
    val contextualHint: String = "",
    val radialDialOpen: Boolean = false
)

data class RunSummary(
    val mode: GameMode,
    val victory: Boolean,
    val score: Int,
    val distanceMeters: Int,
    val bossesDefeated: Int,
    val durationSec: Int,
    val stars: Int,
    val noDamageMedal: Boolean,
    val allShardsMedal: Boolean,
    val speedMedal: Boolean,
    val favoriteForm: AlienForm,
    val newStickerUnlocked: NotebookSticker? = null,
    val newPaletteUnlocked: InkPalette? = null
)

object EntityIdCounter {
    private val seq = AtomicInteger(1)
    fun next(): Int = seq.getAndIncrement()
    fun reset() { seq.set(1) }
}
