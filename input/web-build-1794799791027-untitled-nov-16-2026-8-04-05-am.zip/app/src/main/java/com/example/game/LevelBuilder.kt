package com.example.game

import kotlin.math.roundToInt
import kotlin.random.Random

class LevelBuildResult(
    val platforms: MutableList<Platform>,
    val checkpoints: MutableList<Checkpoint>,
    val crates: MutableList<Crate>,
    val collectibles: MutableList<Collectible>,
    val props: MutableList<InteractiveProp>,
    val enemies: MutableList<EnemyEntity>,
    val boss: BossEntity?,
    val ambientDoodles: MutableList<AmbientDoodle>,
    val ambientCreatures: MutableList<AmbientCreature>,
    val generatedUntilX: Float,
    val nextCheckpointX: Float,
    val nextBossX: Float
)

object LevelBuilder {

    private val noteTexts = arrayOf("SKETCH #10", "HERO TIME!", "PLUMBER NOTE", "WATCH READY", "GO BEN!")

    fun createEnemy(
        type: EnemyType,
        x: Float,
        y: Float,
        width: Float,
        height: Float,
        vx: Float,
        minX: Float,
        maxX: Float,
        hp: Float,
        shootTimer: Int,
        isDummy: Boolean = false
    ): EnemyEntity {
        return EnemyEntity(
            id = EntityIdCounter.next(),
            type = type,
            x = x,
            y = y,
            width = width,
            height = height,
            vx = vx,
            minX = minX,
            maxX = maxX,
            hp = hp,
            maxHp = hp,
            shootTimer = shootTimer,
            facing = if (vx < 0) -1 else 1,
            isDummy = isDummy,
            spawnX = x,
            spawnY = y
        )
    }

    private fun spawnCreature(
        list: MutableList<AmbientCreature>,
        type: CreatureType,
        x: Float,
        groundY: Float,
        minX: Float,
        maxX: Float
    ) {
        val bw = Random.nextFloat() < 0.52f
        val dir = if (Random.nextBoolean()) 1 else -1
        val y = if (type.isSky) 52f + Random.nextFloat() * 115f else groundY
        val spd = when (type) {
            CreatureType.EAGLE -> 1.7f
            CreatureType.BIRD -> 1.45f
            CreatureType.ELEPHANT -> 0.5f
            CreatureType.TURTLE -> 0.35f
            CreatureType.DOG -> 1.1f
            CreatureType.CAT -> 0.9f
            else -> 0f
        }
        list.add(
            AmbientCreature(
                id = EntityIdCounter.next(),
                type = type,
                x = x,
                y = y,
                baseY = y,
                vx = dir * spd,
                minX = minX,
                maxX = maxX,
                facing = dir,
                bw = bw,
                phase = Random.nextFloat() * 6.28f,
                hopTimer = Random.nextInt(90)
            )
        )
    }

    fun populateChunkDoodlesAndCreatures(
        doodles: MutableList<AmbientDoodle>,
        creatures: MutableList<AmbientCreature>,
        startX: Float,
        endX: Float,
        groundPlat: Platform?
    ) {
        val width = (endX - startX).coerceAtLeast(100f)
        // Decluttered landmark count (2-3 crisp landmarks per chunk rather than visual noise wall)
        val doodleCount = 2 + Random.nextInt(2)
        val types = DoodleType.entries
        for (i in 0 until doodleCount) {
            val dt = types[Random.nextInt(types.size)]
            val dx = startX + 45f + Random.nextFloat() * (width - 90f).coerceAtLeast(40f)
            val dy = when (dt) {
                DoodleType.SPIRAL_CLOUD, DoodleType.PAPER_PLANE, DoodleType.SKETCH_NOTE ->
                    48f + Random.nextFloat() * 115f
                else -> groundPlat?.y ?: continue
            }
            doodles.add(
                AmbientDoodle(
                    type = dt,
                    x = dx,
                    y = dy,
                    scale = 0.85f + Random.nextFloat() * 0.25f,
                    flip = if (Random.nextBoolean()) 1 else -1,
                    noteText = noteTexts[Random.nextInt(noteTexts.size)],
                    seed = Random.nextFloat() * 50f
                )
            )
        }

        if (Random.nextFloat() < 0.78f) {
            val sky = listOf(CreatureType.BIRD, CreatureType.EAGLE, CreatureType.OWL)[Random.nextInt(3)]
            spawnCreature(creatures, sky, startX + 90f + Random.nextFloat() * 180f, 110f, startX - 220f, endX + 220f)
        }

        if (groundPlat != null && groundPlat.w >= 210f) {
            val groundChoices = listOf(
                CreatureType.DOG, CreatureType.ELEPHANT, CreatureType.OWL,
                CreatureType.CAT, CreatureType.FROG, CreatureType.TURTLE,
                CreatureType.MAX, CreatureType.GWEN
            )
            val chosen = groundChoices[Random.nextInt(groundChoices.size)]
            val cx = groundPlat.x + 56f + Random.nextFloat() * (groundPlat.w - 112f).coerceAtLeast(24f)
            spawnCreature(creatures, chosen, cx, groundPlat.y, groundPlat.x + 24f, groundPlat.x + groundPlat.w - 24f)
        }
    }

    fun buildModeWorld(mode: GameMode): LevelBuildResult {
        return when (mode) {
            GameMode.MISSION_1 -> buildMission1()
            GameMode.MISSION_2 -> buildMission2()
            GameMode.MISSION_3 -> buildMission3()
            GameMode.MISSION_4 -> buildMission4()
            GameMode.PRACTICE -> buildPracticeDojo()
            GameMode.ENDLESS -> buildEndlessStarter()
        }
    }

    private fun buildMission1(): LevelBuildResult {
        // Bellwood Skyline: Move/Jump -> Safe first drone -> Smashable wall & Bounce pads -> Boss Arena
        val platforms = mutableListOf(
            Platform(0f, 420f, 920f, 120f, PlatformType.SOLID, keep = true),
            Platform(290f, 320f, 170f, 20f, PlatformType.TECH),
            Platform(540f, 240f, 175f, 20f, PlatformType.TECH),
            Platform(790f, 330f, 105f, 18f, PlatformType.BOUNCE),
            // Section 2: Explore & Bounce
            Platform(1020f, 420f, 780f, 120f, PlatformType.SOLID),
            Platform(1170f, 290f, 175f, 20f, PlatformType.TECH),
            Platform(1450f, 225f, 180f, 20f, PlatformType.TECH),
            Platform(1670f, 335f, 105f, 18f, PlatformType.BOUNCE),
            // Section 3: Mix it up (barrier + elevated shard)
            Platform(1910f, 420f, 900f, 120f, PlatformType.SOLID),
            Platform(2090f, 305f, 180f, 20f, PlatformType.TECH),
            Platform(2380f, 240f, 200f, 20f, PlatformType.TECH),
            // Climax Boss Arena
            Platform(2910f, 420f, 1320f, 120f, PlatformType.SOLID, isBossArena = true),
            Platform(3160f, 300f, 180f, 20f, PlatformType.TECH),
            Platform(3480f, 225f, 200f, 20f, PlatformType.TECH),
            Platform(3820f, 300f, 180f, 20f, PlatformType.TECH)
        )
        val checkpoints = mutableListOf(
            Checkpoint(1935f, 356f),
            Checkpoint(2980f, 356f)
        )
        val crates = mutableListOf(
            Crate(450f, 384f),
            Crate(1240f, 254f),
            Crate(2280f, 384f, armored = true),
            Crate(3230f, 264f),
            Crate(3900f, 264f)
        )
        val collectibles = mutableListOf(
            Collectible(360f, 278f, kind = CollectibleKind.CELL),
            Collectible(1520f, 185f, kind = CollectibleKind.SMOOTHIE),
            Collectible(2460f, 198f, kind = CollectibleKind.CELL),
            Collectible(3565f, 185f, kind = CollectibleKind.SMOOTHIE)
        )
        val props = mutableListOf(
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 615f, 195f, 28f, 28f, label = "SHARD 1"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 1245f, 245f, 28f, 28f, label = "SHARD 2"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.BREAKABLE_WALL, 1995f, 315f, 40f, 105f, hp = 4f, maxHp = 4f, label = "SMASH!"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 2170f, 262f, 28f, 28f, label = "SHARD 3"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 2660f, 376f, 28f, 28f, label = "SHARD 4"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 3560f, 145f, 28f, 28f, label = "SHARD 5")
        )
        val enemies = mutableListOf(
            createEnemy(EnemyType.DRONE, 560f, 355f, 38f, 48f, 1.35f, 410f, 840f, 2f, 125),
            createEnemy(EnemyType.BIOID, 1340f, 372f, 40f, 48f, -1.7f, 1080f, 1720f, 3f, 95),
            createEnemy(EnemyType.DRONE, 1520f, 165f, 38f, 48f, 1.55f, 1280f, 1740f, 2f, 105),
            createEnemy(EnemyType.HOUND, 2440f, 372f, 42f, 48f, -2.0f, 2120f, 2760f, 3f, 999),
            createEnemy(EnemyType.TURRET, 2440f, 192f, 36f, 48f, 1.0f, 2400f, 2540f, 2f, 95)
        )
        val boss = BossEntity(
            title = "MECH DRONE COMMANDER",
            x = 3850f, y = 296f, vx = -2.2f, hp = 26f, maxHp = 26f,
            minX = 3130f, maxX = 4140f, arenaStartX = 2910f, arenaEndX = 4230f, wave = 1
        )

        val doodles = mutableListOf<AmbientDoodle>()
        val creatures = mutableListOf<AmbientCreature>()
        populateChunkDoodlesAndCreatures(doodles, creatures, 60f, 900f, platforms[0])
        populateChunkDoodlesAndCreatures(doodles, creatures, 1020f, 1800f, platforms[4])
        populateChunkDoodlesAndCreatures(doodles, creatures, 1910f, 2810f, platforms[8])
        populateChunkDoodlesAndCreatures(doodles, creatures, 2910f, 4230f, platforms[11])
        spawnCreature(creatures, CreatureType.GWEN, 175f, 420f, 150f, 230f)
        spawnCreature(creatures, CreatureType.DOG, 250f, 420f, 140f, 420f)
        spawnCreature(creatures, CreatureType.MAX, 1880f, 420f, 1840f, 1960f)

        return LevelBuildResult(
            platforms, checkpoints, crates, collectibles, props, enemies, boss,
            doodles, creatures, 4230f, 99999f, 99999f
        )
    }

    private fun buildMission2(): LevelBuildResult {
        // Plumber Blueprint Reactor: Moving bridges + 2 Thermal Switches + 3 Shielded Reactor Cores
        val platforms = mutableListOf(
            Platform(0f, 420f, 760f, 120f, PlatformType.SOLID, keep = true),
            Platform(280f, 310f, 170f, 20f, PlatformType.TECH),
            Platform(860f, 345f, 170f, 20f, PlatformType.MOVING, startX = 860f, range = 95f, speed = 1.7f),
            Platform(1140f, 420f, 760f, 120f, PlatformType.SOLID),
            Platform(1300f, 280f, 190f, 20f, PlatformType.TECH),
            Platform(1610f, 230f, 180f, 20f, PlatformType.TECH),
            Platform(2010f, 340f, 165f, 20f, PlatformType.MOVING, startX = 2010f, range = 90f, speed = 1.9f),
            Platform(2290f, 420f, 820f, 120f, PlatformType.SOLID),
            Platform(2480f, 285f, 200f, 20f, PlatformType.TECH),
            Platform(2840f, 330f, 105f, 18f, PlatformType.BOUNCE),
            Platform(3210f, 420f, 1340f, 120f, PlatformType.SOLID, isBossArena = true),
            Platform(3460f, 300f, 180f, 20f, PlatformType.TECH),
            Platform(3790f, 225f, 200f, 20f, PlatformType.TECH),
            Platform(4130f, 300f, 180f, 20f, PlatformType.TECH)
        )
        val checkpoints = mutableListOf(
            Checkpoint(1210f, 356f),
            Checkpoint(3290f, 356f)
        )
        val crates = mutableListOf(
            Crate(520f, 384f),
            Crate(1700f, 194f, armored = true),
            Crate(2580f, 249f),
            Crate(3530f, 264f),
            Crate(4200f, 264f)
        )
        val collectibles = mutableListOf(
            Collectible(355f, 268f, kind = CollectibleKind.CELL),
            Collectible(1385f, 238f, kind = CollectibleKind.SMOOTHIE),
            Collectible(2575f, 245f, kind = CollectibleKind.CELL),
            Collectible(3880f, 185f, kind = CollectibleKind.SMOOTHIE)
        )
        val props = mutableListOf(
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.THERMAL_SWITCH, 600f, 370f, 44f, 50f, hp = 2f, maxHp = 2f, label = "IGNITE!"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHIELD_CORE, 1490f, 352f, 48f, 68f, hp = 4f, maxHp = 4f, label = "CORE 1"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 1685f, 185f, 28f, 28f, label = "SHARD 1"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHIELD_CORE, 2410f, 352f, 48f, 68f, hp = 4f, maxHp = 4f, label = "CORE 2"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.THERMAL_SWITCH, 2740f, 370f, 44f, 50f, hp = 2f, maxHp = 2f, label = "IGNITE!"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHIELD_CORE, 2970f, 352f, 48f, 68f, hp = 4f, maxHp = 4f, label = "CORE 3"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 930f, 295f, 28f, 28f, label = "SHARD 2"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 2080f, 290f, 28f, 28f, label = "SHARD 3"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 2565f, 242f, 28f, 28f, label = "SHARD 4"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 3880f, 145f, 28f, 28f, label = "SHARD 5")
        )
        val enemies = mutableListOf(
            createEnemy(EnemyType.BIOID, 440f, 372f, 40f, 48f, -1.7f, 260f, 700f, 3f, 95),
            createEnemy(EnemyType.DRONE, 920f, 205f, 38f, 48f, 1.7f, 650f, 1250f, 2f, 90),
            createEnemy(EnemyType.TURRET, 1680f, 182f, 36f, 48f, 1.0f, 1620f, 1760f, 2.5f, 80),
            createEnemy(EnemyType.HOUND, 1600f, 372f, 42f, 48f, -2.1f, 1220f, 1860f, 3f, 999),
            createEnemy(EnemyType.BIOID, 2580f, 372f, 40f, 48f, 2.0f, 2350f, 3040f, 3.5f, 85),
            createEnemy(EnemyType.DRONE, 2620f, 180f, 38f, 48f, -1.8f, 2320f, 2980f, 2.5f, 85)
        )
        val boss = BossEntity(
            title = "CYBER-HOUND ALPHA",
            x = 4170f, y = 296f, vx = -2.6f, hp = 32f, maxHp = 32f,
            minX = 3430f, maxX = 4460f, arenaStartX = 3210f, arenaEndX = 4550f, wave = 2
        )

        val doodles = mutableListOf<AmbientDoodle>()
        val creatures = mutableListOf<AmbientCreature>()
        populateChunkDoodlesAndCreatures(doodles, creatures, 60f, 740f, platforms[0])
        populateChunkDoodlesAndCreatures(doodles, creatures, 1140f, 1880f, platforms[3])
        populateChunkDoodlesAndCreatures(doodles, creatures, 2290f, 3090f, platforms[7])
        populateChunkDoodlesAndCreatures(doodles, creatures, 3210f, 4550f, platforms[10])
        spawnCreature(creatures, CreatureType.MAX, 160f, 420f, 120f, 230f)

        return LevelBuildResult(
            platforms, checkpoints, crates, collectibles, props, enemies, boss,
            doodles, creatures, 4550f, 99999f, 99999f
        )
    }

    private fun buildMission3(): LevelBuildResult {
        // Chimerian War-Sketch Deck: Turret reflect lanes + Speed Gates + Collapsing paths
        val platforms = mutableListOf(
            Platform(0f, 420f, 780f, 120f, PlatformType.SOLID, keep = true),
            Platform(290f, 300f, 175f, 20f, PlatformType.TECH),
            Platform(870f, 350f, 155f, 20f, PlatformType.COLLAPSING),
            Platform(1100f, 320f, 155f, 20f, PlatformType.COLLAPSING),
            Platform(1340f, 420f, 820f, 120f, PlatformType.SOLID),
            Platform(1530f, 260f, 200f, 20f, PlatformType.TECH),
            Platform(1880f, 330f, 105f, 18f, PlatformType.BOUNCE),
            Platform(2250f, 420f, 860f, 120f, PlatformType.SOLID),
            Platform(2440f, 290f, 180f, 20f, PlatformType.TECH),
            Platform(2750f, 220f, 180f, 20f, PlatformType.TECH),
            Platform(3220f, 420f, 1360f, 120f, PlatformType.SOLID, isBossArena = true),
            Platform(3470f, 300f, 180f, 20f, PlatformType.TECH),
            Platform(3810f, 225f, 200f, 20f, PlatformType.TECH),
            Platform(4150f, 300f, 180f, 20f, PlatformType.TECH)
        )
        val checkpoints = mutableListOf(
            Checkpoint(1410f, 356f),
            Checkpoint(3300f, 356f)
        )
        val crates = mutableListOf(
            Crate(560f, 384f),
            Crate(1610f, 224f, armored = true),
            Crate(2830f, 184f),
            Crate(3540f, 264f),
            Crate(4230f, 264f)
        )
        val collectibles = mutableListOf(
            Collectible(365f, 258f, kind = CollectibleKind.CELL),
            Collectible(1620f, 378f, kind = CollectibleKind.SMOOTHIE),
            Collectible(2515f, 248f, kind = CollectibleKind.CELL),
            Collectible(3895f, 185f, kind = CollectibleKind.SMOOTHIE)
        )
        val props = mutableListOf(
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SPEED_GATE, 820f, 310f, 34f, 110f, hp = 1f, maxHp = 1f, label = "SPEED GATE"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 935f, 295f, 28f, 28f, label = "SHARD 1"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 1165f, 265f, 28f, 28f, label = "SHARD 2"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.BREAKABLE_WALL, 1790f, 315f, 40f, 105f, hp = 4f, maxHp = 4f, label = "SMASH!"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 2040f, 220f, 28f, 28f, label = "SHARD 3"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SPEED_GATE, 2330f, 310f, 34f, 110f, hp = 1f, maxHp = 1f, label = "SPEED GATE"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 2830f, 145f, 28f, 28f, label = "SHARD 4"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 3900f, 145f, 28f, 28f, label = "SHARD 5")
        )
        val enemies = mutableListOf(
            createEnemy(EnemyType.TURRET, 640f, 372f, 36f, 48f, -1.0f, 610f, 740f, 3f, 70),
            createEnemy(EnemyType.HOUND, 1650f, 372f, 42f, 48f, -2.2f, 1430f, 1760f, 3f, 999),
            createEnemy(EnemyType.TURRET, 2020f, 372f, 36f, 48f, -1.0f, 1960f, 2110f, 3f, 72),
            createEnemy(EnemyType.DRONE, 1980f, 180f, 38f, 48f, 1.85f, 1650f, 2140f, 2.5f, 80),
            createEnemy(EnemyType.BIOID, 2590f, 372f, 40f, 48f, -2.1f, 2390f, 3040f, 3.5f, 78),
            createEnemy(EnemyType.TURRET, 2800f, 172f, 36f, 48f, -1.0f, 2765f, 2900f, 2.5f, 75)
        )
        val boss = BossEntity(
            title = "VILGAX VANGUARD",
            x = 4200f, y = 296f, vx = -2.5f, hp = 36f, maxHp = 36f,
            minX = 3440f, maxX = 4480f, arenaStartX = 3220f, arenaEndX = 4580f, wave = 3
        )

        val doodles = mutableListOf<AmbientDoodle>()
        val creatures = mutableListOf<AmbientCreature>()
        populateChunkDoodlesAndCreatures(doodles, creatures, 60f, 760f, platforms[0])
        populateChunkDoodlesAndCreatures(doodles, creatures, 1340f, 2140f, platforms[4])
        populateChunkDoodlesAndCreatures(doodles, creatures, 2250f, 3090f, platforms[7])
        populateChunkDoodlesAndCreatures(doodles, creatures, 3220f, 4580f, platforms[10])
        spawnCreature(creatures, CreatureType.CAT, 190f, 420f, 120f, 340f)

        return LevelBuildResult(
            platforms, checkpoints, crates, collectibles, props, enemies, boss,
            doodles, creatures, 4580f, 99999f, 99999f
        )
    }

    private fun buildMission4(): LevelBuildResult {
        // Null Void Doodle Dimension: Aerial Rescue Pods + Overlord Vilgax Showdown
        val platforms = mutableListOf(
            Platform(0f, 420f, 760f, 120f, PlatformType.SOLID, keep = true),
            Platform(300f, 300f, 165f, 20f, PlatformType.TECH),
            Platform(610f, 330f, 105f, 18f, PlatformType.BOUNCE),
            Platform(870f, 235f, 180f, 20f, PlatformType.TECH),
            Platform(1160f, 420f, 680f, 120f, PlatformType.SOLID),
            Platform(1350f, 285f, 175f, 20f, PlatformType.MOVING, startX = 1350f, range = 90f, speed = 2.0f),
            Platform(1690f, 330f, 105f, 18f, PlatformType.BOUNCE),
            Platform(1950f, 225f, 185f, 20f, PlatformType.TECH),
            Platform(2250f, 420f, 720f, 120f, PlatformType.SOLID),
            Platform(2470f, 295f, 180f, 20f, PlatformType.TECH),
            Platform(2820f, 330f, 105f, 18f, PlatformType.BOUNCE),
            Platform(3080f, 420f, 1400f, 120f, PlatformType.SOLID, isBossArena = true),
            Platform(3340f, 300f, 185f, 20f, PlatformType.TECH),
            Platform(3680f, 220f, 205f, 20f, PlatformType.TECH),
            Platform(4040f, 300f, 185f, 20f, PlatformType.TECH)
        )
        val checkpoints = mutableListOf(
            Checkpoint(1220f, 356f),
            Checkpoint(3160f, 356f)
        )
        val crates = mutableListOf(
            Crate(500f, 384f),
            Crate(1560f, 384f, armored = true),
            Crate(2540f, 259f),
            Crate(3410f, 264f),
            Crate(4110f, 264f)
        )
        val collectibles = mutableListOf(
            Collectible(370f, 258f, kind = CollectibleKind.SMOOTHIE),
            Collectible(1420f, 235f, kind = CollectibleKind.CELL),
            Collectible(2340f, 378f, kind = CollectibleKind.SMOOTHIE),
            Collectible(3770f, 180f, kind = CollectibleKind.SMOOTHIE)
        )
        val props = mutableListOf(
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.RESCUE_POD, 935f, 165f, 44f, 68f, hp = 1f, maxHp = 1f, label = "RESCUE POD 1"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 740f, 165f, 28f, 28f, label = "SHARD 1"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 1185f, 175f, 28f, 28f, label = "SHARD 2"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.RESCUE_POD, 2020f, 155f, 44f, 68f, hp = 1f, maxHp = 1f, label = "RESCUE POD 2"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 1810f, 175f, 28f, 28f, label = "SHARD 3"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.RESCUE_POD, 2890f, 155f, 44f, 68f, hp = 1f, maxHp = 1f, label = "RESCUE POD 3"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 2545f, 250f, 28f, 28f, label = "SHARD 4"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHARD, 3770f, 135f, 28f, 28f, label = "SHARD 5")
        )
        val enemies = mutableListOf(
            createEnemy(EnemyType.DRONE, 540f, 185f, 38f, 48f, 1.8f, 320f, 920f, 2.5f, 80),
            createEnemy(EnemyType.BIOID, 1460f, 372f, 40f, 48f, -2.2f, 1210f, 1760f, 3.5f, 75),
            createEnemy(EnemyType.DRONE, 1740f, 145f, 38f, 48f, 2.0f, 1440f, 2120f, 2.5f, 72),
            createEnemy(EnemyType.HOUND, 2560f, 372f, 42f, 48f, -2.4f, 2290f, 2900f, 3.5f, 999),
            createEnemy(EnemyType.TURRET, 2520f, 247f, 36f, 48f, -1.0f, 2480f, 2610f, 2.5f, 72)
        )
        val boss = BossEntity(
            title = "OVERLORD VILGAX",
            x = 4120f, y = 296f, vx = -2.8f, hp = 44f, maxHp = 44f,
            minX = 3310f, maxX = 4390f, arenaStartX = 3080f, arenaEndX = 4480f, wave = 4
        )

        val doodles = mutableListOf<AmbientDoodle>()
        val creatures = mutableListOf<AmbientCreature>()
        populateChunkDoodlesAndCreatures(doodles, creatures, 60f, 740f, platforms[0])
        populateChunkDoodlesAndCreatures(doodles, creatures, 1160f, 1820f, platforms[4])
        populateChunkDoodlesAndCreatures(doodles, creatures, 2250f, 2950f, platforms[8])
        populateChunkDoodlesAndCreatures(doodles, creatures, 3080f, 4480f, platforms[11])
        spawnCreature(creatures, CreatureType.GWEN, 165f, 420f, 130f, 230f)
        spawnCreature(creatures, CreatureType.MAX, 240f, 420f, 210f, 310f)

        return LevelBuildResult(
            platforms, checkpoints, crates, collectibles, props, enemies, boss,
            doodles, creatures, 4480f, 99999f, 99999f
        )
    }

    private fun buildPracticeDojo(): LevelBuildResult {
        val platforms = mutableListOf(
            Platform(0f, 420f, 1520f, 120f, PlatformType.SOLID, keep = true),
            Platform(280f, 310f, 180f, 20f, PlatformType.TECH),
            Platform(560f, 235f, 185f, 20f, PlatformType.TECH),
            Platform(880f, 330f, 110f, 18f, PlatformType.BOUNCE),
            Platform(1080f, 270f, 200f, 20f, PlatformType.TECH)
        )
        val checkpoints = mutableListOf(Checkpoint(140f, 356f, active = true))
        val crates = mutableListOf(
            Crate(360f, 274f),
            Crate(720f, 384f, armored = true)
        )
        val collectibles = mutableListOf(
            Collectible(635f, 192f, kind = CollectibleKind.SMOOTHIE),
            Collectible(1165f, 225f, kind = CollectibleKind.CELL)
        )
        val props = mutableListOf(
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.THERMAL_SWITCH, 470f, 370f, 44f, 50f, hp = 2f, maxHp = 2f, label = "HEAT TEST"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SHIELD_CORE, 810f, 352f, 48f, 68f, hp = 4f, maxHp = 4f, label = "ARMOR TEST"),
            InteractiveProp(EntityIdCounter.next(), InteractivePropType.SPEED_GATE, 1020f, 310f, 34f, 110f, hp = 1f, maxHp = 1f, label = "XLR8 GATE")
        )
        val enemies = mutableListOf(
            createEnemy(EnemyType.BIOID, 600f, 372f, 40f, 48f, 0f, 560f, 680f, 5f, 140, isDummy = true),
            createEnemy(EnemyType.DRONE, 1150f, 180f, 38f, 48f, 0.9f, 1060f, 1340f, 4f, 130, isDummy = true),
            createEnemy(EnemyType.TURRET, 1380f, 372f, 36f, 48f, -1.0f, 1350f, 1440f, 4f, 100, isDummy = true)
        )
        val doodles = mutableListOf<AmbientDoodle>()
        val creatures = mutableListOf<AmbientCreature>()
        populateChunkDoodlesAndCreatures(doodles, creatures, 60f, 1460f, platforms[0])
        spawnCreature(creatures, CreatureType.MAX, 210f, 420f, 160f, 270f)
        spawnCreature(creatures, CreatureType.GWEN, 290f, 420f, 250f, 340f)

        return LevelBuildResult(
            platforms, checkpoints, crates, collectibles, props, enemies, null,
            doodles, creatures, 1520f, 99999f, 99999f
        )
    }

    private fun buildEndlessStarter(): LevelBuildResult {
        val platforms = mutableListOf(
            Platform(0f, 420f, 940f, 120f, PlatformType.SOLID, keep = true),
            Platform(280f, 315f, 170f, 20f, PlatformType.TECH),
            Platform(540f, 235f, 180f, 20f, PlatformType.TECH),
            Platform(780f, 315f, 105f, 18f, PlatformType.BOUNCE)
        )
        val crates = mutableListOf(
            Crate(430f, 384f),
            Crate(600f, 199f)
        )
        val collectibles = mutableListOf(
            Collectible(340f, 272f, kind = CollectibleKind.CELL),
            Collectible(615f, 192f, kind = CollectibleKind.SMOOTHIE),
            Collectible(820f, 230f, kind = CollectibleKind.CELL)
        )
        val enemies = mutableListOf(
            createEnemy(EnemyType.DRONE, 520f, 355f, 38f, 48f, 1.5f, 360f, 860f, 2f, 110)
        )
        val doodles = mutableListOf<AmbientDoodle>()
        val creatures = mutableListOf<AmbientCreature>()
        populateChunkDoodlesAndCreatures(doodles, creatures, 60f, 900f, platforms[0])
        spawnCreature(creatures, CreatureType.DOG, 230f, 420f, 120f, 460f)
        spawnCreature(creatures, CreatureType.ELEPHANT, 680f, 420f, 500f, 890f)
        spawnCreature(creatures, CreatureType.EAGLE, 440f, 110f, 60f, 920f)
        spawnCreature(creatures, CreatureType.GWEN, 180f, 420f, 160f, 220f)

        return LevelBuildResult(
            platforms, mutableListOf(), crates, collectibles, mutableListOf(), enemies, null,
            doodles, creatures, 940f, 1550f, 3300f
        )
    }

    fun generateNextEndlessChunk(
        startX: Float,
        distMeters: Int,
        bossesDefeated: Int,
        nextBossX: Float,
        nextCheckpointX: Float,
        platforms: MutableList<Platform>,
        checkpoints: MutableList<Checkpoint>,
        crates: MutableList<Crate>,
        collectibles: MutableList<Collectible>,
        props: MutableList<InteractiveProp>,
        enemies: MutableList<EnemyEntity>,
        doodles: MutableList<AmbientDoodle>,
        creatures: MutableList<AmbientCreature>
    ): Triple<Float, Float, BossEntity?> {
        // Returns (newGeneratedUntilX, newNextCheckpointX, spawnedBossOrNull)
        val difficulty = 1f + (distMeters / 350f).coerceAtMost(2.2f)

        if (startX >= nextBossX) {
            val arenaW = 1360f
            val ground = Platform(startX, 420f, arenaW, 120f, PlatformType.SOLID, isBossArena = true)
            platforms.addAll(
                listOf(
                    ground,
                    Platform(startX + 260f, 300f, 180f, 20f, PlatformType.TECH),
                    Platform(startX + 590f, 225f, 200f, 20f, PlatformType.TECH),
                    Platform(startX + 930f, 300f, 180f, 20f, PlatformType.TECH)
                )
            )
            checkpoints.add(Checkpoint(startX + 80f, 356f))
            crates.addAll(listOf(Crate(startX + 330f, 264f), Crate(startX + 1000f, 264f)))
            collectibles.addAll(
                listOf(
                    Collectible(startX + 675f, 185f, kind = CollectibleKind.SMOOTHIE),
                    Collectible(startX + 340f, 378f, kind = CollectibleKind.CELL)
                )
            )
            val waveHp = 30f + bossesDefeated * 12f
            val boss = BossEntity(
                title = "VILGAX — WAVE ${bossesDefeated + 1}",
                x = startX + 980f, y = 296f,
                vx = -(2.3f + (bossesDefeated * 0.35f).coerceAtMost(1.5f)),
                hp = waveHp, maxHp = waveHp,
                minX = startX + 240f, maxX = startX + arenaW - 90f,
                arenaStartX = startX, arenaEndX = startX + arenaW,
                wave = bossesDefeated + 1
            )
            populateChunkDoodlesAndCreatures(doodles, creatures, startX, startX + arenaW, ground)
            val newEnd = startX + arenaW
            return Triple(newEnd, newEnd + 1350f, boss)
        }

        if (startX >= nextCheckpointX) {
            val safeW = 680f
            val ground = Platform(startX, 420f, safeW, 120f, PlatformType.SOLID)
            platforms.addAll(listOf(ground, Platform(startX + 200f, 295f, 190f, 20f, PlatformType.TECH)))
            checkpoints.add(Checkpoint(startX + 140f, 356f))
            crates.add(Crate(startX + 430f, 384f))
            collectibles.addAll(
                listOf(
                    Collectible(startX + 280f, 252f, kind = CollectibleKind.SMOOTHIE),
                    Collectible(startX + 520f, 378f, kind = CollectibleKind.CELL)
                )
            )
            spawnCreature(creatures, if (Random.nextBoolean()) CreatureType.MAX else CreatureType.GWEN, startX + 230f, 420f, startX + 190f, startX + 340f)
            populateChunkDoodlesAndCreatures(doodles, creatures, startX, startX + safeW, ground)
            val newEnd = startX + safeW
            return Triple(newEnd, newEnd + 1450f, null)
        }

        return when (Random.nextInt(4)) {
            0 -> {
                val gx = startX + 85f + Random.nextFloat() * 40f
                val gw = 760f + Random.nextInt(140)
                val ground = Platform(gx, 420f, gw, 120f, PlatformType.SOLID)
                platforms.addAll(
                    listOf(
                        ground,
                        Platform(gx + 120f, 305f, 170f, 20f, PlatformType.TECH),
                        Platform(gx + 370f, 225f, 185f, 20f, PlatformType.TECH),
                        Platform(gx + gw - 150f, 315f, 105f, 18f, PlatformType.BOUNCE)
                    )
                )
                crates.add(Crate(gx + 290f, 384f, armored = Random.nextFloat() < 0.35f))
                collectibles.addAll(
                    listOf(
                        Collectible(gx + 195f, 265f, kind = CollectibleKind.CELL),
                        Collectible(gx + 445f, 185f, kind = if (Random.nextFloat() < 0.4f) CollectibleKind.SMOOTHIE else CollectibleKind.CELL)
                    )
                )
                enemies.addAll(
                    listOf(
                        createEnemy(if (Random.nextBoolean()) EnemyType.BIOID else EnemyType.HOUND, gx + 380f, 372f, 42f, 48f, -1.9f * difficulty.coerceAtMost(1.4f), gx + 110f, gx + gw - 60f, (2f + difficulty * 0.5f).roundToInt().toFloat(), 95),
                        createEnemy(EnemyType.TURRET, gx + 430f, 177f, 36f, 48f, 1.1f, gx + 385f, gx + 510f, 2f, 80)
                    )
                )
                populateChunkDoodlesAndCreatures(doodles, creatures, gx, gx + gw, ground)
                Triple(gx + gw, nextCheckpointX, null)
            }
            1 -> {
                val gx1 = startX + 90f
                val gw1 = 300f
                val g1 = Platform(gx1, 420f, gw1, 120f, PlatformType.SOLID)
                val bridgeX = gx1 + gw1 + 140f
                val gx2 = bridgeX + 270f
                val gw2 = 340f
                val g2 = Platform(gx2, 420f, gw2, 120f, PlatformType.SOLID)
                platforms.addAll(
                    listOf(
                        g1,
                        Platform(bridgeX, 345f, 165f, 20f, PlatformType.MOVING, startX = bridgeX, range = 95f, speed = 1.85f),
                        Platform(gx1 + 90f, 285f, 150f, 20f, PlatformType.TECH),
                        g2,
                        Platform(gx2 + 90f, 265f, 170f, 20f, PlatformType.TECH)
                    )
                )
                collectibles.addAll(
                    listOf(
                        Collectible(bridgeX + 65f, 295f, kind = CollectibleKind.CELL),
                        Collectible(gx2 + 155f, 222f, kind = CollectibleKind.SMOOTHIE)
                    )
                )
                enemies.addAll(
                    listOf(
                        createEnemy(EnemyType.DRONE, bridgeX - 20f, 210f, 38f, 48f, 1.8f, gx1 + 120f, gx2 + 120f, 2f, 85),
                        createEnemy(EnemyType.BIOID, gx2 + 140f, 372f, 40f, 48f, -2.1f, gx2 + 30f, gx2 + gw2 - 30f, 3f, 80)
                    )
                )
                populateChunkDoodlesAndCreatures(doodles, creatures, gx1, gx1 + gw1, g1)
                populateChunkDoodlesAndCreatures(doodles, creatures, gx2, gx2 + gw2, g2)
                Triple(gx2 + gw2, nextCheckpointX, null)
            }
            2 -> {
                val gx1 = startX + 80f
                val gw1 = 290f
                val g1 = Platform(gx1, 420f, gw1, 120f, PlatformType.SOLID)
                val gx2 = gx1 + gw1 + 310f
                val gw2 = 360f
                val g2 = Platform(gx2, 420f, gw2, 120f, PlatformType.SOLID)
                platforms.addAll(
                    listOf(
                        g1,
                        Platform(gx1 + gw1 - 115f, 340f, 105f, 18f, PlatformType.BOUNCE),
                        Platform(gx1 + gw1 + 70f, 240f, 175f, 20f, PlatformType.TECH),
                        g2
                    )
                )
                props.add(InteractiveProp(EntityIdCounter.next(), InteractivePropType.SPEED_GATE, gx1 + 110f, 310f, 32f, 110f, label = "SPEED GATE"))
                crates.add(Crate(gx1 + gw1 + 140f, 204f))
                collectibles.addAll(
                    listOf(
                        Collectible(gx1 + gw1 + 10f, 215f, kind = CollectibleKind.CELL),
                        Collectible(gx1 + gw1 + 225f, 195f, kind = CollectibleKind.CELL)
                    )
                )
                enemies.addAll(
                    listOf(
                        createEnemy(EnemyType.DRONE, gx1 + gw1 + 60f, 175f, 38f, 48f, 1.9f, gx1 + gw1 + 20f, gx2 + 120f, 2f, 75),
                        createEnemy(EnemyType.HOUND, gx2 + 120f, 372f, 42f, 48f, 2.2f, gx2 + 25f, gx2 + gw2 - 25f, 3f, 999)
                    )
                )
                populateChunkDoodlesAndCreatures(doodles, creatures, gx1, gx1 + gw1, g1)
                populateChunkDoodlesAndCreatures(doodles, creatures, gx2, gx2 + gw2, g2)
                Triple(gx2 + gw2, nextCheckpointX, null)
            }
            else -> {
                val gx = startX + 95f
                val gw = 840f
                val ground = Platform(gx, 420f, gw, 120f, PlatformType.SOLID)
                platforms.addAll(
                    listOf(
                        ground,
                        Platform(gx + 140f, 315f, 180f, 20f, PlatformType.TECH),
                        Platform(gx + 390f, 210f, 190f, 20f, PlatformType.TECH),
                        Platform(gx + 620f, 310f, 165f, 20f, PlatformType.TECH)
                    )
                )
                crates.addAll(listOf(Crate(gx + 210f, 279f), Crate(gx + 540f, 384f)))
                collectibles.addAll(
                    listOf(
                        Collectible(gx + 470f, 170f, kind = CollectibleKind.SMOOTHIE),
                        Collectible(gx + 690f, 270f, kind = CollectibleKind.CELL),
                        Collectible(gx + 320f, 380f, kind = CollectibleKind.CELL)
                    )
                )
                enemies.addAll(
                    listOf(
                        createEnemy(EnemyType.BIOID, gx + 260f, 372f, 40f, 48f, 2.0f, gx + 60f, gx + 520f, 3f, 85),
                        createEnemy(EnemyType.HOUND, gx + 630f, 372f, 42f, 48f, -2.3f, gx + 450f, gx + gw - 40f, 3f, 999),
                        createEnemy(EnemyType.DRONE, gx + 410f, 145f, 38f, 48f, 1.7f, gx + 260f, gx + 700f, 2f, 85)
                    )
                )
                populateChunkDoodlesAndCreatures(doodles, creatures, gx, gx + gw, ground)
                Triple(gx + gw, nextCheckpointX, null)
            }
        }
    }
}
