package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val SketchLightColorScheme = lightColorScheme(
    primary = OmnitrixGreen,
    onPrimary = OmnitrixDark,
    primaryContainer = OmnitrixBright,
    onPrimaryContainer = OmnitrixDark,
    secondary = BluePen,
    onSecondary = PaperCream,
    secondaryContainer = SkyPill,
    onSecondaryContainer = InkBlack,
    tertiary = GoldStar,
    background = PaperWarm,
    onBackground = InkBlack,
    surface = PaperCream,
    onSurface = InkBlack,
    surfaceVariant = PaperDark,
    onSurfaceVariant = GraphiteGray,
    error = RedPen,
    errorContainer = AlertBg,
    outline = InkBlack
)

@Composable
fun OmniverseRushTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SketchLightColorScheme,
        typography = SketchTypography,
        content = content
    )
}
