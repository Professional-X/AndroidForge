package com.example.data.local

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "run_records")
data class RunRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val modeId: String,
    val score: Int,
    val distanceMeters: Int,
    val bossesDefeated: Int,
    val starsEarned: Int,
    val victory: Boolean,
    val favoriteForm: String,
    val durationSec: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "mission_progress")
data class MissionProgressEntity(
    @PrimaryKey val missionId: String,
    val completed: Boolean = false,
    val bestStars: Int = 0,
    val bestScore: Int = 0,
    val bestTimeSec: Int = 0,
    val noDamageMedal: Boolean = false,
    val allShardsMedal: Boolean = false,
    val speedMedal: Boolean = false
)

@Dao
interface GameStatsDao {
    @Query("SELECT * FROM run_records ORDER BY score DESC LIMIT 12")
    fun getTopRuns(): Flow<List<RunRecordEntity>>

    @Query("SELECT * FROM run_records ORDER BY timestamp DESC LIMIT 10")
    fun getRecentRuns(): Flow<List<RunRecordEntity>>

    @Query("SELECT COALESCE(MAX(score), 0) FROM run_records WHERE modeId = 'ENDLESS'")
    fun getBestEndlessScore(): Flow<Int>

    @Query("SELECT COALESCE(MAX(distanceMeters), 0) FROM run_records WHERE modeId = 'ENDLESS'")
    fun getBestEndlessDistance(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRun(record: RunRecordEntity)

    @Query("SELECT * FROM mission_progress")
    fun getAllMissionProgress(): Flow<List<MissionProgressEntity>>

    @Query("SELECT * FROM mission_progress WHERE missionId = :missionId LIMIT 1")
    suspend fun getMissionProgressOnce(missionId: String): MissionProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMissionProgress(progress: MissionProgressEntity)
}
