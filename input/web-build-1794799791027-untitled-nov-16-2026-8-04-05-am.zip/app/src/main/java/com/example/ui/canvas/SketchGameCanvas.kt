package com.example.ui.canvas

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import com.example.game.AlienForm
import com.example.game.AmbientCreature
import com.example.game.AmbientDoodle
import com.example.game.BIOMES
import com.example.game.BossActionState
import com.example.game.CreatureType
import com.example.game.DoodleType
import com.example.game.EnemyBehaviorState
import com.example.game.EnemyType
import com.example.game.GameEngine
import com.example.game.GameScreenState
import com.example.game.InteractivePropType
import com.example.game.PlatformType
import com.example.game.ProjectileKind
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun SketchGameCanvas(
    engine: GameEngine,
    frameTick: Long,
    inkPaletteId: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val art = remember(context) { SketchArt(context) }
    art.applyPalette(inkPaletteId)

    val fillPaint = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL } }
    val strokePaint = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND } }
    val textPaint = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = art.markerTypeface } }
    val notePaint = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = art.noteTypeface } }
    val tempRect = remember { RectF() }
    val tempPath = remember { Path() }

    val gestureMod = modifier
        .fillMaxSize()
        .pointerInput(engine) {
            val activePointers = mutableMapOf<Long, TouchTrack>()
            awaitPointerEventScope {
                while (true) {
                    val event = awaitPointerEvent()
                    val w = size.width.toFloat().coerceAtLeast(1f)
                    val h = size.height.toFloat().coerceAtLeast(1f)
                    val viewW = (GameEngine.LOGICAL_HEIGHT * (w / h)).coerceAtLeast(320f)
                    engine.viewWidth = viewW
                    engine.viewHeight = GameEngine.LOGICAL_HEIGHT

                    if (engine.screenState != GameScreenState.PLAYING) {
                        activePointers.clear()
                        continue
                    }

                    for (change in event.changes) {
                        val id = change.id.value
                        val px = change.position.x
                        val py = change.position.y
                        val vx = (px / w) * viewW
                        val vy = (py / h) * GameEngine.LOGICAL_HEIGHT

                        when (event.type) {
                            PointerEventType.Press -> {
                                if (change.pressed && !change.previousPressed) {
                                    if (engine.radialDial.open) {
                                        engine.updateDialHover(vx, vy)
                                        activePointers[id] = TouchTrack(TouchRole.DIAL, px, py, vx, vy, System.currentTimeMillis())
                                    } else if (px < w * 0.46f) {
                                        engine.leftStick.active = true
                                        engine.leftStick.originX = vx
                                        engine.leftStick.originY = vy
                                        engine.leftStick.currX = vx
                                        engine.leftStick.currY = vy
                                        activePointers[id] = TouchTrack(TouchRole.LEFT_STICK, px, py, vx, vy, System.currentTimeMillis())
                                    } else {
                                        val isUpperJumpZone = py < h * 0.48f
                                        if (isUpperJumpZone) {
                                            engine.input.jumpHeld = true
                                        }
                                        activePointers[id] = TouchTrack(TouchRole.RIGHT_ACTION, px, py, vx, vy, System.currentTimeMillis(), isUpperJumpZone)
                                    }
                                    change.consume()
                                }
                            }
                            PointerEventType.Move -> {
                                val track = activePointers[id] ?: continue
                                when (track.role) {
                                    TouchRole.DIAL -> {
                                        engine.updateDialHover(vx, vy)
                                    }
                                    TouchRole.LEFT_STICK -> {
                                        engine.leftStick.currX = vx
                                        engine.leftStick.currY = vy
                                        val dx = vx - engine.leftStick.originX
                                        val dy = vy - engine.leftStick.originY
                                        val maxR = 46f
                                        engine.input.moveX = (dx / maxR).coerceIn(-1f, 1f)
                                        engine.input.moveY = (dy / maxR).coerceIn(-1f, 1f)
                                    }
                                    TouchRole.RIGHT_ACTION -> {
                                        val dx = px - track.startPx
                                        val dy = py - track.startPy
                                        val elapsed = System.currentTimeMillis() - track.startMs
                                        // Hold >= 240ms without large vertical swipe OR strong horizontal swipe opens 8-Alien Dial
                                        if (!track.consumedGesture && ((elapsed >= 240 && hypot(dx, dy) < 28f) || (abs(dx) > 65f && abs(dx) > abs(dy) * 1.4f))) {
                                            track.consumedGesture = true
                                            engine.input.jumpHeld = false
                                            engine.openRadialDial(vx, vy, byTouch = true)
                                            track.role = TouchRole.DIAL
                                        } else if (!track.consumedGesture && dy < -48f && abs(dy) > abs(dx) * 1.25f) {
                                            track.consumedGesture = true
                                            engine.triggerJump()
                                        } else if (!track.consumedGesture && dy > 48f && abs(dy) > abs(dx) * 1.25f) {
                                            track.consumedGesture = true
                                            engine.input.jumpHeld = false
                                            engine.triggerDownAction()
                                        }
                                    }
                                }
                                change.consume()
                            }
                            PointerEventType.Release -> {
                                if (!change.pressed && change.previousPressed) {
                                    val track = activePointers.remove(id)
                                    if (track != null) {
                                        when (track.role) {
                                            TouchRole.DIAL -> {
                                                engine.updateDialHover(vx, vy)
                                                engine.confirmDialSelection(commit = true)
                                            }
                                            TouchRole.LEFT_STICK -> {
                                                engine.leftStick.active = false
                                                engine.input.moveX = 0f
                                                engine.input.moveY = 0f
                                            }
                                            TouchRole.RIGHT_ACTION -> {
                                                engine.input.jumpHeld = false
                                                val dist = hypot(px - track.startPx, py - track.startPy)
                                                if (!track.consumedGesture && dist < 44f) {
                                                    // Non-competing right-side zones:
                                                    // Upper 48%: Jump/Fly; Lower 52% left half: Melee Combo; Lower 52% right edge: Special
                                                    when {
                                                        track.startPy < h * 0.48f -> engine.triggerJump()
                                                        track.startPx < w * 0.76f -> engine.triggerPunch()
                                                        else -> engine.triggerSpecialAction()
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    change.consume()
                                }
                            }
                        }
                    }
                }
            }
        }

    Canvas(modifier = gestureMod) {
        // Trigger recomposition cleanly every frame tick
        @Suppress("UNUSED_EXPRESSION")
        frameTick

        val w = size.width
        val h = size.height
        val viewW = (GameEngine.LOGICAL_HEIGHT * (w / h.coerceAtLeast(1f))).coerceAtLeast(320f)
        val viewH = GameEngine.LOGICAL_HEIGHT
        engine.viewWidth = viewW
        engine.viewHeight = viewH

        drawIntoCanvas { composeCanvas ->
            val c = composeCanvas.nativeCanvas
            c.save()
            val sx = w / viewW
            val sy = h / viewH
            c.scale(sx, sy)

            // 1. Paper surface + Decluttered Parallax Background
            art.renderPaperBackground(c, viewW, viewH, engine.biomeIndex)
            renderParallaxDoodles(c, art, engine, viewW, fillPaint, strokePaint, tempRect)

            // 2. Camera Space
            c.save()
            val shakeX = if (engine.shakeTimer > 0) (Random.nextFloat() - 0.5f) * engine.shakeIntensity * 2f else 0f
            val shakeY = if (engine.shakeTimer > 0) (Random.nextFloat() - 0.5f) * engine.shakeIntensity * 2f else 0f
            c.translate(-engine.cameraX + shakeX, -engine.cameraY + shakeY)

            // Decluttered B&W doodles (lower alpha so action lane pops!)
            renderBWDoodles(c, art, engine, viewW, fillPaint, strokePaint, notePaint)
            renderPlatforms(c, art, engine, viewW, fillPaint, strokePaint, tempRect)
            renderPropsAndCollectibles(c, art, engine, viewW, fillPaint, strokePaint, textPaint)
            renderAmbientCreatures(c, art, engine, viewW, fillPaint, strokePaint, notePaint, tempRect)
            renderEnemiesAndBoss(c, art, engine, viewW, fillPaint, strokePaint, textPaint, tempRect)
            renderPlayerAndAfterimages(c, art, engine, strokePaint, fillPaint)
            renderProjectilesAndVfx(c, art, engine, fillPaint, strokePaint, tempRect)

            c.restore()

            // 3. Softened Screen Flash & Low-HP Vignette
            if (engine.screenFlash > 0f) {
                val a = (engine.screenFlash * 255f).toInt().coerceIn(0, 60)
                fillPaint.color = (engine.screenFlashColorHex and 0x00FFFFFF) or (a shl 24)
                c.drawRect(0f, 0f, viewW, viewH, fillPaint)
            }
            if (engine.player.hp <= 30f && engine.screenState == GameScreenState.PLAYING) {
                val pulse = (0.14f + sin(engine.frameCount * 0.16f) * 0.06f).coerceIn(0.05f, 0.22f)
                strokePaint.color = (0x00DC2626) or ((pulse * 255).toInt() shl 24)
                strokePaint.strokeWidth = 18f
                c.drawRect(0f, 0f, viewW, viewH, strokePaint)
            }

            // 4. Touch Affordances, Floating Joystick & 8-Alien Radial Dial
            if (engine.screenState == GameScreenState.PLAYING) {
                renderSubtleTouchZoneHints(c, art, viewW, viewH, engine, notePaint, strokePaint)
                renderLeftTouchJoystick(c, engine, fillPaint, strokePaint)
                renderRadialDial(c, art, engine, viewW, viewH, fillPaint, strokePaint, textPaint, notePaint)
            }

            c.restore()
        }
    }
}

private enum class TouchRole { LEFT_STICK, RIGHT_ACTION, DIAL }

private data class TouchTrack(
    var role: TouchRole,
    val startPx: Float,
    val startPy: Float,
    val startVx: Float,
    val startVy: Float,
    val startMs: Long,
    val isUpperJump: Boolean = false,
    var consumedGesture: Boolean = false
)

private fun renderParallaxDoodles(
    c: Canvas,
    art: SketchArt,
    engine: GameEngine,
    viewW: Float,
    fillPaint: Paint,
    strokePaint: Paint,
    tempRect: RectF
) {
    // Low-contrast background skyline so gameplay silhouettes win every visual competition
    val bStep = 148f
    val bStart = kotlin.math.floor((engine.cameraX * 0.14f) / bStep).toInt() - 1
    val bCount = (viewW / bStep).toInt() + 3
    strokePaint.color = 0x3314161F
    strokePaint.strokeWidth = 1.4f

    for (i in bStart until bStart + bCount) {
        val h = 85f + (abs((i * 37) % 95))
        val bx = i * bStep - engine.cameraX * 0.14f
        val by = 420f - h - engine.cameraY * 0.45f
        c.drawRect(bx, by, bx + bStep - 18f, by + h + 130f, strokePaint)
        art.pencilCrosshatch(c, bx + (bStep - 18f) * 0.65f, by, (bStep - 18f) * 0.35f, h + 130f, 10f, 0x1614161F, false)
    }

    when (engine.biomeIndex.mod(4)) {
        0 -> {
            val mx = viewW * 0.78f - (engine.cameraX * 0.04f) % 400f
            val my = 76f - engine.cameraY * 0.08f
            art.highlighterGlow(c, mx, my, 46f, 0xFFFDE047.toInt(), 0.28f)
            art.sketchCircle(c, mx, my, 25f, 0xCCFEF08A.toInt(), 2.0f, 0x6614161F)

            for (car in engine.hoverCars) {
                val sx = car.x - engine.cameraX * 0.55f
                if (sx < -60f || sx > viewW + 60f) continue
                val sy = car.y - engine.cameraY * 0.4f
                art.sketchPoly(c, floatArrayOf(sx - 14f, sy + 9f, sx - 9f, sy, sx + 9f, sy, sx + 15f, sy + 9f), (car.colorHex and 0x00FFFFFF) or 0x77000000, 0x6614161F, 1.5f, rim = false)
            }
        }
        1 -> {
            strokePaint.color = 0x450E7490
            strokePaint.strokeWidth = 2f
            for (i in 0 until 6) {
                val gx = i * 280f + 90f - (engine.cameraX * 0.30f) % 280f
                val gy = 140f + (i % 2) * 100f
                c.drawCircle(gx, gy, 36f, strokePaint)
                c.drawCircle(gx, gy, 18f, strokePaint)
            }
        }
        2 -> {
            val px = viewW * 0.74f - (engine.cameraX * 0.05f) % 300f
            val py = 114f - engine.cameraY * 0.12f
            art.sketchCircle(c, px, py, 44f, 0x66FDA4AF, 2.2f, 0x6614161F)
            strokePaint.color = 0x66BE123C; strokePaint.strokeWidth = 3f
            tempRect.set(px - 84f, py - 18f, px + 84f, py + 18f)
            c.drawOval(tempRect, strokePaint)
        }
        else -> {
            strokePaint.color = 0x447E22CE; strokePaint.strokeWidth = 1.8f
            for (i in 0 until 4) {
                val vx = ((i * 270f + 90f - engine.cameraX * 0.2f) % (viewW + 200f) + viewW + 200f) % (viewW + 200f) - 100f
                val vy = 95f + (i % 3) * 65f
                c.drawCircle(vx, vy, 24f, strokePaint)
                c.drawCircle(vx, vy, 12f, strokePaint)
            }
        }
    }
}

private fun renderBWDoodles(
    c: Canvas,
    art: SketchArt,
    engine: GameEngine,
    viewW: Float,
    fillPaint: Paint,
    strokePaint: Paint,
    notePaint: Paint
) {
    // Softened opacity (0.58) keeps background doodles atmospheric without cluttering the action lane
    for (d in engine.ambientDoodles) {
        if (d.x < engine.cameraX - 150f || d.x > engine.cameraX + viewW + 150f) continue
        c.save()
        c.translate(d.x, d.y)
        c.scale(d.scale * d.flip, d.scale)
        strokePaint.color = 0x7814161F
        strokePaint.strokeWidth = 1.8f
        fillPaint.color = 0x99FBF6EA.toInt()

        when (d.type) {
            DoodleType.TREE -> {
                c.drawRect(-5f, -50f, 5f, 0f, fillPaint)
                c.drawRect(-5f, -50f, 5f, 0f, strokePaint)
                art.comicDustCloud(c, 0f, -66f, 26f, 0x7814161F, 0x99FBF6EA.toInt())
            }
            DoodleType.BENCH -> {
                c.drawRect(-24f, -22f, 24f, -12f, strokePaint)
                c.drawLine(-20f, -12f, -20f, 0f, strokePaint)
                c.drawLine(20f, -12f, 20f, 0f, strokePaint)
            }
            DoodleType.LAMP -> {
                c.drawLine(-2f, 0f, -2f, -90f, strokePaint)
                c.drawLine(-2f, -90f, 13f, -90f, strokePaint)
                c.drawCircle(13f, -82f, 6f, strokePaint)
            }
            DoodleType.HYDRANT -> {
                c.drawRect(-6f, -20f, 6f, 0f, strokePaint)
                c.drawCircle(0f, -20f, 6f, strokePaint)
            }
            DoodleType.SIGN -> {
                c.drawLine(0f, 0f, 0f, -50f, strokePaint)
                c.drawRect(-16f, -50f, 14f, -34f, strokePaint)
            }
            DoodleType.SKETCH_NOTE -> {
                c.scale(d.flip.toFloat(), 1f)
                c.rotate(-4f)
                c.drawRect(-38f, -14f, 38f, 12f, strokePaint)
                notePaint.color = 0x7814161F
                notePaint.textSize = 11f
                c.drawText(d.noteText, 0f, 3f, notePaint)
            }
            DoodleType.SPIRAL_CLOUD -> {
                art.comicDustCloud(c, 0f, 0f, 22f, 0x6614161F, 0x88FFFFFF.toInt())
            }
            DoodleType.PAPER_PLANE -> {
                val fy = sin(engine.frameCount * 0.05f + d.seed) * 6f
                art.sketchPoly(c, floatArrayOf(-15f, 4f + fy, 17f, -4f + fy, -7f, 12f + fy), 0xAAFFFDF8.toInt(), 0x7814161F, 1.8f, rim = false)
            }
        }
        c.restore()
    }
}

private fun renderPlatforms(
    c: Canvas,
    art: SketchArt,
    engine: GameEngine,
    viewW: Float,
    fillPaint: Paint,
    strokePaint: Paint,
    tempRect: RectF
) {
    val biome = BIOMES[engine.biomeIndex.mod(BIOMES.size)]
    val trim = biome.trimHex

    for (p in engine.platforms) {
        if (p.fallen || p.x + p.w < engine.cameraX - 80f || p.x > engine.cameraX + viewW + 80f) continue

        if (p.type == PlatformType.MOVING) {
            strokePaint.color = 0x6614161F
            strokePaint.strokeWidth = 2f
            strokePaint.pathEffect = art.getDashEffect()
            c.drawLine(p.startX - p.range, p.y + p.h * 0.5f, p.startX + p.range + p.w, p.y + p.h * 0.5f, strokePaint)
            strokePaint.pathEffect = null
        }

        when (p.type) {
            PlatformType.BOUNCE -> {
                val comp = sin(engine.frameCount * 0.22f) * 2.5f
                val midX = p.x + p.w * 0.5f
                art.sketchLine(c, midX - 18f, p.y + p.h + 16f, midX + 18f, p.y + p.h + 9f, width = 3f)
                art.sketchLine(c, midX + 18f, p.y + p.h + 9f, midX - 18f, p.y + p.h + 2f, width = 3f)
                art.sketchPoly(
                    c,
                    floatArrayOf(p.x, p.y + comp, p.x + p.w, p.y + comp, p.x + p.w, p.y + p.h + comp, p.x, p.y + p.h + comp),
                    0xFF84CC16.toInt(), strokeWidth = 2.8f
                )
                art.highlighterGlow(c, midX, p.y + comp + 6f, 28f, 0xFF4ADE80.toInt(), 0.35f)
            }
            PlatformType.SOLID -> {
                fillPaint.color = 0xFFE7E5E4.toInt()
                c.drawRect(p.x, p.y, p.x + p.w, p.y + p.h, fillPaint)
                art.pencilCrosshatch(c, p.x, p.y + 8f, p.w, p.h - 8f, 10f, 0x38282C34, true)
                fillPaint.color = (trim and 0x00FFFFFF) or 0xE0000000.toInt()
                c.drawRect(p.x, p.y, p.x + p.w, p.y + 8f, fillPaint)
                art.sketchLine(c, p.x, p.y, p.x + p.w, p.y, width = 3.2f, overhang = 4f)
                art.sketchLine(c, p.x, p.y, p.x, p.y + p.h, width = 2.8f, overhang = 3f)
                art.sketchLine(c, p.x + p.w, p.y, p.x + p.w, p.y + p.h, width = 2.8f, overhang = 3f)
            }
            PlatformType.COLLAPSING -> {
                val shake = if (p.collapseTimer > 0) sin(engine.frameCount * 1.4f) * 3f else 0f
                val fill = if (p.collapseTimer > 0) 0xFFFCA5A5.toInt() else 0xFFD6D3D1.toInt()
                art.sketchPoly(
                    c,
                    floatArrayOf(p.x + shake, p.y, p.x + p.w + shake, p.y, p.x + p.w + shake, p.y + p.h, p.x + shake, p.y + p.h),
                    fill, strokeWidth = 2.6f
                )
            }
            else -> {
                art.sketchPoly(
                    c,
                    floatArrayOf(p.x, p.y, p.x + p.w, p.y, p.x + p.w, p.y + p.h, p.x, p.y + p.h),
                    0xFF94A3B8.toInt(), strokeWidth = 2.6f
                )
                fillPaint.color = (trim and 0x00FFFFFF) or 0xDD000000.toInt()
                c.drawRect(p.x + 2f, p.y + 1f, p.x + p.w - 2f, p.y + 6f, fillPaint)
            }
        }
    }
}

private fun renderPropsAndCollectibles(
    c: Canvas,
    art: SketchArt,
    engine: GameEngine,
    viewW: Float,
    fillPaint: Paint,
    strokePaint: Paint,
    textPaint: Paint
) {
    // Checkpoints
    for (cp in engine.checkpoints) {
        if (cp.x < engine.cameraX - 80f || cp.x > engine.cameraX + viewW + 80f) continue
        val cx = cp.x + cp.w * 0.5f
        art.sketchLine(c, cx, cp.y + 18f, cx, cp.y + cp.h, width = 3.4f)
        if (cp.active) art.highlighterGlow(c, cx, cp.y + 14f, 28f, 0xFF4ADE80.toInt(), 0.55f)
        art.sketchCircle(c, cx, cp.y + 14f, 14f, if (cp.active) 0xFF10B981.toInt() else 0xFFE2E8F0.toInt(), 2.6f)
    }

    // Crates
    for (cr in engine.crates) {
        if (cr.broken || cr.x + cr.w < engine.cameraX - 60f || cr.x > engine.cameraX + viewW + 60f) continue
        art.sketchPoly(
            c,
            floatArrayOf(cr.x, cr.y, cr.x + cr.w, cr.y, cr.x + cr.w, cr.y + cr.h, cr.x, cr.y + cr.h),
            if (cr.armored) 0xFF64748B.toInt() else 0xFFA8A29E.toInt(), strokeWidth = 2.6f
        )
        val cx = cr.x + cr.w * 0.5f; val cy = cr.y + cr.h * 0.5f
        art.sketchCircle(c, cx, cy, 9.5f, 0xFF10B981.toInt(), 2f)
    }

    // Interactive Mission Props
    for (prop in engine.props) {
        if (prop.x + prop.w < engine.cameraX - 80f || prop.x > engine.cameraX + viewW + 80f) continue
        val cx = prop.x + prop.w * 0.5f
        val cy = prop.y + prop.h * 0.5f

        when (prop.type) {
            InteractivePropType.SHARD -> if (!prop.activated) {
                val bob = sin(engine.frameCount * 0.1f + prop.x * 0.04f) * 4f
                art.highlighterGlow(c, cx, cy + bob, 24f, 0xFF4ADE80.toInt(), 0.52f)
                art.sketchPoly(
                    c,
                    floatArrayOf(cx, prop.y + bob, prop.x + prop.w, cy + bob, cx, prop.y + prop.h + bob, prop.x, cy + bob),
                    0xFF22C55E.toInt(), strokeWidth = 2.5f
                )
            }
            InteractivePropType.THERMAL_SWITCH -> {
                val col = if (prop.activated) 0xFFF97316.toInt() else 0xFF94A3B8.toInt()
                art.sketchPoly(c, floatArrayOf(prop.x, prop.y + prop.h, prop.x + 8f, prop.y, prop.x + prop.w - 8f, prop.y, prop.x + prop.w, prop.y + prop.h), col, strokeWidth = 2.6f)
                if (prop.activated) art.drawSketchFlame(c, cx, prop.y + 4f, 18f, 28f, prop.x, engine.frameCount)
                else art.drawOutlinedText(c, "HEAT", cx, prop.y - 8f, 11f, 0xFFF97316.toInt())
            }
            InteractivePropType.SHIELD_CORE -> if (!prop.activated) {
                art.highlighterGlow(c, cx, cy, 32f, 0xFF06B6D4.toInt(), 0.35f)
                art.sketchPoly(c, floatArrayOf(prop.x, prop.y + prop.h, prop.x, prop.y + 12f, cx, prop.y, prop.x + prop.w, prop.y + 12f, prop.x + prop.w, prop.y + prop.h), 0xFF334155.toInt(), strokeWidth = 2.8f)
                art.sketchCircle(c, cx, cy + 4f, 11f, 0xFF22D3EE.toInt(), 2.2f)
                art.drawOutlinedText(c, "SMASH", cx, prop.y - 8f, 11f, 0xFFEF4444.toInt())
            }
            InteractivePropType.SPEED_GATE -> {
                val col = if (prop.activated) 0xFF4ADE80.toInt() else 0xFF06B6D4.toInt()
                strokePaint.color = col; strokePaint.strokeWidth = 4f
                c.drawRect(prop.x, prop.y, prop.x + prop.w, prop.y + prop.h, strokePaint)
                if (!prop.activated) art.drawOutlinedText(c, "XLR8", cx, prop.y - 8f, 11f, 0xFF06B6D4.toInt())
            }
            InteractivePropType.BREAKABLE_WALL -> if (!prop.activated) {
                art.sketchPoly(c, floatArrayOf(prop.x, prop.y, prop.x + prop.w, prop.y, prop.x + prop.w, prop.y + prop.h, prop.x, prop.y + prop.h), 0xFF78716C.toInt(), strokeWidth = 3f)
                art.sketchLine(c, prop.x + 6f, prop.y + 16f, prop.x + prop.w - 6f, prop.y + 52f, 0xFFEF4444.toInt(), 2.6f)
                art.sketchLine(c, prop.x + prop.w - 8f, prop.y + 38f, prop.x + 8f, prop.y + 84f, 0xFFEF4444.toInt(), 2.6f)
                art.drawOutlinedText(c, "BREAK!", cx, prop.y - 8f, 11f, 0xFFEF4444.toInt())
            }
            InteractivePropType.RESCUE_POD -> {
                val col = if (prop.activated) 0xFF4ADE80.toInt() else 0xFFA855F7.toInt()
                art.sketchPoly(c, floatArrayOf(prop.x, prop.y + prop.h, prop.x + 6f, prop.y + 10f, cx, prop.y, prop.x + prop.w - 6f, prop.y + 10f, prop.x + prop.w, prop.y + prop.h), col, strokeWidth = 2.6f)
                art.drawOutlinedText(c, if (prop.activated) "SAVED!" else "RESCUE", cx, prop.y - 8f, 11f, col)
            }
        }
    }

    // Collectibles
    for (col in engine.collectibles) {
        if (col.collected || col.x < engine.cameraX - 60f || col.x > engine.cameraX + viewW + 60f) continue
        val bob = sin(engine.frameCount * 0.1f + col.x * 0.05f) * 4f
        val cx = col.x + col.w * 0.5f; val cy = col.y + col.h * 0.5f + bob
        if (col.kind == com.example.game.CollectibleKind.SMOOTHIE) {
            art.highlighterGlow(c, cx, cy, 20f, 0xFFF472B6.toInt(), 0.45f)
            art.sketchPoly(c, floatArrayOf(cx - 8f, cy - 6f, cx + 8f, cy - 6f, cx + 6f, cy + 11f, cx - 6f, cy + 11f), 0xFFEC4899.toInt(), strokeWidth = 2.2f)
            art.sketchPoly(c, floatArrayOf(cx - 9f, cy - 9f, cx + 9f, cy - 9f, cx + 9f, cy - 5f, cx - 9f, cy - 5f), 0xFFFFFDF8.toInt(), strokeWidth = 2f)
            art.sketchLine(c, cx + 2f, cy - 9f, cx + 6f, cy - 16f, 0xFF16A34A.toInt(), 2.8f)
        } else {
            art.highlighterGlow(c, cx, cy, 20f, 0xFF4ADE80.toInt(), 0.48f)
            art.sketchCircle(c, cx, cy, 10f, 0xFF10B981.toInt(), 2.3f)
        }
    }
}

private fun renderAmbientCreatures(
    c: Canvas,
    art: SketchArt,
    engine: GameEngine,
    viewW: Float,
    fillPaint: Paint,
    strokePaint: Paint,
    notePaint: Paint,
    tempRect: RectF
) {
    for (cr in engine.ambientCreatures) {
        if (cr.x < engine.cameraX - 130f || cr.x > engine.cameraX + viewW + 130f) continue
        val bw = cr.bw
        val p = cr.phase
        c.save()
        c.translate(cr.x, cr.y)
        c.save()
        c.scale(cr.facing.toFloat(), 1f)

        when (cr.type) {
            CreatureType.BIRD -> {
                art.sketchOval(c, 0f, -10f, 9f, 6f, if (bw) 0xFFF5F5F4.toInt() else 0xFF38BDF8.toInt(), 2f)
                art.sketchCircle(c, 8f, -14f, 5f, if (bw) 0xFFF5F5F4.toInt() else 0xFF38BDF8.toInt(), 2f)
                art.sketchPoly(c, floatArrayOf(12f, -15f, 18f, -13f, 12f, -11f), if (bw) 0xFFD6D3D1.toInt() else 0xFFFACC15.toInt(), strokeWidth = 1.6f)
            }
            CreatureType.DOG -> {
                val trot = sin(p * 1.6f) * 4f
                art.sketchLine(c, -9f, -8f, -11f + trot, 0f, width = 2.2f)
                art.sketchLine(c, 8f, -8f, 9f - trot, 0f, width = 2.2f)
                art.sketchOval(c, 0f, -13f, 13f, 7.5f, if (bw) 0xFFF5F5F4.toInt() else 0xFFD97706.toInt(), 2.2f)
                art.sketchCircle(c, 12f, -20f, 7f, if (bw) 0xFFFFFDF8.toInt() else 0xFFF59E0B.toInt(), 2.2f)
            }
            CreatureType.ELEPHANT -> {
                val trunk = sin(p * 1.1f) * 4f
                art.sketchOval(c, 0f, -28f, 22f, 16f, if (bw) 0xFFE7E5E4.toInt() else 0xFF94A3B8.toInt(), 2.4f)
                art.sketchCircle(c, 18f, -34f, 11f, if (bw) 0xFFE7E5E4.toInt() else 0xFF94A3B8.toInt(), 2.4f)
                art.sketchLine(c, 26f, -31f, 32f, -16f + trunk, width = 5f)
            }
            CreatureType.EAGLE -> {
                art.sketchOval(c, 0f, 0f, 14f, 6f, if (bw) 0xFFE7E5E4.toInt() else 0xFF78350F.toInt(), 2.2f)
                art.sketchCircle(c, 13f, -3f, 6f, 0xFFFFFDF8.toInt(), 2f)
            }
            CreatureType.OWL -> {
                art.sketchOval(c, 0f, -16f, 11f, 14f, if (bw) 0xFFF5F5F4.toInt() else 0xFFA16207.toInt(), 2f)
                art.sketchCircle(c, -4f, -20f, 4f, 0xFFFFFDF8.toInt(), 1.6f)
                art.sketchCircle(c, 4f, -20f, 4f, 0xFFFFFDF8.toInt(), 1.6f)
            }
            CreatureType.CAT -> {
                art.sketchOval(c, 0f, -12f, 12f, 6.5f, if (bw) 0xFFE7E5E4.toInt() else 0xFFFB923C.toInt(), 2f)
                art.sketchCircle(c, 11f, -19f, 6f, if (bw) 0xFFE7E5E4.toInt() else 0xFFFB923C.toInt(), 2f)
            }
            CreatureType.FROG -> {
                art.sketchOval(c, 0f, -9f, 11f, 8f, if (bw) 0xFFF5F5F4.toInt() else 0xFF4ADE80.toInt(), 2f)
            }
            CreatureType.TURTLE -> {
                art.sketchOval(c, 0f, -8f, 13f, 9f, if (bw) 0xFFD6D3D1.toInt() else 0xFF15803D.toInt(), 2.2f)
                art.sketchCircle(c, 14f, -9f, 5f, if (bw) 0xFFE7E5E4.toInt() else 0xFF84CC16.toInt(), 2f)
            }
            CreatureType.MAX -> {
                art.sketchPoly(c, floatArrayOf(-10f, -34f, 10f, -34f, 10f, -14f, -10f, -14f), 0xFFEF4444.toInt(), strokeWidth = 2.2f)
                art.sketchLine(c, -5f, -14f, -5f, 0f, width = 4.5f)
                art.sketchLine(c, 5f, -14f, 5f, 0f, width = 4.5f)
                art.sketchCircle(c, 0f, -42f, 8.5f, 0xFFFED7AA.toInt(), 2.2f)
            }
            CreatureType.GWEN -> {
                art.sketchPoly(c, floatArrayOf(-8f, -33f, 8f, -33f, 8f, -14f, -8f, -14f), 0xFF38BDF8.toInt(), strokeWidth = 2.1f)
                art.sketchLine(c, -4f, -14f, -4f, 0f, width = 4f)
                art.sketchLine(c, 4f, -14f, 4f, 0f, width = 4f)
                art.sketchCircle(c, 0f, -41f, 8f, 0xFFFED7AA.toInt(), 2.1f)
            }
        }
        c.restore()

        if (cr.bubbleTimer > 0 && cr.bubbleText.isNotEmpty()) {
            val by = if (cr.type == CreatureType.ELEPHANT || cr.type == CreatureType.MAX || cr.type == CreatureType.GWEN) -62f else -42f
            tempRect.set(-30f, by - 14f, 30f, by + 6f)
            fillPaint.color = 0xEEFFFDF8.toInt()
            c.drawRoundRect(tempRect, 7f, 7f, fillPaint)
            strokePaint.color = art.currentInkColor; strokePaint.strokeWidth = 1.6f
            c.drawRoundRect(tempRect, 7f, 7f, strokePaint)
            notePaint.color = if (cr.bw) art.currentInkColor else 0xFFDC2626.toInt()
            notePaint.textSize = 10f
            c.drawText(cr.bubbleText, 0f, by - 1f, notePaint)
        }
        c.restore()
    }
}

private fun renderEnemiesAndBoss(
    c: Canvas,
    art: SketchArt,
    engine: GameEngine,
    viewW: Float,
    fillPaint: Paint,
    strokePaint: Paint,
    textPaint: Paint,
    tempRect: RectF
) {
    for (e in engine.enemies) {
        if (!e.alive || e.x + e.width < engine.cameraX - 80f || e.x > engine.cameraX + viewW + 80f) continue
        val cx = e.x + e.width * 0.5f
        val cy = e.y + e.height * 0.5f
        val isFlash = e.flash > 0

        c.save()
        c.translate(cx, cy)
        fillPaint.color = 0x38282C34
        tempRect.set(-e.width * 0.45f, e.height * 0.5f - 4f, e.width * 0.45f, e.height * 0.5f + 5f)
        c.drawOval(tempRect, fillPaint)

        when (e.type) {
            EnemyType.DRONE -> {
                art.sketchPoly(c, floatArrayOf(0f, -20f, 18f, 0f, 0f, 18f, -18f, 0f), if (isFlash) 0xFFFFFDF8.toInt() else 0xFFA855F7.toInt(), strokeWidth = 2.6f)
                art.sketchCircle(c, e.facing * 4f, -2f, 5f, 0xFFEF4444.toInt(), 1.8f)
            }
            EnemyType.BIOID -> {
                c.scale(e.facing.toFloat(), 1f)
                val walk = sin(engine.frameCount * 0.2f + e.id) * 5f
                art.sketchLine(c, -6f, 8f, -9f + walk, 23f, width = 4f)
                art.sketchLine(c, 6f, 8f, 9f - walk, 23f, width = 4f)
                art.sketchPoly(c, floatArrayOf(-14f, -10f, 14f, -10f, 12f, 12f, -12f, 12f), if (isFlash) 0xFFFFFDF8.toInt() else 0xFF64748B.toInt(), strokeWidth = 2.6f)
                art.sketchPoly(c, floatArrayOf(-11f, -24f, 12f, -24f, 14f, -10f, -11f, -10f), if (isFlash) 0xFFFFFDF8.toInt() else 0xFFDC2626.toInt(), strokeWidth = 2.5f)
            }
            EnemyType.TURRET -> {
                art.sketchLine(c, -14f, 24f, 0f, 4f, width = 3.5f)
                art.sketchLine(c, 14f, 24f, 0f, 4f, width = 3.5f)
                art.sketchPoly(c, floatArrayOf(-15f, -6f, 15f, -6f, 12f, 10f, -12f, 10f), if (isFlash) 0xFFFFFDF8.toInt() else 0xFF94A3B8.toInt(), strokeWidth = 2.5f)
                art.sketchCircle(c, 0f, -10f, 11f, if (isFlash) 0xFFFFFDF8.toInt() else 0xFFEF4444.toInt(), 2.5f)
                art.sketchLine(c, e.facing * 8f, -11f, e.facing * 24f, -11f, width = 4f)
            }
            EnemyType.HOUND -> {
                c.scale(e.facing.toFloat(), 1f)
                val leg = if (e.state == EnemyBehaviorState.PATROL) sin(engine.frameCount * 0.35f + e.id) * 6f else 0f
                art.sketchLine(c, -12f, 8f, -15f + leg, 23f, width = 3.4f)
                art.sketchLine(c, 14f, 8f, 16f - leg, 23f, width = 3.4f)
                art.sketchPoly(c, floatArrayOf(-18f, -6f, 12f, -10f, 20f, 0f, 15f, 10f, -16f, 10f), if (isFlash) 0xFFFFFDF8.toInt() else 0xFF9333EA.toInt(), strokeWidth = 2.6f)
            }
        }
        c.restore()

        // Enemy HP micro-bar when damaged
        if (e.hp < e.maxHp) {
            fillPaint.color = 0xFFE5E7EB.toInt()
            c.drawRect(e.x, e.y - 10f, e.x + e.width, e.y - 5f, fillPaint)
            fillPaint.color = 0xFFEF4444.toInt()
            c.drawRect(e.x, e.y - 10f, e.x + e.width * (e.hp / e.maxHp).coerceIn(0f, 1f), e.y - 5f, fillPaint)
        }

        // Clear ! warning indicator or Stun stars
        if (e.warn) {
            val wy = e.y - 22f
            art.highlighterGlow(c, cx, wy, 18f, 0xFFFACC15.toInt(), 0.7f)
            art.sketchCircle(c, cx, wy, 11f, 0xFFFEF08A.toInt(), 2.4f, 0xFFDC2626.toInt())
            textPaint.color = 0xFFDC2626.toInt()
            textPaint.textSize = 15f
            c.drawText("!", cx, wy + 5f, textPaint)
        } else if (e.state == EnemyBehaviorState.STUNNED) {
            art.drawOutlinedText(c, "★ STUN ★", cx, e.y - 16f, 11f, 0xFFFACC15.toInt())
        }
    }

    // Vilgax Boss
    val b = engine.boss
    if (b != null && b.alive && b.x + b.width > engine.cameraX - 150f && b.x < engine.cameraX + viewW + 150f) {
        val bx = b.x + b.width * 0.5f
        val by = b.y + b.height * 0.5f
        val bDir = if (engine.player.x + engine.player.width * 0.5f >= bx) 1f else -1f
        val isFlash = b.flashTimer > 0

        c.save()
        c.translate(bx, by)
        if (b.phase2) {
            strokePaint.color = 0xFFDC2626.toInt(); strokePaint.strokeWidth = 2.4f
            tempRect.set(-56f, -72f, 56f, 72f)
            c.drawOval(tempRect, strokePaint)
        }
        val stride = if (b.onGround) sin(engine.frameCount * 0.16f) * 6f else 0f
        art.sketchPoly(c, floatArrayOf(-26f, 26f, -8f, 26f, -6f + stride, 60f, -28f + stride, 60f), if (isFlash) 0xFFFFFDF8.toInt() else 0xFF334155.toInt(), strokeWidth = 3.5f)
        art.sketchPoly(c, floatArrayOf(8f, 26f, 26f, 26f, 28f - stride, 60f, 6f - stride, 60f), if (isFlash) 0xFFFFFDF8.toInt() else 0xFF334155.toInt(), strokeWidth = 3.5f)
        art.sketchPoly(c, floatArrayOf(-32f, -26f, 32f, -26f, 26f, 30f, -26f, 30f), if (isFlash) 0xFFFFFDF8.toInt() else 0xFF334155.toInt(), strokeWidth = 3.8f)
        art.sketchPoly(c, floatArrayOf(-32f, -26f, -50f, -44f, -24f, -34f), if (isFlash) 0xFFFFFDF8.toInt() else 0xFF881337.toInt(), strokeWidth = 3.2f)
        art.sketchPoly(c, floatArrayOf(32f, -26f, 50f, -44f, 24f, -34f), if (isFlash) 0xFFFFFDF8.toInt() else 0xFF881337.toInt(), strokeWidth = 3.2f)
        art.sketchCircle(c, 0f, -2f, 11f, 0xFFFB7185.toInt(), 2.5f)
        art.sketchLine(c, -30f, -14f, -42f, 20f, if (isFlash) 0xFFFFFDF8.toInt() else 0xFF65A30D.toInt(), 10f)
        art.sketchLine(c, 30f, -14f, 42f, 20f, if (isFlash) 0xFFFFFDF8.toInt() else 0xFF65A30D.toInt(), 10f)
        art.sketchCircle(c, 0f, -44f, 19f, if (isFlash) 0xFFFFFDF8.toInt() else 0xFF65A30D.toInt(), 3.4f)
        for (t in -2..2) {
            art.sketchLine(c, t * 5f, -30f, t * 7f + bDir * 3f, -14f + abs(t) * 2f, 0xFF4D7C0F.toInt(), 4.5f)
        }
        fillPaint.color = 0xFFEF4444.toInt()
        c.drawCircle(-6f + bDir * 2f, -49f, 3.2f, fillPaint)
        c.drawCircle(6f + bDir * 2f, -49f, 3.2f, fillPaint)
        c.restore()

        if (b.actionState == BossActionState.TELEGRAPH_LEAP || b.actionState == BossActionState.TELEGRAPH_VOLLEY) {
            art.drawOutlinedText(c, if (b.actionState == BossActionState.TELEGRAPH_LEAP) "! LEAP !" else "! BLAST !", bx, b.y - 24f, 15f, 0xFFDC2626.toInt())
        } else if (b.actionState == BossActionState.RECOVER) {
            art.drawOutlinedText(c, "COUNTER!", bx, b.y - 20f, 13f, 0xFF10B981.toInt())
        }
    }
}

private fun renderPlayerAndAfterimages(
    c: Canvas,
    art: SketchArt,
    engine: GameEngine,
    strokePaint: Paint,
    fillPaint: Paint
) {
    for (ai in engine.afterimages) {
        val alpha = (ai.life.toFloat() / ai.maxLife) * 0.35f
        art.drawHeroForm(c, ai.form, ai.x, ai.y, ai.width, ai.height, ai.facing, engine.player, engine.frameCount, false, alpha)
    }

    val p = engine.player
    if (p.invulnTimer > 0 && (p.invulnTimer / 3) % 2 == 0) return

    art.drawHeroForm(c, p.form, p.x, p.y, p.width, p.height, p.facing, p, engine.frameCount, engine.input.jumpHeld, 1f)

    if (p.form == AlienForm.DIAMONDHEAD && p.shieldTimer > 0) {
        val cx = p.x + p.width * 0.5f; val cy = p.y + p.height * 0.5f
        art.highlighterGlow(c, cx, cy, 46f, 0xFF2DD4BF.toInt(), 0.35f)
        strokePaint.color = 0xFF1D4ED8.toInt(); strokePaint.strokeWidth = 2.8f
        fillPaint.color = 0x302DD4BF
        c.drawCircle(cx, cy, 38f, fillPaint)
        c.drawCircle(cx, cy, 38f, strokePaint)
    }
}

private fun renderProjectilesAndVfx(
    c: Canvas,
    art: SketchArt,
    engine: GameEngine,
    fillPaint: Paint,
    strokePaint: Paint,
    tempRect: RectF
) {
    for (sm in engine.smokePuffs) {
        val alpha = ((sm.life.toFloat() / sm.maxLife) * 0.65f * 255).toInt().coerceIn(0, 255)
        art.comicDustCloud(c, sm.x, sm.y, sm.r, (0x0027272A) or (alpha shl 24), (sm.tintHex and 0x00FFFFFF) or (alpha shl 24))
    }

    for (fw in engine.flameWisps) {
        val alpha = (fw.life.toFloat() / 10f).coerceIn(0f, 1f)
        art.drawSketchFlame(c, fw.x, fw.y, fw.w, fw.h, fw.seed, engine.frameCount, alpha)
    }

    for (cs in engine.crystalSpires) {
        if (cs.delay > 0) continue
        val topY = cs.y - cs.curH
        val cx = cs.x + cs.w * 0.5f
        art.sketchPoly(c, floatArrayOf(cs.x, cs.y, cs.x + 3f, topY + cs.curH * 0.3f, cx, topY, cs.x + cs.w - 3f, topY + cs.curH * 0.3f, cs.x + cs.w, cs.y), 0xFF14B8A6.toInt(), strokeWidth = 2.5f)
    }

    for (sp in engine.slimePuddles) {
        art.sketchOval(c, sp.x + sp.w * 0.5f, sp.y + 4f, sp.w * 0.5f, 6f, 0xFF84CC16.toInt(), 2.2f)
    }

    for (pr in engine.projectiles) {
        val cx = pr.x + pr.w * 0.5f; val cy = pr.y + pr.h * 0.5f
        when (pr.kind) {
            ProjectileKind.ENEMY_ORB -> {
                // High-contrast enemy threat visual language (crimson core + spiky warning ring)
                art.highlighterGlow(c, cx, cy, pr.w * 0.9f, 0xFFDC2626.toInt(), 0.5f)
                art.sketchCircle(c, cx, cy, pr.w * 0.45f, 0xFFEF4444.toInt(), 2.6f, 0xFF450A0A.toInt())
                fillPaint.color = 0xFFFEF08A.toInt()
                c.drawCircle(cx, cy, pr.w * 0.18f, fillPaint)
            }
            ProjectileKind.MELEE -> {
                strokePaint.color = art.currentInkColor; strokePaint.strokeWidth = 5f
                tempRect.set(cx - pr.w * 0.5f, cy - pr.h * 0.45f, cx + pr.w * 0.5f, cy + pr.h * 0.45f)
                c.drawArc(tempRect, if (pr.facing > 0) -60f else 120f, 120f, false, strokePaint)
                strokePaint.color = pr.colorHex; strokePaint.strokeWidth = 3f
                c.drawArc(tempRect, if (pr.facing > 0) -60f else 120f, 120f, false, strokePaint)
            }
            ProjectileKind.FLAMESTREAM, ProjectileKind.FIREBALL -> {
                art.drawSketchFlame(c, cx, cy + pr.h * 0.35f, pr.w * 1.1f, pr.h * 1.4f, pr.seed, engine.frameCount, 1f)
            }
            ProjectileKind.NEUROLASER -> {
                art.sketchLine(c, pr.x, cy, pr.x + pr.w, cy, 0xFFF43F5E.toInt(), 5.5f)
                art.sketchLine(c, pr.x + 2f, cy, pr.x + pr.w - 2f, cy, 0xFFFEF08A.toInt(), 2.4f)
            }
            else -> {
                art.sketchCircle(c, cx, cy, (pr.w * 0.46f).coerceAtLeast(6f), pr.colorHex, 2.3f)
            }
        }
    }

    for (sw in engine.shockwaves) {
        val alpha = ((sw.life.toFloat() / sw.maxLife) * 255).toInt().coerceIn(0, 255)
        strokePaint.color = (sw.colorHex and 0x00FFFFFF) or (alpha shl 24)
        strokePaint.strokeWidth = 3.2f
        c.drawCircle(sw.x, sw.y, sw.r, strokePaint)
    }

    for (pt in engine.particles) {
        val alpha = ((pt.life / 12f).coerceIn(0f, 1f) * 255).toInt()
        fillPaint.color = (pt.colorHex and 0x00FFFFFF) or (alpha shl 24)
        c.drawCircle(pt.x, pt.y, pt.size * 0.65f, fillPaint)
    }

    for (ft in engine.floatingTexts) {
        art.drawOutlinedText(c, ft.text, ft.x, ft.y, ft.size, ft.colorHex, ft.tilt * 40f)
    }
}

private fun renderSubtleTouchZoneHints(
    c: Canvas,
    art: SketchArt,
    viewW: Float,
    viewH: Float,
    engine: GameEngine,
    notePaint: Paint,
    strokePaint: Paint
) {
    // Show whisper-quiet zone guides during first 6 seconds or Practice Dojo
    val showHints = engine.elapsedFrames < 360 || engine.currentMode == com.example.game.GameMode.PRACTICE
    if (!showHints) return

    notePaint.color = 0x5514161F
    notePaint.textSize = 12f
    c.drawText("SLIDE TO MOVE", viewW * 0.18f, viewH - 22f, notePaint)
    c.drawText("TAP JUMP / FLY ↑", viewW * 0.80f, viewH * 0.28f, notePaint)
    c.drawText("MELEE ⚔", viewW * 0.64f, viewH - 22f, notePaint)
    c.drawText("SPECIAL ★", viewW * 0.88f, viewH - 22f, notePaint)

    strokePaint.color = 0x2214161F
    strokePaint.strokeWidth = 1.4f
    strokePaint.pathEffect = art.getDashEffect()
    c.drawLine(viewW * 0.46f, 65f, viewW * 0.46f, viewH - 12f, strokePaint)
    c.drawLine(viewW * 0.46f, viewH * 0.48f, viewW - 12f, viewH * 0.48f, strokePaint)
    c.drawLine(viewW * 0.76f, viewH * 0.48f, viewW * 0.76f, viewH - 12f, strokePaint)
    strokePaint.pathEffect = null
}

private fun renderLeftTouchJoystick(
    c: Canvas,
    engine: GameEngine,
    fillPaint: Paint,
    strokePaint: Paint
) {
    if (!engine.leftStick.active) return
    val ox = engine.leftStick.originX; val oy = engine.leftStick.originY
    val cx = engine.leftStick.currX; val cy = engine.leftStick.currY

    strokePaint.color = 0x881D4ED8.toInt(); strokePaint.strokeWidth = 2.2f
    strokePaint.pathEffect = android.graphics.DashPathEffect(floatArrayOf(6f, 4f), 0f)
    c.drawCircle(ox, oy, 44f, strokePaint)
    strokePaint.pathEffect = null

    fillPaint.color = 0x401D4ED8
    c.drawCircle(cx, cy, 17f, fillPaint)
    strokePaint.color = 0xFF1D4ED8.toInt(); strokePaint.strokeWidth = 2.5f
    c.drawCircle(cx, cy, 17f, strokePaint)
}

private fun renderRadialDial(
    c: Canvas,
    art: SketchArt,
    engine: GameEngine,
    viewW: Float,
    viewH: Float,
    fillPaint: Paint,
    strokePaint: Paint,
    textPaint: Paint,
    notePaint: Paint
) {
    if (!engine.radialDial.open) return
    val cx = engine.radialDial.x
    val cy = engine.radialDial.y
    val ringR = 104f

    fillPaint.color = 0xBDF8F3E4.toInt()
    c.drawRect(0f, 0f, viewW, viewH, fillPaint)

    strokePaint.color = 0xAA1D4ED8.toInt(); strokePaint.strokeWidth = 2.4f
    c.drawCircle(cx, cy, ringR, strokePaint)

    strokePaint.pathEffect = art.getDashEffect()
    for (i in 0 until 8) {
        val a = (i / 8f) * (PI.toFloat() * 2f) - PI.toFloat() * 0.5f
        c.drawLine(cx, cy, cx + cos(a) * (ringR + 14f), cy + sin(a) * (ringR + 14f), strokePaint)
    }
    strokePaint.pathEffect = null

    val forms = AlienForm.entries
    for (i in forms.indices) {
        val form = forms[i]
        val isSel = i == engine.radialDial.selectedIdx
        val a = (i / 8f) * (PI.toFloat() * 2f) - PI.toFloat() * 0.5f
        val tx = cx + cos(a) * ringR
        val ty = cy + sin(a) * ringR
        val r = if (isSel) 31f else 23f

        if (isSel) art.highlighterGlow(c, tx, ty, 44f, form.colorHex, 0.58f)
        art.sketchCircle(c, tx, ty, r, if (isSel) form.colorHex else 0xFFFBF6EA.toInt(), if (isSel) 3.2f else 2.2f)

        textPaint.color = art.currentInkColor
        textPaint.textSize = if (isSel) 14f else 12f
        c.drawText(form.badgeIcon, tx, ty + 1f, textPaint)

        notePaint.color = art.currentInkColor
        notePaint.textSize = if (isSel) 10f else 8.5f
        c.drawText(form.shortName, tx, ty + 14f, notePaint)
    }

    val sel = forms[engine.radialDial.selectedIdx]
    art.sketchCircle(c, cx, cy, 35f, sel.colorHex, 3f)
    textPaint.color = art.currentInkColor
    textPaint.textSize = 12f
    c.drawText(sel.shortName, cx, cy + 4f, textPaint)
}
