package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

val PermanentMarkerFamily = FontFamily(
    Font(R.font.permanent_marker, FontWeight.Normal)
)

val ArchitectsDaughterFamily = FontFamily(
    Font(R.font.architects_daughter, FontWeight.Normal)
)

val PatrickHandFamily = FontFamily(
    Font(R.font.patrick_hand, FontWeight.Normal)
)

val SketchTypography = Typography(
    displaySmall = TextStyle(
        fontFamily = PermanentMarkerFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 28.sp,
        lineHeight = 32.sp,
        letterSpacing = 0.5.sp
    ),
    headlineSmall = TextStyle(
        fontFamily = PermanentMarkerFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 20.sp,
        lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
        fontFamily = PermanentMarkerFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 18.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = ArchitectsDaughterFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelMedium = TextStyle(
        fontFamily = PatrickHandFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        lineHeight = 16.sp
    ),
    labelSmall = TextStyle(
        fontFamily = PatrickHandFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        lineHeight = 13.sp
    )
)
