package com.example.game

import com.example.audio.SfxCue
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

class GameEngine(
    private val onPlaySfx: (SfxCue) -> Unit = {},
    private val onVibrate: (Long) -> Unit = {},
    private val onRunFinished: (RunSummary) -> Unit = {},
    private val onBiomeChanged: (Int) -> Unit = {}
) {
    companion object {
        const val LOGICAL_HEIGHT = 540f
        const val BASE_VIEW_WIDTH = 960f
        private const val MAX_PARTICLES = 90
        private const val MAX_SMOKE = 55
        private const val MAX_FLAMES = 70
        private const val MAX_FLOATING_TEXT = 24
    }

    var screenState: GameScreenState = GameScreenState.MENU
        private set
    var currentMode: GameMode = GameMode.MISSION_1
        private set

    var viewWidth: Float = BASE_VIEW_WIDTH
    var viewHeight: Float = LOGICAL_HEIGHT
    var cameraX: Float = 0f
    var cameraY: Float = 0f
    var cameraZoom: Float = 1f

    var frameCount: Int = 0
        private set
    var boilStep: Int = 0
        private set
    var elapsedFrames: Int = 0
        private set
    var dialSlowCounter: Int = 0
        private set
    var reducedMotion: Boolean = false
    var selectedInkPaletteId: String = "CLASSIC_INK"

    var score: Int = 0
        private set
    var maxPlayerX: Float = 80f
        private set
    var distMeters: Int = 0
        private set
    var bossesDefeated: Int = 0
        private set
    var biomeIndex: Int = 0
        private set
    var waveNumber: Int = 1
        private set
    var lives: Int = 3
        private set
    var combo: Int = 0
        private set
    var comboTimer: Int = 0
        private set
    var damageTaken: Int = 0
        private set

    var hitStopFrames: Int = 0
    var shakeTimer: Int = 0
    var shakeIntensity: Float = 0f
    var screenFlash: Float = 0f
    var screenFlashColorHex: Int = 0xFFFFFFFF.toInt()

    var bannerTimer: Int = 0
    var bannerSub: String = ""
    var bannerTitle: String = ""
    var contextualHint: String = ""
    var hintTimer: Int = 0
    private var combatHintShown = false

    val player = PlayerState()
    val input = InputState()
    val radialDial = RadialDialState()
    val leftStick = LeftJoystickState()

    val platforms = mutableListOf<Platform>()
    val checkpoints = mutableListOf<Checkpoint>()
    val crates = mutableListOf<Crate>()
    val collectibles = mutableListOf<Collectible>()
    val props = mutableListOf<InteractiveProp>()
    val enemies = mutableListOf<EnemyEntity>()
    var boss: BossEntity? = null
    val projectiles = mutableListOf<Projectile>()
    val slimePuddles = mutableListOf<SlimePuddle>()
    val crystalSpires = mutableListOf<CrystalSpire>()
    val ambientDoodles = mutableListOf<AmbientDoodle>()
    val ambientCreatures = mutableListOf<AmbientCreature>()
    val hoverCars = mutableListOf<HoverCar>()

    val particles = mutableListOf<Particle>()
    val smokePuffs = mutableListOf<SmokePuff>()
    val flameWisps = mutableListOf<FlameWisp>()
    val shockwaves = mutableListOf<Shockwave>()
    val impactBursts = mutableListOf<ImpactBurst>()
    val floatingTexts = mutableListOf<FloatingText>()
    val afterimages = mutableListOf<Afterimage>()

    private var generatedUntilX = 940f
    private var nextCheckpointX = 1550f
    private var nextBossX = 3300f
    private var arenaLockMinX = 0f
    private var arenaLockMaxX: Float? = null
    private var lastAnimalSfxFrame = -999
    private val formUsageFrames = mutableMapOf<AlienForm, Int>()

    init {
        initAmbientHoverCars()
        loadMenuBackdrop()
    }

    private fun initAmbientHoverCars() {
        hoverCars.clear()
        val colors = intArrayOf(0xFF10B981.toInt(), 0xFF06B6D4.toInt(), 0xFFF59E0B.toInt(), 0xFFF43F5E.toInt())
        for (i in 0 until 8) {
            hoverCars.add(
                HoverCar(
                    x = i * 240f,
                    y = 62f + (i % 4) * 36f,
                    vx = (if (i % 2 == 0) 1f else -1f) * (1.1f + (i % 3) * 0.45f),
                    colorHex = colors[i % colors.size]
                )
            )
        }
    }

    fun loadMenuBackdrop() {
        EntityIdCounter.reset()
        val res = LevelBuilder.buildModeWorld(GameMode.MISSION_1)
        applyLevelResult(res)
        biomeIndex = 0
        onBiomeChanged(biomeIndex)
        player.x = 120f
        player.y = 364f
        applyFormStats(AlienForm.BEN)
        screenState = GameScreenState.MENU
        cameraX = 0f
        cameraY = 0f
    }

    fun startNewRun(mode: GameMode) {
        currentMode = mode
        EntityIdCounter.reset()
        score = 0
        maxPlayerX = 80f
        distMeters = 0
        bossesDefeated = 0
        biomeIndex = mode.biomeIndex
        waveNumber = 1
        lives = if (mode == GameMode.PRACTICE) 99 else 3
        combo = 0
        comboTimer = 0
        damageTaken = 0
        elapsedFrames = 0
        dialSlowCounter = 0
        hitStopFrames = 0
        shakeTimer = 0
        shakeIntensity = 0f
        screenFlash = 0f
        cameraZoom = 1f
        combatHintShown = false
        formUsageFrames.clear()

        releaseAllInputs()
        radialDial.open = false

        projectiles.clear()
        slimePuddles.clear()
        crystalSpires.clear()
        particles.clear()
        smokePuffs.clear()
        flameWisps.clear()
        shockwaves.clear()
        impactBursts.clear()
        floatingTexts.clear()
        afterimages.clear()

        val built = LevelBuilder.buildModeWorld(mode)
        applyLevelResult(built)

        player.hp = 100f
        player.maxHp = 100f
        player.energy = 100f
        player.maxEnergy = 100f
        player.vx = 0f
        player.vy = 0f
        player.x = 80f
        player.y = 364f
        player.facing = 1
        player.invulnTimer = 0
        player.punchCooldown = 0
        player.specialCooldown = 0
        player.attackAnimTimer = 0
        player.attackPhase = AttackPhase.IDLE
        player.comboStep = 0
        player.comboWindowTimer = 0
        player.dashTimer = 0
        player.rollTimer = 0
        player.shieldTimer = 0
        player.slamming = false
        player.squashX = 1f
        player.squashY = 1f
        player.walkPhase = 0f
        player.wingPhase = 0f
        player.landingRecoilTimer = 0
        player.damageRecoilTimer = 0
        player.transformPoseTimer = 0
        player.celebrationTimer = 0
        player.checkpointX = 80f
        player.checkpointY = 364f
        player.dashHitIds.clear()
        applyFormStats(AlienForm.BEN)

        arenaLockMinX = 0f
        arenaLockMaxX = null
        cameraX = 0f
        cameraY = 0f
        screenState = GameScreenState.PLAYING
        onBiomeChanged(biomeIndex)

        val mission = MISSIONS.find { it.mode == mode }
        if (mission != null) {
            showBanner("MISSION ${mission.number}", mission.zoneName)
            if (mode == GameMode.MISSION_1) {
                contextualHint = "Slide Left to Move  •  Tap Jump (↗)  •  Tap Watch (10) to Transform"
                hintTimer = 340
            } else {
                contextualHint = mission.objectiveSummary
                hintTimer = 260
            }
        } else if (mode == GameMode.PRACTICE) {
            showBanner("TRAINING ARENA", "PRACTICE DOJO • ALL 8 ALIENS")
            contextualHint = "Test all 8 forms, 3-hit combos, Thermal Switches & Speed Gates safely!"
            hintTimer = 300
        } else {
            showBanner("ENDLESS ZONE 1", BIOMES[0].title)
            contextualHint = "Outrun Vilgax's army! Tap Watch (10) anytime to switch aliens."
            hintTimer = 260
        }
    }

    private fun applyLevelResult(res: LevelBuildResult) {
        platforms.clear(); platforms.addAll(res.platforms)
        checkpoints.clear(); checkpoints.addAll(res.checkpoints)
        crates.clear(); crates.addAll(res.crates)
        collectibles.clear(); collectibles.addAll(res.collectibles)
        props.clear(); props.addAll(res.props)
        enemies.clear(); enemies.addAll(res.enemies)
        boss = res.boss
        ambientDoodles.clear(); ambientDoodles.addAll(res.ambientDoodles)
        ambientCreatures.clear(); ambientCreatures.addAll(res.ambientCreatures)
        generatedUntilX = res.generatedUntilX
        nextCheckpointX = res.nextCheckpointX
        nextBossX = res.nextBossX
    }

    fun pause() {
        if (screenState == GameScreenState.PLAYING) {
            screenState = GameScreenState.PAUSED
            radialDial.open = false
            releaseAllInputs()
        }
    }

    fun resume() {
        if (screenState == GameScreenState.PAUSED) {
            screenState = GameScreenState.PLAYING
            releaseAllInputs()
        }
    }

    fun returnToMenu() {
        radialDial.open = false
        releaseAllInputs()
        loadMenuBackdrop()
    }

    fun releaseAllInputs() {
        input.clearAll()
        leftStick.active = false
    }

    fun showBanner(sub: String, title: String) {
        bannerSub = sub
        bannerTitle = title
        bannerTimer = 155
    }

    // -------------------------------------------------------------------------
    // Transformations & Radial Dial
    // -------------------------------------------------------------------------
    fun applyFormStats(form: AlienForm) {
        val oldBottom = player.y + player.height
        val oldW = player.width
        player.form = form
        player.speed = form.speed
        player.jumpPower = form.jumpPower
        player.gravity = form.gravity
        player.width = form.width
        player.height = form.height
        player.maxJumps = form.maxJumps
        player.canFly = form.canFly
        player.x += (oldW - form.width) * 0.5f
        player.y = oldBottom - form.height
        player.jumpsLeft = if (player.onGround) form.maxJumps else minOf(player.jumpsLeft, form.maxJumps).coerceAtLeast(0)
    }

    fun transformTo(form: AlienForm, silent: Boolean = false) {
        if (player.form == form && !silent) return
        applyFormStats(form)
        player.dashTimer = 0
        player.rollTimer = 0
        player.slamming = false
        player.comboStep = 0
        player.squashX = 1.32f
        player.squashY = 0.72f
        player.transformPoseTimer = 16

        if (!silent) {
            onPlaySfx(SfxCue.TRANSFORM)
            onVibrate(20)
            hitStopFrames = maxOf(hitStopFrames, 3)
            triggerFlash(form.colorHex, 0.14f)
            addScreenShake(4f, 8)
            val cx = player.x + player.width * 0.5f
            val cy = player.y + player.height * 0.5f
            addShockwave(cx, cy, 8f, 88f, form.colorHex, 18)
            addImpactBurst(cx, cy, 44f, 0xFF4ADE80.toInt(), 13)
            spawnParticles(cx, cy, 14, form.colorHex, "spark")
            addFloatingText(cx, player.y - 16f, "${form.shortName}!", form.colorHex, 17f)
        }
    }

    fun cycleAlien(dir: Int) {
        val all = AlienForm.entries
        val idx = all.indexOf(player.form)
        val next = (idx + dir + all.size) % all.size
        transformTo(all[next])
    }

    fun openRadialDial(dialViewX: Float = viewWidth * 0.5f, dialViewY: Float = viewHeight * 0.5f, byTouch: Boolean = true) {
        if (screenState != GameScreenState.PLAYING) return
        radialDial.open = true
        radialDial.byTouch = byTouch
        radialDial.x = dialViewX.coerceIn(135f, (viewWidth - 135f).coerceAtLeast(135f))
        radialDial.y = dialViewY.coerceIn(135f, (viewHeight - 135f).coerceAtLeast(135f))
        radialDial.selectedIdx = AlienForm.entries.indexOf(player.form).coerceAtLeast(0)
        onPlaySfx(SfxCue.DIAL_CLICK)
    }

    fun updateDialHover(dialViewX: Float, dialViewY: Float) {
        if (!radialDial.open) return
        val dx = dialViewX - radialDial.x
        val dy = dialViewY - radialDial.y
        if (hypot(dx, dy) < 22f) return
        var ang = atan2(dy, dx) + (PI.toFloat() * 0.5f)
        if (ang < 0f) ang += (PI.toFloat() * 2f)
        val newIdx = (floor((ang / (PI.toFloat() * 2f)) * 8f + 0.5f).toInt()) % 8
        if (newIdx != radialDial.selectedIdx) {
            radialDial.selectedIdx = newIdx
            onPlaySfx(SfxCue.DIAL_CLICK)
            onVibrate(8)
        }
    }

    fun confirmDialSelection(commit: Boolean = true) {
        if (!radialDial.open) return
        val chosen = AlienForm.entries[radialDial.selectedIdx]
        radialDial.open = false
        if (commit) {
            transformTo(chosen)
        }
    }

    // -------------------------------------------------------------------------
    // Combat & Movement Triggers (3-Step Melee Combo + Air Slam + Specials)
    // -------------------------------------------------------------------------
    fun triggerJump() {
        if (screenState != GameScreenState.PLAYING) return
        if (player.canFly) {
            player.vy = minOf(player.vy, -6.5f)
            player.onGround = false
            player.wingPhase += 1.4f
            player.squashX = 0.86f
            player.squashY = 1.18f
            onPlaySfx(SfxCue.WING_FLAP)
            onVibrate(10)
            spawnParticles(player.x + player.width * 0.5f, player.y + player.height * 0.7f, 3, player.form.accentHex, "dust")
            return
        }

        if (player.onGround || player.coyoteTimer > 0) {
            player.vy = player.jumpPower
            player.onGround = false
            player.coyoteTimer = 0
            player.jumpsLeft = (player.maxJumps - 1).coerceAtLeast(0)
            player.squashX = 0.76f
            player.squashY = 1.28f
            onPlaySfx(SfxCue.JUMP)
            onVibrate(12)
            spawnParticles(player.x + player.width * 0.5f, player.y + player.height, 6, 0xFFA8A29E.toInt(), "dust")
        } else if (player.jumpsLeft > 0) {
            player.vy = player.jumpPower * 0.92f
            player.jumpsLeft -= 1
            player.squashX = 0.80f
            player.squashY = 1.25f
            onPlaySfx(SfxCue.DOUBLE_JUMP)
            onVibrate(12)
            addShockwave(player.x + player.width * 0.5f, player.y + player.height, 6f, 42f, player.form.colorHex, 14)
        } else {
            player.jumpBuffer = 8
        }
    }

    fun triggerPunch() {
        if (screenState != GameScreenState.PLAYING || player.punchCooldown > 0) return
        val dir = player.facing
        val cx = player.x + player.width * 0.5f
        val cy = player.y + player.height * 0.5f

        // 3-step combo progression (Light -> Follow-up -> Finisher)
        val step = if (player.comboWindowTimer > 0) (player.comboStep + 1) % 3 else 0
        player.comboStep = step
        player.comboWindowTimer = 38
        val stepMult = when (step) {
            0 -> 1.0f
            1 -> 1.25f
            else -> 1.65f
        }
        val finisherBoost = step == 2

        player.attackAnimDuration = if (finisherBoost) 16 else 13
        player.attackAnimTimer = player.attackAnimDuration
        player.attackAnimType = if (finisherBoost) "finisher" else "punch"
        player.attackPhase = AttackPhase.WINDUP
        player.squashX = if (finisherBoost) 1.32f else 1.22f
        player.squashY = if (finisherBoost) 0.78f else 0.85f

        when (player.form) {
            AlienForm.BEN -> {
                player.punchCooldown = if (finisherBoost) 16 else 12
                spawnMelee(
                    style = if (finisherBoost) "benfinisher" else "benkick",
                    x = if (dir > 0) cx else cx - 58f,
                    y = player.y + 6f,
                    w = if (finisherBoost) 64f else 54f,
                    h = 44f,
                    vx = dir * (if (finisherBoost) 3.4f else 2.2f),
                    vy = if (finisherBoost) -1.2f else 0f,
                    dmg = 1.5f * stepMult,
                    life = 10,
                    colorHex = 0xFF10B981.toInt(),
                    heavyBreak = finisherBoost
                )
                onPlaySfx(SfxCue.PUNCH)
            }
            AlienForm.HEATBLAST -> {
                player.punchCooldown = 14
                spawnMelee(
                    style = "fireuppercut",
                    x = if (dir > 0) cx + 4f else cx - 60f,
                    y = player.y - 6f,
                    w = 56f,
                    h = 56f,
                    vx = dir * 2.8f,
                    vy = -1.8f,
                    dmg = 2.0f * stepMult,
                    life = 12,
                    colorHex = 0xFFF97316.toInt(),
                    burns = true,
                    heavyBreak = finisherBoost
                )
                spawnFlamePlume(cx + dir * 26f, cy, 3, 20f, 34f, dir * 2.2f, -2.5f)
                onPlaySfx(SfxCue.FLAME)
            }
            AlienForm.XLR8 -> {
                player.punchCooldown = 9
                spawnMelee(
                    style = "xlr8flurry",
                    x = if (dir > 0) cx + 2f else cx - 66f,
                    y = player.y + 6f,
                    w = 64f,
                    h = 42f,
                    vx = dir * 3.8f,
                    vy = 0f,
                    dmg = 1.35f * stepMult,
                    life = 8,
                    colorHex = 0xFF06B6D4.toInt()
                )
                spawnParticles(cx + dir * 26f, cy, 6, 0xFF22D3EE.toInt(), "spark")
                onPlaySfx(SfxCue.ZIP)
            }
            AlienForm.FOURARMS -> {
                player.punchCooldown = 16
                spawnMelee(
                    style = "quadpunch",
                    x = if (dir > 0) cx + 4f else cx - 78f,
                    y = player.y - 4f,
                    w = 74f,
                    h = 64f,
                    vx = dir * 1.9f,
                    vy = 0f,
                    dmg = 2.8f * stepMult,
                    life = 12,
                    colorHex = 0xFFEF4444.toInt(),
                    heavyBreak = true
                )
                if (finisherBoost) addScreenShake(4.5f, 9)
                onPlaySfx(SfxCue.SMASH)
            }
            AlienForm.DIAMONDHEAD -> {
                player.punchCooldown = 14
                spawnMelee(
                    style = "crystalslash",
                    x = if (dir > 0) cx + 4f else cx - 70f,
                    y = player.y,
                    w = 66f,
                    h = 56f,
                    vx = dir * 2.1f,
                    vy = 0f,
                    dmg = 2.2f * stepMult,
                    life = 10,
                    colorHex = 0xFF14B8A6.toInt(),
                    heavyBreak = finisherBoost
                )
                onPlaySfx(SfxCue.CRYSTAL)
            }
            AlienForm.CANNONBOLT -> {
                player.punchCooldown = 15
                player.vx = dir * (if (finisherBoost) 11f else 9f)
                spawnMelee(
                    style = "shoulderbash",
                    x = if (dir > 0) cx else cx - 58f,
                    y = player.y + 4f,
                    w = 58f,
                    h = 48f,
                    vx = dir * 3.2f,
                    vy = 0f,
                    dmg = 2.3f * stepMult,
                    life = 11,
                    colorHex = 0xFFEAB308.toInt(),
                    heavyBreak = true
                )
                spawnSmoke(cx - dir * 10f, player.y + player.height - 6f, 2, 13f, -dir * 1.2f, -0.8f)
                onPlaySfx(SfxCue.PUNCH)
            }
            AlienForm.JETRAY -> {
                player.punchCooldown = 12
                spawnMelee(
                    style = "wingslash",
                    x = cx - 38f,
                    y = cy - 30f,
                    w = 76f,
                    h = 60f,
                    vx = dir * 2.6f,
                    vy = 0f,
                    dmg = 1.9f * stepMult,
                    life = 10,
                    colorHex = 0xFFF43F5E.toInt()
                )
                onPlaySfx(SfxCue.WING_FLAP)
                onPlaySfx(SfxCue.PUNCH)
            }
            AlienForm.STINKFLY -> {
                player.punchCooldown = 13
                spawnMelee(
                    style = "stinger",
                    x = if (dir > 0) cx + 6f else cx - 66f,
                    y = cy - 16f,
                    w = 60f,
                    h = 32f,
                    vx = dir * 3.0f,
                    vy = 0f,
                    dmg = 1.95f * stepMult,
                    life = 10,
                    colorHex = 0xFF84CC16.toInt(),
                    slows = true
                )
                onPlaySfx(SfxCue.SLIME)
            }
        }
        onVibrate(12)
    }

    private fun spawnMelee(
        style: String,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        vx: Float,
        vy: Float,
        dmg: Float,
        life: Int,
        colorHex: Int,
        burns: Boolean = false,
        slows: Boolean = false,
        heavyBreak: Boolean = false
    ) {
        projectiles.add(
            Projectile(
                id = EntityIdCounter.next(),
                fromPlayer = true,
                kind = ProjectileKind.MELEE,
                style = style,
                x = x,
                y = y,
                w = w,
                h = h,
                vx = vx,
                vy = vy,
                dmg = dmg,
                life = life,
                maxLife = life,
                colorHex = colorHex,
                facing = player.facing,
                pierce = true,
                burns = burns,
                slows = slows,
                heavyBreak = heavyBreak
            )
        )
    }

    fun triggerDownAction() {
        if (screenState != GameScreenState.PLAYING) return
        if (!player.onGround && !player.canFly) {
            if (!player.slamming) {
                player.slamming = true
                player.vy = when (player.form) {
                    AlienForm.FOURARMS -> 18.5f
                    AlienForm.CANNONBOLT -> 17f
                    else -> 15f
                }
                player.vx *= 0.25f
                player.squashX = 0.74f
                player.squashY = 1.32f
                onPlaySfx(SfxCue.JUMP)
            }
        } else {
            triggerPunch()
        }
    }

    fun triggerSpecialAction() {
        if (screenState != GameScreenState.PLAYING || player.specialCooldown > 0) return
        val cx = player.x + player.width * 0.5f
        val cy = player.y + player.height * 0.48f
        val dir = player.facing
        player.attackAnimDuration = 16
        player.attackAnimTimer = 16
        player.attackAnimType = "special"
        player.attackPhase = AttackPhase.WINDUP
        player.squashX = 1.2f
        player.squashY = 0.85f

        when (player.form) {
            AlienForm.BEN -> {
                player.specialCooldown = 22
                player.specialMaxCooldown = 22
                projectiles.add(
                    Projectile(
                        id = EntityIdCounter.next(),
                        fromPlayer = true,
                        kind = ProjectileKind.OMNIDISC,
                        x = cx + dir * 12f - 15f,
                        y = cy - 15f,
                        w = 30f,
                        h = 30f,
                        vx = dir * 11.5f,
                        vy = 0f,
                        accelX = -dir * 0.42f,
                        dmg = 2.0f,
                        life = 56,
                        maxLife = 56,
                        colorHex = 0xFF10B981.toInt(),
                        facing = dir,
                        pierce = true
                    )
                )
                onPlaySfx(SfxCue.DISC)
                onVibrate(14)
                addFloatingText(cx, player.y - 12f, "OMNI DISC!", 0xFF10B981.toInt(), 15f)
            }
            AlienForm.HEATBLAST -> {
                player.specialCooldown = 22
                player.specialMaxCooldown = 22
                for (f in 0 until 3) {
                    projectiles.add(
                        Projectile(
                            id = EntityIdCounter.next(),
                            fromPlayer = true,
                            kind = ProjectileKind.FLAMESTREAM,
                            x = cx + dir * (16f + f * 18f) - 15f,
                            y = cy - 16f,
                            w = 30f,
                            h = 32f,
                            vx = dir * (7.2f + f * 1.4f),
                            vy = (f - 1) * 0.45f,
                            gravity = -0.04f,
                            dmg = 1.5f,
                            life = 24 + f * 4,
                            maxLife = 32,
                            colorHex = 0xFFF97316.toInt(),
                            facing = dir,
                            pierce = true,
                            burns = true,
                            seed = (f + frameCount).toFloat()
                        )
                    )
                }
                projectiles.add(
                    Projectile(
                        id = EntityIdCounter.next(),
                        fromPlayer = true,
                        kind = ProjectileKind.FIREBALL,
                        x = cx + dir * 20f - 11f,
                        y = cy - 11f,
                        w = 22f,
                        h = 22f,
                        vx = dir * 10.6f,
                        vy = -0.6f,
                        gravity = 0.04f,
                        dmg = 2.2f,
                        life = 52,
                        maxLife = 52,
                        colorHex = 0xFFEF4444.toInt(),
                        facing = dir,
                        burns = true
                    )
                )
                spawnFlamePlume(cx + dir * 24f, cy, 4, 22f, 32f, dir * 3.5f, -1.8f)
                onPlaySfx(SfxCue.FLAME)
                onVibrate(18)
                addFloatingText(cx, player.y - 14f, "FWOOOSH!", 0xFFF97316.toInt(), 16f)
            }
            AlienForm.XLR8 -> {
                if (player.energy >= 14f) {
                    player.energy -= 14f
                    player.specialCooldown = 20
                    player.specialMaxCooldown = 20
                    player.dashTimer = 16
                    player.vx = dir * 17.5f
                    player.vy = -0.8f
                    player.dashHitIds.clear()
                    projectiles.add(
                        Projectile(
                            id = EntityIdCounter.next(),
                            fromPlayer = true,
                            kind = ProjectileKind.TORNADO,
                            x = cx + dir * 16f - 20f,
                            y = player.y + player.height - 68f,
                            w = 40f,
                            h = 68f,
                            vx = dir * 10.2f,
                            vy = 0f,
                            dmg = 2.4f,
                            life = 42,
                            maxLife = 42,
                            colorHex = 0xFF06B6D4.toInt(),
                            facing = dir,
                            pierce = true
                        )
                    )
                    onPlaySfx(SfxCue.ZIP)
                    onPlaySfx(SfxCue.TORNADO)
                    onVibrate(18)
                    addFloatingText(cx, player.y - 14f, "CYCLONE ZOOM!", 0xFF06B6D4.toInt(), 16f)
                } else {
                    triggerPunch()
                }
            }
            AlienForm.FOURARMS -> {
                player.specialCooldown = 24
                player.specialMaxCooldown = 24
                addShockwave(cx + dir * 18f, cy, 10f, 130f, 0xFFEF4444.toInt(), 18)
                addImpactBurst(cx + dir * 18f, cy, 50f, 0xFFFACC15.toInt(), 14)
                listOf(Pair(dir * 8.6f, -5.2f), Pair(dir * 10.4f, -2.8f)).forEachIndexed { idx, pair ->
                    val sz = if (idx == 0) 28f else 22f
                    projectiles.add(
                        Projectile(
                            id = EntityIdCounter.next(),
                            fromPlayer = true,
                            kind = ProjectileKind.BOULDER,
                            x = cx + dir * 16f - sz * 0.5f,
                            y = cy - sz * 0.5f,
                            w = sz,
                            h = sz,
                            vx = pair.first,
                            vy = pair.second,
                            gravity = 0.28f,
                            dmg = 3.4f,
                            life = 58,
                            maxLife = 58,
                            colorHex = 0xFF78716C.toInt(),
                            facing = dir,
                            heavyBreak = true
                        )
                    )
                }
                projectiles.add(
                    Projectile(
                        id = EntityIdCounter.next(),
                        fromPlayer = true,
                        kind = ProjectileKind.FISSURE,
                        x = cx + dir * 18f - 22f,
                        y = player.y + player.height - 40f,
                        w = 44f,
                        h = 40f,
                        vx = dir * 8.8f,
                        vy = 0f,
                        dmg = 3.2f,
                        life = 28,
                        maxLife = 28,
                        colorHex = 0xFFEF4444.toInt(),
                        facing = dir,
                        pierce = true,
                        heavyBreak = true
                    )
                )
                addScreenShake(6f, 12)
                spawnSmoke(cx + dir * 18f, player.y + player.height - 6f, 3, 18f, dir * 1.4f, -1.2f)
                onPlaySfx(SfxCue.SMASH)
                onVibrate(24)
                addFloatingText(cx, player.y - 16f, "THUNDER CLAP!", 0xFFDC2626.toInt(), 17f)
            }
            AlienForm.DIAMONDHEAD -> {
                player.specialCooldown = 24
                player.specialMaxCooldown = 24
                player.shieldTimer = 64
                val floorY = player.y + player.height
                for (s in 0 until 4) {
                    crystalSpires.add(
                        CrystalSpire(
                            x = cx + dir * (48f + s * 56f) - 14f,
                            y = floorY,
                            w = 28f,
                            maxH = 58f + (s % 2) * 16f,
                            curH = 4f,
                            delay = s * 5,
                            life = 36,
                            maxLife = 36,
                            dmg = 2.2f
                        )
                    )
                }
                listOf(-0.6f, 0.5f).forEach { vy ->
                    projectiles.add(
                        Projectile(
                            id = EntityIdCounter.next(),
                            fromPlayer = true,
                            kind = ProjectileKind.CRYSTAL,
                            x = cx + dir * 16f - 12f,
                            y = cy - 5f,
                            w = 24f,
                            h = 10f,
                            vx = dir * 12f,
                            vy = vy,
                            dmg = 2.0f,
                            life = 42,
                            maxLife = 42,
                            colorHex = 0xFF14B8A6.toInt(),
                            facing = dir
                        )
                    )
                }
                onPlaySfx(SfxCue.CRYSTAL)
                onVibrate(16)
                addFloatingText(cx, player.y - 14f, "CRYSTAL SPIRE!", 0xFF0D9488.toInt(), 16f)
            }
            AlienForm.CANNONBOLT -> {
                if (player.energy >= 12f) {
                    player.energy -= 12f
                    player.specialCooldown = 22
                    player.specialMaxCooldown = 22
                    player.rollTimer = 38
                    player.vx = dir * 15.5f
                    if (player.onGround) player.vy = -4.2f
                    player.dashHitIds.clear()
                    spawnSmoke(cx, player.y + player.height - 6f, 3, 15f, -dir * 1.8f, -1.0f)
                    onPlaySfx(SfxCue.PINBALL)
                    onVibrate(20)
                    addFloatingText(cx, player.y - 14f, "PINBALL ROLL!", 0xFFCA8A04.toInt(), 16f)
                } else {
                    triggerPunch()
                }
            }
            AlienForm.JETRAY -> {
                player.specialCooldown = 16
                player.specialMaxCooldown = 16
                listOf(-8f, 8f).forEachIndexed { idx, yOff ->
                    projectiles.add(
                        Projectile(
                            id = EntityIdCounter.next(),
                            fromPlayer = true,
                            kind = ProjectileKind.NEUROLASER,
                            x = cx + dir * 20f - 19f,
                            y = cy + yOff - 4f,
                            w = 38f,
                            h = 8f,
                            vx = dir * 14.5f,
                            vy = 0f,
                            baseY = cy + yOff - 4f,
                            wavePhase = idx * PI.toFloat(),
                            dmg = 1.7f,
                            life = 45,
                            maxLife = 45,
                            colorHex = 0xFFF43F5E.toInt(),
                            facing = dir
                        )
                    )
                }
                onPlaySfx(SfxCue.LASER)
                onVibrate(14)
                addFloatingText(cx, player.y - 12f, "NEURO BEAM!", 0xFFE11D48.toInt(), 15f)
            }
            AlienForm.STINKFLY -> {
                player.specialCooldown = 22
                player.specialMaxCooldown = 22
                listOf(Pair(dir * 8.2f, -4.2f), Pair(dir * 10.6f, -2.2f)).forEach { pair ->
                    projectiles.add(
                        Projectile(
                            id = EntityIdCounter.next(),
                            fromPlayer = true,
                            kind = ProjectileKind.SLIMEBOMB,
                            x = cx + dir * 16f - 9f,
                            y = cy - 9f,
                            w = 18f,
                            h = 18f,
                            vx = pair.first,
                            vy = pair.second,
                            gravity = 0.22f,
                            dmg = 2.2f,
                            life = 68,
                            maxLife = 68,
                            colorHex = 0xFF84CC16.toInt(),
                            facing = dir,
                            slows = true
                        )
                    )
                }
                onPlaySfx(SfxCue.SLIME)
                onVibrate(14)
                addFloatingText(cx, player.y - 12f, "SPLAT BOMB!", 0xFF65A30D.toInt(), 15f)
            }
        }
    }

    // -------------------------------------------------------------------------
    // Main Fixed-60Hz Simulation Step
    // -------------------------------------------------------------------------
    fun stepFrame() {
        frameCount++
        if (frameCount % 6 == 0) boilStep = (boilStep + 1) % 3

        if (screenState == GameScreenState.MENU) {
            cameraX += 0.55f
            if (cameraX > 320f) cameraX = 0f
            updateAmbientEntities()
            return
        }

        if (screenState != GameScreenState.PLAYING) return

        // Slow-motion (1/5th speed) when 8-Alien Radial Dial is open
        if (radialDial.open) {
            dialSlowCounter = (dialSlowCounter + 1) % 5
            if (dialSlowCounter != 0) return
        }

        if (bannerTimer > 0) bannerTimer--
        if (hintTimer > 0) {
            hintTimer--
            if (hintTimer == 0) contextualHint = ""
        }

        if (hitStopFrames > 0) {
            hitStopFrames--
            if (shakeTimer > 0) shakeTimer--
            if (screenFlash > 0f) screenFlash = (screenFlash - 0.025f).coerceAtLeast(0f)
            return
        }

        elapsedFrames++
        formUsageFrames[player.form] = (formUsageFrames[player.form] ?: 0) + 1

        if (shakeTimer > 0) shakeTimer--
        if (screenFlash > 0f) screenFlash = (screenFlash - 0.025f).coerceAtLeast(0f)
        if (comboTimer > 0) {
            comboTimer--
            if (comboTimer == 0) combo = 0
        }
        if (player.comboWindowTimer > 0) {
            player.comboWindowTimer--
            if (player.comboWindowTimer == 0) player.comboStep = 0
        }

        updatePlatforms()
        updatePlayerPhysics()
        updateCombatAndProjectiles()
        updateInteractiveProps()
        updateEnemiesAndBoss()
        updateAmbientEntities()
        updateVfx()
        updateCameraAndWorldStreaming()
    }

    private fun updatePlatforms() {
        val t = elapsedFrames * 0.03f
        for (p in platforms) {
            if (p.type == PlatformType.MOVING) {
                val oldX = p.x
                p.x = p.startX + sin(t * p.speed) * p.range
                p.dx = p.x - oldX
            } else if (p.type == PlatformType.COLLAPSING) {
                if (p.collapseTimer > 0) {
                    p.collapseTimer--
                    if (p.collapseTimer == 0) {
                        p.fallen = true
                        p.respawnTimer = 150
                        spawnSmoke(p.x + p.w * 0.5f, p.y + 8f, 3, 14f)
                    }
                } else if (p.fallen && p.respawnTimer > 0) {
                    p.respawnTimer--
                    if (p.respawnTimer == 0) p.fallen = false
                }
            }
        }
    }

    private fun updatePlayerPhysics() {
        if (player.invulnTimer > 0) player.invulnTimer--
        if (player.punchCooldown > 0) player.punchCooldown--
        if (player.specialCooldown > 0) player.specialCooldown--
        if (player.shieldTimer > 0) player.shieldTimer--
        if (player.landingRecoilTimer > 0) player.landingRecoilTimer--
        if (player.damageRecoilTimer > 0) player.damageRecoilTimer--
        if (player.transformPoseTimer > 0) player.transformPoseTimer--
        if (player.celebrationTimer > 0) player.celebrationTimer--

        if (player.attackAnimTimer > 0) {
            player.attackAnimTimer--
            val prog = 1f - player.attackAnimTimer.toFloat() / player.attackAnimDuration.coerceAtLeast(1)
            player.attackPhase = when {
                prog < 0.25f -> AttackPhase.WINDUP
                prog < 0.68f -> AttackPhase.ACTIVE
                else -> AttackPhase.RECOVERY
            }
            if (player.attackAnimTimer == 0) player.attackPhase = AttackPhase.IDLE
        } else {
            player.attackPhase = AttackPhase.IDLE
        }

        // Combined directional input (keyboard + touch stick)
        var moveDir = input.moveX
        if (input.keyLeft) moveDir -= 1f
        if (input.keyRight) moveDir += 1f
        moveDir = moveDir.coerceIn(-1f, 1f)

        var vertDir = input.moveY
        if (input.keyUp || input.jumpHeld) vertDir -= 1f
        if (input.keyDown) vertDir += 1f
        vertDir = vertDir.coerceIn(-1f, 1f)

        if (abs(moveDir) > 0.14f) {
            player.facing = if (moveDir > 0f) 1 else -1
        }

        if (player.dashTimer > 0) {
            player.dashTimer--
            afterimages.add(Afterimage(player.form, player.x, player.y, player.width, player.height, player.facing, 12, 12))
            if (player.dashTimer == 0) player.vx *= 0.45f
        } else if (player.rollTimer > 0) {
            player.rollTimer--
            if (abs(moveDir) > 0.15f) player.vx += moveDir * 0.45f
            player.vx = player.vx.coerceIn(-16f, 16f)
            if (frameCount % 2 == 0) {
                afterimages.add(Afterimage(player.form, player.x, player.y, player.width, player.height, player.facing, 10, 10))
            }
        } else {
            val targetVx = moveDir * player.speed
            val accel = when (player.form) {
                AlienForm.XLR8 -> 0.42f
                AlienForm.FOURARMS -> 0.22f
                else -> 0.30f
            }
            player.vx += (targetVx - player.vx) * accel
            if (abs(player.vx) < 0.08f && abs(moveDir) < 0.1f) player.vx = 0f
        }

        // Flying vs Gravity
        if (player.canFly) {
            val flyUp = input.jumpHeld || input.keyUp || vertDir < -0.25f
            if (flyUp && player.energy > 1.5f) {
                player.vy += (-0.62f - player.vy) * 0.22f
                player.energy = (player.energy - 0.19f).coerceAtLeast(0f)
                player.wingPhase += 0.55f
            } else if (vertDir > 0.25f) {
                player.vy += (6.5f - player.vy) * 0.2f
            } else {
                player.vy = (player.vy + player.gravity).coerceAtMost(5.2f)
            }
            if (player.onGround) player.energy = (player.energy + 0.65f).coerceAtMost(player.maxEnergy)
        } else {
            // Heatblast jet-hover glide when holding jump
            val jetHover = player.form == AlienForm.HEATBLAST && !player.onGround &&
                (input.jumpHeld || input.keyUp) && player.vy > 0f && player.energy > 2f
            if (jetHover) {
                player.vy = (player.vy + 0.12f).coerceAtMost(2.1f)
                player.energy = (player.energy - 0.25f).coerceAtLeast(0f)
                if (frameCount % 3 == 0) {
                    spawnFlamePlume(player.x + player.width * 0.5f, player.y + player.height, 1, 12f, 18f, 0f, 1.5f)
                }
            } else {
                player.vy = (player.vy + player.gravity).coerceAtMost(19f)
            }
            player.energy = (player.energy + 0.32f).coerceAtMost(player.maxEnergy)
        }

        // Horizontal movement + arena bounds
        player.x += player.vx
        if (player.x < arenaLockMinX) {
            player.x = arenaLockMinX
            if (player.rollTimer > 0) {
                player.vx = abs(player.vx) * 0.9f
                player.facing = 1
                onPlaySfx(SfxCue.PINBALL)
            } else player.vx = 0f
        }
        val maxBound = arenaLockMaxX
        if (maxBound != null && player.x + player.width > maxBound) {
            player.x = maxBound - player.width
            if (player.rollTimer > 0) {
                player.vx = -abs(player.vx) * 0.9f
                player.facing = -1
                onPlaySfx(SfxCue.PINBALL)
            } else player.vx = 0f
        }

        // Vertical platform landing
        val prevBottom = player.y + player.height
        val wasOnGround = player.onGround
        player.y += player.vy
        player.onGround = false

        for (p in platforms) {
            if (p.fallen) continue
            val horizOverlap = (player.x + player.width - 4f) > p.x && (player.x + 4f) < (p.x + p.w)
            if (!horizOverlap) continue
            val newBottom = player.y + player.height
            if (player.vy >= 0f && prevBottom <= p.y + 14f && newBottom >= p.y) {
                player.y = p.y - player.height
                if (p.type == PlatformType.BOUNCE) {
                    player.vy = -17.4f
                    player.onGround = false
                    player.jumpsLeft = player.maxJumps
                    player.slamming = false
                    player.squashX = 0.72f
                    player.squashY = 1.35f
                    onPlaySfx(SfxCue.BOING)
                    onVibrate(16)
                    spawnParticles(player.x + player.width * 0.5f, p.y, 6, 0xFF84CC16.toInt(), "dust")
                } else {
                    if (p.type == PlatformType.MOVING) player.x += p.dx
                    if (p.type == PlatformType.COLLAPSING && p.collapseTimer == 0) p.collapseTimer = 28
                    if (!wasOnGround) {
                        player.landingRecoilTimer = 8
                        player.squashX = 1.24f
                        player.squashY = 0.78f
                        if (player.slamming) {
                            performGroundSlamAoE()
                            player.slamming = false
                        }
                    }
                    player.vy = 0f
                    player.onGround = true
                    player.coyoteTimer = 7
                    player.jumpsLeft = player.maxJumps
                }
                break
            }
        }

        if (!player.onGround && player.coyoteTimer > 0) player.coyoteTimer--
        if (player.jumpBuffer > 0) {
            player.jumpBuffer--
            if (player.onGround) {
                player.jumpBuffer = 0
                triggerJump()
            }
        }

        // Smooth squash recovery + walk cadence
        player.squashX += (1f - player.squashX) * 0.22f
        player.squashY += (1f - player.squashY) * 0.22f
        if (player.onGround && abs(player.vx) > 0.35f) {
            val cadence = if (player.form == AlienForm.XLR8) 0.34f else if (player.form == AlienForm.FOURARMS) 0.16f else 0.23f
            player.walkPhase += cadence * (abs(player.vx) / player.speed).coerceAtLeast(0.4f)
        }

        // Pit fall recovery
        if (player.y > LOGICAL_HEIGHT + 90f) {
            if (currentMode == GameMode.PRACTICE) {
                player.x = player.checkpointX
                player.y = player.checkpointY
                player.vx = 0f
                player.vy = 0f
            } else {
                damagePlayer(34f, player.x, fromPit = true)
                if (screenState == GameScreenState.PLAYING) {
                    player.x = player.checkpointX
                    player.y = player.checkpointY
                    player.vx = 0f
                    player.vy = 0f
                }
            }
        }

        // First-drone contextual combat prompt in Mission 1
        if (currentMode == GameMode.MISSION_1 && !combatHintShown && player.x > 360f) {
            combatHintShown = true
            contextualHint = "Watch for the ! enemy warning, then tap Lower-Right to Attack or Right-Edge for Special!"
            hintTimer = 280
        }
    }

    private fun performGroundSlamAoE() {
        val cx = player.x + player.width * 0.5f
        val cy = player.y + player.height
        val heavy = player.form == AlienForm.FOURARMS || player.form == AlienForm.CANNONBOLT
        val radius = if (heavy) 130f else 88f
        val dmg = if (heavy) 4.2f else 2.5f

        addShockwave(cx, cy, 10f, radius, player.form.colorHex, 18)
        addImpactBurst(cx, cy - 8f, 44f, player.form.accentHex, 12)
        spawnSmoke(cx, cy - 4f, 4, 15f, 0f, -1.2f)
        onPlaySfx(SfxCue.SMASH)
        if (heavy) {
            addScreenShake(6.5f, 12)
            onVibrate(24)
        }

        for (e in enemies) {
            if (!e.alive) continue
            val ex = e.x + e.width * 0.5f
            val ey = e.y + e.height * 0.5f
            if (abs(ex - cx) <= radius && abs(ey - cy) <= 95f) {
                damageEnemy(e, dmg, player.form.colorHex, stun = heavy)
            }
        }
        val b = boss
        if (b != null && b.alive && abs((b.x + b.width * 0.5f) - cx) <= radius + 40f) {
            damageBoss(dmg, player.form.colorHex)
        }
        for (c in crates) {
            if (!c.broken && abs((c.x + c.w * 0.5f) - cx) <= radius) breakCrate(c)
        }
        for (prop in props) {
            if (!prop.activated && (prop.type == InteractivePropType.BREAKABLE_WALL || prop.type == InteractivePropType.SHIELD_CORE)) {
                if (abs((prop.x + prop.w * 0.5f) - cx) <= radius) {
                    damageProp(prop, if (heavy) 4f else 2f, heavy)
                }
            }
        }
    }

    private fun updateCombatAndProjectiles() {
        // Dash / Roll collision with enemies, crates, and breakable walls
        if (player.dashTimer > 0 || player.rollTimer > 0) {
            val dmg = if (player.rollTimer > 0) 2.8f else 2.3f
            for (e in enemies) {
                if (e.alive && !player.dashHitIds.contains(e.id) &&
                    rectsOverlap(player.x, player.y, player.width, player.height, e.x, e.y, e.width, e.height)
                ) {
                    player.dashHitIds.add(e.id)
                    damageEnemy(e, dmg, player.form.colorHex, stun = player.rollTimer > 0)
                    if (player.rollTimer > 0) {
                        player.vy = -5.5f
                        onPlaySfx(SfxCue.PINBALL)
                    }
                }
            }
            val b = boss
            if (b != null && b.alive && b.hitById != player.rollTimer &&
                rectsOverlap(player.x, player.y, player.width, player.height, b.x, b.y, b.width, b.height)
            ) {
                if (player.rollTimer > 0) {
                    player.vx = -player.vx * 0.9f
                    player.vy = -7f
                    onPlaySfx(SfxCue.PINBALL)
                }
                damageBoss(dmg, player.form.colorHex)
            }
            for (c in crates) {
                if (!c.broken && rectsOverlap(player.x, player.y, player.width, player.height, c.x, c.y, c.w, c.h)) {
                    breakCrate(c)
                }
            }
            for (prop in props) {
                if (!prop.activated && (prop.type == InteractivePropType.BREAKABLE_WALL || prop.type == InteractivePropType.SHIELD_CORE)) {
                    if (rectsOverlap(player.x, player.y, player.width, player.height, prop.x, prop.y, prop.w, prop.h)) {
                        damageProp(prop, if (player.rollTimer > 0) 4f else 2f, player.rollTimer > 0)
                    }
                }
            }
        }

        // Update projectiles
        var idx = projectiles.size - 1
        while (idx >= 0) {
            val pr = projectiles[idx]
            pr.life--
            pr.vx += pr.accelX
            pr.vy += pr.gravity
            pr.x += pr.vx
            pr.y += pr.vy
            pr.rot += 0.35f
            if (pr.kind == ProjectileKind.NEUROLASER) {
                pr.wavePhase += 0.35f
                pr.y = pr.baseY + sin(pr.wavePhase) * 8f
            }

            if (pr.fromPlayer) {
                // Check enemies
                for (e in enemies) {
                    if (e.alive && !pr.hitIds.contains(e.id) &&
                        rectsOverlap(pr.x, pr.y, pr.w, pr.h, e.x, e.y, e.width, e.height)
                    ) {
                        pr.hitIds.add(e.id)
                        damageEnemy(e, pr.dmg, pr.colorHex, applyBurn = pr.burns, applySlow = pr.slows, stun = pr.heavyBreak)
                        if (pr.kind == ProjectileKind.SLIMEBOMB) {
                            spawnSlimePuddle(pr.x, pr.y)
                        }
                        if (!pr.pierce) pr.life = 0
                    }
                }
                // Check boss
                val b = boss
                if (b != null && b.alive && !pr.hitIds.contains(-99) &&
                    rectsOverlap(pr.x, pr.y, pr.w, pr.h, b.x, b.y, b.width, b.height)
                ) {
                    pr.hitIds.add(-99)
                    damageBoss(pr.dmg, pr.colorHex)
                    if (pr.kind == ProjectileKind.SLIMEBOMB) spawnSlimePuddle(pr.x, pr.y)
                    if (!pr.pierce) pr.life = 0
                }
                // Check crates & breakable props
                for (c in crates) {
                    if (!c.broken && rectsOverlap(pr.x, pr.y, pr.w, pr.h, c.x, c.y, c.w, c.h)) {
                        breakCrate(c)
                        if (!pr.pierce) pr.life = 0
                    }
                }
                for (prop in props) {
                    if (!prop.activated && !pr.hitIds.contains(prop.id) &&
                        rectsOverlap(pr.x, pr.y, pr.w, pr.h, prop.x, prop.y, prop.w, prop.h)
                    ) {
                        pr.hitIds.add(prop.id)
                        when (prop.type) {
                            InteractivePropType.THERMAL_SWITCH -> {
                                val heatBonus = pr.burns || player.form == AlienForm.HEATBLAST
                                damageProp(prop, if (heatBonus) 2f else 1f, heatBonus)
                                if (!pr.pierce) pr.life = 0
                            }
                            InteractivePropType.SHIELD_CORE, InteractivePropType.BREAKABLE_WALL -> {
                                val heavy = pr.heavyBreak || player.form == AlienForm.FOURARMS || player.form == AlienForm.CANNONBOLT
                                damageProp(prop, if (heavy) 4f else pr.dmg.coerceAtLeast(1f), heavy)
                                if (!pr.pierce) pr.life = 0
                            }
                            else -> Unit
                        }
                    }
                }
                // Slime bomb hits ground
                if (pr.kind == ProjectileKind.SLIMEBOMB && pr.y >= 412f) {
                    spawnSlimePuddle(pr.x, 418f)
                    pr.life = 0
                }
            } else {
                // Enemy projectile: check Diamondhead Prism Reflect Shield first!
                if (rectsOverlap(pr.x, pr.y, pr.w, pr.h, player.x - 6f, player.y - 6f, player.width + 12f, player.height + 12f)) {
                    if (player.form == AlienForm.DIAMONDHEAD && player.shieldTimer > 0) {
                        // Reflect back at enemy!
                        projectiles[idx] = pr.copy(
                            fromPlayer = true,
                            vx = -pr.vx * 1.45f,
                            vy = -pr.vy * 1.2f,
                            dmg = 3.0f,
                            life = 55,
                            maxLife = 55,
                            colorHex = 0xFF14B8A6.toInt(),
                            hitIds = mutableSetOf()
                        )
                        onPlaySfx(SfxCue.CRYSTAL)
                        addScore(75, player.x + player.width * 0.5f, player.y - 14f, "REFLECT!")
                        idx--
                        continue
                    } else {
                        damagePlayer(16f, pr.x)
                        pr.life = 0
                    }
                }
            }

            if (pr.life <= 0) projectiles.removeAt(idx)
            idx--
        }

        // Update crystal spires
        var csIdx = crystalSpires.size - 1
        while (csIdx >= 0) {
            val cs = crystalSpires[csIdx]
            if (cs.delay > 0) {
                cs.delay--
            } else {
                cs.curH += (cs.maxH - cs.curH) * 0.35f
                cs.life--
                for (e in enemies) {
                    if (e.alive && !cs.hitIds.contains(e.id) &&
                        rectsOverlap(cs.x, cs.y - cs.curH, cs.w, cs.curH, e.x, e.y, e.width, e.height)
                    ) {
                        cs.hitIds.add(e.id)
                        damageEnemy(e, cs.dmg, 0xFF14B8A6.toInt())
                    }
                }
                val b = boss
                if (b != null && b.alive && !cs.hitIds.contains(-99) &&
                    rectsOverlap(cs.x, cs.y - cs.curH, cs.w, cs.curH, b.x, b.y, b.width, b.height)
                ) {
                    cs.hitIds.add(-99)
                    damageBoss(cs.dmg, 0xFF14B8A6.toInt())
                }
                if (cs.life <= 0) crystalSpires.removeAt(csIdx)
            }
            csIdx--
        }

        // Update slime puddles
        var spIdx = slimePuddles.size - 1
        while (spIdx >= 0) {
            val sp = slimePuddles[spIdx]
            sp.life--
            if (frameCount % 18 == 0) {
                for (e in enemies) {
                    if (e.alive && rectsOverlap(sp.x, sp.y - 16f, sp.w, 24f, e.x, e.y, e.width, e.height)) {
                        damageEnemy(e, 0.7f, 0xFF84CC16.toInt(), applySlow = true)
                    }
                }
            }
            if (sp.life <= 0) slimePuddles.removeAt(spIdx)
            spIdx--
        }
    }

    private fun spawnSlimePuddle(x: Float, y: Float) {
        if (slimePuddles.size >= 8) slimePuddles.removeAt(0)
        slimePuddles.add(SlimePuddle(x - 26f, y.coerceAtMost(416f), 64f, 12f, 180, 180))
    }

    private fun damageProp(prop: InteractiveProp, dmg: Float, signatureFormBonus: Boolean) {
        prop.hp -= dmg
        val cx = prop.x + prop.w * 0.5f
        val cy = prop.y + prop.h * 0.5f
        spawnParticles(cx, cy, 8, 0xFFFACC15.toInt(), "shard")
        if (prop.hp <= 0f) {
            prop.activated = true
            val pts = if (signatureFormBonus) 350 else 150
            val label = when (prop.type) {
                InteractivePropType.THERMAL_SWITCH -> if (signatureFormBonus) "HEAT IGNITE!" else "ACTIVATED!"
                InteractivePropType.SHIELD_CORE -> if (signatureFormBonus) "ARMOR SHATTER!" else "CORE BROKEN!"
                InteractivePropType.BREAKABLE_WALL -> "SMASHED!"
                else -> "CLEARED!"
            }
            addScore(pts, cx, prop.y - 12f, label)
            addShockwave(cx, cy, 10f, 80f, 0xFFFACC15.toInt(), 16)
            onPlaySfx(SfxCue.SMASH)
            onVibrate(18)
        } else {
            onPlaySfx(SfxCue.ENEMY_HIT)
        }
    }

    private fun updateInteractiveProps() {
        // Checkpoints
        for (cp in checkpoints) {
            if (!cp.active && rectsOverlap(player.x, player.y, player.width, player.height, cp.x, cp.y, cp.w, cp.h)) {
                cp.active = true
                player.checkpointX = cp.x
                player.checkpointY = cp.y - player.height + cp.h - 2f
                player.hp = (player.hp + 35f).coerceAtMost(player.maxHp)
                player.energy = player.maxEnergy
                onPlaySfx(SfxCue.CHECKPOINT)
                addFloatingText(cp.x + cp.w * 0.5f, cp.y - 16f, "CHECKPOINT!", 0xFF10B981.toInt(), 16f)
            }
        }

        // Collectibles (Omni Cells & Mr. Smoothy)
        for (col in collectibles) {
            if (!col.collected && rectsOverlap(player.x, player.y, player.width, player.height, col.x, col.y, col.w, col.h)) {
                col.collected = true
                onPlaySfx(SfxCue.COLLECT)
                if (col.kind == CollectibleKind.SMOOTHIE) {
                    player.hp = (player.hp + 30f).coerceAtMost(player.maxHp)
                    player.energy = player.maxEnergy
                    addScore(150, col.x, col.y - 10f, "SMOOTHY +HP!")
                } else {
                    player.energy = (player.energy + 28f).coerceAtMost(player.maxEnergy)
                    addScore(75, col.x, col.y - 10f)
                }
                spawnParticles(col.x + col.w * 0.5f, col.y + col.h * 0.5f, 8, 0xFF4ADE80.toInt(), "spark")
            }
        }

        // Interactive Mission Props (Shards, Speed Gates, Rescue Pods)
        for (prop in props) {
            if (prop.activated) continue
            if (rectsOverlap(player.x, player.y, player.width, player.height, prop.x, prop.y, prop.w, prop.h)) {
                when (prop.type) {
                    InteractivePropType.SHARD -> {
                        prop.activated = true
                        onPlaySfx(SfxCue.CHECKPOINT)
                        addScore(250, prop.x + 14f, prop.y - 12f, "OMNI SHARD!")
                        addShockwave(prop.x + 14f, prop.y + 14f, 6f, 56f, 0xFF4ADE80.toInt(), 14)
                    }
                    InteractivePropType.SPEED_GATE -> {
                        prop.activated = true
                        val isFast = player.form == AlienForm.XLR8 || player.dashTimer > 0 || abs(player.vx) > 6.5f
                        player.energy = player.maxEnergy
                        onPlaySfx(SfxCue.ZIP)
                        addScore(if (isFast) 300 else 120, prop.x, prop.y - 10f, if (isFast) "XLR8 BOOST!" else "GATE CLEARED!")
                    }
                    InteractivePropType.RESCUE_POD -> {
                        prop.activated = true
                        onPlaySfx(SfxCue.CHECKPOINT)
                        player.hp = (player.hp + 20f).coerceAtMost(player.maxHp)
                        addScore(350, prop.x + 20f, prop.y - 14f, "ALLY RESCUED!")
                        addShockwave(prop.x + 22f, prop.y + 34f, 8f, 70f, 0xFF22D3EE.toInt(), 16)
                    }
                    InteractivePropType.BREAKABLE_WALL -> {
                        // Solid barrier until smashed (pushes player back gently unless dashing/rolling)
                        if (player.rollTimer > 0 || player.dashTimer > 0) {
                            damageProp(prop, 4f, true)
                        } else if (player.x + player.width * 0.5f < prop.x + prop.w * 0.5f) {
                            player.x = prop.x - player.width
                            player.vx = 0f
                        }
                    }
                    else -> Unit
                }
            }
        }
    }

    private fun updateEnemiesAndBoss() {
        val pcx = player.x + player.width * 0.5f
        val pcy = player.y + player.height * 0.5f

        for (e in enemies) {
            if (!e.alive) {
                // Practice Dojo dummies respawn cleanly after 90 frames
                if (e.isDummy) {
                    e.stateTimer++
                    if (e.stateTimer >= 90) {
                        e.alive = true
                        e.hp = e.maxHp
                        e.x = e.spawnX
                        e.y = e.spawnY
                        e.state = EnemyBehaviorState.PATROL
                        e.stateTimer = 0
                        e.warn = false
                        spawnParticles(e.x + e.width * 0.5f, e.y + e.height * 0.5f, 8, 0xFF4ADE80.toInt(), "spark")
                    }
                }
                continue
            }

            if (e.flash > 0) e.flash--
            if (e.slowTimer > 0) e.slowTimer--
            if (e.burnTimer > 0) {
                e.burnTimer--
                if (e.burnTimer % 20 == 0) {
                    damageEnemy(e, 0.5f, 0xFFF97316.toInt())
                    if (!e.alive) continue
                }
            }

            val ecx = e.x + e.width * 0.5f
            val ecy = e.y + e.height * 0.5f
            val distToPlayer = abs(pcx - ecx)
            val slowMult = if (e.slowTimer > 0) 0.48f else 1f

            when (e.state) {
                EnemyBehaviorState.STUNNED -> {
                    e.warn = false
                    e.stateTimer--
                    if (e.stateTimer <= 0) e.state = EnemyBehaviorState.PATROL
                }
                EnemyBehaviorState.WINDUP -> {
                    e.warn = true
                    e.facing = if (pcx >= ecx) 1 else -1
                    e.stateTimer--
                    if (e.stateTimer <= 0) {
                        e.warn = false
                        e.state = EnemyBehaviorState.STRIKE
                        if (e.type == EnemyType.HOUND) {
                            e.vx = e.facing * 6.8f
                            e.vy = -5.4f
                            e.stateTimer = 26
                        } else {
                            // Fire telegraphed enemy orb
                            val dx = (pcx - ecx)
                            val dy = (pcy - ecy)
                            val len = hypot(dx, dy).coerceAtLeast(1f)
                            val orbSpeed = if (e.type == EnemyType.TURRET) 6.6f else 5.4f
                            projectiles.add(
                                Projectile(
                                    id = EntityIdCounter.next(),
                                    fromPlayer = false,
                                    kind = ProjectileKind.ENEMY_ORB,
                                    x = ecx + e.facing * 14f - 8f,
                                    y = ecy - 8f,
                                    w = 16f,
                                    h = 16f,
                                    vx = (dx / len) * orbSpeed,
                                    vy = (dy / len) * orbSpeed * 0.5f,
                                    dmg = 1f,
                                    life = 110,
                                    maxLife = 110,
                                    colorHex = 0xFFDC2626.toInt()
                                )
                            )
                            e.stateTimer = 24
                        }
                    }
                }
                EnemyBehaviorState.STRIKE -> {
                    e.warn = false
                    if (e.type == EnemyType.HOUND) {
                        e.x += e.vx * slowMult
                        e.vy += 0.35f
                        e.y = (e.y + e.vy).coerceAtMost(372f)
                        if (e.y >= 372f) e.vy = 0f
                    }
                    e.stateTimer--
                    if (e.stateTimer <= 0) {
                        e.state = EnemyBehaviorState.RECOVER
                        e.stateTimer = 32
                        e.vx = e.facing * (if (e.type == EnemyType.HOUND) 1.8f else 1.4f)
                    }
                }
                EnemyBehaviorState.RECOVER -> {
                    e.warn = false
                    e.stateTimer--
                    if (e.stateTimer <= 0) e.state = EnemyBehaviorState.PATROL
                }
                EnemyBehaviorState.PATROL -> {
                    e.warn = false
                    if (e.type != EnemyType.TURRET) {
                        e.x += e.vx * slowMult
                        if (e.x <= e.minX) {
                            e.x = e.minX
                            e.vx = abs(e.vx)
                            e.facing = 1
                        } else if (e.x >= e.maxX) {
                            e.x = e.maxX
                            e.vx = -abs(e.vx)
                            e.facing = -1
                        } else if (abs(e.vx) > 0.05f) {
                            e.facing = if (e.vx > 0f) 1 else -1
                        }
                    } else {
                        e.facing = if (pcx >= ecx) 1 else -1
                    }

                    if (!e.isDummy && distToPlayer < 460f) {
                        if (e.type == EnemyType.HOUND) {
                            if (distToPlayer < 210f) {
                                e.state = EnemyBehaviorState.WINDUP
                                e.stateTimer = 28 // Clear 0.45s telegraph before pounce
                                onPlaySfx(SfxCue.ENEMY_WARN)
                            }
                        } else {
                            e.shootTimer--
                            if (e.shootTimer <= 0) {
                                e.shootTimer = if (e.type == EnemyType.TURRET) 92 else 110
                                e.state = EnemyBehaviorState.WINDUP
                                e.stateTimer = 26 // Clear ! glint before firing
                                onPlaySfx(SfxCue.ENEMY_WARN)
                            }
                        }
                    }
                }
            }

            // Contact damage check
            if (!e.isDummy && rectsOverlap(player.x + 4f, player.y + 4f, player.width - 8f, player.height - 8f, e.x, e.y, e.width, e.height)) {
                if (player.dashTimer == 0 && player.rollTimer == 0) {
                    damagePlayer(15f, ecx)
                }
            }
        }

        // Boss AI (Learnable telegraphed states + counter windows)
        val b = boss
        if (b != null && b.alive) {
            if (b.flashTimer > 0) b.flashTimer--
            val bx = b.x + b.width * 0.5f

            // Lock arena when player enters
            if (player.x >= b.arenaStartX + 40f && arenaLockMaxX == null) {
                arenaLockMinX = b.arenaStartX
                arenaLockMaxX = b.arenaEndX
                onPlaySfx(SfxCue.BOSS_ALARM)
                showBanner("BOSS ENCOUNTER", b.title)
            }

            if (arenaLockMaxX != null) {
                if (!b.phase2 && b.hp <= b.maxHp * 0.5f) {
                    b.phase2 = true
                    b.actionState = BossActionState.PHASE_SHIFT
                    b.stateTimer = 36
                    addShockwave(bx, b.y + b.height * 0.5f, 12f, 150f, 0xFFDC2626.toInt(), 20)
                    addFloatingText(bx, b.y - 20f, "PHASE 2 OVERDRIVE!", 0xFFDC2626.toInt(), 18f)
                    onPlaySfx(SfxCue.BOSS_ALARM)
                }

                when (b.actionState) {
                    BossActionState.PHASE_SHIFT -> {
                        b.stateTimer--
                        if (b.stateTimer <= 0) b.actionState = BossActionState.RECOVER
                    }
                    BossActionState.TELEGRAPH_LEAP -> {
                        b.stateTimer--
                        if (b.stateTimer <= 0) {
                            b.actionState = BossActionState.LEAPING
                            b.vy = -12.8f
                            b.vx = (if (pcx >= bx) 1f else -1f) * (if (b.phase2) 6.2f else 4.9f)
                            b.onGround = false
                        }
                    }
                    BossActionState.LEAPING -> {
                        b.x = (b.x + b.vx).coerceIn(b.minX, b.maxX)
                        b.vy += 0.52f
                        b.y += b.vy
                        if (b.y >= 296f) {
                            b.y = 296f
                            b.vy = 0f
                            b.onGround = true
                            b.actionState = BossActionState.RECOVER
                            b.stateTimer = 42 // Generous counter window!
                            addScreenShake(5.5f, 10)
                            addShockwave(bx, 420f, 12f, 110f, 0xFFEF4444.toInt(), 16)
                            onPlaySfx(SfxCue.SMASH)
                        }
                    }
                    BossActionState.TELEGRAPH_VOLLEY -> {
                        b.stateTimer--
                        if (b.stateTimer <= 0) {
                            val dir = if (pcx >= bx) 1f else -1f
                            val shots = if (b.phase2) 3 else 2
                            for (s in 0 until shots) {
                                projectiles.add(
                                    Projectile(
                                        id = EntityIdCounter.next(),
                                        fromPlayer = false,
                                        kind = ProjectileKind.ENEMY_ORB,
                                        x = bx + dir * 24f - 10f,
                                        y = b.y + 42f + (s - 1) * 18f,
                                        w = 20f,
                                        h = 20f,
                                        vx = dir * (6.8f + s * 0.8f),
                                        vy = (s - 1) * 0.7f,
                                        dmg = 1f,
                                        life = 130,
                                        maxLife = 130,
                                        colorHex = 0xFFDC2626.toInt()
                                    )
                                )
                            }
                            b.actionState = BossActionState.RECOVER
                            b.stateTimer = 36
                            onPlaySfx(SfxCue.LASER)
                        }
                    }
                    BossActionState.RECOVER -> {
                        b.stateTimer--
                        if (b.stateTimer <= 0) {
                            b.actionState = BossActionState.PATROL
                            b.vx = (if (pcx >= bx) 1f else -1f) * (if (b.phase2) 3.2f else 2.4f)
                        }
                    }
                    BossActionState.PATROL -> {
                        b.x += b.vx
                        if (b.x <= b.minX) { b.x = b.minX; b.vx = abs(b.vx) }
                        if (b.x >= b.maxX) { b.x = b.maxX; b.vx = -abs(b.vx) }
                        b.attackTimer--
                        b.jumpTimer--
                        if (b.jumpTimer <= 0) {
                            b.jumpTimer = if (b.phase2) 135 else 175
                            b.actionState = BossActionState.TELEGRAPH_LEAP
                            b.stateTimer = 28
                            onPlaySfx(SfxCue.ENEMY_WARN)
                        } else if (b.attackTimer <= 0) {
                            b.attackTimer = if (b.phase2) 85 else 110
                            b.actionState = BossActionState.TELEGRAPH_VOLLEY
                            b.stateTimer = 28
                            onPlaySfx(SfxCue.ENEMY_WARN)
                        }
                    }
                }

                if (rectsOverlap(player.x + 6f, player.y + 6f, player.width - 12f, player.height - 12f, b.x + 8f, b.y + 8f, b.width - 16f, b.height - 16f)) {
                    if (player.dashTimer == 0 && player.rollTimer == 0) {
                        damagePlayer(18f, bx)
                    }
                }
            }
        }
    }

    private fun updateAmbientEntities() {
        val pcx = player.x + player.width * 0.5f
        for (car in hoverCars) {
            car.x += car.vx
            if (car.x < cameraX * 0.55f - 200f) car.x += 1920f
            if (car.x > cameraX * 0.55f + viewWidth + 220f) car.x -= 1920f
        }
        for (cr in ambientCreatures) {
            cr.phase += 0.08f
            if (cr.bubbleTimer > 0) cr.bubbleTimer--
            if (!cr.type.isSky && cr.vx != 0f) {
                cr.x += cr.vx
                if (cr.x <= cr.minX) { cr.x = cr.minX; cr.vx = abs(cr.vx); cr.facing = 1 }
                if (cr.x >= cr.maxX) { cr.x = cr.maxX; cr.vx = -abs(cr.vx); cr.facing = -1 }
            } else if (cr.type.isSky) {
                cr.x += cr.vx
                cr.y = cr.baseY + sin(cr.phase * 0.7f) * 14f
                if (cr.x < cr.minX) { cr.x = cr.minX; cr.vx = abs(cr.vx); cr.facing = 1 }
                if (cr.x > cr.maxX) { cr.x = cr.maxX; cr.vx = -abs(cr.vx); cr.facing = -1 }
            }
            // Friendly cheer reaction when player passes close by
            if (cr.reactTimer > 0) cr.reactTimer--
            if (screenState == GameScreenState.PLAYING && cr.reactTimer == 0 && abs(cr.x - pcx) < 95f) {
                cr.reactTimer = 240
                cr.bubbleTimer = 95
                cr.bubbleText = when (cr.type) {
                    CreatureType.MAX -> "GO BEN!"
                    CreatureType.GWEN -> "NICE MOVE!"
                    CreatureType.DOG -> "WOOF!"
                    CreatureType.OWL -> "HOOT!"
                    CreatureType.BIRD, CreatureType.EAGLE -> "CHIRP!"
                    CreatureType.ELEPHANT -> "PAWOO!"
                    else -> "HERO!"
                }
                if (frameCount - lastAnimalSfxFrame > 110) {
                    lastAnimalSfxFrame = frameCount
                    when (cr.type) {
                        CreatureType.DOG -> onPlaySfx(SfxCue.BARK)
                        CreatureType.OWL -> onPlaySfx(SfxCue.HOOT)
                        CreatureType.BIRD, CreatureType.EAGLE -> onPlaySfx(SfxCue.CHIRP)
                        CreatureType.ELEPHANT -> onPlaySfx(SfxCue.TRUMPET)
                        else -> Unit
                    }
                }
            }
        }
    }

    private fun updateVfx() {
        var i = particles.size - 1
        while (i >= 0) {
            val pt = particles[i]
            pt.x += pt.vx
            pt.y += pt.vy
            pt.vy += 0.14f
            pt.rot += pt.vrot
            pt.life--
            if (pt.life <= 0) particles.removeAt(i)
            i--
        }
        i = smokePuffs.size - 1
        while (i >= 0) {
            val sm = smokePuffs[i]
            sm.x += sm.vx; sm.y += sm.vy; sm.r += sm.grow; sm.rot += sm.vrot; sm.life--
            if (sm.life <= 0) smokePuffs.removeAt(i)
            i--
        }
        i = flameWisps.size - 1
        while (i >= 0) {
            val fw = flameWisps[i]
            fw.x += fw.vx; fw.y += fw.vy; fw.life--
            if (fw.life <= 0) flameWisps.removeAt(i)
            i--
        }
        i = shockwaves.size - 1
        while (i >= 0) {
            val sw = shockwaves[i]
            sw.r += (sw.maxR - sw.r) * 0.24f
            sw.life--
            if (sw.life <= 0) shockwaves.removeAt(i)
            i--
        }
        i = impactBursts.size - 1
        while (i >= 0) {
            val ib = impactBursts[i]
            ib.life--
            if (ib.life <= 0) impactBursts.removeAt(i)
            i--
        }
        i = floatingTexts.size - 1
        while (i >= 0) {
            val ft = floatingTexts[i]
            ft.y += ft.vy
            ft.life--
            if (ft.life <= 0) floatingTexts.removeAt(i)
            i--
        }
        i = afterimages.size - 1
        while (i >= 0) {
            val ai = afterimages[i]
            ai.life--
            if (ai.life <= 0) afterimages.removeAt(i)
            i--
        }
    }

    private fun updateCameraAndWorldStreaming() {
        if (player.x > maxPlayerX) {
            maxPlayerX = player.x
            val newDist = ((maxPlayerX - 80f) / 20f).roundToInt().coerceAtLeast(0)
            if (newDist > distMeters) {
                score += (newDist - distMeters) * 2
                distMeters = newDist
            }
        }

        val targetCamX = (player.x - viewWidth * 0.34f).coerceAtLeast(0f)
        cameraX += (targetCamX - cameraX) * 0.14f
        val targetCamY = ((player.y - viewHeight * 0.56f) * 0.35f).coerceIn(-60f, 35f)
        cameraY += (targetCamY - cameraY) * 0.12f

        if (currentMode == GameMode.ENDLESS) {
            while (generatedUntilX < cameraX + viewWidth + 950f) {
                val (newEnd, newCp, spawnedBoss) = LevelBuilder.generateNextEndlessChunk(
                    startX = generatedUntilX,
                    distMeters = distMeters,
                    bossesDefeated = bossesDefeated,
                    nextBossX = nextBossX,
                    nextCheckpointX = nextCheckpointX,
                    platforms = platforms,
                    checkpoints = checkpoints,
                    crates = crates,
                    collectibles = collectibles,
                    props = props,
                    enemies = enemies,
                    doodles = ambientDoodles,
                    creatures = ambientCreatures
                )
                generatedUntilX = newEnd
                nextCheckpointX = newCp
                if (spawnedBoss != null) {
                    boss = spawnedBoss
                    nextBossX = generatedUntilX + 3200f + bossesDefeated * 350f
                }
            }
            pruneBehindCamera()
        }
    }

    private fun pruneBehindCamera() {
        val cutoff = minOf(cameraX - 900f, player.checkpointX - 650f)
        if (cutoff <= 0f) return
        platforms.removeAll { it.x + it.w <= cutoff }
        checkpoints.removeAll { it.x + it.w <= cutoff }
        crates.removeAll { it.broken || it.x + it.w <= cutoff }
        collectibles.removeAll { it.collected || it.x + it.w <= cutoff }
        props.removeAll { it.x + it.w <= cutoff }
        enemies.removeAll { !it.alive || it.x + it.width <= cutoff }
        ambientDoodles.removeAll { it.x <= cutoff - 150f }
        ambientCreatures.removeAll { it.x <= cutoff - 180f }
    }

    // -------------------------------------------------------------------------
    // Damage, Victory & Game Over Calculations
    // -------------------------------------------------------------------------
    fun damagePlayer(amount: Float, srcX: Float, fromPit: Boolean = false) {
        if (player.invulnTimer > 0 && !fromPit) return
        if (currentMode == GameMode.PRACTICE && !fromPit) {
            player.invulnTimer = 35
            player.hp = (player.hp - amount * 0.25f).coerceAtLeast(25f)
            onPlaySfx(SfxCue.HIT)
            return
        }

        damageTaken += amount.roundToInt()
        player.hp -= amount
        player.invulnTimer = 55
        player.damageRecoilTimer = 14
        combo = 0
        comboTimer = 0
        if (!fromPit) {
            val knockDir = if (player.x + player.width * 0.5f >= srcX) 1f else -1f
            player.vx = knockDir * 5.2f
            player.vy = -5.5f
        }
        onPlaySfx(SfxCue.HIT)
        onVibrate(22)
        triggerFlash(0xFFEF4444.toInt(), 0.14f)
        addScreenShake(4.5f, 9)

        if (player.hp <= 0f) {
            lives--
            if (lives > 0) {
                player.hp = player.maxHp
                player.energy = player.maxEnergy
                player.x = player.checkpointX
                player.y = player.checkpointY
                player.vx = 0f
                player.vy = 0f
                arenaLockMaxX = null
                addFloatingText(player.x + 20f, player.y - 20f, "RESTORED!", 0xFF10B981.toInt(), 16f)
            } else {
                player.hp = 0f
                finishRun(victory = false)
            }
        }
    }

    private fun damageEnemy(
        enemy: EnemyEntity,
        dmg: Float,
        hitColorHex: Int,
        applyBurn: Boolean = false,
        applySlow: Boolean = false,
        stun: Boolean = false
    ) {
        enemy.hp -= dmg
        enemy.flash = 8
        if (applyBurn) enemy.burnTimer = 110
        if (applySlow) enemy.slowTimer = 120
        if (stun) {
            enemy.state = EnemyBehaviorState.STUNNED
            enemy.stateTimer = 42
            enemy.warn = false
        }

        val cx = enemy.x + enemy.width * 0.5f
        val cy = enemy.y + enemy.height * 0.5f
        spawnParticles(cx, cy, 6, hitColorHex, "spark")
        addImpactBurst(cx, cy, 24f, hitColorHex, 8)
        onPlaySfx(SfxCue.ENEMY_HIT)

        if (enemy.hp <= 0f) {
            enemy.alive = false
            enemy.stateTimer = 0
            addScore(120, cx, enemy.y - 10f)
            spawnSmoke(cx, cy, 3, 14f)
            spawnParticles(cx, cy, 10, hitColorHex, "shard")
        } else {
            addFloatingText(cx, enemy.y - 8f, "-${dmg.roundToInt().coerceAtLeast(1)}", hitColorHex, 14f)
        }
    }

    private fun damageBoss(dmg: Float, hitColorHex: Int) {
        val b = boss ?: return
        if (!b.alive) return
        b.hp -= dmg
        b.flashTimer = 8
        val bx = b.x + b.width * 0.5f
        val by = b.y + b.height * 0.45f
        spawnParticles(bx, by, 7, hitColorHex, "spark")
        addImpactBurst(bx, by, 30f, hitColorHex, 9)
        onPlaySfx(SfxCue.ENEMY_HIT)
        addScreenShake(3.5f, 6)

        if (b.hp <= 0f) {
            b.hp = 0f
            b.alive = false
            bossesDefeated++
            arenaLockMinX = 0f
            arenaLockMaxX = null
            addScore(1000, bx, b.y - 18f, "BOSS KO!")
            addShockwave(bx, by, 14f, 160f, 0xFF4ADE80.toInt(), 24)
            spawnSmoke(bx, by, 5, 18f)
            onPlaySfx(SfxCue.VICTORY)
            onVibrate(28)

            if (currentMode.id.startsWith("MISSION_")) {
                player.celebrationTimer = 90
                finishRun(victory = true)
            } else {
                // Endless Rush advances to next biome wave!
                waveNumber++
                biomeIndex = (biomeIndex + 1) % BIOMES.size
                onBiomeChanged(biomeIndex)
                showBanner("ENDLESS ZONE $waveNumber", BIOMES[biomeIndex].title)
                player.hp = (player.hp + 45f).coerceAtMost(player.maxHp)
                player.energy = player.maxEnergy
            }
        }
    }

    private fun breakCrate(crate: Crate) {
        crate.broken = true
        val cx = crate.x + crate.w * 0.5f
        val cy = crate.y + crate.h * 0.5f
        spawnParticles(cx, cy, 8, 0xFFA8A29E.toInt(), "shard")
        onPlaySfx(SfxCue.SMASH)
        addScore(60, cx, crate.y - 8f)
        player.energy = (player.energy + 12f).coerceAtMost(player.maxEnergy)
    }

    private fun addScore(basePoints: Int, x: Float, y: Float, label: String? = null) {
        combo += 1
        comboTimer = 180
        val mult = minOf(5, 1 + (combo - 1) / 2)
        val pts = basePoints * mult
        score += pts
        val text = when {
            label != null -> "$label +$pts"
            mult > 1 -> "+$pts (${mult}x)"
            else -> "+$pts"
        }
        addFloatingText(x, y, text, if (mult > 1) 0xFFD97706.toInt() else 0xFF15803D.toInt(), if (mult > 1) 16f else 14f)
    }

    private fun finishRun(victory: Boolean) {
        releaseAllInputs()
        radialDial.open = false
        screenState = if (victory) GameScreenState.VICTORY else GameScreenState.GAME_OVER

        val durationSec = (elapsedFrames / 60).coerceAtLeast(1)
        val mission = MISSIONS.find { it.mode == currentMode }
        val shardProps = props.filter { it.type == InteractivePropType.SHARD }
        val allShards = shardProps.isNotEmpty() && shardProps.all { it.activated }
        val noDamage = victory && damageTaken == 0
        val speedMedal = victory && mission != null && durationSec <= mission.parTimeSec
        val stars = computeStars(victory, score, bossesDefeated, noDamage, allShards, speedMedal)
        val favForm = formUsageFrames.maxByOrNull { it.value }?.key ?: player.form

        val summary = RunSummary(
            mode = currentMode,
            victory = victory,
            score = score,
            distanceMeters = distMeters,
            bossesDefeated = bossesDefeated,
            durationSec = durationSec,
            stars = stars,
            noDamageMedal = noDamage,
            allShardsMedal = allShards,
            speedMedal = speedMedal,
            favoriteForm = favForm
        )
        onRunFinished(summary)
    }

    fun computeStars(
        victory: Boolean,
        runScore: Int,
        bosses: Int,
        noDamage: Boolean,
        allShards: Boolean,
        speedMedal: Boolean
    ): Int {
        if (currentMode.id.startsWith("MISSION_")) {
            if (!victory) return 0
            val bonusMedals = listOf(noDamage, allShards, speedMedal).count { it }
            return (1 + (if (bonusMedals >= 1) 1 else 0) + (if (bonusMedals >= 2 || runScore >= 3000) 1 else 0)).coerceIn(1, 3)
        }
        return when {
            runScore >= 3500 || bosses >= 2 -> 3
            runScore >= 1400 || bosses >= 1 -> 2
            else -> 1
        }
    }

    // -------------------------------------------------------------------------
    // VFX Spawn Helpers (Bounded for decluttered clarity)
    // -------------------------------------------------------------------------
    private fun spawnParticles(x: Float, y: Float, count: Int, colorHex: Int, kind: String) {
        val actualCount = if (reducedMotion) (count / 2).coerceAtLeast(1) else count
        for (i in 0 until actualCount) {
            if (particles.size >= MAX_PARTICLES) particles.removeAt(0)
            val ang = Random.nextFloat() * 6.283f
            val spd = 1.4f + Random.nextFloat() * 4.8f
            particles.add(
                Particle(
                    x = x, y = y,
                    vx = cos(ang) * spd, vy = sin(ang) * spd - 1.1f,
                    size = 3f + Random.nextFloat() * 4.5f,
                    colorHex = colorHex, kind = kind,
                    rot = Random.nextFloat() * 6.283f,
                    vrot = (Random.nextFloat() - 0.5f) * 0.3f,
                    life = 16 + Random.nextInt(16), maxLife = 32
                )
            )
        }
    }

    private fun spawnSmoke(x: Float, y: Float, count: Int, size: Float, vxBias: Float = 0f, vyBias: Float = -1.2f) {
        for (i in 0 until count) {
            if (smokePuffs.size >= MAX_SMOKE) smokePuffs.removeAt(0)
            smokePuffs.add(
                SmokePuff(
                    x = x + (Random.nextFloat() - 0.5f) * 10f,
                    y = y + (Random.nextFloat() - 0.5f) * 8f,
                    vx = vxBias + (Random.nextFloat() - 0.5f),
                    vy = vyBias - Random.nextFloat(),
                    r = size * (0.65f + Random.nextFloat() * 0.4f),
                    grow = 0.30f + Random.nextFloat() * 0.22f,
                    rot = Random.nextFloat() * 6.283f,
                    vrot = (Random.nextFloat() - 0.5f) * 0.06f,
                    tintHex = 0xFFD6D3D1.toInt(),
                    life = 24 + Random.nextInt(16), maxLife = 40
                )
            )
        }
    }

    private fun spawnFlamePlume(x: Float, y: Float, count: Int, w: Float, h: Float, vx: Float, vy: Float) {
        for (i in 0 until count) {
            if (flameWisps.size >= MAX_FLAMES) flameWisps.removeAt(0)
            flameWisps.add(
                FlameWisp(
                    x = x + (Random.nextFloat() - 0.5f) * 10f,
                    y = y + (Random.nextFloat() - 0.5f) * 8f,
                    vx = vx + (Random.nextFloat() - 0.5f) * 1.2f,
                    vy = vy - Random.nextFloat() * 1.2f,
                    w = w * (0.75f + Random.nextFloat() * 0.45f),
                    h = h * (0.8f + Random.nextFloat() * 0.45f),
                    seed = Random.nextFloat() * 20f,
                    life = 14 + Random.nextInt(10), maxLife = 24
                )
            )
        }
    }

    private fun addShockwave(x: Float, y: Float, r: Float, maxR: Float, colorHex: Int, life: Int) {
        if (shockwaves.size >= 10) shockwaves.removeAt(0)
        shockwaves.add(Shockwave(x, y, r, maxR, colorHex, life, life))
    }

    private fun addImpactBurst(x: Float, y: Float, r: Float, colorHex: Int, life: Int) {
        if (impactBursts.size >= 10) impactBursts.removeAt(0)
        impactBursts.add(ImpactBurst(x, y, r, colorHex, life, life))
    }

    private fun addFloatingText(x: Float, y: Float, text: String, colorHex: Int, size: Float) {
        if (floatingTexts.size >= MAX_FLOATING_TEXT) floatingTexts.removeAt(0)
        floatingTexts.add(
            FloatingText(
                x = x, y = y, vy = -1.35f, text = text, colorHex = colorHex,
                size = size, tilt = (Random.nextFloat() - 0.5f) * 0.18f, life = 40, maxLife = 40
            )
        )
    }

    fun addScreenShake(intensity: Float, duration: Int) {
        val mult = if (reducedMotion) 0.25f else 1f
        shakeIntensity = maxOf(shakeIntensity, intensity * mult)
        shakeTimer = maxOf(shakeTimer, duration)
    }

    fun triggerFlash(colorHex: Int, alpha: Float) {
        if (reducedMotion) return
        screenFlash = maxOf(screenFlash, alpha.coerceAtMost(0.14f))
        screenFlashColorHex = colorHex
    }

    // -------------------------------------------------------------------------
    // HUD Snapshot Builder
    // -------------------------------------------------------------------------
    fun snapshotHud(): HudUiState {
        val shards = props.filter { it.type == InteractivePropType.SHARD }
        val shardsDone = shards.count { it.activated }
        val shardsTotal = shards.size
        val b = boss

        val objText = when {
            currentMode == GameMode.ENDLESS -> "ZONE ${biomeIndex + 1} • ${distMeters}m"
            currentMode == GameMode.PRACTICE -> "PRACTICE DOJO • ALL 8 ALIENS"
            currentMode == GameMode.MISSION_2 -> {
                val cores = props.filter { it.type == InteractivePropType.SHIELD_CORE }
                val sw = props.filter { it.type == InteractivePropType.THERMAL_SWITCH }
                "SHARDS $shardsDone/$shardsTotal • CORES ${cores.count { it.activated }}/${cores.size} • SWITCHES ${sw.count { it.activated }}/${sw.size}"
            }
            currentMode == GameMode.MISSION_4 -> {
                val pods = props.filter { it.type == InteractivePropType.RESCUE_POD }
                "PODS ${pods.count { it.activated }}/${pods.size} • SHARDS $shardsDone/$shardsTotal"
            }
            else -> "SHARDS $shardsDone/$shardsTotal • BOSS ${if (b == null || !b.alive) "KO" else "ACTIVE"}"
        }

        val objProg = if (currentMode.id.startsWith("MISSION_")) {
            val totalItems = props.size + 1
            val doneItems = props.count { it.activated } + (if (b == null || !b.alive) 1 else 0)
            (doneItems.toFloat() / totalItems.coerceAtLeast(1)).coerceIn(0f, 1f)
        } else {
            ((distMeters % 160) / 160f).coerceIn(0f, 1f)
        }

        val cdFrac = 1f - (player.specialCooldown.toFloat() / player.specialMaxCooldown.coerceAtLeast(1)).coerceIn(0f, 1f)

        return HudUiState(
            screenState = screenState,
            mode = currentMode,
            form = player.form,
            hpFraction = (player.hp / player.maxHp).coerceIn(0f, 1f),
            energyFraction = (player.energy / player.maxEnergy).coerceIn(0f, 1f),
            specialReadyFraction = cdFrac,
            isLowHp = player.hp <= 30f && screenState == GameScreenState.PLAYING,
            isInvulnerable = player.invulnTimer > 0,
            score = score,
            distanceMeters = distMeters,
            lives = lives,
            combo = combo,
            comboStep = player.comboStep,
            biomeIndex = biomeIndex,
            waveNumber = waveNumber,
            objectiveText = objText,
            objectiveProgress = objProg,
            shardsCollected = shardsDone,
            totalShards = shardsTotal,
            bossActive = b != null && b.alive && arenaLockMaxX != null,
            bossName = b?.title ?: "",
            bossHpFraction = if (b != null && b.maxHp > 0f) (b.hp / b.maxHp).coerceIn(0f, 1f) else 0f,
            bossPhase2 = b?.phase2 == true,
            bannerVisible = bannerTimer > 0,
            bannerSub = bannerSub,
            bannerTitle = bannerTitle,
            contextualHint = contextualHint,
            radialDialOpen = radialDial.open
        )
    }

    private fun rectsOverlap(ax: Float, ay: Float, aw: Float, ah: Float, bx: Float, by: Float, bw: Float, bh: Float): Boolean {
        return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by
    }
}
