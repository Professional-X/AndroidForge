package com.example.ui.canvas

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.game.AlienForm
import com.example.game.AttackPhase
import com.example.game.INK_PALETTES
import com.example.game.PlayerState
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class SketchArt(context: Context) {

    val markerTypeface: Typeface = ResourcesCompat.getFont(context, R.font.permanent_marker) ?: Typeface.DEFAULT_BOLD
    val noteTypeface: Typeface = ResourcesCompat.getFont(context, R.font.patrick_hand) ?: Typeface.DEFAULT_BOLD

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val hatchPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = markerTypeface
    }
    private val textStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        textAlign = Paint.Align.CENTER
        typeface = markerTypeface
    }
    private val polyPath = Path()
    private val tempRect = RectF()
    private val dashEffect = DashPathEffect(floatArrayOf(6f, 5f), 0f)
    private val dash12 = DashPathEffect(floatArrayOf(12f, 8f), 0f)

    private val biomeShaders = Array<BitmapShader?>(4) { null }
    private val paperColors = intArrayOf(0xFFFBF5E6.toInt(), 0xFFE8F4F8.toInt(), 0xFFEEE2DF.toInt(), 0xFFF3EDFB.toInt())
    private val shaderMatrix = Matrix()

    var currentInkColor: Int = 0xFF14161F.toInt()
    var currentHighlightColor: Int = 0xFF4ADE80.toInt()

    init {
        initBiomeTextures()
    }

    fun applyPalette(paletteId: String) {
        val pal = INK_PALETTES.find { it.id == paletteId } ?: INK_PALETTES.first()
        currentInkColor = pal.inkHex
        currentHighlightColor = pal.highlightHex
    }

    private fun sketchHash(a: Float, b: Float, seed: Float = 0f): Float {
        val n = sin(a * 127.1f + b * 311.7f + seed * 74.7f) * 43758.5453f
        return (n - kotlin.math.floor(n)) * 2f - 1f
    }

    private fun initBiomeTextures() {
        // Biome 0: Warm Ruled Sketchpad
        val b0 = Bitmap.createBitmap(336, 336, Bitmap.Config.ARGB_8888)
        Canvas(b0).apply {
            drawColor(paperColors[0])
            val dotP = Paint().apply { color = 0x1E78644B }
            for (i in 0 until 260) {
                val x = abs(sketchHash(i.toFloat(), 1f, 3f)) * 336f
                val y = abs(sketchHash(i.toFloat(), 2f, 7f)) * 336f
                drawRect(x, y, x + 1.5f, y + 1.5f, dotP)
            }
            val lineP = Paint().apply { color = 0x2E3B82F6; strokeWidth = 1.25f }
            var y = 28f
            while (y <= 336f) {
                drawLine(0f, y, 336f, y + 0.3f, lineP)
                y += 28f
            }
        }
        biomeShaders[0] = BitmapShader(b0, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)

        // Biome 1: Cyan Blueprint Graph Pad
        val b1 = Bitmap.createBitmap(240, 240, Bitmap.Config.ARGB_8888)
        Canvas(b1).apply {
            drawColor(paperColors[1])
            val minorP = Paint().apply { color = 0x1F0E7490; strokeWidth = 1f }
            val majorP = Paint().apply { color = 0x3A0E7490; strokeWidth = 1.5f }
            for (g in 0 until 240 step 24) {
                val p = if (g % 120 == 0) majorP else minorP
                drawLine(g.toFloat(), 0f, g.toFloat(), 240f, p)
                drawLine(0f, g.toFloat(), 240f, g.toFloat(), p)
            }
        }
        biomeShaders[1] = BitmapShader(b1, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)

        // Biome 2: Aged War-Sketch Cardstock
        val b2 = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        Canvas(b2).apply {
            drawColor(paperColors[2])
            val grainP = Paint().apply { color = 0x1C3C2D2D }
            for (i in 0 until 280) {
                val x = abs(sketchHash(i.toFloat(), 9f, 17f)) * 256f
                val y = abs(sketchHash(i.toFloat(), 4f, 21f)) * 256f
                drawRect(x, y, x + 2f, y + 1.5f, grainP)
            }
            val diagP = Paint().apply { color = 0x16B91C1C; strokeWidth = 1.3f }
            for (i in -256 until 512 step 32) {
                drawLine(i.toFloat(), 256f, i + 256f, 0f, diagP)
            }
        }
        biomeShaders[2] = BitmapShader(b2, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)

        // Biome 3: Null Void Dotted Sketch Journal
        val b3 = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
        Canvas(b3).apply {
            drawColor(paperColors[3])
            val dotP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x386D28D9 }
            for (yy in 12 until 192 step 24) {
                for (xx in 12 until 192 step 24) {
                    drawCircle(xx.toFloat(), yy.toFloat(), 1.4f, dotP)
                }
            }
        }
        biomeShaders[3] = BitmapShader(b3, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }

    fun renderPaperBackground(canvas: Canvas, viewW: Float, viewH: Float, biomeIdx: Int) {
        val shader = biomeShaders[biomeIdx.mod(4)]
        fillPaint.shader = shader
        if (shader != null) {
            shaderMatrix.reset()
            shader.setLocalMatrix(shaderMatrix)
        } else {
            fillPaint.color = paperColors[biomeIdx.mod(4)]
        }
        canvas.drawRect(0f, 0f, viewW, viewH, fillPaint)
        fillPaint.shader = null

        // Subtle notebook edge vignette & margin details
        when (biomeIdx.mod(4)) {
            0 -> {
                strokePaint.color = 0x48F43F5E
                strokePaint.strokeWidth = 1.4f
                canvas.drawLine(56f, 0f, 56f, viewH, strokePaint)
                canvas.drawLine(61f, 0f, 61f, viewH, strokePaint)
                var y = 26f
                while (y < viewH) {
                    fillPaint.color = 0xFF57534E.toInt()
                    canvas.drawCircle(20f, y, 5.8f, fillPaint)
                    strokePaint.color = currentInkColor
                    strokePaint.strokeWidth = 1.4f
                    canvas.drawCircle(20f, y, 5.8f, strokePaint)
                    strokePaint.color = 0xFF475569.toInt()
                    strokePaint.strokeWidth = 2.8f
                    tempRect.set(1f, y - 9f, 21f, y + 9f)
                    canvas.drawArc(tempRect, -80f, 160f, false, strokePaint)
                    y += 42f
                }
            }
            1 -> {
                strokePaint.color = 0x600E7490
                strokePaint.strokeWidth = 1.2f
                var x = 0f
                while (x < viewW) {
                    val h = if (x.toInt() % 120 == 0) 11f else 6f
                    canvas.drawLine(x, 0f, x, h, strokePaint)
                    canvas.drawLine(x, viewH, x, viewH - h, strokePaint)
                    x += 24f
                }
            }
            2 -> {
                fillPaint.color = 0x26292524
                canvas.drawRect(0f, 0f, viewW, 12f, fillPaint)
            }
            else -> {
                strokePaint.color = 0x356D28D9
                strokePaint.strokeWidth = 1.8f
                tempRect.set(14f, 14f, 62f, 62f)
                canvas.drawArc(tempRect, 0f, 300f, false, strokePaint)
            }
        }
    }

    fun highlighterGlow(canvas: Canvas, cx: Float, cy: Float, radius: Float, colorHex: Int, alpha: Float = 0.45f) {
        val a = (alpha * 255f).toInt().coerceIn(0, 255)
        val col = (colorHex and 0x00FFFFFF) or (a shl 24)
        val transparent = colorHex and 0x00FFFFFF
        fillPaint.shader = RadialGradient(cx, cy, radius.coerceAtLeast(1f), col, transparent, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, radius, fillPaint)
        fillPaint.shader = null
    }

    fun pencilCrosshatch(
        canvas: Canvas,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        spacing: Float,
        colorHex: Int,
        cross: Boolean = false
    ) {
        canvas.save()
        canvas.clipRect(x, y, x + w, y + h)
        hatchPaint.color = colorHex
        hatchPaint.strokeWidth = 1.3f
        var dx = -h
        while (dx <= w + h) {
            canvas.drawLine(x + dx, y + h, x + dx + h, y, hatchPaint)
            if (cross) {
                canvas.drawLine(x + dx, y, x + dx + h, y + h, hatchPaint)
            }
            dx += spacing
        }
        canvas.restore()
    }

    fun sketchLine(
        canvas: Canvas,
        x1: Float,
        y1: Float,
        x2: Float,
        y2: Float,
        colorHex: Int = currentInkColor,
        width: Float = 2.6f,
        overhang: Float = 0f
    ) {
        strokePaint.color = colorHex
        strokePaint.strokeWidth = width
        if (overhang > 0f) {
            val dx = x2 - x1
            val dy = y2 - y1
            val len = kotlin.math.hypot(dx, dy).coerceAtLeast(1f)
            val ux = (dx / len) * overhang
            val uy = (dy / len) * overhang
            canvas.drawLine(x1 - ux, y1 - uy, x2 + ux, y2 + uy, strokePaint)
        } else {
            canvas.drawLine(x1, y1, x2, y2, strokePaint)
        }
    }

    fun sketchPoly(
        canvas: Canvas,
        pts: FloatArray,
        fillHex: Int,
        inkHex: Int = currentInkColor,
        strokeWidth: Float = 2.5f,
        rim: Boolean = true
    ) {
        if (pts.size < 4) return
        polyPath.reset()
        polyPath.moveTo(pts[0], pts[1])
        var i = 2
        while (i < pts.size) {
            polyPath.lineTo(pts[i], pts[i + 1])
            i += 2
        }
        polyPath.close()

        fillPaint.color = fillHex
        canvas.drawPath(polyPath, fillPaint)
        if (rim) {
            strokePaint.color = 0x55FFFDF8
            strokePaint.strokeWidth = 1.4f
            canvas.drawLine(pts[0] + 1.5f, pts[1] + 1.5f, pts[2] - 1.5f, pts[3] + 1.5f, strokePaint)
        }
        strokePaint.color = inkHex
        strokePaint.strokeWidth = strokeWidth
        canvas.drawPath(polyPath, strokePaint)
    }

    fun sketchCircle(canvas: Canvas, cx: Float, cy: Float, r: Float, fillHex: Int, strokeWidth: Float = 2.5f, inkHex: Int = currentInkColor) {
        fillPaint.color = fillHex
        canvas.drawCircle(cx, cy, r, fillPaint)
        strokePaint.color = inkHex
        strokePaint.strokeWidth = strokeWidth
        canvas.drawCircle(cx, cy, r, strokePaint)
    }

    fun sketchOval(canvas: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, fillHex: Int, strokeWidth: Float = 2.4f, inkHex: Int = currentInkColor) {
        tempRect.set(cx - rx, cy - ry, cx + rx, cy + ry)
        fillPaint.color = fillHex
        canvas.drawOval(tempRect, fillPaint)
        strokePaint.color = inkHex
        strokePaint.strokeWidth = strokeWidth
        canvas.drawOval(tempRect, strokePaint)
    }

    fun comicDustCloud(canvas: Canvas, cx: Float, cy: Float, r: Float, strokeHex: Int, fillHex: Int) {
        val puffs = 6
        fillPaint.color = fillHex
        strokePaint.color = strokeHex
        strokePaint.strokeWidth = 2.0f
        for (i in 0 until puffs) {
            val a = (i.toFloat() / puffs) * 6.283f
            val px = cx + cos(a) * r * 0.42f
            val py = cy + sin(a) * r * 0.34f
            canvas.drawCircle(px, py, r * 0.56f, fillPaint)
        }
        canvas.drawCircle(cx, cy, r * 0.62f, fillPaint)
        for (i in 0 until puffs) {
            val a = (i.toFloat() / puffs) * 6.283f
            val px = cx + cos(a) * r * 0.42f
            val py = cy + sin(a) * r * 0.34f
            canvas.drawCircle(px, py, r * 0.56f, strokePaint)
        }
    }

    fun drawSketchFlame(canvas: Canvas, cx: Float, baseY: Float, w: Float, h: Float, seed: Float, frameCount: Int, alpha: Float = 1f) {
        val flicker = sin(frameCount * 0.34f + seed) * (w * 0.2f)
        val a = (alpha * 255f).toInt().coerceIn(0, 255)
        val outerColor = (0x00F97316) or (a shl 24)
        val innerColor = (0x00FDE047) or (a shl 24)
        val coreColor = (0x00FFFDF8) or (a shl 24)

        val outerPts = floatArrayOf(
            cx - w * 0.48f, baseY,
            cx - w * 0.52f, baseY - h * 0.45f,
            cx + flicker, baseY - h,
            cx + w * 0.52f, baseY - h * 0.45f,
            cx + w * 0.48f, baseY
        )
        sketchPoly(canvas, outerPts, outerColor, (currentInkColor and 0x00FFFFFF) or (a shl 24), 2.1f, rim = false)

        val innerPts = floatArrayOf(
            cx - w * 0.28f, baseY - 2f,
            cx - w * 0.30f, baseY - h * 0.4f,
            cx + flicker * 0.6f, baseY - h * 0.72f,
            cx + w * 0.30f, baseY - h * 0.4f,
            cx + w * 0.28f, baseY - 2f
        )
        sketchPoly(canvas, innerPts, innerColor, innerColor, 1f, rim = false)
        fillPaint.color = coreColor
        canvas.drawCircle(cx, baseY - h * 0.25f, w * 0.16f, fillPaint)
    }

    fun drawOutlinedText(canvas: Canvas, text: String, x: Float, y: Float, size: Float, fillHex: Int, tiltDeg: Float = 0f) {
        canvas.save()
        canvas.translate(x, y)
        if (tiltDeg != 0f) canvas.rotate(tiltDeg)
        textStrokePaint.textSize = size
        textStrokePaint.strokeWidth = 4.2f
        textStrokePaint.color = currentInkColor
        canvas.drawText(text, 0f, 0f, textStrokePaint)
        textPaint.textSize = size
        textPaint.color = fillHex
        canvas.drawText(text, 0f, 0f, textPaint)
        canvas.restore()
    }

    fun getDashEffect(): DashPathEffect = dashEffect
    fun getArenaDash(): DashPathEffect = dash12

    // -------------------------------------------------------------------------
    // Articulated Cartoon Limb & Pose System (Expressive Hero Animation)
    // -------------------------------------------------------------------------
    data class CartoonPose(
        val hipBob: Float,
        val torsoLean: Float,
        val headBob: Float,
        val headTilt: Float,
        val legL1: Float, val legL2: Float,
        val legR1: Float, val legR2: Float,
        val armL1: Float, val armL2: Float,
        val armR1: Float, val armR2: Float,
        val isAttacking: Boolean
    )

    private data class LimbResult(val mx: Float, val my: Float, val ex: Float, val ey: Float)

    private fun drawArticulatedLimb(
        canvas: Canvas,
        x0: Float, y0: Float,
        len1: Float, len2: Float,
        ang1: Float, ang2: Float,
        thickness: Float,
        fillHex: Int,
        endCapType: String = "fist",
        accentHex: Int = fillHex
    ): LimbResult {
        val mx = x0 + sin(ang1) * len1
        val my = y0 + cos(ang1) * len1
        val ex = mx + sin(ang1 + ang2) * len2
        val ey = my + cos(ang1 + ang2) * len2

        // Ink casing
        strokePaint.color = currentInkColor
        strokePaint.strokeWidth = thickness + 4.4f
        polyPath.reset()
        polyPath.moveTo(x0, y0)
        polyPath.lineTo(mx, my)
        polyPath.lineTo(ex, ey)
        canvas.drawPath(polyPath, strokePaint)

        // Inner fill
        strokePaint.color = fillHex
        strokePaint.strokeWidth = thickness
        canvas.drawPath(polyPath, strokePaint)

        // End cap
        fillPaint.color = accentHex
        strokePaint.color = currentInkColor
        strokePaint.strokeWidth = 2.1f
        when (endCapType) {
            "boot" -> {
                tempRect.set(ex + 3f - thickness * 0.72f, ey - thickness * 0.45f, ex + 3f + thickness * 0.72f, ey + thickness * 0.45f)
                canvas.drawOval(tempRect, fillPaint)
                canvas.drawOval(tempRect, strokePaint)
            }
            "wheel" -> {
                fillPaint.color = currentInkColor
                canvas.drawCircle(ex, ey, thickness * 0.75f, fillPaint)
                fillPaint.color = 0xFF22D3EE.toInt()
                canvas.drawCircle(ex, ey, thickness * 0.34f, fillPaint)
            }
            "blade" -> {
                val bPts = floatArrayOf(mx, my, ex + 12f, ey + 2f, ex - 2f, ey + 8f)
                sketchPoly(canvas, bPts, accentHex, currentInkColor, 2f, rim = false)
            }
            else -> {
                canvas.drawCircle(ex, ey, thickness * 0.62f, fillPaint)
                canvas.drawCircle(ex, ey, thickness * 0.62f, strokePaint)
            }
        }
        return LimbResult(mx, my, ex, ey)
    }

    private fun computeCartoonPose(player: PlayerState, frameCount: Int): CartoonPose {
        val speed = abs(player.vx)
        val isMoving = speed > 0.35f
        val runIntensity = (speed / 5.2f).coerceIn(0f, 1f)
        val isAttacking = player.attackAnimTimer > 0
        val atkProg = if (isAttacking) 1f - player.attackAnimTimer.toFloat() / player.attackAnimDuration.coerceAtLeast(1) else 0f

        var hipBob = 0f
        var torsoLean = 0f
        var headBob = 0f
        var headTilt = 0f
        var legL1 = 0f; var legL2 = 0f; var legR1 = 0f; var legR2 = 0f
        var armL1 = 0f; var armL2 = 0.25f; var armR1 = 0f; var armR2 = 0.25f

        when {
            player.celebrationTimer > 0 -> {
                val hop = abs(sin(frameCount * 0.25f)) * -6f
                hipBob = hop
                armL1 = 2.4f; armR1 = 2.5f
                legL1 = 0.25f; legR1 = -0.25f
            }
            player.damageRecoilTimer > 0 -> {
                torsoLean = -0.35f
                headTilt = -0.2f
                armL1 = -0.8f; armR1 = -0.5f
            }
            player.canFly && !player.onGround -> {
                torsoLean = (0.36f + player.vy * 0.045f + speed * 0.04f).coerceIn(-0.55f, 0.85f)
                hipBob = sin(frameCount * 0.14f) * 3f
                legL1 = -0.35f + sin(frameCount * 0.18f) * 0.15f; legL2 = -0.25f
                legR1 = -0.5f + cos(frameCount * 0.18f) * 0.15f; legR2 = -0.3f
                armL1 = -0.6f + sin(frameCount * 0.14f) * 0.2f
                armR1 = 0.45f + cos(frameCount * 0.14f) * 0.2f
            }
            !player.onGround -> {
                val rising = player.vy < 0f
                torsoLean = if (rising) -0.08f else 0.18f
                legL1 = if (rising) 0.65f else -0.25f
                legL2 = if (rising) -0.95f else -0.45f
                legR1 = if (rising) -0.35f else 0.35f
                legR2 = if (rising) -0.55f else -0.80f
                armL1 = if (rising) 2.4f else 2.1f; armL2 = 0.35f
                armR1 = if (rising) -0.8f else 1.7f; armR2 = 0.40f
            }
            player.landingRecoilTimer > 0 -> {
                hipBob = 4.5f
                torsoLean = 0.24f
                legL1 = 0.45f; legL2 = -0.85f
                legR1 = -0.45f; legR2 = -0.85f
                armL1 = -0.5f; armR1 = 0.6f
            }
            isMoving -> {
                val wp = player.walkPhase
                val s = sin(wp)
                val c = cos(wp)
                hipBob = abs(c) * -4.2f * runIntensity
                torsoLean = 0.14f + 0.16f * runIntensity
                headBob = sin(wp * 2f) * 1.8f * runIntensity
                headTilt = -torsoLean * 0.45f
                legL1 = s * (0.65f + 0.35f * runIntensity)
                legL2 = if (s > 0f) -0.25f else -0.95f * runIntensity
                legR1 = -s * (0.65f + 0.35f * runIntensity)
                legR2 = if (-s > 0f) -0.25f else -0.95f * runIntensity
                armL1 = -s * (0.65f + 0.45f * runIntensity)
                armL2 = 0.55f + 0.55f * runIntensity
                armR1 = s * (0.65f + 0.45f * runIntensity)
                armR2 = 0.55f + 0.55f * runIntensity
            }
            else -> {
                val breath = sin(frameCount * 0.08f)
                hipBob = breath * 1.4f
                headBob = breath * 1.1f
                legL1 = 0.14f; legL2 = -0.14f
                legR1 = -0.14f; legR2 = -0.12f
                armL1 = -0.18f + breath * 0.06f; armL2 = 0.35f
                armR1 = 0.22f - breath * 0.06f; armR2 = 0.38f
            }
        }

        if (isAttacking) {
            val windup = player.attackPhase == AttackPhase.WINDUP
            val thrust = if (windup) -0.55f else sin(atkProg * PI.toFloat())
            torsoLean += 0.28f * thrust
            armR1 = 1.55f * thrust + 0.2f
            armR2 = 0.12f
            armL1 = -0.75f * thrust
            armL2 = 0.65f
        }

        return CartoonPose(hipBob, torsoLean, headBob, headTilt, legL1, legL2, legR1, legR2, armL1, armL2, armR1, armR2, isAttacking)
    }

    fun drawHeroForm(
        canvas: Canvas,
        form: AlienForm,
        x: Float, y: Float, w: Float, h: Float,
        facing: Int,
        player: PlayerState,
        frameCount: Int,
        jumpHeld: Boolean,
        ghostAlpha: Float = 1f
    ) {
        val cx = x + w * 0.5f
        val bottomY = y + h
        val isReal = ghostAlpha >= 0.99f
        val pose = computeCartoonPose(player, frameCount)

        canvas.save()
        if (!isReal) {
            canvas.saveLayerAlpha(x - 50f, y - 50f, x + w + 50f, y + h + 50f, (ghostAlpha * 255).toInt())
        }

        if (isReal) {
            fillPaint.color = 0x38282C34
            tempRect.set(cx - w * 0.45f, bottomY - 4f, cx + w * 0.45f, bottomY + 5f)
            canvas.drawOval(tempRect, fillPaint)
        }

        canvas.translate(cx, bottomY)
        canvas.scale(player.squashX, player.squashY)
        canvas.scale(facing.toFloat(), 1f)

        // Cannonbolt rolling ball form
        if (form == AlienForm.CANNONBOLT && (player.rollTimer > 0 || (isReal && player.slamming))) {
            canvas.translate(0f, -h * 0.5f)
            canvas.rotate((frameCount * 28f) % 360f)
            sketchCircle(canvas, 0f, 0f, 25f, 0xFFEAB308.toInt(), 3.2f)
            sketchPoly(canvas, floatArrayOf(-17f, -8f, 17f, -8f, 21f, 8f, -21f, 8f), 0xFFFEF9C3.toInt(), currentInkColor, 2.2f)
            strokePaint.color = currentInkColor
            strokePaint.strokeWidth = 2.6f
            tempRect.set(-31f, -31f, 31f, 31f)
            canvas.drawArc(tempRect, 12f, 110f, false, strokePaint)
            canvas.drawArc(tempRect, 190f, 110f, false, strokePaint)
            if (!isReal) canvas.restore()
            canvas.restore()
            return
        }

        canvas.translate(0f, pose.hipBob)
        val hipY = -20f
        val shoulderY = -40f
        val torsoDeg = (pose.torsoLean * 180f / PI.toFloat())

        fun withTorso(block: () -> Unit) {
            canvas.save()
            canvas.translate(0f, hipY)
            canvas.rotate(torsoDeg)
            canvas.translate(0f, -hipY)
            block()
            canvas.restore()
        }

        when (form) {
            AlienForm.BEN -> {
                drawArticulatedLimb(canvas, -4f, hipY, 10f, 10f, pose.legL1, pose.legL2, 5.5f, 0xFF1D4ED8.toInt(), "boot", 0xFF16A34A.toInt())
                withTorso { drawArticulatedLimb(canvas, -6f, shoulderY + 3f, 9f, 9f, pose.armL1, pose.armL2, 4.5f, 0xFF16A34A.toInt(), "fist", 0xFFFED7AA.toInt()) }
                drawArticulatedLimb(canvas, 4f, hipY, 10f, 10f, pose.legR1, pose.legR2, 5.8f, 0xFF2563EB.toInt(), "boot", 0xFF22C55E.toInt())
                withTorso {
                    sketchPoly(canvas, floatArrayOf(-10f, shoulderY, 10f, shoulderY, 9f, hipY + 2f, -9f, hipY + 2f), 0xFF16A34A.toInt(), strokeWidth = 2.6f)
                    fillPaint.color = 0xFFFFFDF8.toInt()
                    canvas.drawRect(-2f, shoulderY + 1f, 2f, shoulderY + 19f, fillPaint)
                    canvas.save()
                    canvas.translate(0f, shoulderY - 6f + pose.headBob)
                    canvas.rotate(pose.headTilt * 180f / PI.toFloat())
                    sketchCircle(canvas, 0f, 0f, 9.5f, 0xFFFED7AA.toInt(), 2.5f)
                    val hs = (-player.vx * 0.45f).coerceIn(-5f, 5f)
                    sketchPoly(canvas, floatArrayOf(-11f, -3f, -10f + hs, -13f, -2f + hs, -10f, 3f + hs * 0.5f, -15f, 10f, -8f, 10f, -2f, 0f, -4f), 0xFF78350F.toInt(), strokeWidth = 2.2f)
                    fillPaint.color = 0xFFFFFDF8.toInt(); canvas.drawCircle(4f, -1f, 2.8f, fillPaint)
                    fillPaint.color = currentInkColor; canvas.drawCircle(4.8f, -1f, 1.5f, fillPaint)
                    canvas.restore()
                    val armTip = drawArticulatedLimb(canvas, 5f, shoulderY + 3f, 9.5f, 9.5f, pose.armR1, pose.armR2, 4.8f, 0xFF22C55E.toInt(), "fist", 0xFFFED7AA.toInt())
                    highlighterGlow(canvas, armTip.mx, armTip.my, 11f, currentHighlightColor, 0.72f)
                    sketchCircle(canvas, armTip.mx, armTip.my, 3.6f, 0xFF10B981.toInt(), 1.6f)
                }
            }
            AlienForm.HEATBLAST -> {
                if (isReal && !player.onGround && jumpHeld) {
                    drawSketchFlame(canvas, -6f, 6f, 12f, 22f, 1f, frameCount, 0.9f)
                    drawSketchFlame(canvas, 6f, 6f, 12f, 22f, 3f, frameCount, 0.9f)
                }
                drawArticulatedLimb(canvas, -5f, hipY, 10f, 10f, pose.legL1, pose.legL2, 6f, 0xFF292524.toInt(), "boot", 0xFFF97316.toInt())
                withTorso { drawArticulatedLimb(canvas, -7f, shoulderY + 2f, 10f, 10f, pose.armL1, pose.armL2, 5.2f, 0xFF292524.toInt(), "fist", 0xFFFB923C.toInt()) }
                drawArticulatedLimb(canvas, 5f, hipY, 10f, 10f, pose.legR1, pose.legR2, 6.2f, 0xFF44403C.toInt(), "boot", 0xFFFB923C.toInt())
                withTorso {
                    sketchPoly(canvas, floatArrayOf(-12f, shoulderY - 2f, 12f, shoulderY - 2f, 10f, hipY + 2f, -10f, hipY + 2f), 0xFF292524.toInt(), strokeWidth = 2.7f)
                    sketchLine(canvas, -7f, shoulderY + 5f, 4f, shoulderY + 11f, 0xFFF97316.toInt(), 2.8f)
                    sketchLine(canvas, 4f, shoulderY + 11f, -3f, hipY - 1f, 0xFFFDE047.toInt(), 2.2f)
                    canvas.save()
                    canvas.translate(0f, shoulderY - 6f + pose.headBob)
                    highlighterGlow(canvas, 0f, -8f, 22f, 0xFFF97316.toInt(), 0.52f)
                    drawSketchFlame(canvas, -3f, 2f, 18f, 30f, 1f, frameCount, 1f)
                    drawSketchFlame(canvas, 4f, 3f, 15f, 25f, 4f, frameCount, 0.95f)
                    fillPaint.color = 0xFFFEF9C3.toInt()
                    canvas.drawCircle(4f, -3f, 2.8f, fillPaint)
                    canvas.restore()
                    val armEnd = drawArticulatedLimb(canvas, 6f, shoulderY + 2f, 10.5f, 10.5f, pose.armR1, pose.armR2, 5.4f, 0xFF44403C.toInt(), "fist", 0xFFF97316.toInt())
                    drawSketchFlame(canvas, armEnd.ex, armEnd.ey + 2f, 11f, 18f, 7f, frameCount, 0.85f)
                }
            }
            AlienForm.XLR8 -> {
                val tailW = sin(frameCount * 0.28f + player.walkPhase) * 6f
                withTorso {
                    polyPath.reset()
                    polyPath.moveTo(-6f, hipY)
                    polyPath.quadTo(-22f, hipY - 6f + tailW, -35f, hipY - 14f - tailW)
                    strokePaint.color = currentInkColor; strokePaint.strokeWidth = 7.5f
                    canvas.drawPath(polyPath, strokePaint)
                    strokePaint.color = 0xFF06B6D4.toInt(); strokePaint.strokeWidth = 3.6f
                    canvas.drawPath(polyPath, strokePaint)
                }
                drawArticulatedLimb(canvas, -4f, hipY, 10f, 10f, pose.legL1, pose.legL2, 5.2f, 0xFF0F172A.toInt(), "wheel")
                withTorso { drawArticulatedLimb(canvas, -5f, shoulderY + 3f, 9f, 9f, pose.armL1, pose.armL2, 4.2f, 0xFF0F172A.toInt(), "fist", 0xFF06B6D4.toInt()) }
                drawArticulatedLimb(canvas, 4f, hipY, 10f, 10f, pose.legR1, pose.legR2, 5.4f, 0xFF1E293B.toInt(), "wheel")
                withTorso {
                    sketchPoly(canvas, floatArrayOf(-10f, shoulderY, 10f, shoulderY, 8f, hipY + 2f, -8f, hipY + 2f), 0xFF0F172A.toInt(), strokeWidth = 2.6f)
                    fillPaint.color = 0xFF06B6D4.toInt(); canvas.drawRect(0f, shoulderY + 2f, 4f, shoulderY + 18f, fillPaint)
                    canvas.save()
                    canvas.translate(0f, shoulderY - 6f + pose.headBob)
                    sketchPoly(canvas, floatArrayOf(-14f, -2f, -20f, -11f, 6f, -11f, 15f, -2f, 8f, 6f, -8f, 6f), 0xFF0F172A.toInt(), strokeWidth = 2.5f)
                    highlighterGlow(canvas, 8f, -2f, 11f, 0xFF22D3EE.toInt(), 0.65f)
                    fillPaint.color = 0xFF22D3EE.toInt(); canvas.drawRect(2f, -4f, 12f, 1f, fillPaint)
                    canvas.restore()
                    drawArticulatedLimb(canvas, 5f, shoulderY + 3f, 9.5f, 9.5f, pose.armR1, pose.armR2, 4.5f, 0xFF1E293B.toInt(), "fist", 0xFF06B6D4.toInt())
                }
            }
            AlienForm.FOURARMS -> {
                val bigHipY = -24f
                val bigShY = -50f
                drawArticulatedLimb(canvas, -8f, bigHipY, 12f, 12f, pose.legL1, pose.legL2, 8.5f, 0xFFB91C1C.toInt(), "boot", currentInkColor)
                withTorso {
                    drawArticulatedLimb(canvas, -13f, bigShY + 2f, 12f, 12f, pose.armL1 - 0.3f, pose.armL2, 7.2f, 0xFFB91C1C.toInt(), "fist", 0xFFEF4444.toInt())
                    drawArticulatedLimb(canvas, -11f, bigShY + 14f, 11f, 11f, pose.armR1 * 0.7f - 0.4f, pose.armR2 + 0.2f, 6.8f, 0xFFB91C1C.toInt(), "fist", 0xFFEF4444.toInt())
                }
                drawArticulatedLimb(canvas, 8f, bigHipY, 12f, 12f, pose.legR1, pose.legR2, 8.8f, 0xFFDC2626.toInt(), "boot", currentInkColor)
                withTorso {
                    sketchPoly(canvas, floatArrayOf(-18f, bigShY, 18f, bigShY, 14f, bigHipY + 2f, -14f, bigHipY + 2f), 0xFFEF4444.toInt(), strokeWidth = 3.0f)
                    fillPaint.color = currentInkColor; canvas.drawRect(-15f, bigHipY - 3f, 15f, bigHipY + 3f, fillPaint)
                    fillPaint.color = 0xFFFACC15.toInt(); canvas.drawRect(-5f, bigHipY - 3f, 5f, bigHipY + 3f, fillPaint)
                    canvas.save()
                    canvas.translate(0f, bigShY - 8f + pose.headBob)
                    sketchCircle(canvas, 0f, 0f, 10.5f, 0xFFEF4444.toInt(), 2.8f)
                    fillPaint.color = 0xFFFEF08A.toInt()
                    canvas.drawCircle(3f, -3f, 2.2f, fillPaint); canvas.drawCircle(7.5f, -2f, 1.9f, fillPaint)
                    canvas.drawCircle(3f, 2f, 1.9f, fillPaint); canvas.drawCircle(7.5f, 2f, 1.7f, fillPaint)
                    canvas.restore()
                    drawArticulatedLimb(canvas, 13f, bigShY + 2f, 13f, 13f, pose.armR1, pose.armR2, 7.6f, 0xFFEF4444.toInt(), "fist", 0xFFFCA5A5.toInt())
                    drawArticulatedLimb(canvas, 11f, bigShY + 14f, 11.5f, 11.5f, pose.armL1 * 0.8f + 0.5f, pose.armL2 + 0.1f, 7.0f, 0xFFDC2626.toInt(), "fist", 0xFFFCA5A5.toInt())
                }
            }
            AlienForm.DIAMONDHEAD -> {
                val dShY = -44f
                drawArticulatedLimb(canvas, -5f, hipY, 10f, 10f, pose.legL1, pose.legL2, 6.2f, 0xFF0F766E.toInt(), "boot", 0xFF2DD4BF.toInt())
                withTorso { drawArticulatedLimb(canvas, -8f, dShY + 3f, 10f, 10f, pose.armL1, pose.armL2, 5.5f, 0xFF0D9488.toInt(), "blade", 0xFF5EEAD4.toInt()) }
                drawArticulatedLimb(canvas, 5f, hipY, 10f, 10f, pose.legR1, pose.legR2, 6.5f, 0xFF14B8A6.toInt(), "boot", 0xFF5EEAD4.toInt())
                withTorso {
                    sketchPoly(canvas, floatArrayOf(-13f, dShY, 13f, dShY, 10f, hipY + 2f, -10f, hipY + 2f), 0xFF14B8A6.toInt(), strokeWidth = 2.8f)
                    sketchPoly(canvas, floatArrayOf(-12f, dShY + 2f, -22f, dShY - 12f, -7f, dShY - 4f), 0xFF5EEAD4.toInt(), strokeWidth = 2.2f)
                    sketchPoly(canvas, floatArrayOf(12f, dShY + 2f, 22f, dShY - 12f, 7f, dShY - 4f), 0xFF5EEAD4.toInt(), strokeWidth = 2.2f)
                    canvas.save()
                    canvas.translate(0f, dShY - 8f + pose.headBob)
                    sketchPoly(canvas, floatArrayOf(-8f, 6f, -10f, -8f, 0f, -15f, 10f, -8f, 8f, 6f), 0xFF2DD4BF.toInt(), strokeWidth = 2.7f)
                    fillPaint.color = 0xFFFFFDF8.toInt(); canvas.drawRect(2f, -4f, 7f, -1f, fillPaint)
                    canvas.restore()
                    drawArticulatedLimb(canvas, 8f, dShY + 3f, 10.5f, 11f, pose.armR1, pose.armR2, 5.8f, 0xFF2DD4BF.toInt(), if (pose.isAttacking) "blade" else "fist", 0xFF99F6E4.toInt())
                }
            }
            AlienForm.CANNONBOLT -> {
                val cShY = -38f
                drawArticulatedLimb(canvas, -7f, -14f, 7f, 7f, pose.legL1, pose.legL2, 6.2f, currentInkColor, "boot", 0xFFEAB308.toInt())
                withTorso { drawArticulatedLimb(canvas, -12f, cShY + 8f, 8f, 8f, pose.armL1, pose.armL2, 5.6f, 0xFFEAB308.toInt(), "fist", 0xFFFEF9C3.toInt()) }
                drawArticulatedLimb(canvas, 7f, -14f, 7f, 7f, pose.legR1, pose.legR2, 6.5f, currentInkColor, "boot", 0xFFEAB308.toInt())
                withTorso {
                    sketchOval(canvas, 0f, -25f, 18f, 16f, 0xFFFEF9C3.toInt(), 2.8f)
                    sketchPoly(canvas, floatArrayOf(-17f, -32f, -9f, -44f, 9f, -44f, 17f, -32f, 0f, -28f), 0xFFEAB308.toInt(), strokeWidth = 2.5f)
                    canvas.save()
                    canvas.translate(3f, cShY - 5f + pose.headBob)
                    sketchCircle(canvas, 0f, 0f, 8.5f, 0xFFFEF9C3.toInt(), 2.4f)
                    fillPaint.color = currentInkColor; canvas.drawRect(3f, -2f, 8f, 1f, fillPaint)
                    canvas.restore()
                    drawArticulatedLimb(canvas, 12f, cShY + 8f, 8.5f, 8.5f, pose.armR1, pose.armR2, 5.8f, 0xFFEAB308.toInt(), "fist", 0xFFFEF9C3.toInt())
                }
            }
            AlienForm.JETRAY -> {
                val wPhase = if (isReal) player.wingPhase else frameCount * 0.25f
                val wingY = sin(wPhase) * 17f
                val tipLag = cos(wPhase) * 9f
                withTorso {
                    sketchPoly(canvas, floatArrayOf(-4f, shoulderY + 4f, -24f, shoulderY - 8f + wingY * 0.7f, -40f, shoulderY - 2f + wingY + tipLag, -14f, hipY + 2f), 0xFFEAB308.toInt(), strokeWidth = 2.5f)
                    val tw = sin(frameCount * 0.22f) * 5f
                    sketchLine(canvas, -4f, hipY, -24f, hipY + 12f + tw, 0xFFE11D48.toInt(), 4.5f)
                    drawArticulatedLimb(canvas, -3f, hipY, 9f, 9f, pose.legL1, pose.legL2, 4.5f, 0xFFE11D48.toInt(), "boot", 0xFFFACC15.toInt())
                    drawArticulatedLimb(canvas, 3f, hipY, 9f, 9f, pose.legR1, pose.legR2, 4.5f, 0xFFF43F5E.toInt(), "boot", 0xFFFACC15.toInt())
                    sketchPoly(canvas, floatArrayOf(-9f, shoulderY, 9f, shoulderY, 7f, hipY + 2f, -7f, hipY + 2f), 0xFFF43F5E.toInt(), strokeWidth = 2.7f)
                    sketchCircle(canvas, 0f, shoulderY + 10f, 4.5f, 0xFF4ADE80.toInt(), 1.6f)
                    sketchPoly(canvas, floatArrayOf(4f, shoulderY + 4f, 22f, shoulderY - 10f + wingY * 0.75f, 38f, shoulderY - 4f + wingY + tipLag, 12f, hipY + 2f), 0xFFFACC15.toInt(), strokeWidth = 2.6f)
                    canvas.save()
                    canvas.translate(0f, shoulderY - 6f + pose.headBob)
                    sketchPoly(canvas, floatArrayOf(-14f, -7f, 0f, -11f, 14f, -7f, 8f, 4f, -8f, 4f), 0xFFF43F5E.toInt(), strokeWidth = 2.5f)
                    fillPaint.color = 0xFFA3E635.toInt(); canvas.drawCircle(4.5f, -2f, 2.8f, fillPaint)
                    canvas.restore()
                }
            }
            AlienForm.STINKFLY -> {
                val wPhase = if (isReal) player.wingPhase * 1.9f else frameCount * 0.55f
                val upStroke = sin(wPhase) * 10f
                val lowStroke = cos(wPhase) * 8f
                withTorso {
                    sketchOval(canvas, -18f, shoulderY - 2f + upStroke, 19f, 8.5f, 0xDCF0FDF4.toInt(), 1.7f, 0xFF1D4ED8.toInt())
                    sketchOval(canvas, -15f, shoulderY + 7f + lowStroke, 15f, 6.5f, 0xDCF0FDF4.toInt(), 1.7f, 0xFF1D4ED8.toInt())
                    val stingExt = if (pose.isAttacking) 12f else 0f
                    sketchPoly(canvas, floatArrayOf(-4f, hipY, -22f - stingExt, hipY - 8f, -7f, hipY + 5f), currentInkColor, strokeWidth = 2f)
                    drawArticulatedLimb(canvas, -5f, hipY, 8f, 8f, pose.legL1, pose.legL2, 3.6f, 0xFF65A30D.toInt(), "fist")
                    drawArticulatedLimb(canvas, 5f, hipY, 8f, 8f, pose.legR1, pose.legR2, 3.8f, 0xFF84CC16.toInt(), "fist")
                    sketchPoly(canvas, floatArrayOf(-9f, shoulderY, 9f, shoulderY, 8f, hipY + 3f, -8f, hipY + 3f), 0xFF84CC16.toInt(), strokeWidth = 2.7f)
                    fillPaint.color = 0xFFFEF9C3.toInt(); canvas.drawRect(-5f, shoulderY + 4f, 5f, shoulderY + 17f, fillPaint)
                    sketchOval(canvas, 18f, shoulderY - 2f - upStroke, 19f, 8.5f, 0xE0FFFDF8.toInt(), 1.7f, 0xFF1D4ED8.toInt())
                    sketchOval(canvas, 15f, shoulderY + 7f - lowStroke, 15f, 6.5f, 0xE0FFFDF8.toInt(), 1.7f, 0xFF1D4ED8.toInt())
                    canvas.save()
                    canvas.translate(0f, shoulderY - 6f + pose.headBob)
                    sketchCircle(canvas, 0f, 0f, 8.5f, 0xFF84CC16.toInt(), 2.5f)
                    val sb = sin(frameCount * 0.3f) * 2f
                    sketchLine(canvas, -3f, -6f, -7f, -14f + sb, currentInkColor, 2.2f)
                    sketchLine(canvas, 4f, -6f, 8f, -14f - sb, currentInkColor, 2.2f)
                    fillPaint.color = 0xFFFB923C.toInt()
                    canvas.drawCircle(-7f, -14f + sb, 3.2f, fillPaint)
                    canvas.drawCircle(8f, -14f - sb, 3.2f, fillPaint)
                    canvas.restore()
                }
            }
        }

        if (!isReal) canvas.restore()
        canvas.restore()
    }
}
