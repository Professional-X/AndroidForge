package com.example.viewmodel

import android.app.Application
import android.view.KeyEvent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioSynthEngine
import com.example.data.local.AppDatabase
import com.example.data.local.GameRepository
import com.example.data.local.MissionProgressEntity
import com.example.data.local.RunRecordEntity
import com.example.data.local.UserPreferences
import com.example.game.AlienForm
import com.example.game.GameEngine
import com.example.game.GameMode
import com.example.game.GameScreenState
import com.example.game.HudUiState
import com.example.game.INK_PALETTES
import com.example.game.InkPalette
import com.example.game.MISSIONS
import com.example.game.NOTEBOOK_STICKERS
import com.example.game.NotebookSticker
import com.example.game.RunSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CosmeticUnlocks(
    val unlockedPaletteIds: Set<String> = setOf("CLASSIC_INK"),
    val unlockedStickerIds: Set<String> = emptySet()
)

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val repository = GameRepository(application, db.gameStatsDao())
    private val audio = AudioSynthEngine(application).apply { start() }

    private val _hudState = MutableStateFlow(HudUiState())
    val hudState: StateFlow<HudUiState> = _hudState.asStateFlow()

    private val _frameTick = MutableStateFlow(0L)
    val frameTick: StateFlow<Long> = _frameTick.asStateFlow()

    private val _lastSummary = MutableStateFlow<RunSummary?>(null)
    val lastSummary: StateFlow<RunSummary?> = _lastSummary.asStateFlow()

    val preferences: StateFlow<UserPreferences> = repository.preferences
        .stateIn(viewModelScope, SharingStarted.Eagerly, UserPreferences())

    val missionProgress: StateFlow<List<MissionProgressEntity>> = repository.missionProgress
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val topRuns: StateFlow<List<RunRecordEntity>> = repository.topRuns
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val bestEndlessScore: StateFlow<Int> = repository.bestEndlessScore
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    val bestEndlessDistance: StateFlow<Int> = repository.bestEndlessDistance
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    val cosmeticUnlocks: StateFlow<CosmeticUnlocks> = missionProgress
        .combine(preferences) { progressList, _ ->
            computeUnlocks(progressList)
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, CosmeticUnlocks())

    val engine: GameEngine = GameEngine(
        onPlaySfx = { cue -> audio.playSfx(cue) },
        onVibrate = { ms -> audio.vibrate(ms) },
        onRunFinished = { summary -> handleRunFinished(summary) },
        onBiomeChanged = { idx -> audio.biomeIndex = idx }
    )

    private var accumulatorNs: Long = 0L
    private val fixedStepNs: Long = 16_666_667L // 60 Hz

    init {
        viewModelScope.launch {
            preferences.collect { prefs ->
                audio.musicVolume = prefs.musicVolume
                audio.sfxVolume = prefs.sfxVolume
                audio.isMuted = prefs.isMuted
                audio.reducedMotion = prefs.reducedMotion
                engine.reducedMotion = prefs.reducedMotion
                engine.selectedInkPaletteId = prefs.selectedInkPaletteId
            }
        }
        syncHudAndAudio()
    }

    override fun onCleared() {
        super.onCleared()
        audio.release()
    }

    fun stepAnimationFrame(deltaNanos: Long) {
        val clamped = deltaNanos.coerceIn(0L, 120_000_000L)
        accumulatorNs += clamped
        var stepped = false
        while (accumulatorNs >= fixedStepNs) {
            engine.stepFrame()
            accumulatorNs -= fixedStepNs
            stepped = true
        }
        if (stepped) {
            _frameTick.value = _frameTick.value + 1L
            syncHudAndAudio()
        }
    }

    private fun syncHudAndAudio() {
        val hud = engine.snapshotHud()
        _hudState.value = hud
        audio.musicPlaying = hud.screenState == GameScreenState.PLAYING
        audio.dialDucked = hud.radialDialOpen
    }

    private fun computeUnlocks(progress: List<MissionProgressEntity>): CosmeticUnlocks {
        val palettes = mutableSetOf("CLASSIC_INK")
        val stickers = mutableSetOf<String>()
        val byId = progress.associateBy { it.missionId }

        MISSIONS.forEach { m ->
            val p = byId[m.mode.id]
            if (p != null && p.completed) {
                stickers.add(m.rewardStickerId)
                m.rewardPaletteId?.let { palettes.add(it) }
            }
        }
        if (progress.any { it.noDamageMedal }) stickers.add("STICKER_NODMG")
        if (progress.any { it.speedMedal }) stickers.add("STICKER_SPEED")
        return CosmeticUnlocks(palettes, stickers)
    }

    private fun handleRunFinished(summary: RunSummary) {
        val beforeUnlocks = cosmeticUnlocks.value
        val mission = MISSIONS.find { it.mode == summary.mode }
        var newSticker: NotebookSticker? = null
        var newPalette: InkPalette? = null

        if (summary.victory && mission != null) {
            if (!beforeUnlocks.unlockedStickerIds.contains(mission.rewardStickerId)) {
                newSticker = NOTEBOOK_STICKERS.find { it.id == mission.rewardStickerId }
            }
            val palId = mission.rewardPaletteId
            if (palId != null && !beforeUnlocks.unlockedPaletteIds.contains(palId)) {
                newPalette = INK_PALETTES.find { it.id == palId }
            }
        }
        if (newSticker == null && summary.noDamageMedal && !beforeUnlocks.unlockedStickerIds.contains("STICKER_NODMG")) {
            newSticker = NOTEBOOK_STICKERS.find { it.id == "STICKER_NODMG" }
        }
        if (newSticker == null && summary.speedMedal && !beforeUnlocks.unlockedStickerIds.contains("STICKER_SPEED")) {
            newSticker = NOTEBOOK_STICKERS.find { it.id == "STICKER_SPEED" }
        }

        val enriched = summary.copy(
            newStickerUnlocked = newSticker,
            newPaletteUnlocked = newPalette
        )
        _lastSummary.value = enriched

        if (summary.mode != GameMode.PRACTICE) {
            viewModelScope.launch {
                repository.recordRunAndMission(
                    modeId = summary.mode.id,
                    score = summary.score,
                    distanceMeters = summary.distanceMeters,
                    bossesDefeated = summary.bossesDefeated,
                    starsEarned = summary.stars,
                    victory = summary.victory,
                    favoriteForm = summary.favoriteForm.shortName,
                    durationSec = summary.durationSec,
                    noDamageMedal = summary.noDamageMedal,
                    allShardsMedal = summary.allShardsMedal,
                    speedMedal = summary.speedMedal
                )
            }
        }
        syncHudAndAudio()
    }

    // UI & User Actions
    fun startRun(mode: GameMode) {
        _lastSummary.value = null
        engine.startNewRun(mode)
        syncHudAndAudio()
    }

    fun restartCurrentRun() {
        startRun(engine.currentMode)
    }

    fun pauseGame() {
        engine.pause()
        syncHudAndAudio()
    }

    fun resumeGame() {
        engine.resume()
        syncHudAndAudio()
    }

    fun returnToMenu() {
        _lastSummary.value = null
        engine.returnToMenu()
        syncHudAndAudio()
    }

    fun toggleWatchDial() {
        if (engine.radialDial.open) {
            engine.confirmDialSelection(commit = true)
        } else {
            engine.openRadialDial(byTouch = false)
        }
        syncHudAndAudio()
    }

    fun selectDialAlien(index: Int) {
        if (index in AlienForm.entries.indices) {
            engine.transformTo(AlienForm.entries[index])
            engine.radialDial.open = false
            syncHudAndAudio()
        }
    }

    fun toggleMute() {
        viewModelScope.launch {
            repository.setMuted(!preferences.value.isMuted)
        }
    }

    fun setMusicVolume(vol: Float) {
        viewModelScope.launch {
            repository.setMusicVolume(vol)
        }
    }

    fun setSfxVolume(vol: Float) {
        viewModelScope.launch {
            repository.setSfxVolume(vol)
        }
    }

    fun toggleReducedMotion() {
        viewModelScope.launch {
            repository.setReducedMotion(!preferences.value.reducedMotion)
        }
    }

    fun selectInkPalette(paletteId: String) {
        if (cosmeticUnlocks.value.unlockedPaletteIds.contains(paletteId)) {
            viewModelScope.launch {
                repository.setInkPalette(paletteId)
            }
        }
    }

    // Hardware Keyboard Routing (WASD/Arrows, Space/W Jump, K/Z Punch, F/X/J Special, Q/E & 1-8 Transform, P/Esc Pause)
    fun handleKeyDown(keyCode: Int): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_P, KeyEvent.KEYCODE_ESCAPE -> {
                when (engine.screenState) {
                    GameScreenState.PLAYING -> pauseGame()
                    GameScreenState.PAUSED -> resumeGame()
                    else -> Unit
                }
                return true
            }
        }
        if (engine.screenState != GameScreenState.PLAYING) return false
        return when (keyCode) {
            KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_DPAD_LEFT -> { engine.input.keyLeft = true; true }
            KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_DPAD_RIGHT -> { engine.input.keyRight = true; true }
            KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_SPACE -> {
                if (!engine.input.jumpHeld) engine.triggerJump()
                engine.input.keyUp = true
                engine.input.jumpHeld = true
                true
            }
            KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (!engine.input.keyDown) engine.triggerDownAction()
                engine.input.keyDown = true
                true
            }
            KeyEvent.KEYCODE_K, KeyEvent.KEYCODE_Z -> { engine.triggerPunch(); true }
            KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_X, KeyEvent.KEYCODE_J -> { engine.triggerSpecialAction(); true }
            KeyEvent.KEYCODE_Q -> { engine.cycleAlien(-1); true }
            KeyEvent.KEYCODE_E -> { engine.cycleAlien(1); true }
            KeyEvent.KEYCODE_1 -> { engine.transformTo(AlienForm.entries[0]); true }
            KeyEvent.KEYCODE_2 -> { engine.transformTo(AlienForm.entries[1]); true }
            KeyEvent.KEYCODE_3 -> { engine.transformTo(AlienForm.entries[2]); true }
            KeyEvent.KEYCODE_4 -> { engine.transformTo(AlienForm.entries[3]); true }
            KeyEvent.KEYCODE_5 -> { engine.transformTo(AlienForm.entries[4]); true }
            KeyEvent.KEYCODE_6 -> { engine.transformTo(AlienForm.entries[5]); true }
            KeyEvent.KEYCODE_7 -> { engine.transformTo(AlienForm.entries[6]); true }
            KeyEvent.KEYCODE_8 -> { engine.transformTo(AlienForm.entries[7]); true }
            else -> false
        }
    }

    fun handleKeyUp(keyCode: Int): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_DPAD_LEFT -> { engine.input.keyLeft = false; true }
            KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_DPAD_RIGHT -> { engine.input.keyRight = false; true }
            KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_SPACE -> {
                engine.input.keyUp = false
                engine.input.jumpHeld = false
                true
            }
            KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_DPAD_DOWN -> { engine.input.keyDown = false; true }
            else -> false
        }
    }
}
