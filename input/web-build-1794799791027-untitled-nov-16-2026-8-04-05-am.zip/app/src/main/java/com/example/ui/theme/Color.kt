package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val InkBlack = Color(0xFF14161F)
val PaperCream = Color(0xFFFBF6EA)
val PaperWarm = Color(0xFFFBF5E6)
val PaperDark = Color(0xFFEFE3C8)
val TapeYellow = Color(0xFFFDE68A)
val HighlightYellow = Color(0xFFFEF08A)
val OmnitrixGreen = Color(0xFF10B981)
val OmnitrixBright = Color(0xFF4ADE80)
val OmnitrixDark = Color(0xFF052E16)
val BluePen = Color(0xFF1D4ED8)
val SkyPill = Color(0xFFE0F2FE)
val RedPen = Color(0xFFDC2626)
val AlertBg = Color(0xFFFEE2E2)
val GoldStar = Color(0xFFEAB308)
val GraphiteGray = Color(0xFF57534E)
