package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

enum class SfxCue {
    JUMP, DOUBLE_JUMP, BOING, TRANSFORM, DIAL_CLICK,
    PUNCH, DISC, FLAME, ZIP, TORNADO, SMASH, CRYSTAL,
    PINBALL, LASER, SLIME, WING_FLAP, COLLECT, CHECKPOINT,
    HIT, ENEMY_HIT, ENEMY_WARN, BOSS_ALARM, VICTORY,
    CHIRP, BARK, HOOT, TRUMPET
}

class AudioSynthEngine(context: Context) {

    private data class Voice(
        var freqStart: Float,
        var freqEnd: Float,
        val wave: Int, // 0=sine, 1=triangle, 2=saw, 3=square, 4=noise
        val totalSamples: Int,
        val gain: Float,
        val isMusic: Boolean,
        var delaySamples: Int = 0,
        var sampleIdx: Int = 0,
        var phase: Double = 0.0,
        var lfoFreq: Float = 0f,
        var lfoDepth: Float = 0f
    )

    private data class BiomeTrack(
        val bass: FloatArray,
        val lead: FloatArray,
        val kicks: IntArray
    )

    private val soundtrack = arrayOf(
        BiomeTrack(
            bass = floatArrayOf(110f, 110f, 130.81f, 146.83f, 110f, 110f, 164.81f, 146.83f),
            lead = floatArrayOf(
                440f, 0f, 523.25f, 587.33f, 659.25f, 587.33f, 523.25f, 392f,
                440f, 0f, 659.25f, 783.99f, 659.25f, 587.33f, 523.25f, 493.88f
            ),
            kicks = intArrayOf(0, 4, 8, 12)
        ),
        BiomeTrack(
            bass = floatArrayOf(98f, 98f, 116.54f, 130.81f, 98f, 146.83f, 130.81f, 116.54f),
            lead = floatArrayOf(
                392f, 466.16f, 587.33f, 466.16f, 392f, 523.25f, 587.33f, 698.46f,
                783.99f, 698.46f, 587.33f, 523.25f, 466.16f, 523.25f, 392f, 0f
            ),
            kicks = intArrayOf(0, 4, 8, 12)
        ),
        BiomeTrack(
            bass = floatArrayOf(82.41f, 82.41f, 98f, 110f, 82.41f, 82.41f, 123.47f, 110f),
            lead = floatArrayOf(
                329.63f, 392f, 493.88f, 659.25f, 622.25f, 587.33f, 493.88f, 392f,
                329.63f, 493.88f, 659.25f, 783.99f, 739.99f, 659.25f, 587.33f, 493.88f
            ),
            kicks = intArrayOf(0, 4, 8, 10, 12)
        ),
        BiomeTrack(
            bass = floatArrayOf(123.47f, 123.47f, 146.83f, 164.81f, 123.47f, 185f, 164.81f, 146.83f),
            lead = floatArrayOf(
                493.88f, 587.33f, 739.99f, 659.25f, 587.33f, 493.88f, 440f, 493.88f,
                739.99f, 880f, 739.99f, 659.25f, 587.33f, 659.25f, 493.88f, 0f
            ),
            kicks = intArrayOf(0, 3, 8, 11)
        )
    )

    private val sampleRate = 22050
    private val stepSamples = (sampleRate * 0.148f).toInt()
    private val pendingVoices = ConcurrentLinkedQueue<Voice>()
    private val activeVoices = ArrayList<Voice>(32)

    @Volatile var musicVolume: Float = 0.55f
    @Volatile var sfxVolume: Float = 0.85f
    @Volatile var isMuted: Boolean = false
    @Volatile var musicPlaying: Boolean = false
    @Volatile var dialDucked: Boolean = false
    @Volatile var biomeIndex: Int = 0
    @Volatile var reducedMotion: Boolean = false

    private var running = false
    private var audioThread: Thread? = null
    private var audioTrack: AudioTrack? = null

    private val vibrator: Vibrator? = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }.getOrNull()

    fun start() {
        if (running) return
        running = true
        audioThread = Thread({ runAudioLoop() }, "OmniverseAudioSynth").apply {
            isDaemon = true
            start()
        }
    }

    fun release() {
        running = false
        audioThread?.interrupt()
        audioThread = null
        runCatching {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.release()
        }
        audioTrack = null
    }

    fun vibrate(ms: Long) {
        if (reducedMotion || isMuted) return
        val vib = vibrator ?: return
        runCatching {
            if (!vib.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(ms)
            }
        }
    }

    fun playSfx(cue: SfxCue) {
        if (isMuted || sfxVolume <= 0.01f || !running) return
        when (cue) {
            SfxCue.JUMP -> {
                addTone(230f, 560f, 1, 0.14f, 0.24f)
                addNoise(0.035f, 0.14f)
            }
            SfxCue.DOUBLE_JUMP -> {
                addTone(380f, 820f, 0, 0.12f, 0.22f)
                addTone(540f, 1080f, 1, 0.10f, 0.14f, delaySec = 0.04f)
            }
            SfxCue.BOING -> {
                addBoing(210f, 0.34f, 0.26f)
            }
            SfxCue.TRANSFORM -> {
                addTone(220f, 880f, 2, 0.20f, 0.22f)
                addTone(440f, 1320f, 1, 0.18f, 0.20f, delaySec = 0.05f)
                addNoise(0.05f, 0.16f)
            }
            SfxCue.DIAL_CLICK -> {
                addTone(760f, 1040f, 0, 0.04f, 0.15f)
            }
            SfxCue.PUNCH -> {
                addNoise(0.08f, 0.22f)
                addTone(210f, 70f, 1, 0.08f, 0.25f)
            }
            SfxCue.DISC -> {
                addTone(580f, 1180f, 0, 0.18f, 0.20f)
                addTone(900f, 480f, 1, 0.12f, 0.13f, delaySec = 0.07f)
            }
            SfxCue.FLAME -> {
                addNoise(0.26f, 0.28f)
                addTone(135f, 75f, 2, 0.24f, 0.16f)
            }
            SfxCue.ZIP -> {
                addTone(520f, 1950f, 0, 0.07f, 0.20f)
                addTone(960f, 2400f, 1, 0.09f, 0.16f, delaySec = 0.04f)
                addNoise(0.12f, 0.16f)
            }
            SfxCue.TORNADO -> {
                addNoise(0.30f, 0.22f)
                addTone(240f, 660f, 1, 0.28f, 0.16f)
            }
            SfxCue.SMASH -> {
                addTone(135f, 34f, 2, 0.30f, 0.32f)
                addNoise(0.20f, 0.28f)
            }
            SfxCue.CRYSTAL -> {
                addTone(1180f, 1760f, 0, 0.15f, 0.17f)
                addTone(1580f, 2380f, 1, 0.16f, 0.14f, delaySec = 0.04f)
            }
            SfxCue.PINBALL -> {
                addTone(340f, 920f, 3, 0.09f, 0.18f)
                addBoing(340f, 0.18f, 0.16f)
            }
            SfxCue.LASER -> {
                addTone(1240f, 260f, 2, 0.14f, 0.17f)
                addTone(920f, 180f, 3, 0.12f, 0.09f, delaySec = 0.03f)
            }
            SfxCue.SLIME -> {
                addNoise(0.12f, 0.18f)
                addTone(310f, 110f, 0, 0.13f, 0.22f)
                addTone(460f, 760f, 0, 0.08f, 0.13f, delaySec = 0.06f)
            }
            SfxCue.WING_FLAP -> {
                addNoise(0.065f, 0.10f)
            }
            SfxCue.COLLECT -> {
                addTone(680f, 1020f, 1, 0.08f, 0.20f)
                addTone(1040f, 1480f, 0, 0.11f, 0.18f, delaySec = 0.05f)
            }
            SfxCue.CHECKPOINT -> {
                floatArrayOf(523.25f, 659.25f, 783.99f, 1046.5f).forEachIndexed { i, f ->
                    addTone(f, f, 1, 0.16f, 0.18f, delaySec = i * 0.07f)
                }
            }
            SfxCue.HIT -> {
                addTone(260f, 52f, 2, 0.24f, 0.30f)
                addNoise(0.14f, 0.22f)
            }
            SfxCue.ENEMY_HIT -> {
                addTone(340f, 115f, 3, 0.07f, 0.19f)
                addNoise(0.03f, 0.14f)
            }
            SfxCue.ENEMY_WARN -> {
                addTone(880f, 1120f, 1, 0.06f, 0.12f)
            }
            SfxCue.BOSS_ALARM -> {
                addTone(440f, 300f, 2, 0.18f, 0.20f)
                addTone(440f, 300f, 2, 0.18f, 0.20f, delaySec = 0.22f)
            }
            SfxCue.VICTORY -> {
                floatArrayOf(523.25f, 659.25f, 783.99f, 1046.5f, 1318.5f).forEachIndexed { i, f ->
                    addTone(f, f, 1, 0.22f, 0.22f, delaySec = i * 0.085f)
                }
            }
            SfxCue.CHIRP -> {
                addTone(1550f, 2250f, 0, 0.06f, 0.08f)
                addTone(1700f, 2400f, 0, 0.06f, 0.07f, delaySec = 0.07f)
            }
            SfxCue.BARK -> {
                addTone(260f, 140f, 2, 0.08f, 0.09f)
                addTone(290f, 150f, 2, 0.07f, 0.08f, delaySec = 0.09f)
            }
            SfxCue.HOOT -> {
                addTone(460f, 430f, 0, 0.15f, 0.08f)
                addTone(390f, 360f, 0, 0.22f, 0.08f, delaySec = 0.18f)
            }
            SfxCue.TRUMPET -> {
                addTone(320f, 540f, 2, 0.22f, 0.09f)
            }
        }
    }

    private fun addTone(
        freqStart: Float,
        freqEnd: Float,
        wave: Int,
        durSec: Float,
        gain: Float,
        isMusic: Boolean = false,
        delaySec: Float = 0f
    ) {
        if (pendingVoices.size > 48) return
        pendingVoices.offer(
            Voice(
                freqStart = freqStart,
                freqEnd = freqEnd,
                wave = wave,
                totalSamples = (sampleRate * durSec).toInt().coerceAtLeast(1),
                gain = gain,
                isMusic = isMusic,
                delaySamples = (sampleRate * delaySec).toInt().coerceAtLeast(0)
            )
        )
    }

    private fun addNoise(durSec: Float, gain: Float, isMusic: Boolean = false) {
        if (pendingVoices.size > 48) return
        pendingVoices.offer(
            Voice(
                freqStart = 100f,
                freqEnd = 100f,
                wave = 4,
                totalSamples = (sampleRate * durSec).toInt().coerceAtLeast(1),
                gain = gain,
                isMusic = isMusic
            )
        )
    }

    private fun addBoing(baseFreq: Float, durSec: Float, gain: Float) {
        if (pendingVoices.size > 48) return
        pendingVoices.offer(
            Voice(
                freqStart = baseFreq,
                freqEnd = baseFreq * 1.9f,
                wave = 1,
                totalSamples = (sampleRate * durSec).toInt().coerceAtLeast(1),
                gain = gain,
                isMusic = false,
                lfoFreq = 28f,
                lfoDepth = 65f
            )
        )
    }

    private fun runAudioLoop() {
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) return

        val track = runCatching {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuf, 2048))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        }.getOrNull() ?: return

        audioTrack = track
        runCatching { track.play() }

        val chunkSize = 512
        val pcm = ShortArray(chunkSize)
        var seqCounter = 0
        var musicStep = 0

        while (running && !Thread.currentThread().isInterrupted) {
            while (true) {
                val v = pendingVoices.poll() ?: break
                if (activeVoices.size < 28) activeVoices.add(v)
            }

            val muted = isMuted
            val mVol = if (muted) 0f else (musicVolume * (if (dialDucked) 0.30f else 0.55f))
            val sVol = if (muted) 0f else sfxVolume

            for (i in 0 until chunkSize) {
                if (musicPlaying && !muted && mVol > 0.01f) {
                    if (seqCounter == 0) {
                        val tr = soundtrack[biomeIndex.mod(soundtrack.size)]
                        val s = musicStep % 16
                        val bf = tr.bass[s % 8]
                        if (bf > 0f) addMusicVoice(bf, bf, 2, 0.13f, 0.16f)
                        val lf = tr.lead[s]
                        if (lf > 0f) addMusicVoice(lf, lf, 3, 0.12f, 0.08f)
                        if (s in tr.kicks) addMusicVoice(128f, 40f, 0, 0.11f, 0.30f)
                        if (s % 4 == 2) addMusicNoise(0.06f, 0.08f)
                        musicStep = (musicStep + 1) % 16
                    }
                    seqCounter = (seqCounter + 1) % stepSamples
                }

                var mix = 0f
                var idx = activeVoices.size - 1
                while (idx >= 0) {
                    val v = activeVoices[idx]
                    if (v.delaySamples > 0) {
                        v.delaySamples--
                        idx--
                        continue
                    }
                    val t = v.sampleIdx.toFloat() / v.totalSamples.toFloat()
                    val env = (1f - t) * (1f - t)
                    var freq = v.freqStart + (v.freqEnd - v.freqStart) * t
                    if (v.lfoFreq > 0f) {
                        freq += sin(2.0 * PI * v.lfoFreq * (v.sampleIdx.toDouble() / sampleRate)).toFloat() * v.lfoDepth
                    }
                    v.phase = (v.phase + freq / sampleRate) % 1.0
                    val p = v.phase.toFloat()
                    val raw = when (v.wave) {
                        0 -> sin(p * 2.0 * PI).toFloat()
                        1 -> (1f - 4f * kotlin.math.abs(p - 0.5f))
                        2 -> (2f * p - 1f)
                        3 -> if (p < 0.5f) 1f else -1f
                        else -> Random.nextFloat() * 2f - 1f
                    }
                    val vol = if (v.isMusic) mVol else sVol
                    mix += raw * env * v.gain * vol

                    v.sampleIdx++
                    if (v.sampleIdx >= v.totalSamples) {
                        activeVoices.removeAt(idx)
                    }
                    idx--
                }

                val clamped = mix.coerceIn(-0.95f, 0.95f)
                pcm[i] = (clamped * 32767f).toInt().toShort()
            }

            val written = runCatching { track.write(pcm, 0, chunkSize) }.getOrDefault(-1)
            if (written < 0) break
        }
    }

    private fun addMusicVoice(f0: Float, f1: Float, wave: Int, dur: Float, gain: Float) {
        if (activeVoices.size < 24) {
            activeVoices.add(
                Voice(
                    freqStart = f0,
                    freqEnd = f1,
                    wave = wave,
                    totalSamples = (sampleRate * dur).toInt().coerceAtLeast(1),
                    gain = gain,
                    isMusic = true
                )
            )
        }
    }

    private fun addMusicNoise(dur: Float, gain: Float) {
        if (activeVoices.size < 24) {
            activeVoices.add(
                Voice(
                    freqStart = 100f,
                    freqEnd = 100f,
                    wave = 4,
                    totalSamples = (sampleRate * dur).toInt().coerceAtLeast(1),
                    gain = gain,
                    isMusic = true
                )
            )
        }
    }
}
