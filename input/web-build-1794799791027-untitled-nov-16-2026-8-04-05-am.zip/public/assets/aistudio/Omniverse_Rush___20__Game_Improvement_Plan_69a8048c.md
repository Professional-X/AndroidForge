# Omniverse Rush — 20× Game Improvement Plan

## Goal

Make the game feel less like an endless sequence of hazards and more like a memorable, responsive action game. “20× better” is an ambition, not a measurable guarantee: the biggest gains will come from a clear play loop, readable action, expressive characters, and meaningful progression—not from adding more effects or more buttons.

## Keep the foundation

The game already has a strong identity: a hand-drawn notebook world, side-scrolling movement, alien transformations, touch and keyboard controls, checkpoints, combat, and boss encounters. Keep the sketchbook look and the transformation fantasy. Improve the clarity and depth around them rather than replacing the game’s personality.

## What to remove or reduce

1. **Reduce visual noise in the action lane.** Keep scribbles and paper texture in the world, but lower the opacity or density of decorative marks near the player, enemies, projectiles, and landing surfaces. The player’s silhouette and immediate threats should win every visual competition. Keep standout doodles as landmarks, not a constant wall of overlapping lines.
2. **Remove effects that hide useful information.** Shorten or soften large screen flashes and shakes; cap particles during busy fights; keep damage numbers and hit sparks near the point of contact. A player should be able to tell whether they were hit, what hit them, and whether their attack connected.
3. **Simplify the first-run instruction dump.** Replace the full-page list of gestures with a short “move, jump, transform” tutorial, then teach attacks when the player reaches a safe first encounter. Keep a complete controls reference available from pause.
4. **Reduce control ambiguity.** A tap, swipe, hold, and watch-button action should not compete for the same area. Prefer a clear watch button for transformations, a consistent jump/flight control, and a separate special-attack action. Keep gestures as optional shortcuts, not the only way to use a core action.
5. **Reduce repetitive procedural filler.** Keep generated levels, but remove long stretches that repeat the same platform-and-enemy pattern without a new decision. Each short section should introduce a hazard, teach a response, then combine it with something the player already knows.
6. **Remove unfair, untelegraphed damage.** Enemies and bosses should show a readable wind-up before charging, firing, or striking. Avoid placing a projectile, enemy, or pit directly where a player lands without warning or a recovery option.
7. **Avoid feature clutter.** Do not add multiple currencies, intrusive pop-ups, compulsory daily chores, or power-ups that all do the same thing. Every added system should deepen movement, combat, transformation, or replay value.

## What to add

### 1. A stronger play loop

Give the game short, complete missions in addition to endless play. A useful structure is:

- **Start:** a clear objective and a quick visual preview of the zone.
- **Explore:** a few platforming and combat challenges that teach the zone’s mechanic.
- **Mix it up:** combine a familiar enemy with a new hazard or traversal choice.
- **Climax:** a miniboss, escape sequence, or focused boss encounter.
- **Reward:** show the result, unlock progress, and offer “next mission” or “endless run.”

Aim for a satisfying 3–5 minute mission. Preserve Endless Rush as a separate replay mode for score-chasing. Give players varied goals—reach the exit, rescue a character, collect Omnitrix fragments, clear a marked enemy group—so progress is not measured only by distance.

### 2. Make every alien feel different to control

Each form should have a distinct movement advantage, attack rhythm, and best use case. Use the existing roster rather than adding forms before the current ones feel unique.

| Form role | Make it feel special through… | Example encounter that rewards it |
|---|---|---|
| Fast form | Acceleration, air steering, short burst dash, and time trials | Speed gates, collapsing paths, or a chase |
| Heavy form | Weighty wind-up, broad hit, enemy stun, and strong landing | Armored enemies or breakable barriers |
| Flame form | Ranged pressure, controlled area damage, and heat interactions | Enemy groups or a lighting puzzle |
| Crystal form | Guard, reflect, or create temporary terrain | Projectile lanes or a gap with a crystal route |
| Rolling form | Momentum, impact, and a satisfying bounce or break | Sloped tracks, fragile walls, or a charge attack |
| Flying forms | Sustained flight with clear energy limits and precise steering | Elevated routes, aerial threats, or rescue objectives |
| Utility form | A unique way to interact with switches, traps, or small passages | A puzzle shortcut or a safe route around a hazard |

These are design roles, not a requirement to add extra powers. Make transformation decisions matter: the player should sometimes think “this form is the best tool here,” while still being able to finish with skill in another form.

### 3. Improve combat readability and mastery

- Give each enemy a recognizable silhouette, a short idle tell, a wind-up, an attack, and a recovery window.
- Add a compact combo system: light attack, follow-up, launcher or slam, and a finisher that differs by form.
- Make dodging and attacking feel intentional. Add clear hit-stop only for major hits, crisp hit sparks, distinct enemy reactions, and a small sound cue for a successful strike.
- Communicate player state: a readable low-health warning, energy feedback, temporary invulnerability cue, and a clear signal when an attack is on cooldown.
- Keep enemy projectiles visually distinct from friendly attacks. Use consistent color and shape language so players can parse danger quickly.
- Let the boss have a small number of learnable phases. Telegraph each phase change; give the player safe openings to counter rather than only more health to drain.

### 4. Make the hero feel alive

Keep the hand-drawn style, but strengthen the character read at gameplay size. The hero should have a distinctive silhouette, clear face/hair and outfit shapes, and a visible Omnitrix cue. Aliens should remain recognizable even when small on a phone.

Prioritize a compact animation set before adding elaborate detail:

- idle breathing/look-around;
- run with planted feet and form-specific cadence;
- jump anticipation, rising, falling, and a readable landing;
- form-specific flight or dash poses;
- attack wind-up, impact, and recovery;
- damage recoil, brief recovery, and transformation pose;
- win/mission-complete celebration.

Use anticipation and follow-through: a short lean before a dash, a clear pose before a heavy hit, and a small recoil after landing. Keep effects attached to the action. Do not make every action shake the camera; reserve the strongest camera response for boss hits, large slams, or a major transformation.

### 5. Give zones their own identity

Keep the notebook paper as the unifying art direction, then let each zone use a distinct accent palette, a few signature props, a different music layer, and one gameplay mechanic. Use parallax sparingly to add depth without reducing contrast. Make platforms and hazards readable by silhouette and edge treatment, not color alone.

Each zone should have at least one memorable landmark and one mechanic that changes how the player moves. A background should help the player understand where they are, not compete with the action.

### 6. Add fair progression and replay value

- Save mission completion, best score, and a small set of unlocks locally.
- Reward skill with optional objectives, medals, character palettes, or notebook stickers; avoid pay-to-win power increases.
- Add a simple mission board or chapter map so the player sees what comes next.
- Provide a practice area where players can test transformations and attacks without losing a run.
- Include a few challenge variants: time trial, no-damage run, collect-all route, or form-specific trial.
- Make the pause menu useful: controls, sound, reduced motion, restart confirmation, and a return-to-menu option.

### 7. Upgrade sound and feedback

Give each alien a recognizable transformation cue, each attack a distinct sound family, and each enemy type a clear warning sound. Keep music quieter than important attack cues. Add a small, satisfying mission-complete sting and a calm transition between zones. All sound should have an independent mute/volume control.

## Practical build order

### Phase 1 — Clarity and feel

1. Reduce scribble/effect clutter in the active play area.
2. Tune the hero’s silhouette, run/jump/land poses, and transformation feedback.
3. Make damage, enemy wind-ups, and successful hits unambiguous.
4. Simplify and teach mobile controls in context.
5. Add a tiny automated regression checklist for restart, checkpoint, pause/resume, transformation, game-over, and narrow-screen HUD layout.

### Phase 2 — One excellent vertical slice

Build one complete zone with a beginning, a traversal lesson, two or three enemy behaviors, one miniboss or boss, a clear mission objective, a reward, and a replay option. Make this short section feel polished before generating many more chunks or zones.

### Phase 3 — Form depth and variety

Give every form a distinct movement/combat identity; add form-specific challenges; then create additional zones that use the same clear mission structure with new mechanics and enemy combinations.

### Phase 4 — Replay and finish

Add local progression, optional challenges, accessibility checks, sound polish, performance testing, and a small set of unlockable visual rewards. Use playtests to remove confusing steps before expanding content.

## Success checks

Before calling an update “better,” verify that:

- A new player can start moving and understand the first objective within 30 seconds.
- The player and immediate hazards remain easy to see on both portrait and landscape screens.
- A hit has a clear cause and a fair warning; a successful attack has a clear response.
- At least three forms produce noticeably different decisions in the same short level.
- A mission can be completed, replayed, and understood without needing a score guide.
- Restarting, dying, pausing, changing forms, and reaching a checkpoint do not preserve stale input or create impossible states.
- The game remains readable with reduced motion enabled and playable using touch or keyboard.

## Highest-impact first five

If only five improvements are possible, do these first: **(1)** declutter the active play lane, **(2)** add a short mission objective and satisfying ending, **(3)** make enemy attacks telegraphed and combat feedback crisp, **(4)** give every alien a distinct movement/combat role, and **(5)** animate the hero with strong anticipation, impact, and recovery poses. Those changes will do more for perceived quality than simply adding more particles, enemies, or buttons.
