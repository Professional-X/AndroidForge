# Omniverse Rush — Native Android Sketchbook Action Game (20× Revised Plan)

A native Kotlin and Jetpack Compose Canvas side-scrolling action-platformer in a hand-drawn sketchbook aesthetic, combining structured 3–5 minute missions, an Endless Rush mode, a safe Practice Arena, 8 distinct alien transformations with telegraphed combat and combos, synthesized audio with independent volume controls, and local Room/DataStore progression.

## User Review & Critical Decisions

> [!IMPORTANT]
> Confirmed Phase 1 choices plus all **20× Game Improvement Plan** upgrades are unified below:
> - **Game Engine**: Pure native **Kotlin + Jetpack Compose Canvas** engine running at a fixed 60 Hz simulation step (no WebView wrapper).
> - **Orientation**: Dedicated **landscape mode** (`sensorLandscape`) with edge-to-edge rendering and `WindowInsets.safeDrawing` padding.
> - **Control Clarity (Gestures Without Ambiguity)**: Left-side floating joystick for run/fly movement; dedicated non-competing right-side action zones (Jump/Fly vs. Attack/Combo vs. Special) with optional swipe shortcuts, plus a clear **HUD Watch Button** for the slow-motion 8-Alien Radial Dial. Full keyboard/gamepad support is preserved.
> - **Play Modes & Loop**: **Mission Board** (4 structured missions with clear objectives, zone mechanics, miniboss/boss climaxes, and rewards), **Endless Rush** (replayable score/distance chase), and **Practice Dojo** (test all 8 forms safely).
> - **Local Persistence**: **Room** database (run history, mission stars, challenge medals, unlocked cosmetic notebook stickers & ink palettes) + **DataStore Preferences** (music/SFX volume, mute, reduced motion).

---

## 1. Overview & Core Concept

- **What It Does**: Players choose between curated **Story Missions** (reach the beacon, shatter shielded reactor cores, rescue allies, defeat Vilgax), **Endless Rush**, or **Practice Mode**, transforming seamlessly among Ben Tennyson and 7 aliens to match each encounter's traversal or combat challenge.
- **Target Audience & Context**: Fans of responsive 2D cartoon action-platformers on Android phones and tablets, tuned for readable landscape play and fair, learnable mastery.
- **Key Value**: Elevates the original HTML5 endless prototype into a cohesive, uncluttered native Android action game with strong silhouette contrast, telegraphed enemy patterns, meaningful form choices, and replayable local progression.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Launch & Mission Board**:
   - Opens directly over the live animated sketchbook canvas into a clean title/mode selector (**Play Missions**, **Endless Rush**, **Practice Dojo**), displaying unlocked medals, stickers, and personal bests—without dumping a wall of control instructions on first launch.
2. **Contextual Onboarding & Clear Controls**:
   - Mission 1 begins with a brief, in-world **"Move • Jump • Transform"** visual prompt, then introduces combat safely at the first telegraphed drone encounter.
   - **Touch Controls (Zero Ambiguity)**:
     - *Left 46%*: Floating dashed blue-pen joystick for horizontal movement and flying elevation.
     - *Right 54%*: Cleanly separated **Jump/Fly** (upper/swipe-up region), **Melee/Slam** (swipe-down or strike tap), and **Special** (dedicated right-edge tap region), so tap, hold, and swipe never conflict.
     - *Omnitrix Watch Button (Top-Left HUD)*: Dedicated, unmistakable tap target that opens the slow-motion (1/5th speed) 8-Alien Holographic Radial Dial (with optional quick-cycle swipe).
3. **Structured Mission Loop (3–5 Minutes Each)**:
   - **Start**: Objective card + quick zone preview (e.g., *"Collect 5 Omnitrix Shards & Break the Reactor"*).
   - **Explore**: Hand-crafted & variably paced sections that teach the zone's signature mechanic without repetitive filler.
   - **Mix It Up**: Combines familiar enemies with traversal puzzles that reward specific alien roles.
   - **Climax & Reward**: Focused miniboss or multi-phase Vilgax encounter with telegraphed windows, followed by a hero celebration pose, 1–3 star rating, optional challenge medals (*No-Damage*, *Speedrun*, *All-Shards*), and cosmetic sticker/palette unlocks.
4. **Useful Pause & Controls Reference**:
   - Full illustrated **Controls Reference**, independent **Music** & **SFX** volume sliders + Mute toggle, **Reduced Motion** toggle, **Restart Run** (with confirmation), and **Return to Menu**.

### Visual Identity & Action Clarity
- **Decluttered Action Lane**: Keep the ruled/graph/cardstock/dotted paper surfaces, B&W architectural doodles, and 10 animated background critters/allies (birds, dogs, elephants, eagles, owls, cats, frogs, turtles, Max, Gwen), but push decorative marks back with lower contrast/opacity near platforms, enemies, and projectiles so the hero and threats dominate every frame.
- **Controlled VFX & Readable Feedback**:
  - Soften and shorten full-screen flashes; cap active particles during hectic fights; anchor damage popups and hit sparks tightly to the point of contact.
  - Reserve heavy camera shake for boss hits, Four Arms/Cannonbolt slams, and major transformations.
  - Distinct visual language: friendly attacks use hero signature ink + bright highlighter fills; enemy threats use high-contrast warning crimson/violet shapes with pre-attack `!` glints and wind-up poses.
- **4 Distinct Zones & Mechanics**:
  - *Zone 1 — Bellwood Notebook Skyline* (`#FBF5E6` ruled pad, `#22C55E` emerald): Bounce pads, breakable barriers, and rescue beacons.
  - *Zone 2 — Plumber Blueprint Reactor* (`#E8F4F8` graph pad, `#06B6D4` cyan): Moving bridges, thermal switches, and shielded reactor cores.
  - *Zone 3 — Chimerian War-Sketch Deck* (`#EEE2DF` cardstock, `#F43F5E` crimson): Projectile reflect lanes, collapsing paths, and cyber-turret gauntlets.
  - *Zone 4 — Null Void Doodle Dimension* (`#F3EDFB` dotted journal, `#A855F7` violet): Ink portals, aerial shard routes, and Overlord Vilgax showdown.
- **Typography & Palette**:
  - Bundled local Google Fonts in `res/font/`: **Permanent Marker** (headings, comic bursts, HUD stats), **Architects Daughter** (body text), and **Patrick Hand** (badges, hints, speech bubbles).
  - Selectable cosmetic **Ink Palettes** & **Notebook Stickers** unlocked via mission stars/medals (purely visual, no pay-to-win stats).

---

## 3. Key Product Decisions & Trade-Offs

- **Structured Missions + Endless Rush vs. Endless-Only**
  - *Chosen Approach*: Add 4 curated, objective-driven Missions and a Practice Dojo alongside the full Endless Rush mode.
  - *Why*: Gives players clear goals, memorable climaxes, and rewarding progression while preserving endless score-chasing.
- **Distinct Alien Roles & Compact Combo System**
  - *Chosen Approach*: Differentiate all 8 forms through movement physics, a 3-step melee rhythm (Light -> Follow-up -> Finisher/Slam), and role-rewarding level encounters:
    - **Ben** (Utility/Balanced): Double jump, returning Omni Disc switch-trigger, versatile all-rounder.
    - **XLR8** (Speed): Rapid acceleration, air steering, Cyclone Zoom dash, speed-gate & collapsing-path specialist.
    - **Four Arms** (Heavy): Weighty wind-up, wide cleave + stun, Quake Slam, shatters armored barriers & heavy crates.
    - **Heatblast** (Flame): Jet-hover glide, ranged fireballs & lingering burn, ignites thermal switches and enemy groups.
    - **Diamondhead** (Crystal): Prism guard shield that reflects enemy bolts, erupting crystal spires for traversal & damage.
    - **Cannonbolt** (Rolling): Momentum pinball ball-form, rebounds off walls/enemies, smashes fragile walls and sloped tracks.
    - **Jetray & Stinkfly** (Flight): Sustained aerial steering with clear energy meter, neuro-laser speed vs. acid-slime crowd control for elevated rescues.
- **Expressive Hero Animation & Enemy Telegraphing**
  - *Chosen Approach*: Upgrade the articulated limb rig with dedicated states (idle breathing, cadence-matched run, jump anticipation, rising/falling/landing recoil, attack wind-up -> impact -> recovery, damage recoil, transformation burst, and victory celebration), and give every enemy/boss explicit idle -> wind-up -> strike -> recovery windows.
- **Native PCM Audio Mixer (`AudioTrack`) + Independent Volumes**
  - *Chosen Approach*: Real-time synthesized 4-biome music sequencer (quieter music bed) plus distinct per-alien transformation/attack sound families and enemy warning cues, controlled by independent Music and SFX sliders.
- **Local Room + DataStore Progression**
  - *Chosen Approach*: Persist mission stars, challenge medals, unlocked stickers/palettes, Endless Rush high scores, and run history locally in Room; persist audio/accessibility settings in DataStore.

---

## 4. Technical Architecture & Data Strategy

```
┌──────────────────────────────────────────────────────────────────────────┐
│                        MainActivity (Landscape)                          │
│     Edge-to-Edge • Immersive Safe Insets • Lifecycle Pause • Key Input   │
└────────────────────────────────────┬─────────────────────────────────────┘
                                     │
                                     ▼
┌──────────────────────────────────────────────────────────────────────────┐
│                       GameViewModel (MVVM + Flows)                       │
│  • Drives 60 Hz fixed-step loop (withFrameNanos) across Play/Practice    │
│  • Manages Mode Routing (Mission Board, Active Run, Pause, Summary)      │
│  • Exposes HudUiState, ProgressionState & AudioPrefs StateFlows          │
└───┬────────────────────────────────┬─────────────────────────────────┬───┘
    │                                │                                 │
    ▼                                ▼                                 ▼
┌────────────────────────┐ ┌────────────────────────┐ ┌────────────────────┐
│  Simulation & LevelMgr │ │   AudioSynth & Haptics │ │  Local Persistence │
│                        │ │                        │ │                    │
│ • Mission Builder (1-4)│ │ • Independent Music &  │ │ • Room Database    │
│ • Endless Chunk Gen    │ │   SFX Gain Mixer       │ │   (RunRecord,      │
│ • 8-Form Rig & Combos  │ │ • Per-Form Sound Family│ │    MissionProgress,│
│ • Telegraphed Enemy &  │ │ • Enemy Wind-Up Tells  │ │    UnlockedRewards)│
│   Multi-Phase Vilgax   │ │ • Victory Fanfare      │ │ • DataStore Prefs  │
│ • Decluttered VFX Cap  │ │ • Scaled Vibrator Hapt.│ │   (Vol, Mute, RM)  │
└───────────┬────────────┘ └────────────────────────┘ └────────────────────┘
            │
            ▼
┌──────────────────────────────────────────────────────────────────────────┐
│                 Jetpack Compose UI & SketchCanvas                        │
│                                                                          │
│ • SketchCanvas: Biome Paper Bitmaps, Low-Clutter Doodles, Articulated    │
│   Hero/Enemy Rigs, Telegraph Indicators, Joystick & 8-Alien Radial Dial  │
│ • TopHudOverlay: Watch Button, Low-HP/Cooldown Cues, Mission Obj Pill    │
│ • Taped Sketchbook Sheets: Mission Board, Controls Guide, Pause, Summary │
└──────────────────────────────────────────────────────────────────────────┘
```

### Data Model & Interactive State Mapping
- **World & Combat State**:
  - `PlayerState`: Position, velocity, form, combo step (`0..2`), combo window timer, attack phase (`IDLE`, `WINDUP`, `ACTIVE`, `RECOVERY`), stamina/energy, invulnerability blink timer, cooldown progress, and animation pose state.
  - `EnemyEntity` & `BossEntity`: State machine (`IDLE`, `PATROL`, `WINDUP`, `STRIKE`, `RECOVER`, `STUNNED`) with explicit telegraph timer so players always see an attack coming before impact.
  - `MissionObjective`: Tracks mode (`MISSION_1..4`, `ENDLESS`, `PRACTICE`), target goals (fragments, breakable cores, rescues, enemy waves, boss defeat), elapsed time, damage taken, and live completion banner.
- **Local Room Entities & DAOs**:
  - `RunRecordEntity`: Score, distance, mode, bosses defeated, stars, favorite alien, timestamp.
  - `MissionProgressEntity`: `missionId`, `completed`, `bestStars`, `bestTimeMs`, `noDamageMedal`, `allShardsMedal`, `speedMedal`.
  - `PreferenceStore` (DataStore): `musicVolume`, `sfxVolume`, `isMuted`, `reducedMotion`, `selectedInkPaletteId`.
- **Automated Regression Suite (JVM / Robolectric)**:
  - Verifies mission completion & replay, endless restart, checkpoint restore, pause/resume input clearing, 8-alien transformations, game-over star calculation, and reduced-motion / narrow-landscape HUD invariants.
