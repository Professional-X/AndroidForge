package com.ogurchik.pubg120;

import android.app.*;
import android.os.*;
import android.provider.Settings;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import android.hardware.display.DisplayManager;
import android.view.Display;
import java.util.Locale;

public class MainActivity extends Activity {
    TextView status, hz;
    int green = Color.rgb(0,200,83);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi(); updateStatus();
    }

    TextView tv(String s, float size) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.WHITE); t.setPadding(24,18,24,18); return t; }
    Button btn(String s) { Button x=new Button(this); x.setText(s); x.setTextSize(16); return x; }

    void buildUi() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,30,28,24); root.setBackgroundColor(Color.rgb(18,18,18));
        TextView title=tv("PUBG 120 FPS ASSISTANT",24); title.setTextColor(green); root.addView(title);
        root.addView(tv("Honor 200 • 120 Hz подготовка",15));
        hz=tv("Частота экрана: проверка…",18); root.addView(hz);
        status=tv("Статус: —",16); root.addView(status);

        Button enable=btn("⚡ ВКЛЮЧИТЬ 120 ГЦ"); enable.setOnClickListener(v->enable120()); root.addView(enable);
        Button launch=btn("🎮 ВКЛЮЧИТЬ 120 ГЦ И ЗАПУСТИТЬ PUBG"); launch.setOnClickListener(v->{ enable120(); new Handler().postDelayed(this::launchPubg,700); }); root.addView(launch);
        Button restore=btn("↩ ВЕРНУТЬ АВТОМАТИЧЕСКИЙ РЕЖИМ"); restore.setOnClickListener(v->restoreAuto()); root.addView(restore);
        Button settings=btn("⚙ ДОСТУП К СИСТЕМНЫМ НАСТРОЙКАМ"); settings.setOnClickListener(v->openWriteSettings()); root.addView(settings);
        TextView note=tv("Важно: приложение меняет системную частоту дисплея, но не может гарантировать разблокировку 120 FPS внутри PUBG Mobile, если игра сама ограничивает режим. Без root мы не подменяем игровые файлы.",13); note.setTextColor(Color.LTGRAY); root.addView(note);
        setContentView(root);
    }

    void openWriteSettings(){ try { startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:"+getPackageName()))); } catch(Exception e){ startActivity(new Intent(Settings.ACTION_SETTINGS)); } }

    boolean canWrite(){ return Build.VERSION.SDK_INT < 23 || Settings.System.canWrite(this); }

    void enable120(){
        if(!canWrite()){ openWriteSettings(); Toast.makeText(this,"Разреши изменение системных настроек и нажми кнопку ещё раз",Toast.LENGTH_LONG).show(); return; }
        boolean ok=false;
        try { ok |= Settings.System.putFloat(getContentResolver(), "peak_refresh_rate", 120f); } catch(Exception ignored){}
        try { ok |= Settings.System.putFloat(getContentResolver(), "min_refresh_rate", 120f); } catch(Exception ignored){}
        status.setText(ok ? "Статус: 120 Гц запрошено" : "Статус: система не разрешила изменение");
        updateStatus();
        Toast.makeText(this, ok ? "Запрошен режим 120 Гц" : "Не удалось изменить частоту", Toast.LENGTH_SHORT).show();
    }

    void restoreAuto(){
        if(!canWrite()){ openWriteSettings(); return; }
        try { Settings.System.putFloat(getContentResolver(), "peak_refresh_rate", 0f); } catch(Exception ignored){}
        try { Settings.System.putFloat(getContentResolver(), "min_refresh_rate", 0f); } catch(Exception ignored){}
        status.setText("Статус: автоматический режим запрошен"); updateStatus();
    }

    void updateStatus(){
        try {
            Display d=((DisplayManager)getSystemService(DISPLAY_SERVICE)).getDisplay(Display.DEFAULT_DISPLAY);
            float r=d.getRefreshRate(); hz.setText(String.format(Locale.US,"Частота экрана сейчас: %.0f Гц",r));
        } catch(Exception e){ hz.setText("Частота экрана: недоступна"); }
    }

    void launchPubg(){
        String[] pkgs={"com.tencent.ig","com.pubg.imobile","com.rekoo.pubgm","com.vng.pubgmobile","com.pubg.krmobile"};
        PackageManager pm=getPackageManager();
        for(String p:pkgs){ Intent i=pm.getLaunchIntentForPackage(p); if(i!=null){ i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return; } }
        Toast.makeText(this,"PUBG Mobile не найдена. Запусти игру вручную.",Toast.LENGTH_LONG).show();
    }
}
