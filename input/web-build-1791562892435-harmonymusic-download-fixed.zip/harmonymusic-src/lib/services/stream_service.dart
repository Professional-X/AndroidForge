import 'dart:io';

import 'package:flutter/services.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart';

class StreamProvider {
  final bool playable;
  final List<Audio>? audioFormats;
  final String statusMSG;

  StreamProvider({
    required this.playable,
    this.audioFormats,
    this.statusMSG = "",
  });

  static const MethodChannel _newPipeChannel = MethodChannel('newpipe_bridge');

  /// NewPipe is the primary extractor. youtube_explode_dart is kept as a
  /// fallback because either extractor can be temporarily blocked by YouTube.
  static Future<StreamProvider> fetch(String videoId) async {
    // Try NewPipe first. A timeout prevents a stuck extraction from blocking
    // playback or downloads indefinitely.
    try {
      final result = await _newPipeChannel.invokeMapMethod<String, dynamic>(
        'resolveStreamUrl',
        {'videoId': videoId},
      ).timeout(const Duration(seconds: 7));

      final formats = _formatsFromNewPipe(result);
      if (formats.isNotEmpty) {
        return StreamProvider(
          playable: true,
          audioFormats: formats,
          statusMSG: "OK",
        );
      }
    } catch (_) {
      // Continue to youtube_explode_dart without showing an intermediate error.
    }

    final yt = YoutubeExplode();
    try {
      final manifest = await yt.videos.streamsClient
          .getManifest(videoId)
          .timeout(const Duration(seconds: 7));
      final audio = manifest.audioOnly;
      if (audio.isNotEmpty) {
        final formats = audio.map((e) => Audio(
          itag: e.tag,
          audioCodec: e.audioCodec.contains('mp') ? Codec.mp4a : Codec.opus,
          bitrate: e.bitrate.bitsPerSecond,
          duration: e.duration ?? 0,
          loudnessDb: e.loudnessDb,
          url: e.url.toString(),
          size: e.size.totalBytes,
        )).toList()
          ..sort((a, b) => a.bitrate.compareTo(b.bitrate));
        return StreamProvider(
          playable: true,
          statusMSG: "OK",
          audioFormats: formats,
        );
      }
      return StreamProvider(playable: false, statusMSG: "Unable to extract audio");
    } catch (error) {
      return StreamProvider(
        playable: false,
        statusMSG: _friendlyFallbackError(error),
      );
    } finally {
      yt.close();
    }
  }

  static List<Audio> _formatsFromNewPipe(Map<String, dynamic>? result) {
    if (result == null || result['playable'] != true) return <Audio>[];
    final rawFormats = (result['audioFormats'] as List?) ?? const [];
    final formats = rawFormats
        .whereType<Map>()
        .map((json) => Audio.fromJson(Map<String, dynamic>.from(json)))
        .where((audio) => audio.url.isNotEmpty)
        .toList()
      ..sort((a, b) => a.bitrate.compareTo(b.bitrate));
    return formats;
  }

  static String _friendlyFallbackError(Object error) {
    final message = error.toString();
    if (message.contains("429") ||
        message.toLowerCase().contains("rate limit") ||
        message.toLowerCase().contains("challenge")) {
      return "YouTube is temporarily rate-limited";
    }
    return "Unable to fetch audio";
  }

  Audio? get highestQualityAudio =>
      audioFormats?.lastWhere(
        (item) => item.itag == 251 || item.itag == 140,
        orElse: () => audioFormats!.first,
      );

  Audio? get highestBitrateMp4aAudio =>
      audioFormats?.lastWhere(
        (item) => item.itag == 140 || item.itag == 139,
        orElse: () => audioFormats!.first,
      );

  Audio? get highestBitrateOpusAudio =>
      audioFormats?.lastWhere(
        (item) => item.itag == 251 || item.itag == 250,
        orElse: () => audioFormats!.first,
      );

  Audio? get lowQualityAudio =>
      audioFormats?.lastWhere(
        (item) => item.itag == 249 || item.itag == 139,
        orElse: () => audioFormats!.first,
      );

  Map<String, dynamic> get hmStreamingData {
    return {
      "playable": playable,
      "statusMSG": statusMSG,
      "lowQualityAudio": lowQualityAudio?.toJson(),
      "highQualityAudio": highestQualityAudio?.toJson(),
    };
  }
}

class Audio {
  final int itag;
  final Codec audioCodec;
  final int bitrate;
  final int duration;
  final int size;
  final double loudnessDb;
  final String url;

  Audio({
    required this.itag,
    required this.audioCodec,
    required this.bitrate,
    required this.duration,
    required this.loudnessDb,
    required this.url,
    required this.size,
  });

  Map<String, dynamic> toJson() => {
        "itag": itag,
        "audioCodec": audioCodec.toString(),
        "bitrate": bitrate,
        "loudnessDb": loudnessDb,
        "url": url,
        "approxDurationMs": duration,
        "size": size,
      };

  factory Audio.fromJson(dynamic json) => Audio(
        audioCodec: (json["audioCodec"] as String).contains("mp4a")
            ? Codec.mp4a
            : Codec.opus,
        itag: json['itag'],
        duration: json["approxDurationMs"] ?? json["duration"] ?? 0,
        bitrate: json["bitrate"] ?? 0,
        loudnessDb: (json['loudnessDb'])?.toDouble() ?? 0.0,
        url: json['url'],
        size: json["size"] ?? 0,
      );
}

enum Codec { mp4a, opus }
