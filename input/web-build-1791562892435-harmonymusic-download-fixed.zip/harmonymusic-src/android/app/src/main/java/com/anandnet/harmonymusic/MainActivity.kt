package com.anandnet.harmonymusic

import android.os.Handler
import android.os.Looper
import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.util.concurrent.Executors

class MainActivity : AudioServiceActivity() {
    companion object {
        private const val CHANNEL = "newpipe_bridge"
    }

    private val executor = Executors.newCachedThreadPool()
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method != "resolveStreamUrl") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }

                val videoId = call.argument<String>("videoId")
                if (videoId.isNullOrBlank()) {
                    result.error("INVALID_VIDEO_ID", "videoId is empty", null)
                    return@setMethodCallHandler
                }

                executor.execute {
                    try {
                        val data = NewPipeBridge.resolveStreamUrl(videoId)
                        mainHandler.post { result.success(data) }
                    } catch (error: Throwable) {
                        mainHandler.post {
                            result.error(
                                "NEWPIPE_ERROR",
                                error.message ?: "NewPipe extraction failed",
                                null
                            )
                        }
                    }
                }
            }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
