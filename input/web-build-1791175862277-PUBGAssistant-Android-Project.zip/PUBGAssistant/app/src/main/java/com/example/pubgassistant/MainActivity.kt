package com.example.pubgassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090B0E)
private val Card = Color(0xFF14171C)
private val Accent = Color(0xFFFFB000)
private val Muted = Color(0xFF8E959F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PUBGAssistant() } }
}

@Composable fun PUBGAssistant() {
    var tab by remember { mutableStateOf(0) }
    var profile by remember { mutableStateOf("M416 • 3x") }
    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Accent)) {
        Scaffold(containerColor = Bg, bottomBar = { NavigationBar(containerColor = Card) {
            listOf("Главная", "Профили", "Гироскоп", "Оптимизация").forEachIndexed { i, t ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(listOf("⌂","⚙","◎","⚡")[i], fontSize = 20.sp) }, label = { Text(t, fontSize = 10.sp) })
            }
        }}) { pad -> Box(Modifier.padding(pad).fillMaxSize()) {
            when(tab) { 0 -> Home(profile); 1 -> Profiles(onSelect = { profile = it; tab = 0 }); 2 -> Gyro(); else -> Optimize() }
        }}
    }
}

@Composable fun Header(title: String, sub: String) { Column(Modifier.padding(20.dp)) { Text("PUBG ASSISTANT", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold); Text(title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold); Text(sub, color = Muted, fontSize = 13.sp) } }

@Composable fun Home(profile: String) { LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
    item { Header("Твой игровой профиль", "Быстрые настройки под твой стиль игры") }
    item { CardBox { Text("АКТИВНЫЙ ПРОФИЛЬ", color = Muted, fontSize = 11.sp); Text(profile, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(10.dp)); Text("4 пальца • гироскоп • средняя/дальняя дистанция", color = Muted) } }
    item { Spacer(Modifier.height(12.dp)); Section("Быстрые настройки") }
    items(listOf("🎯 Чувствительность" to "Камера • ADS • прицелы", "◎ Гироскоп" to "Управление отдачей", "🔫 Оружие" to "M416 • AKM • AUG", "⚡ FPS и нагрев" to "90 FPS • стабильность")) { (a,b) -> CardBox(Modifier.padding(vertical = 5.dp)) { Text(a, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold); Text(b, color = Muted, fontSize = 13.sp) } }
}}

@Composable fun Profiles(onSelect: (String)->Unit) { val profiles = listOf("M416 • 3x","M416 • 4x","M416 • Red Dot","AKM • Red Dot","AUG • 3x","AUG • 4x"); LazyColumn(contentPadding = PaddingValues(bottom=24.dp)) { item { Header("Профили", "Сохраняй отдельные настройки для каждого оружия") }; items(profiles) { p -> CardBox(Modifier.padding(vertical=5.dp).clickable { onSelect(p) }) { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) { Column { Text(p, color=Color.White, fontSize=17.sp, fontWeight=FontWeight.Bold); Text("Чувствительность • гироскоп", color=Muted, fontSize=12.sp) }; Text("›", color=Accent, fontSize=28.sp) } } } } }

@Composable fun Gyro() { LazyColumn(contentPadding = PaddingValues(bottom=24.dp)) { item { Header("Гироскоп", "Быстрый подбор значений для контроля отдачи") }; item { SliderCard("Red Dot", 285); SliderCard("3x", 245); SliderCard("4x", 220); SliderCard("6x", 105); }; item { CardBox { Text("Совет", color=Accent, fontWeight=FontWeight.Bold); Text("Начинай с умеренных значений и повышай их, если прицел медленно доворачивается. Проверяй результат в тренировочной зоне.", color=Muted, fontSize=13.sp) } } } }

@Composable fun SliderCard(name: String, initial: Int) { var value by remember { mutableFloatStateOf(initial.toFloat()) }; CardBox(Modifier.padding(vertical=5.dp)) { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text(name, color=Color.White, fontWeight=FontWeight.Bold); Text(value.toInt().toString(), color=Accent, fontWeight=FontWeight.Bold) }; Slider(value={value}, onValueChange={value=it}, valueRange=0f..400f, colors=SliderDefaults.colors(thumbColor=Accent, activeTrackColor=Accent)) } }

@Composable fun Optimize() { LazyColumn(contentPadding = PaddingValues(bottom=24.dp)) { item { Header("FPS и нагрев", "Подготовка телефона к стабильной игре") }; item { CardBox { Text("ЦЕЛЬ", color=Muted, fontSize=11.sp); Text("90 FPS", color=Accent, fontSize=30.sp, fontWeight=FontWeight.Bold); Text("Стабильность важнее пиковых значений", color=Muted) } }; items(listOf("Графика" to "Плавно / Smooth", "Частота кадров" to "Максимальная доступная", "Тени" to "Выключить", "Автонастройка графики" to "Выключить", "Перед игрой" to "Закрыть фоновые приложения")) { (a,b) -> CardBox(Modifier.padding(vertical=5.dp)) { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text(a,color=Color.White); Text(b,color=Accent,fontWeight=FontWeight.SemiBold) } } } } }

@Composable fun Section(t:String){ Text(t, color=Color.White, fontSize=18.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(horizontal=20.dp, vertical=8.dp)) }
@Composable fun CardBox(modifier: Modifier=Modifier, content:@Composable ColumnScope.()->Unit){ Card(modifier.fillMaxWidth().padding(horizontal=16.dp), shape=RoundedCornerShape(16.dp), colors=CardDefaults.cardColors(containerColor=Card)){ Column(Modifier.padding(16.dp), content=content) } }
