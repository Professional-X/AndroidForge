import { createFileRoute } from "@tanstack/react-router";
import { Viewer } from "@/components/Viewer";

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Visualizador DFF / TXD — modelos GTA no navegador" },
      { name: "description", content: "Abra modelos .dff e texturas .txd do GTA direto no navegador ou celular." },
      { property: "og:title", content: "Visualizador DFF / TXD" },
      { property: "og:description", content: "Abra modelos .dff e texturas .txd do GTA direto no navegador ou celular." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Viewer,
});
