import { Canvas, useThree } from "@react-three/fiber";
import { OrbitControls, Bounds, Grid } from "@react-three/drei";
import { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { SkinEditor } from "./SkinEditor";
import { Button } from "@/components/ui/button";
import { parseDFF, parseTXD, type RWGeometry, type RWTexture } from "@/lib/rw";

const norm = (n: string) => n.trim().toLowerCase().replace(/\.(png|tga|bmp|dds)$/, "");

function buildMeshes(geoms: RWGeometry[], texs: Map<string, THREE.Texture>, wire: boolean) {
  return geoms.map((g) => {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(g.positions, 3));
    if (g.uvs) geo.setAttribute("uv", new THREE.BufferAttribute(g.uvs, 2));
    const idx: number[] = [];
    g.groups.forEach((gr, i) => { geo.addGroup(idx.length, gr.indices.length, i); for (const v of gr.indices) idx.push(v); });
    geo.setIndex(new THREE.BufferAttribute(new Uint32Array(idx), 1));
    if (g.normals) geo.setAttribute("normal", new THREE.BufferAttribute(g.normals, 3)); else geo.computeVertexNormals();
    const mats = g.groups.map((gr) => {
      const m = g.materials[gr.mat];
      const map = m?.texture ? texs.get(norm(m.texture)) : undefined;
      const col = m ? new THREE.Color(m.color[0] / 255, m.color[1] / 255, m.color[2] / 255) : new THREE.Color(0.8, 0.8, 0.8);
      return new THREE.MeshStandardMaterial({ color: map ? 0xffffff : col, map: map ?? null, wireframe: wire, side: THREE.DoubleSide, alphaTest: 0.3, transparent: !!map, roughness: 0.8 });
    });
    const mesh = new THREE.Mesh(geo, mats);
    if (g.matrix) { mesh.matrixAutoUpdate = false; mesh.matrix.fromArray(g.matrix); }
    return mesh;
  });
}

// exposes the canvas "redraw" function so texture edits can request a new frame
function Invalidator({ fnRef }: { fnRef: React.MutableRefObject<() => void> }) {
  const invalidate = useThree((s) => s.invalidate);
  useEffect(() => { fnRef.current = () => invalidate(); }, [invalidate, fnRef]);
  return null;
}

export function Viewer() {
  const [geoms, setGeoms] = useState<RWGeometry[]>([]);
  const [rawTex, setRawTex] = useState<RWTexture[]>([]);
  const [names, setNames] = useState<{ dff?: string; txd: string[] }>({ txd: [] });
  const [err, setErr] = useState("");
  const [wire, setWire] = useState(false);
  const [panel, setPanel] = useState<"files" | "editor">("files");

  const redraw = useRef<() => void>(() => {});
  const texCache = useRef(new Map<string, { tx: THREE.DataTexture; w: number; h: number }>());
  const texKeys = rawTex.map((t) => `${norm(t.name)}:${t.width}x${t.height}`).join("|");
  const texs = useMemo(() => {
    const m = new Map<string, THREE.Texture>();
    const cache = texCache.current;
    rawTex.forEach((t) => {
      const k = norm(t.name);
      let c = cache.get(k);
      if (!c || c.w !== t.width || c.h !== t.height) {
        const tx = new THREE.DataTexture(t.rgba, t.width, t.height, THREE.RGBAFormat);
        tx.colorSpace = THREE.SRGBColorSpace; tx.wrapS = tx.wrapT = THREE.RepeatWrapping; tx.magFilter = THREE.LinearFilter; tx.minFilter = THREE.LinearFilter; tx.needsUpdate = true;
        c = { tx, w: t.width, h: t.height }; cache.set(k, c);
      }
      m.set(k, c.tx);
    });
    for (const k of [...cache.keys()]) if (!m.has(k)) { cache.get(k)!.tx.dispose(); cache.delete(k); }
    return m;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [texKeys]);
  // live texture edits: update pixels in place, without rebuilding the model
  useEffect(() => {
    rawTex.forEach((t) => { const c = texCache.current.get(norm(t.name)); if (c && c.tx.image.data !== t.rgba) { c.tx.image.data = t.rgba; c.tx.needsUpdate = true; } });
    redraw.current();
  }, [rawTex]);
  const preview = (i: number, rgba: Uint8Array) => {
    const t = rawTex[i]; if (!t) return;
    const c = texCache.current.get(norm(t.name)); if (!c) return;
    c.tx.image.data = rgba; c.tx.needsUpdate = true; redraw.current();
  };
  const needed = useMemo(() => { const s = new Set<string>(); geoms.forEach((g) => g.materials.forEach((m) => m?.texture && s.add(norm(m.texture)))); return [...s]; }, [geoms]);
  const missing = needed.filter((n) => !texs.has(n));
  const meshes = useMemo(() => buildMeshes(geoms, texs, wire), [geoms, texs, wire]);
  useEffect(() => () => meshes.forEach((m) => { m.geometry.dispose(); (m.material as THREE.Material[]).forEach((x) => x.dispose()); }), [meshes]);

  const onFiles = async (files: FileList | null) => {
    if (!files) return; setErr("");
    for (const f of Array.from(files)) {
      const buf = await f.arrayBuffer();
      try {
        if (f.name.toLowerCase().endsWith(".txd")) {
          const t = parseTXD(buf).map((x) => ({ ...x, txd: f.name })); if (!t.length) throw new Error("Nenhuma textura reconhecida neste TXD"); setRawTex((p) => [...p, ...t]); setNames((n) => ({ ...n, txd: [...n.txd, f.name] }));
        } else {
          const g = parseDFF(buf); if (!g.length) throw new Error("Nenhuma malha encontrada");
          setGeoms(g); setNames((n) => ({ ...n, dff: f.name }));
        }
      } catch (e) { setErr(`${f.name}: ${(e as Error).message}`); }
    }
  };

  return (
    <div className="fixed inset-0 bg-background text-foreground">
      <div aria-label="Objeto 3D" className={panel === "editor" ? "absolute inset-x-0 top-[calc(4rem+min(22dvh,160px)+0.75rem)] bottom-[calc(34dvh+1.5rem)] sm:inset-0" : "absolute inset-0"}>
      <Canvas frameloop="demand" camera={{ position: [4, 3, 6], fov: 50 }} dpr={[1, 1.5]}>
        <Invalidator fnRef={redraw} />
        <color attach="background" args={["#1c1f24"]} />
        <hemisphereLight args={["#ffffff", "#444444", 1.6]} />
        <directionalLight position={[5, 10, 5]} intensity={1.8} />
        <Grid infiniteGrid sectionColor="#5a6270" cellColor="#2e333b" fadeDistance={40} />
        <Bounds fit clip observe margin={1.3} key={names.dff ?? "none"}>
          <group rotation-x={-Math.PI / 2}>{meshes.map((m, i) => <primitive key={i} object={m} />)}</group>
        </Bounds>
        <OrbitControls makeDefault />
      </Canvas>
      </div>
      <div className="absolute left-3 right-3 top-3 flex flex-col gap-2 pointer-events-none [&>*]:pointer-events-auto sm:right-auto sm:w-80">
        <div className="grid grid-cols-2 gap-2" role="tablist" aria-label="Painéis do visualizador">
          <Button id="files-tab" role="tab" aria-selected={panel === "files"} aria-controls="files-panel" variant={panel === "files" ? "default" : "secondary"} onClick={() => setPanel("files")}>1/2 · DFF / TXD</Button>
          <Button id="editor-tab" role="tab" aria-selected={panel === "editor"} aria-controls="editor-panel" variant={panel === "editor" ? "default" : "secondary"} disabled={!rawTex.length} onClick={() => setPanel("editor")}>2/2 · Editar skin</Button>
        </div>
        <div id="files-panel" role="tabpanel" aria-labelledby="files-tab" hidden={panel !== "files"} className="max-h-[calc(60dvh-3.5rem)] overflow-y-auto rounded-lg border border-border bg-card p-4 shadow-lg break-words">
          <h1 className="text-lg font-bold">Visualizador DFF / TXD</h1>
          <p className="mb-3 text-xs text-muted-foreground">Abra um modelo .dff e as texturas .txd (GTA III, VC, SA).</p>
          <label className="block cursor-pointer rounded-md bg-primary px-3 py-2 text-center text-sm font-medium text-primary-foreground">
            Abrir arquivos
            <input type="file" multiple className="hidden" onChange={(e) => { onFiles(e.target.files); e.target.value = ""; }} />
          </label>
          <div className="mt-3 space-y-1 text-xs">
            <div>Modelo: <span className="text-muted-foreground">{names.dff ?? "nenhum"}</span></div>
            <div>Texturas: <span className="text-muted-foreground">{names.txd.length ? `${names.txd.join(", ")} (${rawTex.length})` : "nenhuma"}</span></div>
            {needed.length > 0 && <div>Partes de textura: <span className="text-muted-foreground">{needed.length - missing.length}/{needed.length} aplicadas</span></div>}
            {missing.length > 0 && <div className="text-destructive">Faltando: {missing.join(", ")}</div>}
            {err && <div className="text-destructive">{err}</div>}
          </div>
          <div className="mt-3 flex gap-2">
            <button className="flex-1 rounded-md border border-input px-2 py-1 text-xs" onClick={() => setWire((w) => !w)}>{wire ? "Sólido" : "Wireframe"}</button>
            <button className="flex-1 rounded-md border border-input px-2 py-1 text-xs" onClick={() => { setGeoms([]); setRawTex([]); setNames({ txd: [] }); setErr(""); }}>Limpar</button>
          </div>
        </div>
      </div>
      {rawTex.length > 0 && <SkinEditor open={panel === "editor"} onClose={() => setPanel("files")} textures={rawTex} onPreview={preview} onChange={(i, rgba) => setRawTex((p) => p.map((x, j) => (j === i ? { ...x, rgba } : x)))} />}
    </div>
  );
}
