import { useEffect, useRef, useState } from "react";
import { writeTXD, type RWTexture } from "@/lib/rw";
import { Button } from "@/components/ui/button";

type Src = HTMLImageElement | HTMLCanvasElement;
type Decal = { img: Src; x: number; y: number; scale: number; rot: number };

// load an image and shrink very large photos so drawing them each frame stays fast
const loadImg = (f: File) =>
  new Promise<Src>((res, rej) => {
    const i = new Image();
    i.onload = () => {
      URL.revokeObjectURL(i.src);
      const max = 1024, k = Math.min(1, max / Math.max(i.width, i.height));
      if (k >= 1) return res(i);
      const c = document.createElement("canvas");
      c.width = Math.max(1, Math.round(i.width * k)); c.height = Math.max(1, Math.round(i.height * k));
      c.getContext("2d")?.drawImage(i, 0, 0, c.width, c.height);
      res(c);
    };
    i.onerror = rej;
    i.src = URL.createObjectURL(f);
  });

const ctx2d = (c: HTMLCanvasElement) => c.getContext("2d", { willReadFrequently: true });

let shared: HTMLCanvasElement | null = null;
// draws base (+ decal / cover) onto the given canvas (or a shared offscreen one)
function draw(target: HTMLCanvasElement | null, base: ImageData, decal: Decal | null, cover?: Src) {
  const c = target ?? shared ?? (shared = document.createElement("canvas"));
  const { width: w, height: h } = base;
  if (c.width !== w) c.width = w;
  if (c.height !== h) c.height = h;
  const ctx = ctx2d(c);
  if (!ctx) return null;
  if (cover) { ctx.clearRect(0, 0, w, h); ctx.drawImage(cover, 0, 0, w, h); }
  else ctx.putImageData(base, 0, 0);
  if (decal) {
    const dw = decal.img.width * decal.scale, dh = decal.img.height * decal.scale;
    ctx.save(); ctx.translate(decal.x, decal.y); ctx.rotate((decal.rot * Math.PI) / 180);
    ctx.drawImage(decal.img, -dw / 2, -dh / 2, dw, dh); ctx.restore();
  }
  return ctx;
}
const read = (ctx: CanvasRenderingContext2D, w: number, h: number) => new Uint8Array(ctx.getImageData(0, 0, w, h).data.buffer);
const toImageData = (rgba: Uint8Array, w: number, h: number) => {
  const a = new Uint8ClampedArray(w * h * 4);
  a.set(rgba.subarray(0, a.length));
  return new ImageData(a, w, h);
};

type Props = {
  open: boolean;
  onClose: () => void;
  textures: RWTexture[];
  /** saves the texture (history, download) */
  onChange: (i: number, rgba: Uint8Array) => void;
  /** fast live update of the 3D view only, no saving */
  onPreview: (i: number, rgba: Uint8Array) => void;
};

export function SkinEditor({ open, onClose, textures, onChange, onPreview }: Props) {
  const [sel, setSel] = useState(0);
  const [decal, setDecal] = useState<Decal | null>(null);
  const decalRef = useRef<Decal | null>(null);
  const base = useRef<{ i: number; img: ImageData } | null>(null);
  const originals = useRef(new Map<number, Uint8Array>());
  const cv = useRef<HTMLCanvasElement>(null);
  const raf = useRef(0);
  const last3d = useRef(0);
  const commitTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const t = textures[sel];
  const [past, setPast] = useState<{ i: number; rgba: Uint8Array }[]>([]);
  const [future, setFuture] = useState<{ i: number; rgba: Uint8Array }[]>([]);
  const record = (i: number, rgba: Uint8Array) => { setPast((p) => [...p.slice(-29), { i, rgba }]); setFuture([]); };

  const holdTimer = useRef<ReturnType<typeof setInterval> | undefined>(undefined);
  const stopMove = () => { clearInterval(holdTimer.current); holdTimer.current = undefined; };
  const stopTimers = () => { stopMove(); cancelAnimationFrame(raf.current); raf.current = 0; clearTimeout(commitTimer.current); clearTimeout(last3d.current); };
  // writes the floating decal into the saved texture; returns the result
  const commit = (): { i: number; rgba: Uint8Array } | null => {
    stopTimers();
    const d = decalRef.current, b = base.current; if (!d || !b) return null;
    const ctx = draw(null, b.img, d); if (!ctx) return null;
    const rgba = read(ctx, b.img.width, b.img.height);
    onChange(b.i, rgba);
    return { i: b.i, rgba };
  };
  const dropDecal = () => { stopTimers(); decalRef.current = null; base.current = null; setDecal(null); };
  useEffect(() => () => stopTimers(), []);

  const undo = () => {
    const c = commit(); dropDecal();
    const last = past[past.length - 1]; if (!last) return;
    const cur = c && c.i === last.i ? c.rgba : textures[last.i]?.rgba ?? last.rgba;
    setPast(past.slice(0, -1)); setFuture((f) => [...f, { i: last.i, rgba: cur }]);
    onChange(last.i, last.rgba); setSel(last.i);
  };
  const redo = () => {
    const c = commit(); dropDecal();
    const nx = future[future.length - 1]; if (!nx) return;
    const cur = c && c.i === nx.i ? c.rgba : textures[nx.i]?.rgba ?? nx.rgba;
    setFuture(future.slice(0, -1)); setPast((p) => [...p, { i: nx.i, rgba: cur }]);
    onChange(nx.i, nx.rgba); setSel(nx.i);
  };

  // draw preview
  useEffect(() => {
    if (!t || !cv.current) return;
    if (base.current) { draw(cv.current, base.current.img, decalRef.current); return; }
    cv.current.width = t.width; cv.current.height = t.height;
    ctx2d(cv.current)?.putImageData(toImageData(t.rgba, t.width, t.height), 0, 0);
  }, [t, open]);

  if (!t) return null;
  const remember = () => { if (!originals.current.has(sel)) originals.current.set(sel, t.rgba); };

  const updateDecal = (d: Decal) => {
    if (!base.current) { remember(); base.current = { i: sel, img: toImageData(t.rgba, t.width, t.height) }; }
    decalRef.current = d; setDecal(d);
    clearTimeout(commitTimer.current);
    // saving is heavy; only do it after the user really stops (or presses "Fixar")
    commitTimer.current = setTimeout(() => { if (!holdTimer.current) commit(); }, 5000);
    if (raf.current) return;
    raf.current = requestAnimationFrame(() => {
      raf.current = 0;
      const b = base.current, pd = decalRef.current; if (!b || !pd) return;
      draw(cv.current, b.img, pd);
    });
    // the 3D model is only updated once the finger/mouse pauses, so dragging stays smooth
    clearTimeout(last3d.current);
    last3d.current = window.setTimeout(() => {
      const b = base.current, pd = decalRef.current; if (!b || !pd) return;
      const ctx = draw(null, b.img, pd); if (ctx) onPreview(b.i, read(ctx, b.img.width, b.img.height));
    }, 350);
  };

  const replace = async (f?: File) => {
    if (!f) return;
    const img = await loadImg(f);
    const cur = commit()?.rgba ?? t.rgba; dropDecal();
    remember(); record(sel, cur);
    const ctx = draw(null, toImageData(cur, t.width, t.height), null, img);
    if (ctx) onChange(sel, read(ctx, t.width, t.height));
  };

  const addDecal = async (f?: File) => {
    if (!f) return;
    const img = await loadImg(f);
    const cur = commit()?.rgba ?? t.rgba; dropDecal();
    remember(); record(sel, cur);
    base.current = { i: sel, img: toImageData(cur, t.width, t.height) };
    const scale = Math.min(1, (t.width * 0.5) / img.width);
    updateDecal({ img, x: t.width / 2, y: t.height / 2, scale, rot: 0 });
  };

  const moveBy = (dx: number, dy: number, mult: number) => {
    const d = decalRef.current; if (!d) return;
    const step = Math.max(1, Math.round(t.width / 128)) * mult;
    updateDecal({ ...d, x: Math.min(t.width, Math.max(0, d.x + dx * step)), y: Math.min(t.height, Math.max(0, d.y + dy * step)) });
  };
  const startMove = (dx: number, dy: number) => {
    stopMove(); moveBy(dx, dy, 1);
    let n = 0;
    holdTimer.current = setInterval(() => { n++; if (n > 4) moveBy(dx, dy, n > 20 ? 3 : 1); }, 60);
  };
  const drag = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const d = decalRef.current;
    if (!d || (e.type === "pointermove" && e.buttons !== 1)) return;
    const r = e.currentTarget.getBoundingClientRect();
    updateDecal({ ...d, x: ((e.clientX - r.left) / r.width) * t.width, y: ((e.clientY - r.top) / r.height) * t.height });
  };

  const download = () => {
    const c = commit();
    const all = c ? textures.map((x, j) => (j === c.i ? { ...x, rgba: c.rgba } : x)) : textures;
    const groups = new Map<string, RWTexture[]>();
    all.forEach((x) => {
      const k = x.txd ?? "texturas.txd";
      const group = groups.get(k);
      if (group) group.push(x);
      else groups.set(k, [x]);
    });
    groups.forEach((list, name) => {
      const url = URL.createObjectURL(new Blob([writeTXD(list) as Uint8Array<ArrayBuffer>], { type: "application/octet-stream" }));
      const a = document.createElement("a"); a.href = url; a.download = name; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    });
  };

  const btn = "rounded-md border border-input px-2 py-1 text-xs cursor-pointer text-center";
  return (
    <div id="editor-panel" role="tabpanel" aria-labelledby="editor-tab" hidden={!open} className={`pointer-events-none absolute inset-x-3 bottom-3 top-16 sm:left-3 sm:right-auto sm:w-96 ${open ? "" : "hidden"}`}>
      <div className="pointer-events-auto absolute left-0 top-0 flex h-[min(22dvh,160px)] w-[min(22dvh,160px)] items-center justify-center overflow-hidden [container-type:size] sm:h-48 sm:w-48">
        <canvas ref={cv} aria-label="Prévia da textura" onPointerDown={drag} onPointerMove={drag}
          className="block h-[min(100cqw,100cqh)] w-[min(100cqw,100cqh)] touch-none border border-border bg-muted [image-rendering:pixelated]" />
      </div>
      <div className="pointer-events-auto absolute inset-x-0 bottom-0 max-h-[34dvh] overflow-y-auto overscroll-contain rounded-lg border border-border bg-card p-3 shadow-lg sm:max-h-[50dvh]">
      <div className="mb-2 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2">
        <h2 className="text-sm font-bold">Editar skin</h2>
        <Button variant="ghost" size="sm" onClick={onClose}>
          Voltar
        </Button>
      </div>
      <select aria-label="Textura para editar" className="mb-2 w-full rounded-md border border-input bg-background px-2 py-1 text-xs" value={sel} onChange={(e) => { commit(); dropDecal(); setSel(+e.target.value); }}>
        {textures.map((x, i) => <option key={i} value={i}>{x.name} ({x.width}x{x.height})</option>)}
      </select>
      <div className="mb-2 grid grid-cols-2 gap-2">
        <Button variant="outline" size="sm" disabled={!past.length} onClick={undo}>↶ Desfazer</Button>
        <Button variant="outline" size="sm" disabled={!future.length} onClick={redo}>↷ Refazer</Button>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <label className={btn}>Trocar por imagem<input type="file" accept="image/*" className="hidden" onChange={(e) => { replace(e.target.files?.[0]); e.target.value = ""; }} /></label>
        <label className={btn}>Adicionar decalque<input type="file" accept="image/*" className="hidden" onChange={(e) => { addDecal(e.target.files?.[0]); e.target.value = ""; }} /></label>
      </div>
      {decal && (
        <div className="mt-2 space-y-1 text-xs">
          <div className="grid grid-cols-[7rem_minmax(0,1fr)] items-center gap-2">
          <div className="row-span-2 grid grid-cols-3 gap-1">
            {([["", 0, 0], ["↑", 0, -1], ["", 0, 0], ["←", -1, 0], ["•", 0, 0], ["→", 1, 0], ["", 0, 0], ["↓", 0, 1], ["", 0, 0]] as const).map(([l, dx, dy], k) =>
              l && l !== "•" ? (
                <Button key={k} variant="outline" size="sm" className="h-9 touch-none select-none px-0 text-base"
                  onPointerDown={(e) => { e.preventDefault(); startMove(dx, dy); }}
                  onPointerUp={stopMove} onPointerLeave={stopMove} onPointerCancel={stopMove}
                  onContextMenu={(e) => e.preventDefault()}>{l}</Button>
              ) : <span key={k} />
            )}
          </div>
          <div className="flex min-w-0 flex-wrap items-center gap-1">
            <span className="w-full">Tamanho</span>
            <Button variant="outline" size="sm" className="h-7 px-2" onClick={() => updateDecal({ ...decal, scale: Math.max(0.02, decal.scale / 1.1) })}>−</Button>
            <input type="range" className="min-w-0 flex-1" min={0.02} max={4} step={0.01} value={decal.scale} onChange={(e) => updateDecal({ ...decal, scale: +e.target.value })} />
            <Button variant="outline" size="sm" className="h-7 px-2" onClick={() => updateDecal({ ...decal, scale: Math.min(4, decal.scale * 1.1) })}>+</Button>
            <span className="w-10 text-right">{Math.round(decal.scale * 100)}%</span>
          </div>
          <div className="flex min-w-0 flex-wrap items-center gap-1">
            <span className="w-full">Rotação</span>
            <Button variant="outline" size="sm" className="h-7 px-2" onClick={() => updateDecal({ ...decal, rot: ((decal.rot - 15 + 540) % 360) - 180 })}>↺</Button>
            <input type="range" className="min-w-0 flex-1" min={-180} max={180} value={decal.rot} onChange={(e) => updateDecal({ ...decal, rot: +e.target.value })} />
            <Button variant="outline" size="sm" className="h-7 px-2" onClick={() => updateDecal({ ...decal, rot: ((decal.rot + 15 + 180) % 360) - 180 })}>↻</Button>
            <span className="w-10 text-right">{Math.round(decal.rot)}°</span>
          </div>
          </div>
          <Button variant="outline" size="sm" className="w-full" onClick={() => { commit(); dropDecal(); }}>Fixar decalque</Button>
        </div>
      )}
      <div className="mt-2 grid grid-cols-2 gap-2">
        <Button variant="outline" size="sm" onClick={() => { const cur = commit()?.rgba ?? t.rgba; dropDecal(); const o = originals.current.get(sel); if (o && o !== cur) { record(sel, cur); onChange(sel, o); } }}>Restaurar</Button>
        <Button size="sm" onClick={download}>Baixar TXD</Button>
      </div>
      </div>
    </div>
  );
}
