// @ts-nocheck -- binary parser with heavy typed-array indexing
// RenderWare DFF / TXD parsers (GTA III / VC / SA, PC)
export interface RWMaterial { color: [number, number, number, number]; texture?: string }
export interface RWGeometry {
  positions: Float32Array; normals?: Float32Array; uvs?: Float32Array; colors?: Uint8Array;
  groups: { mat: number; indices: number[] }[]; materials: RWMaterial[];
  matrix?: number[]; name?: string;
}
export interface RWTexture { name: string; width: number; height: number; rgba: Uint8Array; mask?: string; filter?: number; ver?: number; txd?: string }

class R {
  v: DataView; o = 0;
  constructor(public b: ArrayBuffer) { this.v = new DataView(b); }
  u8() { return this.v.getUint8(this.o++); }
  u16() { const x = this.v.getUint16(this.o, true); this.o += 2; return x; }
  u32() { const x = this.v.getUint32(this.o, true); this.o += 4; return x; }
  i32() { const x = this.v.getInt32(this.o, true); this.o += 4; return x; }
  f32() { const x = this.v.getFloat32(this.o, true); this.o += 4; return x; }
  head() { const type = this.u32(), size = this.u32(), raw = this.u32(); return { type, size, ver: libVer(raw), end: this.o + size }; }
  str(n: number) { let s = ""; for (let i = 0; i < n; i++) { const c = this.v.getUint8(this.o + i); if (!c) break; s += String.fromCharCode(c); } this.o += n; return s; }
}
const libVer = (v: number) => (v & 0xffff0000 ? (((v >>> 14) & 0x3ff00) + 0x30000) | ((v >>> 16) & 0x3f) : v << 8);

function findChild(r: R, end: number, type: number) {
  while (r.o + 12 <= end) { const h = r.head(); if (h.type === type) return h; r.o = h.end; }
  return null;
}

export function parseDFF(buf: ArrayBuffer): RWGeometry[] {
  const r = new R(buf);
  const out: RWGeometry[] = [];
  const bend = buf.byteLength;
  while (r.o + 12 <= bend) {
    const clump = r.head();
    const cend = Math.min(clump.end, bend);
    if (clump.type !== 0x10) { r.o = clump.end; continue; }
    // frames
    const frames: { m: number[]; parent: number; name: string; world?: number[] }[] = [];
    const geoms: RWGeometry[] = [];
    const atomics: { frame: number; geo: number }[] = [];
    { const st = r.head(); r.o = st.end; } // clump struct
    while (r.o + 12 <= cend) {
      const h = r.head(); const hend = Math.min(h.end, cend);
      if (h.type === 0x0e) {
        const st = r.head(); const n = r.u32();
        for (let i = 0; i < n; i++) {
          const a = []; for (let k = 0; k < 12; k++) a.push(r.f32());
          const parent = r.i32(); r.u32();
          frames.push({ m: [a[0], a[1], a[2], 0, a[3], a[4], a[5], 0, a[6], a[7], a[8], 0, a[9], a[10], a[11], 1], parent, name: "" });
        }
        r.o = st.end;
        for (let i = 0; i < n && r.o + 12 <= hend; i++) {
          const ext = r.head(); const eend = Math.min(ext.end, hend);
          while (r.o + 12 <= eend) { const e = r.head(); if (e.type === 0x253f2fe) frames[i].name = r.str(e.size).toLowerCase(); r.o = e.end; }
          r.o = ext.end;
        }
      } else if (h.type === 0x1a) {
        const st = r.head(); const n = r.u32(); r.o = st.end;
        for (let g = 0; g < n; g++) {
          const gh = findChild(r, hend, 0x0f); if (!gh) break;
          try { geoms.push(parseGeometry(r, Math.min(gh.end, hend))); } catch (e) { console.warn(e); geoms.push(null); }
          r.o = gh.end;
        }
      } else if (h.type === 0x14) {
        const st = r.head(); const frame = r.u32(), geo = r.u32(); atomics.push({ frame, geo }); r.o = st.end;
      }
      r.o = h.end;
    }
    const mul = (a: number[], b: number[]) => { const o = new Array(16).fill(0); for (let c = 0; c < 4; c++) for (let rr = 0; rr < 4; rr++) for (let k = 0; k < 4; k++) o[c * 4 + rr] += a[k * 4 + rr] * b[c * 4 + k]; return o; };
    const world = (i: number, depth = 0): number[] => {
      const f = frames[i]; if (!f) return null;
      if (f.world) return f.world;
      const p = f.parent >= 0 && f.parent !== i && depth < 64 ? world(f.parent, depth + 1) : null;
      f.world = p ? mul(p, f.m) : f.m; return f.world;
    };
    const hidden = (i: number) => { for (let k = i, d = 0; k >= 0 && frames[k] && d < 64; k = frames[k].parent, d++) { const n = frames[k].name; if (/_(dam|vlo|lo)$/.test(n) || /_vlo|_dam/.test(n)) return true; } return false; };
    if (atomics.length) {
      for (const a of atomics) {
        const g = geoms[a.geo]; if (!g) continue;
        if (hidden(a.frame)) continue;
        // root frame transform is ignored so model is centered
        out.push({ ...g, matrix: frames[a.frame] && frames[a.frame].parent >= 0 ? world(a.frame) : undefined, name: frames[a.frame]?.name });
      }
    } else for (const g of geoms) if (g) out.push(g);
    r.o = clump.end;
  }
  return out;
}

function parseGeometry(r: R, end: number): RWGeometry {
  const s = r.head();
  const flags = r.u32();
  const nTri = r.u32(), nVert = r.u32(); r.u32();
  if (s.ver < 0x34000) r.o += 12;
  const native = (flags & 0x01000000) !== 0;
  let numUV = (flags >>> 16) & 0xff;
  if (!numUV) numUV = flags & 0x80 ? 2 : flags & 0x04 ? 1 : 0;
  let colors: Uint8Array | undefined, uvs: Float32Array | undefined;
  const tris: number[][] = [];
  if (!native) {
    if (flags & 0x08) { colors = new Uint8Array(r.b.slice(r.o, r.o + nVert * 4)); r.o += nVert * 4; }
    for (let t = 0; t < numUV; t++) {
      if (t === 0) { uvs = new Float32Array(nVert * 2); for (let i = 0; i < nVert * 2; i++) uvs[i] = r.f32(); }
      else r.o += nVert * 8;
    }
    for (let i = 0; i < nTri; i++) { const b = r.u16(), a = r.u16(), m = r.u16(), c = r.u16(); tris.push([a, b, c, m]); }
  }
  r.o += 16; // bounding sphere
  const hasV = r.u32(), hasN = r.u32();
  const positions = new Float32Array(nVert * 3);
  let normals: Float32Array | undefined;
  if (hasV) for (let i = 0; i < nVert * 3; i++) positions[i] = r.f32();
  if (hasN) { normals = new Float32Array(nVert * 3); for (let i = 0; i < nVert * 3; i++) normals[i] = r.f32(); }
  r.o = s.end;
  // some mods contain junk (huge/NaN) unused vertices that break camera framing: collapse them to origin
  for (let i = 0; i < nVert; i++) {
    const x = positions[i * 3], y = positions[i * 3 + 1], z = positions[i * 3 + 2];
    if (!(Math.abs(x) < 1e4 && Math.abs(y) < 1e4 && Math.abs(z) < 1e4)) { positions[i * 3] = positions[i * 3 + 1] = positions[i * 3 + 2] = 0; }
  }
  if (normals) for (let i = 0; i < normals.length; i++) if (!Number.isFinite(normals[i])) normals[i] = 0;
  // materials
  const materials: RWMaterial[] = [];
  const ml = findChild(r, end, 0x08);
  if (ml) {
    const ms = r.head(); const nm = r.u32(); const idx: number[] = []; for (let i = 0; i < nm; i++) idx.push(r.i32()); r.o = ms.end;
    for (let i = 0; i < nm; i++) {
      if (idx[i] >= 0) { materials.push(materials[idx[i]]); continue; }
      const mh = findChild(r, ml.end, 0x07); if (!mh) break;
      const mst = r.head(); r.u32();
      const color: [number, number, number, number] = [r.u8(), r.u8(), r.u8(), r.u8()];
      r.u32(); const textured = r.u32(); r.o = mst.end;
      const mat: RWMaterial = { color };
      if (textured) {
        const th = findChild(r, mh.end, 0x06);
        if (th) { const ts = r.head(); r.o = ts.end; const sh = r.head(); mat.texture = r.str(sh.size).toLowerCase(); }
      }
      materials.push(mat); r.o = mh.end;
    }
    r.o = ml.end;
  }
  // groups
  const groups: { mat: number; indices: number[] }[] = [];
  const save = r.o;
  // Prefer Bin Mesh PLG (authoritative material split)
  {
    const ext = findChild(r, end, 0x03);
    const bm = ext ? findChild(r, ext.end, 0x50e) : null;
    if (bm) {
      const strip = r.u32() === 1; const ns = r.u32(); r.u32();
      for (let i = 0; i < ns; i++) {
        const ni = r.u32(), mat = r.u32(); const raw: number[] = []; for (let k = 0; k < ni; k++) raw.push(r.u32());
        const indices: number[] = [];
        if (strip) for (let k = 0; k + 2 < raw.length; k++) {
          const a = raw[k], b = raw[k + 1], c = raw[k + 2]; if (a === b || b === c || a === c) continue;
          if (k & 1) indices.push(b, a, c); else indices.push(a, b, c);
        } else for (const v of raw) indices.push(v);
        groups.push({ mat, indices });
      }
    }
  }
  r.o = save;
  if (groups.length) { /* done */ }
  else if (tris.length) {
    const map = new Map<number, number[]>();
    for (const [a, b, c, m] of tris) { if (!map.has(m)) map.set(m, []); map.get(m)!.push(a, b, c); }
    map.forEach((indices, mat) => groups.push({ mat, indices }));
  } else {
    // Bin Mesh PLG in extension
    const ext = findChild(r, end, 0x03);
    if (ext) {
      const bm = findChild(r, ext.end, 0x50e);
      if (bm) {
        const strip = r.u32() === 1; const ns = r.u32(); r.u32();
        for (let i = 0; i < ns; i++) {
          const ni = r.u32(), mat = r.u32(); const raw: number[] = []; for (let k = 0; k < ni; k++) raw.push(r.u32());
          const indices: number[] = [];
          if (strip) for (let k = 0; k + 2 < raw.length; k++) {
            const a = raw[k], b = raw[k + 1], c = raw[k + 2]; if (a === b || b === c || a === c) continue;
            if (k & 1) indices.push(b, a, c); else indices.push(a, b, c);
          } else for (const v of raw) indices.push(v);
          groups.push({ mat, indices });
        }
      }
    }
  }
  return { positions, normals, uvs, colors, groups, materials };
}

// ---------- TXD ----------
export function parseTXD(buf: ArrayBuffer): RWTexture[] {
  const r = new R(buf); const out: RWTexture[] = [];
  const ver = new DataView(buf).getUint32(8, true);
  const root = r.head(); if (root.type !== 0x16) throw new Error("Não é um arquivo TXD válido");
  const st = r.head(); r.o = st.end;
  const tEnd = Math.min(root.end, buf.byteLength);
  while (r.o + 12 <= tEnd) {
    const h = r.head();
    if (h.type === 0x15) { try { const t = parseNative(r); t.ver = ver; out.push(t); } catch (e) { console.warn(e); } }
    r.o = h.end;
  }
  return out;
}

function parseNative(r: R): RWTexture {
  const s = r.head();
  const platform = r.u32(); const filter = r.u32();
  const name = r.str(32).toLowerCase(); const mask = r.str(32);
  const rasterFmt = r.u32(); const fourOrAlpha = r.u32();
  const w = r.u16(), h = r.u16(), depth = r.u8(); r.u8(); r.u8(); const comp = r.u8();
  let dxt = 0;
  if (platform === 9) { const cc = String.fromCharCode(fourOrAlpha & 255, (fourOrAlpha >> 8) & 255, (fourOrAlpha >> 16) & 255, fourOrAlpha >>> 24); if (cc.startsWith("DXT")) dxt = +cc[3]; }
  else if (platform === 8 && comp) dxt = comp;
  else if (platform !== 8 && platform !== 9) throw new Error("Plataforma de textura não suportada: " + platform);
  let palette: Uint8Array | undefined;
  if (rasterFmt & 0x2000) { palette = new Uint8Array(r.b, r.o, 1024); r.o += 1024; }
  else if (rasterFmt & 0x4000) { palette = new Uint8Array(r.b, r.o, 64); r.o += 64; }
  const size = r.u32();
  const avail = Math.min(size, r.b.byteLength - r.o);
  if (avail <= 0) throw new Error("Textura sem dados: " + name);
  const data = new Uint8Array(r.b, r.o, avail);
  const rgba = new Uint8Array(w * h * 4);
  if (dxt) decodeDXT(data, w, h, dxt, rgba);
  else if (palette) {
    for (let i = 0; i < w * h; i++) { const p = depth === 4 ? (data[i >> 1] >> ((i & 1) * 4)) & 15 : data[i]; rgba.set(palette.subarray(p * 4, p * 4 + 4), i * 4); }
  } else {
    const f = rasterFmt & 0xf00;
    for (let i = 0; i < w * h; i++) {
      const o = i * 4;
      if (f === 0x500 || f === 0x600 || depth === 32) { rgba[o] = data[o + 2]; rgba[o + 1] = data[o + 1]; rgba[o + 2] = data[o]; rgba[o + 3] = f === 0x600 ? 255 : data[o + 3]; }
      else {
        const v = data[i * 2] | (data[i * 2 + 1] << 8);
        if (f === 0x200) { rgba[o] = ((v >> 11) & 31) * 8.226; rgba[o + 1] = ((v >> 5) & 63) * 4.048; rgba[o + 2] = (v & 31) * 8.226; rgba[o + 3] = 255; }
        else if (f === 0x300) { rgba[o] = ((v >> 8) & 15) * 17; rgba[o + 1] = ((v >> 4) & 15) * 17; rgba[o + 2] = (v & 15) * 17; rgba[o + 3] = (v >> 12) * 17; }
        else { rgba[o] = ((v >> 10) & 31) * 8.226; rgba[o + 1] = ((v >> 5) & 31) * 8.226; rgba[o + 2] = (v & 31) * 8.226; rgba[o + 3] = v & 0x8000 ? 255 : 0; }
      }
    }
  }
  r.o = s.end;
  return { name, width: w, height: h, rgba, mask, filter };
}

function decodeDXT(d: Uint8Array, w: number, h: number, t: number, out: Uint8Array) {
  const bs = t === 1 ? 8 : 16; let off = 0;
  const c = new Uint8Array(16);
  const bw = Math.max(1, Math.ceil(w / 4)), bh = Math.max(1, Math.ceil(h / 4));
  for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++, off += bs) {
    if (off + bs > d.length) return;
    const co = off + (t === 1 ? 0 : 8);
    const c0 = d[co] | (d[co + 1] << 8), c1 = d[co + 2] | (d[co + 3] << 8);
    const rgb = (v: number, i: number) => { c[i] = ((v >> 11) & 31) * 255 / 31; c[i + 1] = ((v >> 5) & 63) * 255 / 63; c[i + 2] = (v & 31) * 255 / 31; c[i + 3] = 255; };
    rgb(c0, 0); rgb(c1, 4);
    if (c0 > c1 || t !== 1) for (let k = 0; k < 3; k++) { c[8 + k] = (2 * c[k] + c[4 + k]) / 3; c[12 + k] = (c[k] + 2 * c[4 + k]) / 3; c[11] = c[15] = 255; }
    else { for (let k = 0; k < 3; k++) { c[8 + k] = (c[k] + c[4 + k]) / 2; c[12 + k] = 0; } c[11] = 255; c[15] = 0; }
    const bits = d[co + 4] | (d[co + 5] << 8) | (d[co + 6] << 16) | (d[co + 7] << 24);
    let a: number[] | null = null;
    if (t === 5) { const a0 = d[off], a1 = d[off + 1]; a = [a0, a1]; if (a0 > a1) for (let k = 1; k < 7; k++) a.push(((7 - k) * a0 + k * a1) / 7); else { for (let k = 1; k < 5; k++) a.push(((5 - k) * a0 + k * a1) / 5); a.push(0, 255); } }
    for (let p = 0; p < 16; p++) {
      const x = bx * 4 + (p & 3), y = by * 4 + (p >> 2); if (x >= w || y >= h) continue;
      const ci = ((bits >>> (p * 2)) & 3) * 4, o = (y * w + x) * 4;
      out[o] = c[ci]; out[o + 1] = c[ci + 1]; out[o + 2] = c[ci + 2]; out[o + 3] = c[ci + 3];
      if (t === 3) out[o + 3] = ((d[off + (p >> 1)] >> ((p & 1) * 4)) & 15) * 17;
      else if (a) { const bit = p * 3, byte = off + 2 + (bit >> 3); const v = (d[byte] | (d[byte + 1] << 8)) >> (bit & 7); out[o + 3] = a![v & 7]; }
    }
  }
}

// ---------- TXD writer (D3D9, 32-bit uncompressed, no mipmaps) ----------
export function writeTXD(texs: RWTexture[]): Uint8Array {
  const ver = texs[0]?.ver ?? 0x1803ffff;
  const parts: Uint8Array[] = [];
  const chunk = (type: number, body: Uint8Array) => {
    const o = new Uint8Array(12 + body.length); const v = new DataView(o.buffer);
    v.setUint32(0, type, true); v.setUint32(4, body.length, true); v.setUint32(8, ver, true); o.set(body, 12); return o;
  };
  const cat = (a: Uint8Array[]) => { const n = a.reduce((s, x) => s + x.length, 0); const o = new Uint8Array(n); let p = 0; for (const x of a) { o.set(x, p); p += x.length; } return o; };
  const st = new Uint8Array(4); new DataView(st.buffer).setUint16(0, texs.length, true);
  parts.push(chunk(1, st));
  for (const t of texs) {
    let alpha = false; for (let i = 3; i < t.rgba.length; i += 4) if (t.rgba[i] < 255) { alpha = true; break; }
    const px = t.width * t.height * 4;
    const b = new Uint8Array(88 + 4 + px); const v = new DataView(b.buffer);
    v.setUint32(0, 9, true); v.setUint32(4, t.filter ?? 0x1106, true);
    const ws = (s: string, at: number) => { for (let i = 0; i < Math.min(31, s.length); i++) b[at + i] = s.charCodeAt(i); };
    ws(t.name, 8); ws(t.mask ?? "", 40);
    v.setUint32(72, alpha ? 0x0500 : 0x0600, true); v.setUint32(76, alpha ? 21 : 22, true);
    v.setUint16(80, t.width, true); v.setUint16(82, t.height, true);
    b[84] = 32; b[85] = 1; b[86] = 4; b[87] = alpha ? 1 : 0;
    v.setUint32(88, px, true);
    for (let i = 0; i < px; i += 4) { b[92 + i] = t.rgba[i + 2]; b[93 + i] = t.rgba[i + 1]; b[94 + i] = t.rgba[i]; b[95 + i] = alpha ? t.rgba[i + 3] : 255; }
    parts.push(chunk(0x15, cat([chunk(1, b), chunk(3, new Uint8Array(0))])));
  }
  parts.push(chunk(3, new Uint8Array(0)));
  return chunk(0x16, cat(parts));
}
