<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Viewer owns the files/editor panel selection and keeps SkinEditor mounted while switching, so floating decals and undo history survive navigation.
- SkinEditor uses a small upper texture preview and separate height-limited bottom controls with a transparent, pointer-pass-through parent; Viewer reserves an unobstructed mobile 3D viewport between them so camera fitting never centers the model behind editing panels.
