// Trace AR v2: расширения (переопределяют show(), кнопки и т.д.)
Object.assign(st,{mode:0,stage:0,th:40,tk:2,fi:0,gn:0});
const GN=[0,3,4,6,8],MN=['Фото','Линии'];
const css=document.createElement('style');css.textContent=`.top2{position:fixed;left:12px;top:calc(env(safe-area-inset-top,0px) + 12px);display:flex;gap:10px;z-index:5}.rb{font-size:20px}
#set{position:fixed;left:10px;right:10px;top:calc(env(safe-area-inset-top,0px) + 66px);max-height:62vh;overflow:auto;z-index:6;background:rgba(20,20,28,.88);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border-radius:20px;padding:12px;border:1px solid rgba(255,255,255,.1)}
.cr{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:7px 0}.cr small{min-width:74px;color:rgba(255,255,255,.6);font-size:12px}
.cr button{padding:7px 11px;border-radius:12px;border:0;background:rgba(255,255,255,.12);color:#fff;font-size:13px}.cr button.on{background:#7c8cff;color:#000}.cr input{flex:1;min-width:120px}
#stg{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(env(safe-area-inset-bottom,0px) + 222px);z-index:5;display:flex;gap:6px;padding:6px;border-radius:16px;background:rgba(20,20,28,.72);backdrop-filter:blur(12px)}
#stg button{padding:8px 12px;border-radius:12px;border:0;background:rgba(255,255,255,.12);color:#fff;font-size:13px}#stg button.on{background:#7c8cff;color:#000}#panel.hide~#stg{display:none}`;document.head.append(css);
const T=b=>'<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 1024 1024"><rect width="1024" height="1024" fill="#fff"/>'+b+'</svg>';
const TPL={'Бойкиссер':T('<g stroke="#000" stroke-width="17" stroke-linejoin="round" stroke-linecap="round" fill="#fff"><path d="M512 360Q475 352 440 358L345 285 292 400 262 458 298 472 268 528 304 542C306 665 405 718 512 718 619 718 718 665 720 542L756 528 726 472 762 458 732 400 679 285 584 358Q549 352 512 360Z"/><path d="M386 472L464 510 386 548M638 472L560 510 638 548" fill="none" stroke-width="22"/><path d="M497 550Q512 565 527 550" fill="none"/><path d="M430 588Q471 617 512 591 553 617 594 588 585 692 512 696 439 692 430 588Z" fill="#fff"/><ellipse cx="362" cy="580" rx="34" ry="19" fill="#ffb3c6" stroke="none"/><ellipse cx="662" cy="580" rx="34" ry="19" fill="#ffb3c6" stroke="none"/><ellipse cx="512" cy="668" rx="32" ry="20" fill="#ff8fb8" stroke="none"/></g>'),
'Сердце':T('<path d="M512 880C150 620 200 280 380 280 450 280 495 320 512 370 529 320 574 280 644 280 824 280 874 620 512 880Z" fill="#fff" stroke="#000" stroke-width="16"/>'),
'Звезда':T('<polygon points="512,150 600,420 884,420 654,590 740,860 512,700 284,860 370,590 140,420 424,420" fill="#fff" stroke="#000" stroke-width="16" stroke-linejoin="round"/>')};
// изображение
function src(im,m,f){const k=Math.min(1,m/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);if(f)x.filter=f;x.drawImage(im,0,0,c.width,c.height);return c}
// PURE-START
function bx(g,w,h,r){const o=new Float32Array(w*h),t=new Float32Array(w*h),n=2*r+1,cx=(v,m)=>Math.min(m-1,Math.max(0,v));
for(let j=0;j<h;j++){let s=0;for(let i=-r;i<=r;i++)s+=g[j*w+cx(i,w)];for(let i=0;i<w;i++){t[j*w+i]=s/n;s+=g[j*w+cx(i+r+1,w)]-g[j*w+cx(i-r,w)]}}
for(let i=0;i<w;i++){let s=0;for(let j=-r;j<=r;j++)s+=t[cx(j,h)*w+i];for(let j=0;j<h;j++){o[j*w+i]=s/n;s+=t[cx(j+r+1,h)*w+i]-t[cx(j-r,h)*w+i]}}return o}
function sob(g,w,h,th){const m=new Uint8Array(w*h);for(let j=1;j<h-1;j++)for(let i=1;i<w-1;i++){const o=j*w+i,gx=-g[o-w-1]-2*g[o-1]-g[o+w-1]+g[o-w+1]+2*g[o+1]+g[o+w+1],gy=-g[o-w-1]-2*g[o-w]-g[o-w+1]+g[o+w-1]+2*g[o+w]+g[o+w+1];if(Math.hypot(gx,gy)*1.2>th)m[o]=1}return m}
function dil(m,w,h,r){if(r<1)return m;const a=new Uint8Array(w*h),b=new Uint8Array(w*h);for(let j=0;j<h;j++)for(let i=0;i<w;i++)if(m[j*w+i])for(let k=Math.max(0,i-r);k<=Math.min(w-1,i+r);k++)a[j*w+k]=1;
for(let j=0;j<h;j++)for(let i=0;i<w;i++)if(a[j*w+i])for(let k=Math.max(0,j-r);k<=Math.min(h-1,j+r);k++)b[k*w+i]=1;return b}
function comps(m,w,h){const seen=new Uint8Array(w*h),q=new Int32Array(w*h),r=[];for(let s=0;s<w*h;s++){if(!m[s]||seen[s])continue;let a=0,b=0;q[b++]=s;seen[s]=1;
while(a<b){const p=q[a++],x=p%w,y=(p/w)|0;for(let dy=-1;dy<2;dy++)for(let dx=-1;dx<2;dx++){const X=x+dx,Y=y+dy;if(X<0||Y<0||X>=w||Y>=h)continue;const k=Y*w+X;if(m[k]&&!seen[k]){seen[k]=1;q[b++]=k}}}r.push(q.slice(0,b))}return r}
function clean(m,w,h,min){comps(m,w,h).forEach(c=>{if(c.length<min)c.forEach(k=>m[k]=0)})}
function thin(m,w,h){let ch=1;while(ch){ch=0;for(let s=0;s<2;s++){const del=[];for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){const o=y*w+x;if(!m[o])continue;const p2=m[o-w],p3=m[o-w+1],p4=m[o+1],p5=m[o+w+1],p6=m[o+w],p7=m[o+w-1],p8=m[o-1],p9=m[o-w-1],B=p2+p3+p4+p5+p6+p7+p8+p9;if(B<2||B>6)continue;
const A=(!p2&&p3)+(!p3&&p4)+(!p4&&p5)+(!p5&&p6)+(!p6&&p7)+(!p7&&p8)+(!p8&&p9)+(!p9&&p2);if(A!=1)continue;if(s==0?(p2*p4*p6||p4*p6*p8):(p2*p4*p8||p2*p6*p8))continue;del.push(o)}if(del.length){ch=1;for(const o of del)m[o]=0}}}return m}
// слои: S — силуэт, B — основа, D — детали (не пересекаются)
function layersFrom(p,w,h){const n=w*h,g=new Float32Array(n),f=Math.max(w,h)/900;let dk=0,sm=0;
for(let i=0;i<n;i++){g[i]=.299*p[i*4]+.587*p[i*4+1]+.114*p[i*4+2];sm+=g[i];if(g[i]<140)dk++}
const line=sm/n>190&&dk/n>.003&&dk/n<.3;let K;
if(line){K=new Uint8Array(n);for(let i=0;i<n;i++)K[i]=g[i]<140?1:0}else K=sob(bx(g,w,h,Math.max(1,Math.round(f))),w,h,st.th);
clean(K,w,h,Math.round((line?12:8)*f*f));let area=0;for(let i=0;i<n;i++)area+=K[i];
const Sk=thin(K.slice(),w,h);let sk=0;for(let i=0;i<n;i++)sk+=Sk[i];const ws=Math.max(2,2*area/(sk||1));
const bi=[];for(let x=0;x<w;x++)bi.push(x,(h-1)*w+x);for(let y=0;y<h;y++)bi.push(y*w,y*w+w-1);
let r0=0,g0=0,u0=0;bi.forEach(o=>{r0+=p[o*4];g0+=p[o*4+1];u0+=p[o*4+2]});r0/=bi.length;g0/=bi.length;u0/=bi.length;
const rc=Math.max(3,Math.round(Math.max(w,h)/150)),Kd=dil(K,w,h,rc),bg=new Uint8Array(n),q=new Int32Array(n);let a=0,t=0;
const go=o=>{if(!bg[o]&&!Kd[o]&&Math.abs(p[o*4]-r0)+Math.abs(p[o*4+1]-g0)+Math.abs(p[o*4+2]-u0)<90){bg[o]=1;q[t++]=o}};
bi.forEach(go);while(a<t){const o=q[a++],x=o%w,y=(o/w)|0;if(x>0)go(o-1);if(x<w-1)go(o+1);if(y>0)go(o-w);if(y<h-1)go(o+w)}
const S=new Uint8Array(n);
if(t/n>.03){const e1=dil(bg,w,h,rc+1),e0=dil(bg,w,h,rc);for(let i=0;i<n;i++)S[i]=e1[i]&&!e0[i]?1:0;const sc=comps(S,w,h),mx=Math.max(0,...sc.map(c=>c.length));sc.forEach(c=>{if(c.length<.25*mx)c.forEach(k=>S[k]=0)});const d0=dil(S,w,h,3),fl=bx(bx(Float32Array.from(d0),w,h,6),w,h,6),T2=new Uint8Array(n);for(let i=0;i<n;i++)T2[i]=fl[i]>.3?1:0;thin(T2,w,h);S.set(T2)}
else{const c=comps(Sk,w,h).sort((x,y)=>y.length-x.length)[0];if(c)c.forEach(k=>S[k]=1)}
const ns=dil(S,w,h,Math.ceil(ws/2)+3),B=new Uint8Array(n),D=new Uint8Array(n),R=Sk.map((v,i)=>v&&!ns[i]?1:0),cs=comps(R,w,h).sort((x,y)=>y.length-x.length);
const mx2=cs.length?cs[0].length:0;cs.forEach(c=>{if(c.length<6*f)return;const T=c.length>=.35*mx2?B:D;c.forEach(k=>T[k]=1)});
if(sk/n>.02){const R1=Math.max(3,Math.round(Math.max(w,h)/140)),T=bx(bx(g,w,h,R1),w,h,R1),hs=new Float32Array(256);let sum=0;for(let i=0;i<n;i++){hs[Math.min(255,T[i]|0)]++;sum+=T[i]}
let wB=0,sB=0,best=0,th2=128;for(let t=0;t<256;t++){wB+=hs[t];if(!wB)continue;const wF=n-wB;if(!wF)break;sB+=t*hs[t];const d=wB*wF*(sB/wB-(sum-sB)/wF)**2;if(d>best){best=d;th2=t}}
const Bd=new Uint8Array(n);for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){const o=y*w+x;if(T[o]<th2&&(T[o-1]>=th2||T[o+1]>=th2||T[o-w]>=th2||T[o+w]>=th2))Bd[o]=1}
clean(Bd,w,h,Math.round(60*f));B.fill(0);D.fill(0);for(let i=0;i<n;i++)if(Bd[i]&&!ns[i])B[i]=1;const nB=dil(B,w,h,3);for(let i=0;i<n;i++)if(Sk[i]&&!ns[i]&&!nB[i])D[i]=1;clean(D,w,h,Math.round(10*f))}
return{w,h,S,B,D}}
// PURE-END
const LCOL=[[0,229,255],[255,70,70],[255,214,0]];
function srcN(im,N){const k=N/Math.max(im.width,im.height),c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.imageSmoothingQuality='high';x.drawImage(im,0,0,c.width,c.height);return c}
let LC=null,LK='',imgId=0;
async function linesC(im){const key=imgId+'|'+st.th;if(LK!=key){const c=srcN(im,1300);LC=layersFrom(c.getContext('2d').getImageData(0,0,c.width,c.height).data,c.width,c.height);LK=key}
const{w,h}=LC,M=[LC.S,LC.B,LC.D],idx=st.stage<3?[st.stage]:[0,1,2],parts=[];let hd='';
for(const i of idx){const f=Math.max(w,h)/900,d=dil(M[i],w,h,Math.max(1,Math.round(st.tk*f*.5))),sm=bx(bx(Float32Array.from(d),w,h,1),w,h,1),id=new ImageData(w,h),v=id.data;for(let k=0;k<w*h;k++){v[k*4]=v[k*4+1]=v[k*4+2]=sm[k]>.5?0:255;v[k*4+3]=255}
const col='rgb('+(st.stage<3?COL[st.ci]:LCOL[i])+')',s=ImageTracer.imagedataToSVG(id,{pal:[{r:0,g:0,b:0,a:255},{r:255,g:255,b:255,a:255}],colorsampling:0,numberofcolors:2,strokewidth:0,ltres:2,qtres:2,pathomit:Math.round(8*f),roundcoords:1,colorquantcycles:1,blurradius:0,viewbox:false});
hd=s.match(/^<svg[^>]*>/)[0];parts.push(s.replace(/^<svg[^>]*>/,'').replace(/<\/svg>\s*$/,'').replace(/<path fill="rgb\((\d+),[^>]*\/>/g,(m,r)=>+r>128?'':m.replace(/fill="rgb\([^"]*\)"/,'fill="'+col+'"').replace(/stroke="rgb\([^"]*\)"/,'stroke="none"')))}
const svg=hd+parts.join('')+'</svg>';st.svg=svg;const i=new Image();i.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);await i.decode();const k=1400/Math.max(w,h),o=document.createElement('canvas');o.width=Math.round(w*k);o.height=Math.round(h*k);o.getContext('2d').drawImage(i,0,0,o.width,o.height);return o}

let busy=0;
async function show(){if(!st.orig)return;const id=++busy,im=new Image();im.src=st.orig;try{await im.decode()}catch(e){return}
let c;try{c=st.mode==1?await linesC(im):src(im,1200,['','grayscale(1) contrast(1.3)','invert(1)'][st.fi])}catch(e){console.error(e);c=src(im,1200)}
if(id!==busy)return;const N=GN[st.gn];if(N){const x=c.getContext('2d');x.strokeStyle='rgba(255,60,120,.75)';x.lineWidth=Math.max(1,c.width/450);x.beginPath();for(let i=1;i<N;i++){x.moveTo(c.width*i/N,0);x.lineTo(c.width*i/N,c.height);x.moveTo(0,c.height*i/N);x.lineTo(c.width,c.height*i/N)}x.stroke()}
ov.src=c.toDataURL('image/png');ap()}
function setImage(u,keep){st.orig=u;imgId++;if(!keep)Object.assign(st,{x:0,y:0,s:1,r:0,fl:1});$('hint').hidden=true;ov.hidden=false;if(!keep)try{localStorage.setItem('tr_img',u)}catch(e){}show()}
$('f').onchange=e=>{const f=e.target.files[0];e.target.value='';if(!f)return;const im=new Image();im.onload=()=>{setImage(src(im,1200).toDataURL('image/jpeg',.88));URL.revokeObjectURL(im.src)};im.src=URL.createObjectURL(f)};
// режимы и кнопки
function sync(){$('bEdge').lastChild.textContent=MN[st.mode];$('bEdge').classList.toggle('on',st.mode>0);$('bDot').hidden=!st.mode;$('stg').hidden=st.mode!=1;$('bGrid').classList.toggle('on',st.gn>0);
const g=$('grid');g.style.display=st.gn?'block':'none';g.style.backgroundSize=st.gn?100/GN[st.gn]+'% '+100/GN[st.gn]+'%':'';R.forEach(r=>r.up&&r.up())}
const R=[];$('bEdge').onclick=()=>{st.mode=(st.mode+1)%2;sync();show()};$('bGrid').onclick=()=>{st.gn=(st.gn+1)%5;sync();show()};
// панель этапов
const stg=document.createElement('div');stg.id='stg';stg.hidden=true;['Контур','Основа','Детали','Все'].forEach((n,i)=>{const b=document.createElement('button');b.textContent=n;b.onclick=()=>{st.stage=i;sync();show()};stg.append(b)});stg.up=()=>[...stg.children].forEach((b,i)=>b.classList.toggle('on',st.stage==i));R.push(stg);document.body.append(stg);
// настройки
const sh=document.createElement('div');sh.id='set';sh.hidden=true;document.body.append(sh);
function chips(t,items,get,set,keep){const r=document.createElement('div');r.className='cr';r.innerHTML='<small>'+t+'</small>';items.forEach((n,i)=>{const b=document.createElement('button');b.textContent=n;b.onclick=()=>{set(i);if(!keep)show();sync()};r.append(b)});r.up=()=>get&&[...r.querySelectorAll('button')].forEach((b,i)=>b.classList.toggle('on',get()==i));R.push(r);sh.append(r);return r}
function sld(t,mn,mx,k,v){const r=document.createElement('div');r.className='cr';r.innerHTML='<small>'+t+'</small><input type="range" min="'+mn+'" max="'+mx+'" value="'+v+'">';r.lastChild.onchange=e=>{st[k]=+e.target.value;show()};r.up=()=>r.lastChild.value=st[k];R.push(r);sh.append(r);return r}
chips('Режим',MN,()=>st.mode,i=>st.mode=i);chips('Этап линий',['Контур','Основа','Детали','Все'],()=>st.stage,i=>st.stage=i);chips('Фильтр фото',['Цвет','Ч/Б','Негатив'],()=>st.fi,i=>st.fi=i);
chips('Сетка',['Нет','3×3','4×4','6×6','8×8'],()=>st.gn,i=>st.gn=i);sld('Порог контура',10,150,'th',st.th);sld('Толщина',1,6,'tk',st.tk);
const zr=document.createElement('div');zr.className='cr';zr.hidden=true;zr.innerHTML='<small>Зум камеры</small><input type="range">';sh.append(zr);
let fx=0;const fr=chips('Камера',['Зафиксировать фокус и свет'],()=>fx,()=>{fx=!fx;try{track.applyConstraints({advanced:[{focusMode:fx?'manual':'continuous',exposureMode:fx?'manual':'continuous'}]})}catch(e){}},1);
V.addEventListener('loadedmetadata',()=>{const c=track&&track.getCapabilities?track.getCapabilities():{},i=zr.lastChild;zr.hidden=!c.zoom;if(c.zoom){i.min=c.zoom.min;i.max=c.zoom.max;i.step=c.zoom.step||.1;i.value=c.zoom.min;track.applyConstraints({advanced:[{zoom:c.zoom.min}]}).catch(()=>{});i.oninput=()=>track.applyConstraints({advanced:[{zoom:+i.value}]}).catch(()=>{})}});
chips('Шаблоны',Object.keys(TPL),null,i=>setImage('data:image/svg+xml;charset=utf-8,'+encodeURIComponent(Object.values(TPL)[i])),1);
// отмена/повтор
const H=[{x:0,y:0,s:1,r:0,fl:1}];let hi=0;const snap=()=>({x:st.x,y:st.y,s:st.s,r:st.r,fl:st.fl});
$('stage').addEventListener('pointerup',()=>{const a=snap();if(JSON.stringify(a)!==JSON.stringify(H[hi])){H.length=hi+1;H.push(a);hi++;if(H.length>50){H.shift();hi--}}});
const go=d=>{const n=hi+d;if(n<0||n>=H.length)return;hi=n;Object.assign(st,H[hi]);ap()};
// сохранение и запись
function comp(c){const W=c.width,H=c.height,x=c.getContext('2d'),sx=W/innerWidth;x.fillStyle='#000';x.fillRect(0,0,W,H);
if(V.videoWidth){const k=Math.max(W/V.videoWidth,H/V.videoHeight);x.drawImage(V,(W-V.videoWidth*k)/2,(H-V.videoHeight*k)/2,V.videoWidth*k,V.videoHeight*k)}
if(!ov.hidden&&ov.naturalWidth){x.save();x.globalAlpha=+ov.style.opacity;x.translate(W/2+st.x*sx,H/2+st.y*sx);x.rotate(st.r*Math.PI/180);x.scale(st.s*st.fl*sx,st.s*sx);x.drawImage(ov,-ov.offsetWidth/2,-ov.offsetHeight/2,ov.offsetWidth,ov.offsetHeight);x.restore()}}
async function out(b,n){const f=new File([b],n,{type:b.type});try{if(navigator.canShare&&navigator.canShare({files:[f]})){await navigator.share({files:[f]});return}}catch(e){}const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=n;a.click()}
const act=document.createElement('div');act.className='cr';act.innerHTML='<small>Действия</small>';
[['↶ Отмена',()=>go(-1)],['↷ Повтор',()=>go(1)],['SVG',()=>st.svg?out(new Blob([st.svg],{type:'image/svg+xml'}),'trace.svg'):alert('Включи режим «Линии»')],['Сброс памяти',()=>{localStorage.clear();location.reload()}]].forEach(([n,f])=>{const b=document.createElement('button');b.textContent=n;b.onclick=f;act.append(b)});sh.append(act);
const t2=document.createElement('div');t2.className='top2';t2.innerHTML='<button class="rb" id="bSet">⚙</button><button class="rb" id="bSave">⤓</button><button class="rb" id="bRec">●</button>';document.body.append(t2);
$('bSet').onclick=()=>{sh.hidden=!sh.hidden;sync()};$('stage').addEventListener('pointerdown',()=>sh.hidden=true);
$('bSave').onclick=()=>{const c=document.createElement('canvas');c.width=innerWidth*2;c.height=innerHeight*2;comp(c);c.toBlob(b=>out(b,'trace.png'),'image/png')};
let mr,ch=[],ri;$('bRec').onclick=()=>{if(mr&&mr.state=='recording')return mr.stop();if(!window.MediaRecorder)return alert('Запись не поддерживается');const c=document.createElement('canvas');c.width=innerWidth;c.height=innerHeight;
mr=new MediaRecorder(c.captureStream(15),MediaRecorder.isTypeSupported('video/webm')?{mimeType:'video/webm'}:{});ch=[];mr.ondataavailable=e=>ch.push(e.data);mr.onstop=()=>{clearInterval(ri);$('bRec').classList.remove('on');out(new Blob(ch,{type:'video/webm'}),'trace.webm')};mr.start();ri=setInterval(()=>comp(c),66);$('bRec').classList.add('on')};
// память настроек
const K=['x','y','s','r','fl','ci','mode','stage','th','tk','fi','gn'];let last='';
setInterval(()=>{const o={};K.forEach(k=>o[k]=st[k]);o.op=$('op').value;const j=JSON.stringify(o);if(j!==last){last=j;try{localStorage.setItem('tr',j)}catch(e){}}},2000);
try{const o=JSON.parse(localStorage.getItem('tr')||'{}');K.forEach(k=>{if(k in o)st[k]=o[k]});if(st.mode>1)st.mode=1;if(st.stage>3)st.stage=0;if(o.op){$('op').value=o.op;ov.style.opacity=o.op/100;$('opv').textContent=o.op+'%'}$('dot').style.background='rgb('+COL[st.ci]+')';$('bMir').classList.toggle('on',st.fl<0);const u=localStorage.getItem('tr_img');if(u)setImage(u,true)}catch(e){}
$('hint').innerHTML='<b>Trace AR</b><small>1. Добавь картинку или шаблон (⚙)<br>2. Режим «Линии»: контур → основа → детали (на каждом этапе только свои линии)<br>3. Один палец — двигать, два — масштаб и поворот<br>⤓ фото · ● запись процесса</small>';$('hint').onclick=()=>$('hint').hidden=true;if(st.orig)$('hint').hidden=true;
sync();ap();if(location.protocol.startsWith('http')&&navigator.serviceWorker)navigator.serviceWorker.register('sw.js').catch(()=>{});

// переключение объективов (0.5× и др.)
let dev=null;const oldCam=cam;
cam=async function(){if(!dev)return oldCam();try{if(V.srcObject)V.srcObject.getTracks().forEach(t=>t.stop());const s=await navigator.mediaDevices.getUserMedia({video:{deviceId:{exact:dev},width:{ideal:1920}},audio:false});V.srcObject=s;track=s.getVideoTracks()[0];torch=false;$('bTorch').classList.remove('on');const c=track.getCapabilities?track.getCapabilities():{};$('bTorch').hidden=!c.torch}catch(e){dev=null;return oldCam()}};
const bl=document.createElement('button');bl.className='rb';bl.id='bLens';bl.style.fontSize='15px';bl.textContent='1×';t2.append(bl);
bl.onclick=async()=>{try{const ds=(await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind=='videoinput'&&!/front|user|перед/i.test(d.label));
if(ds.length<2){alert('Телефон отдаёт браузеру только один объектив. Попробуй «Зум камеры» в ⚙ (если есть).');return}
const cur=track&&track.getSettings?track.getSettings().deviceId:null,i=(ds.findIndex(d=>d.deviceId==cur)+1)%ds.length;dev=ds[i].deviceId;bl.textContent=/ultra|wide|0\.5/i.test(ds[i].label)?'0.5×':(i+1)+'/'+ds.length;await cam()}catch(e){}};
