// Нативная камера для APK (Capacitor + @capgo/camera-preview): зум 0.5×, объективы. В браузере ничего не делает.
(()=>{const C=window.Capacitor;if(!(C&&C.isNativePlatform&&C.isNativePlatform()))return;const CP=C.Plugins&&C.Plugins.CameraPreview;if(!CP)return;
document.documentElement.classList.add('native');
const s=document.createElement('style');s.textContent='html.native,html.native body,html.native #stage{background:transparent!important}html.native video{display:none}';document.head.append(s);
const prev=cam;let vals=[],vi=1,ok=false;
const setLabel=()=>{$('bLens').textContent=(vals[vi]||1)+'×'};
cam=async function(){try{await CP.stop().catch(()=>{});
await CP.start({position:face==='user'?'front':'rear',toBack:true,disableAudio:true,disableFocusIndicator:true,aspectRatio:'16:9',positioning:'center'});ok=true;
try{wl=await navigator.wakeLock.request('screen')}catch(e){}
$('bTorch').hidden=false;const z=await CP.getZoom(),i=zr.lastChild;zr.hidden=false;i.min=z.min;i.max=Math.min(z.max,10);i.step=.1;i.value=z.current;i.oninput=()=>CP.setZoom({level:+i.value}).catch(()=>{});
try{vals=(await CP.getZoomButtonValues()).values||[]}catch(e){}
if(!vals.length)vals=[...new Set([z.min,1,2].filter(v=>v>=z.min&&v<=z.max))];vi=Math.max(0,vals.indexOf(1));setLabel()}
catch(e){ok=false;console.error(e);return prev()}};
$('bLens').onclick=async()=>{if(!ok)return;vi=(vi+1)%vals.length;try{await CP.setZoom({level:vals[vi]});zr.lastChild.value=vals[vi]}catch(e){}setLabel()};
$('bTorch').onclick=async()=>{torch=!torch;try{await CP.setFlashMode({flashMode:torch?'torch':'off'});$('bTorch').classList.toggle('on',torch)}catch(e){torch=!torch}};
$('bRec').onclick=()=>alert('Запись видео в APK пока недоступна');
$('bSave').onclick=async()=>{try{const r=await CP.capture({quality:90}),im=new Image();im.src='data:image/jpeg;base64,'+r.value;await im.decode();
const c=document.createElement('canvas'),W=c.width=innerWidth*2,H=c.height=innerHeight*2,x=c.getContext('2d'),k=Math.max(W/im.width,H/im.height),sx=W/innerWidth;
x.fillStyle='#000';x.fillRect(0,0,W,H);x.drawImage(im,(W-im.width*k)/2,(H-im.height*k)/2,im.width*k,im.height*k);
if(!ov.hidden&&ov.naturalWidth){x.save();x.globalAlpha=+ov.style.opacity;x.translate(W/2+st.x*sx,H/2+st.y*sx);x.rotate(st.r*Math.PI/180);x.scale(st.s*st.fl*sx,st.s*sx);x.drawImage(ov,-ov.offsetWidth/2,-ov.offsetHeight/2,ov.offsetWidth,ov.offsetHeight);x.restore()}
c.toBlob(b=>out(b,'trace.png'),'image/png')}catch(e){alert('Не удалось сохранить')}};
cam();
})();
