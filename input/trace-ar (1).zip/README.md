# Trace AR

## APK через GitHub (без Android Studio)
1. Создай репозиторий на github.com, загрузи все файлы из ZIP.
2. Вкладка Actions → Build APK → Run workflow.
3. Через ~5 мин скачай `TraceAR-apk` (внутри app-debug.apk), установи на телефон.

## Локально
```
npm install
npx cap add android
# в android/app/src/main/AndroidManifest.xml перед <application> добавь:
# <uses-permission android:name="android.permission.CAMERA" />
npx capacitor-assets generate --android   # иконка из resources/
npx cap sync android
npx cap open android   # Build → Build APK
```
Веб-часть: папка `www/` (после правок: `npx cap sync android`).

## Нативная камера (0.5×)
Плагин @capgo/camera-preview подключается автоматически при сборке через GitHub (npm install + cap sync). В APK появляются реальные объективы и зум до 0.5× (если он есть у телефона). APK из freewebtoapk этого не умеет.
