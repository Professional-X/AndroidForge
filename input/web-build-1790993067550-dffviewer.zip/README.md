# DFF Viewer Android 1.0 — Android 15

Visualizador Android de modelos RenderWare/GTA SA, com implementação própria.

## Alvo
- Android 15 / API 35
- compileSdk 35 / targetSdk 35
- Java/JDK 17
- Android Gradle Plugin 8.10.1
- Gradle 8.11.1
- OpenGL ES 3.0

## Funções da versão
- Seleção de DFF e TXD pelo seletor de arquivos do Android
- Parser DFF convencional com UVs e materiais
- Índice de texturas TXD e suporte a DXT1/DXT3
- Renderização OpenGL ES 3.0
- Rotação, zoom, pan e centralização
- Iluminação e modo wireframe
- Detecção/inspeção de Native Data PLG
- Base separada para Native OpenGL Geometry

## Compilar sem PC
Este projeto pode ser enviado para um serviço de build baseado em GitHub Actions, como AndroidForge, que detecta o projeto Gradle e pode regenerar o Gradle Wrapper quando o `gradle-wrapper.jar` não estiver presente.

Para compilação local, use JDK 17, Android SDK API 35 e Gradle 8.11.1.

## Importante
O pacote contém código-fonte próprio. Não inclui o executável original do DFF Viewer nem assets proprietários de terceiros.

A camada Native Geometry para veículos ainda é experimental; DFF convencional + materiais/TXD é o caminho principal de compatibilidade desta versão.
