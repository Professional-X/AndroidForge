package com.stryker.dffviewer;

import java.util.*;

/**
 * Read-only inspection of RenderWare Native Data PLG blocks.
 * This class intentionally does not copy or depend on proprietary viewer code.
 * It records native plugin blocks so platform-specific decoders can be added safely.
 */
public final class NativeGeometryInspector {
    public static final int NATIVE_DATA_PLG = 0x510;
    public static final int GEOMETRY_NATIVE_FLAG = 0x01000000;
    public static final class Block {
        public final int offset, length, version;
        public Block(int offset, int length, int version) { this.offset=offset; this.length=length; this.version=version; }
    }
    public static final class Report {
        public final ArrayList<Block> blocks = new ArrayList<>();
        public boolean hasNativeData() { return !blocks.isEmpty(); }
    }
    private static int u32(byte[] b, int p) {
        return (b[p]&255)|((b[p+1]&255)<<8)|((b[p+2]&255)<<16)|((b[p+3]&255)<<24);
    }
    public static Report inspect(byte[] b) {
        Report r = new Report();
        for (int p=0; p+12<=b.length; p+=4) {
            int type=u32(b,p), len=u32(b,p+4), ver=u32(b,p+8);
            if (type==NATIVE_DATA_PLG && len>=0 && p+12L+len<=b.length) r.blocks.add(new Block(p,len,ver));
        }
        return r;
    }
}
