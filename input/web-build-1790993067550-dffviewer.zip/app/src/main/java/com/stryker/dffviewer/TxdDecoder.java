package com.stryker.dffviewer;

import android.graphics.Bitmap;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Own decoder for the DXT1/DXT3 raster blocks found in PC GTA SA TXDs. */
public final class TxdDecoder {
    public static final class ImageInfo { public String name=""; public int width,height,format,offset,dataOffset; }
    private TxdDecoder(){}

    public static ArrayList<ImageInfo> index(byte[] b) throws IOException {
        ArrayList<ImageInfo> out=new ArrayList<>();HashSet<Integer> seen=new HashSet<>();
        for(int p=0;p+16<=b.length;p++){
            int fmt=magic(b,p);if(fmt==0)continue;int w=u16(b,p+4),h=u16(b,p+6);if(w<=0||h<=0||w>8192||h>8192)continue;
            int blockBytes=fmt==1?8:16, expected=((w+3)/4)*((h+3)/4)*blockBytes, data=p+16;
            if(data+expected>b.length||!seen.add(p))continue;
            ImageInfo x=new ImageInfo();x.name=readFixedAscii(b,Math.max(0,p-36),32);if(x.name.isEmpty())x.name="texture_"+out.size();x.width=w;x.height=h;x.format=fmt;x.offset=p;x.dataOffset=data;out.add(x);
        }
        if(out.isEmpty())throw new IOException("Nenhuma textura DXT1/DXT3 compatível encontrada.");
        return out;
    }
    public static Bitmap decode(byte[] b,ImageInfo info)throws IOException{
        int blockBytes=info.format==1?8:16,expected=((info.width+3)/4)*((info.height+3)/4)*blockBytes;if(info.dataOffset+expected>b.length)throw new IOException("Raster TXD truncado");return decodeLevel(b,info.dataOffset,info.width,info.height,info.format);
    }
    public static String normalize(String s){return s==null?"":s.trim().toLowerCase(Locale.ROOT);}
    private static int magic(byte[] b,int p){return b[p]=='D'&&b[p+1]=='X'&&b[p+2]=='T'&&b[p+3]=='1'?1:(b[p]=='D'&&b[p+1]=='X'&&b[p+2]=='T'&&b[p+3]=='3'?3:0);}
    private static String readFixedAscii(byte[] b,int p,int n){int e=Math.min(b.length,p+n),z=p;while(z<e&&b[z]!=0)z++;return new String(b,p,z-p,StandardCharsets.US_ASCII).trim();}
    private static int u16(byte[] b,int p){return(b[p]&255)|((b[p+1]&255)<<8);}private static int u32(byte[] b,int p){return(b[p]&255)|((b[p+1]&255)<<8)|((b[p+2]&255)<<16)|((b[p+3]&255)<<24);}private static long u64(byte[]b,int p){long v=0;for(int i=0;i<8;i++)v|=((long)(b[p+i]&255))<<(8*i);return v;}
    private static Bitmap decodeLevel(byte[] b,int off,int w,int h,int fmt){int[] px=new int[w*h];int bxN=(w+3)/4,byN=(h+3)/4,p=off;for(int by=0;by<byN;by++)for(int bx=0;bx<bxN;bx++){long alpha=0;if(fmt==3){alpha=u64(b,p);p+=8;}int c0=u16(b,p),c1=u16(b,p+2),bits=u32(b,p+4);p+=8;int[] cs=colors(c0,c1);for(int y=0;y<4;y++)for(int x=0;x<4;x++){int xx=bx*4+x,yy=by*4+y,ci=(bits>>>(2*(y*4+x)))&3,argb=cs[ci];if(fmt==3){int a=(int)((alpha>>>(4*(y*4+x)))&15)*17;argb=(a<<24)|(argb&0xFFFFFF);}if(xx<w&&yy<h)px[yy*w+xx]=argb;}}return Bitmap.createBitmap(px,w,h,Bitmap.Config.ARGB_8888);}
    private static int[] colors(int c0,int c1){int r0=((c0>>11)&31)*255/31,g0=((c0>>5)&63)*255/63,b0=(c0&31)*255/31,r1=((c1>>11)&31)*255/31,g1=((c1>>5)&63)*255/63,b1=(c1&31)*255/31;int[]c=new int[4];c[0]=0xFF000000|(r0<<16)|(g0<<8)|b0;c[1]=0xFF000000|(r1<<16)|(g1<<8)|b1;if(c0>c1){c[2]=0xFF000000|(((2*r0+r1)/3)<<16)|(((2*g0+g1)/3)<<8)|((2*b0+b1)/3);c[3]=0xFF000000|(((r0+2*r1)/3)<<16)|(((g0+2*g1)/3)<<8)|((b0+2*b1)/3);}else{c[2]=0xFF000000|(((r0+r1)/2)<<16)|(((g0+g1)/2)<<8)|((b0+b1)/2);c[3]=0;}return c;}
}
