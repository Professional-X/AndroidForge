package com.stryker.dffviewer;

import java.util.*;

/**
 * Native RenderWare geometry inspector/decoder dispatcher.
 * GTA SA RenderWare streams are little-endian.  Native geometry is platform
 * specific, so this class never guesses a D3D layout from arbitrary bytes.
 */
public final class NativeGeometryDecoder {
    public static final int NATIVE_DATA_PLG = 0x510;
    public static final int OPENGL_PLATFORM = 2;

    public enum Status { SUPPORTED_CONVENTIONAL, OPENGL_NATIVE, D3D_NATIVE, UNKNOWN_NATIVE, INVALID }

    public static final class NativePart {
        public final int offset, length, version;
        public int platform = -1;
        public boolean hasOpenGLAttributeHeader;
        public int attributeCount;
        public int stride;
        public String reason = "";
        NativePart(int offset, int length, int version) { this.offset=offset; this.length=length; this.version=version; }
        public Status status() {
            if (hasOpenGLAttributeHeader) return Status.OPENGL_NATIVE;
            return platform == 8 || platform == 9 ? Status.D3D_NATIVE : Status.UNKNOWN_NATIVE;
        }
    }

    public static final class Report {
        public final ArrayList<NativePart> parts = new ArrayList<>();
        public int count(){ return parts.size(); }
        public boolean hasOpenGL(){ for(NativePart p:parts) if(p.hasOpenGLAttributeHeader) return true; return false; }
        public String summary(){
            int gl=0,d3d=0,u=0; for(NativePart p:parts){ if(p.hasOpenGLAttributeHeader)gl++; else if(p.platform==8||p.platform==9)d3d++; else u++; }
            return "Native PLG: "+parts.size()+" (OpenGL="+gl+", D3D="+d3d+", desconhecido="+u+")";
        }
    }

    static int u32(byte[] b,int p){ return (b[p]&255)|((b[p+1]&255)<<8)|((b[p+2]&255)<<16)|((b[p+3]&255)<<24); }
    static int s32(byte[] b,int p){ return u32(b,p); }
    static boolean in(byte[] b,int p,int n){ return p>=0 && n>=0 && p+n<=b.length; }

    public static Report inspect(byte[] d){
        Report r=new Report(); if(d==null||d.length<12)return r;
        scan(d,0,d.length,r,0);
        return r;
    }

    private static void scan(byte[] d,int start,int end,Report out,int depth){
        if(depth>64)return;
        int p=start;
        while(p+12<=end){
            int type=u32(d,p), len=u32(d,p+4); long e=(long)p+12+(len&0xffffffffL);
            if(len<0 || e>end){ p+=4; continue; }
            if(type==NATIVE_DATA_PLG){
                NativePart n=new NativePart(p+12,len,u32(d,p+8)); classify(d,n); out.parts.add(n);
            }
            // RenderWare chunks are recursively nested. Only descend into
            // chunks whose payload is large enough to plausibly contain child headers.
            if(len>=12) scan(d,p+12,(int)e,out,depth+1);
            p=(int)e;
        }
    }

    private static void classify(byte[] d,NativePart n){
        int a=n.offset,e=Math.min(d.length,n.offset+n.length);
        if(a+4>e){n.reason="bloco truncado";return;}
        // OpenGL native geometry used by mobile GTA has an attribute-count header:
        // uint32 count followed by attribute records and a tightly packed vertex buffer.
        int count=u32(d,a);
        if(count>=1 && count<=16 && a+4+count*24<=e){
            int base=a+4, commonStride=-1; boolean ok=true;
            for(int i=0;i<count;i++){
                int type=u32(d,base+i*24+4), norm=u32(d,base+i*24+8), size=u32(d,base+i*24+12), stride=u32(d,base+i*24+16), off=u32(d,base+i*24+20);
                if(type>4 || size<1 || size>4 || stride==0 || off>=stride){ok=false;break;}
                if(commonStride<0)commonStride=stride; else if(commonStride!=stride)ok=false;
            }
            if(ok && commonStride>0){n.hasOpenGLAttributeHeader=true;n.attributeCount=count;n.stride=commonStride;n.reason="cabeçalho OpenGL nativo";return;}
        }
        // Do not label arbitrary bytes as D3D8/D3D9. These IDs must come from
        // a known platform header, which is intentionally left as unknown here.
        n.reason="formato nativo ainda não identificado com segurança";
    }
    private NativeGeometryDecoder(){}
}
