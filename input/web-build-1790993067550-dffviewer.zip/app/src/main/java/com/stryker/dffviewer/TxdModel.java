package com.stryker.dffviewer;

import java.io.*;
import java.util.*;

/** Lightweight RenderWare TXD indexer. It reads texture dictionary chunks and exposes names.
 * Native raster decoding is intentionally separated so new GTA SA raster variants can be added safely. */
public final class TxdModel {
    public static final class Texture { public String name="", mask=""; public int width,height,depth,format; }
    public final ArrayList<Texture> textures=new ArrayList<>();
    static final int TEXDICT=0x16, TEXNATIVE=0x15, TEX=0x06, STRUCT=1;
    static final class R { final byte[] b; int p; R(byte[] b){this.b=b;} int i(){if(p+4>b.length)throw new RuntimeException("TXD truncado");int v=(b[p]&255)|((b[p+1]&255)<<8)|((b[p+2]&255)<<16)|((b[p+3]&255)<<24);p+=4;return v;} }
    static final class C {int type,len,ver,data,end;}
    static C chunk(R r,int limit){if(r.p+12>limit)return null;C c=new C();c.type=r.i();c.len=r.i();c.ver=r.i();c.data=r.p;c.end=r.p+c.len;return c.end<=limit&&c.len>=0?c:null;}
    public static TxdModel load(InputStream in)throws IOException{ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] q=new byte[16384];int n;while((n=in.read(q))>0)o.write(q,0,n);return parse(o.toByteArray());}
    public static TxdModel parse(byte[] b)throws IOException{TxdModel out=new TxdModel();scan(new R(b),b.length,out);if(out.textures.isEmpty())throw new IOException("Nenhuma textura RenderWare encontrada.");return out;}
    static void scan(R r,int lim,TxdModel out){while(r.p+12<=lim){C c=chunk(r,lim);if(c==null)break;if(c.type==TEXNATIVE)parseNative(r.b,c,out);else if(c.type==TEX)parseTexture(r.b,c,out);else if(c.len>=12)scan(new R(Arrays.copyOfRange(r.b,c.data,c.end)),c.len,out);r.p=c.end;}}
    static String str(byte[] b,int off,int max){int n=0;while(n<max&&off+n<b.length&&b[off+n]!=0)n++;return new String(b,off,n,java.nio.charset.StandardCharsets.ISO_8859_1).trim();}
    static void parseTexture(byte[] b,C c,TxdModel out){R r=new R(b);r.p=c.data;while(r.p+12<=c.end){C x=chunk(r,c.end);if(x==null)break;if(x.type==STRUCT){ // Texture struct: filter/address fields; names are in following string chunks.
            String name="",mask="";int q=r.p;while(q+12<=c.end){C y=chunk(new R(b),c.end);break;} // names are usually in child string chunks; handled by scan below.
        } else if(x.type==0x02){String s=str(b,x.data, x.len); if(!s.isEmpty()){Texture t=new Texture();t.name=s;out.textures.add(t);}}r.p=x.end;}}
    static void parseNative(byte[] b,C c,TxdModel out){Texture t=new Texture();R r=new R(b);r.p=c.data;while(r.p+12<=c.end){C x=chunk(r,c.end);if(x==null)break;if(x.type==STRUCT){int q=x.data;if(q+80<=x.end){ // D3D9 native texture header varies; first useful strings are searched below.
                String n=str(b,q,32);if(!n.isEmpty()&&n.indexOf('\u0000')<0)t.name=n;
            }}r.p=x.end;}if(t.name.isEmpty())t.name="native_texture_"+(out.textures.size()+1);out.textures.add(t);}
}
