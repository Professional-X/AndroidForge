package com.stryker.dffviewer;

import java.nio.*;
import java.util.*;

/** Decoder for the documented OpenGL native RenderWare vertex-buffer header. */
public final class NativeOpenGLGeometryDecoder {
    public static final class Attribute { public int index,type,normalized,size,stride,offset; }
    public static final class Result {
        public int vertexCount, stride; public final ArrayList<Attribute> attributes=new ArrayList<>();
        public boolean valid; public String message="";
    }
    static int u32(byte[] b,int p){return(b[p]&255)|((b[p+1]&255)<<8)|((b[p+2]&255)<<16)|((b[p+3]&255)<<24);}
    public static Result decode(byte[] payload,int vertexCount){
        Result r=new Result(); if(payload==null||payload.length<4||vertexCount<=0){r.message="dados insuficientes";return r;}
        int n=u32(payload,0); if(n<1||n>16||4+n*24>payload.length){r.message="cabeçalho OpenGL inválido";return r;}
        int stride=-1;
        for(int i=0;i<n;i++){
            int p=4+i*24; Attribute a=new Attribute(); a.index=u32(payload,p);a.type=u32(payload,p+4);a.normalized=u32(payload,p+8);a.size=u32(payload,p+12);a.stride=u32(payload,p+16);a.offset=u32(payload,p+20);
            if(a.index>6||a.type>4||a.size<1||a.size>4||a.stride<=0||a.offset>=a.stride){r.message="atributo inválido";return r;}
            if(stride<0)stride=a.stride; if(a.stride!=stride){r.message="strides divergentes";return r;} r.attributes.add(a);
        }
        long dataStart=4L+n*24L, required=dataStart+(long)stride*vertexCount;
        if(required>payload.length){r.message="buffer de vértices incompleto";return r;}
        r.vertexCount=vertexCount;r.stride=stride;r.valid=true;r.message="OpenGL native decodificado";return r;
    }
    private NativeOpenGLGeometryDecoder(){}
}
