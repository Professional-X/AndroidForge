package com.stryker.dffviewer;

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.opengl.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.*;
import java.util.*;

public class MainActivity extends Activity {
    ModelView modelView; TextView status; Spinner textureSpinner;
    byte[] txdBytes; ArrayList<TxdDecoder.ImageInfo> textureInfos=new ArrayList<>();
    static final int PICK_DFF=101,PICK_TXD=102;
    @Override public void onCreate(Bundle state){super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(12,12,12));getWindow().setNavigationBarColor(Color.BLACK);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(20,20,20));
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(6,4,6,4);
        Button open=new Button(this);open.setText("DFF");Button txd=new Button(this);txd.setText("TXD");Button reset=new Button(this);reset.setText("CENTRAR");Button wire=new Button(this);wire.setText("WIRE");
        textureSpinner=new Spinner(this);textureSpinner.setEnabled(false);status=new TextView(this);status.setText("Abra DFF + TXD para mapeamento automático");status.setTextColor(Color.WHITE);status.setTextSize(12);status.setPadding(6,0,4,0);
        open.setOnClickListener(v->pick(PICK_DFF));txd.setOnClickListener(v->pick(PICK_TXD));reset.setOnClickListener(v->modelView.resetCamera());wire.setOnClickListener(v->{modelView.setWireframe(!modelView.isWireframe());wire.setText(modelView.isWireframe()?"SÓLIDO":"WIRE");});
        bar.addView(open);bar.addView(txd);bar.addView(textureSpinner,new LinearLayout.LayoutParams(0,-2,1));bar.addView(reset);bar.addView(wire);root.addView(bar);
        modelView=new ModelView(this);root.addView(modelView,new LinearLayout.LayoutParams(-1,0,1));
        TextView hint=new TextView(this);hint.setText("1 dedo: girar • pinça: zoom • 2 dedos: mover • Textura: automática por material");hint.setTextColor(Color.LTGRAY);hint.setTextSize(12);hint.setGravity(Gravity.CENTER);hint.setPadding(4,7,4,7);root.addView(hint);setContentView(root);
        textureSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){}public void onItemSelected(AdapterView<?> p,View v,int pos,long id){if(pos>=0&&pos<textureInfos.size())modelView.setManualTexture(textureInfos.get(pos).name);}});
    }
    void pick(int req){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/octet-stream");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,req);}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(result!=RESULT_OK||data==null)return;try(InputStream in=getContentResolver().openInputStream(data.getData())){byte[] bytes=readAll(in);if(req==PICK_DFF){NativeGeometryInspector.Report nr=NativeGeometryInspector.inspect(bytes); DffModel m=DffModel.parse(bytes); modelView.setModel(m); status.setText(m.vertexCount+" vértices • "+m.triangleCount+" triângulos • "+m.groups.size()+" materiais"+(nr.hasNativeData()?" • Native PLG: "+nr.blocks.size():""));}else{txdBytes=bytes;textureInfos=TxdDecoder.index(bytes);ArrayList<String> names=new ArrayList<>();for(TxdDecoder.ImageInfo x:textureInfos)names.add(x.name+"  "+x.width+"x"+x.height+"  DXT"+x.format);textureSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));textureSpinner.setEnabled(true);modelView.setTxd(bytes,textureInfos);status.setText("TXD: "+textureInfos.size()+" textura(s) • mapeamento automático ativo");}}catch(Exception e){status.setText("Erro: "+e.getMessage());}}
    static byte[] readAll(InputStream in)throws IOException{ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] q=new byte[32768];int n;while((n=in.read(q))>0)o.write(q,0,n);return o.toByteArray();}
}

class ModelView extends GLSurfaceView{
    final DffRenderer renderer=new DffRenderer();float lastX,lastY,oldDist,midX,midY;int mode;
    ModelView(Context c){super(c);setEGLContextClientVersion(3);setRenderer(renderer);setRenderMode(RENDERMODE_CONTINUOUSLY);}
    void setModel(DffModel m){renderer.setModel(m);}void setTxd(byte[] b,ArrayList<TxdDecoder.ImageInfo> i){renderer.setTxd(b,i);}void setManualTexture(String n){renderer.manualTexture=TxdDecoder.normalize(n);}void resetCamera(){renderer.resetCamera();}void setWireframe(boolean b){renderer.wireframe=b;}boolean isWireframe(){return renderer.wireframe;}
    @Override public boolean onTouchEvent(MotionEvent e){int n=e.getPointerCount();if(n==1){if(e.getActionMasked()==MotionEvent.ACTION_DOWN){lastX=e.getX();lastY=e.getY();mode=1;}else if(e.getActionMasked()==MotionEvent.ACTION_MOVE&&mode==1){float dx=e.getX()-lastX,dy=e.getY()-lastY;renderer.yaw+=dx*.45f;renderer.pitch=Math.max(-89,Math.min(89,renderer.pitch+dy*.45f));lastX=e.getX();lastY=e.getY();}return true;}if(n>=2){if(e.getActionMasked()==MotionEvent.ACTION_POINTER_DOWN){oldDist=spacing(e);midX=(e.getX(0)+e.getX(1))/2;midY=(e.getY(0)+e.getY(1))/2;mode=2;}else if(e.getActionMasked()==MotionEvent.ACTION_MOVE&&mode==2){float d=spacing(e);if(oldDist>0)renderer.distance=Math.max(.55f,Math.min(20f,renderer.distance*oldDist/d));oldDist=d;float nx=(e.getX(0)+e.getX(1))/2,ny=(e.getY(0)+e.getY(1))/2;renderer.panX+=(nx-midX)/getWidth()*2f;renderer.panY-=(ny-midY)/getHeight()*2f;midX=nx;midY=ny;}return true;}return true;}
    float spacing(MotionEvent e){float dx=e.getX(0)-e.getX(1),dy=e.getY(0)-e.getY(1);return(float)Math.sqrt(dx*dx+dy*dy);}
}

class DffRenderer implements GLSurfaceView.Renderer{
    DffModel model;boolean wireframe;String manualTexture="";byte[] txdBytes;ArrayList<TxdDecoder.ImageInfo> infos=new ArrayList<>();final HashMap<String,Integer> glTextures=new HashMap<>();final HashMap<String,TxdDecoder.ImageInfo> infoByName=new HashMap<>();
    int program,aPos,aNormal,aUv,uMvp,uModel,uLight,uColor,uTex,uUseTex;float yaw=25,pitch=10,distance=3.2f,panX,panY;final float[] proj=new float[16],view=new float[16],modelMat=new float[16],mv=new float[16],mvp=new float[16];
    void setModel(DffModel m){model=m;resetCamera();}
    void setTxd(byte[] b,ArrayList<TxdDecoder.ImageInfo> i){txdBytes=b;infos=new ArrayList<>(i);infoByName.clear();for(TxdDecoder.ImageInfo x:i)infoByName.put(TxdDecoder.normalize(x.name),x);glTextures.clear();}
    void setTextureBitmap(String key,Bitmap b){if(b==null)return;int[] x={0};GLES30.glGenTextures(1,x,0);int id=x[0];GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,id);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MIN_FILTER,GLES30.GL_LINEAR);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MAG_FILTER,GLES30.GL_LINEAR);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_S,GLES30.GL_REPEAT);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_T,GLES30.GL_REPEAT);GLUtils.texImage2D(GLES30.GL_TEXTURE_2D,0,b,0);GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,0);glTextures.put(key,id);b.recycle();}
    int ensureTexture(String name){String key=TxdDecoder.normalize(name);if(key.isEmpty()||txdBytes==null)return 0;Integer cached=glTextures.get(key);if(cached!=null)return cached;TxdDecoder.ImageInfo info=infoByName.get(key);if(info==null)return 0;try{Bitmap b=TxdDecoder.decode(txdBytes,info);setTextureBitmap(key,b);return glTextures.get(key);}catch(Exception e){return 0;}}
    int findTexture(String groupName){if(!manualTexture.isEmpty())return ensureTexture(manualTexture);return ensureTexture(groupName);}
    void resetCamera(){yaw=25;pitch=10;distance=3.2f;panX=panY=0;}
    @Override public void onSurfaceCreated(javax.microedition.khronos.opengles.GL10 gl,javax.microedition.khronos.egl.EGLConfig cfg){GLES30.glClearColor(.055f,.06f,.07f,1);GLES30.glEnable(GLES30.GL_DEPTH_TEST);String vs="#version 300 es\nin vec3 aPos; in vec3 aNormal; in vec2 aUv; uniform mat4 uMvp; uniform mat4 uModel; out vec3 vN; out vec2 vUv; void main(){vN=mat3(uModel)*aNormal;vUv=aUv;gl_Position=uMvp*vec4(aPos,1.0);}";String fs="#version 300 es\nprecision mediump float; in vec3 vN; in vec2 vUv; uniform vec3 uLight; uniform vec4 uColor; uniform sampler2D uTex; uniform int uUseTex; out vec4 frag; void main(){vec3 n=normalize(vN);float d=max(dot(n,normalize(uLight)),0.0);float shade=.30+.70*d;vec4 base=uUseTex==1?texture(uTex,vUv):uColor;frag=vec4(base.rgb*shade,base.a);}";program=link(vs,fs);aPos=GLES30.glGetAttribLocation(program,"aPos");aNormal=GLES30.glGetAttribLocation(program,"aNormal");aUv=GLES30.glGetAttribLocation(program,"aUv");uMvp=GLES30.glGetUniformLocation(program,"uMvp");uModel=GLES30.glGetUniformLocation(program,"uModel");uLight=GLES30.glGetUniformLocation(program,"uLight");uColor=GLES30.glGetUniformLocation(program,"uColor");uTex=GLES30.glGetUniformLocation(program,"uTex");uUseTex=GLES30.glGetUniformLocation(program,"uUseTex");}
    @Override public void onSurfaceChanged(javax.microedition.khronos.opengles.GL10 gl,int w,int h){GLES30.glViewport(0,0,w,h);Matrix.perspectiveM(proj,0,55,(float)w/Math.max(1,h),.05f,100);}
    @Override public void onDrawFrame(javax.microedition.khronos.opengles.GL10 gl){GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT|GLES30.GL_DEPTH_BUFFER_BIT);if(model==null||model.vertices.length==0)return;Matrix.setLookAtM(view,0,panX,panY,distance,panX,panY,0,0,1,0);Matrix.setIdentityM(modelMat,0);Matrix.rotateM(modelMat,0,yaw,0,1,0);Matrix.rotateM(modelMat,0,pitch,1,0,0);Matrix.multiplyMM(mv,0,view,0,modelMat,0);Matrix.multiplyMM(mvp,0,proj,0,mv,0);GLES30.glUseProgram(program);GLES30.glUniformMatrix4fv(uMvp,1,false,mvp,0);GLES30.glUniformMatrix4fv(uModel,1,false,modelMat,0);GLES30.glUniform3f(uLight,-.35f,.75f,1);GLES30.glUniform4f(uColor,.72f,.75f,.82f,1);
        FloatBuffer vb=buf(model.vertices),nb=buf(model.normals),uv=buf(model.uvs);GLES30.glEnableVertexAttribArray(aPos);GLES30.glVertexAttribPointer(aPos,3,GLES30.GL_FLOAT,false,0,vb);GLES30.glEnableVertexAttribArray(aNormal);GLES30.glVertexAttribPointer(aNormal,3,GLES30.GL_FLOAT,false,0,nb);if(aUv>=0){GLES30.glEnableVertexAttribArray(aUv);GLES30.glVertexAttribPointer(aUv,2,GLES30.GL_FLOAT,false,0,uv);}
        if(model.groups.isEmpty()){drawRange(0,model.indices.length,0);}else for(DffModel.DrawGroup g:model.groups)drawRange(g.firstIndex,g.indexCount,findTexture(g.textureName));
        if(aUv>=0)GLES30.glDisableVertexAttribArray(aUv);GLES30.glDisableVertexAttribArray(aPos);GLES30.glDisableVertexAttribArray(aNormal);
    }
    void drawRange(int first,int count,int tex){GLES30.glUniform1i(uUseTex,tex!=0&&model.uvs.length>0?1:0);if(tex!=0){GLES30.glActiveTexture(GLES30.GL_TEXTURE0);GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,tex);GLES30.glUniform1i(uTex,0);}IntBuffer ib=ByteBuffer.allocateDirect(count*4).order(ByteOrder.nativeOrder()).asIntBuffer();ib.position(0);for(int i=0;i<count;i++)ib.put(model.indices[first+i]);ib.position(0);if(wireframe){GLES30.glDisable(GLES30.GL_CULL_FACE);for(int i=0;i<count;i+=3){IntBuffer one=ib.duplicate();one.position(i);GLES30.glDrawElements(GLES30.GL_LINE_LOOP,Math.min(3,count-i),GLES30.GL_UNSIGNED_INT,one);}}else GLES30.glDrawElements(GLES30.GL_TRIANGLES,count,GLES30.GL_UNSIGNED_INT,ib);if(tex!=0)GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,0);}
    FloatBuffer buf(float[] a){FloatBuffer b=ByteBuffer.allocateDirect(a.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();b.put(a).position(0);return b;}
    int link(String v,String f){int a=shader(GLES30.GL_VERTEX_SHADER,v),b=shader(GLES30.GL_FRAGMENT_SHADER,f),p=GLES30.glCreateProgram();GLES30.glAttachShader(p,a);GLES30.glAttachShader(p,b);GLES30.glLinkProgram(p);return p;}int shader(int t,String s){int x=GLES30.glCreateShader(t);GLES30.glShaderSource(x,s);GLES30.glCompileShader(x);return x;}
}
