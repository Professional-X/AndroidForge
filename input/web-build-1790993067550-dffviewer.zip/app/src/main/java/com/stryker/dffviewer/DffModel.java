package com.stryker.dffviewer;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Own, read-only RenderWare DFF parser for GTA-era files. */
public final class DffModel {
    public float[] vertices=new float[0], normals=new float[0], uvs=new float[0];
    public int[] indices=new int[0];
    public int vertexCount, triangleCount;
    public boolean hasNativeGeometry=false;
    public float scale=1f;
    public final ArrayList<DrawGroup> groups=new ArrayList<>();

    public static final class DrawGroup {
        public int firstIndex, indexCount, materialIndex;
        public String textureName="";
        DrawGroup(int first,int count,int mat,String tex){firstIndex=first;indexCount=count;materialIndex=mat;textureName=tex==null?"":tex;}
    }

    static final int STRUCT=1, STRING=2, EXTENSION=3, MATERIAL=7, MATERIAL_LIST=8, GEOMETRY=15;
    static final class R { final byte[] b; int p; R(byte[] b){this.b=b;} int i(){if(p+4>b.length)throw new RuntimeException("DFF truncado");int v=(b[p]&255)|((b[p+1]&255)<<8)|((b[p+2]&255)<<16)|((b[p+3]&255)<<24);p+=4;return v;} int u16(){if(p+2>b.length)throw new RuntimeException("DFF truncado");int v=(b[p]&255)|((b[p+1]&255)<<8);p+=2;return v;} float f(){return Float.intBitsToFloat(i());} void skip(int n){p+=n;} }
    static final class C {int type,len,ver,data,end;}
    static final class Tri {int a,b,c,mat;Tri(int a,int b,int c,int mat){this.a=a;this.b=b;this.c=c;this.mat=mat;}}
    static final class Part {ArrayList<float[]> vs=new ArrayList<>(),uv=new ArrayList<>();ArrayList<Tri> tris=new ArrayList<>();ArrayList<String> mats=new ArrayList<>();boolean nativeGeometry;}

    static C chunk(R r,int limit){if(r.p+12>limit)return null;C c=new C();c.type=r.i();c.len=r.i();c.ver=r.i();c.data=r.p;c.end=c.data+c.len;if(c.len<0||c.end>limit)return null;return c;}
    public static DffModel load(InputStream in)throws IOException{ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] q=new byte[32768];int n;while((n=in.read(q))>0)o.write(q,0,n);return parse(o.toByteArray());}

    public static DffModel parse(byte[] data)throws IOException{
        DffModel out=new DffModel();ArrayList<Part> parts=new ArrayList<>();scan(new R(data),data.length,parts);
        if(parts.isEmpty()) rawGeometryScan(data,parts);
        boolean nativeFound=false;for(Part p:parts)if(p.nativeGeometry)nativeFound=true;out.hasNativeGeometry=nativeFound;
        parts.removeIf(p->p.vs.isEmpty());
        if(parts.isEmpty()&&nativeFound){ NativeGeometryDecoder.Report nr=NativeGeometryDecoder.inspect(data); throw new IOException("Geometria nativa detectada: "+nr.summary()+". Este formato será tratado pelo decodificador nativo, não pelo parser convencional."); }
        if(parts.isEmpty())throw new IOException("Nenhuma geometria RenderWare encontrada.");
        int totalV=0,totalI=0;for(Part p:parts){totalV+=p.vs.size();totalI+=p.tris.size()*3;}
        out.vertexCount=totalV;out.triangleCount=totalI/3;out.vertices=new float[totalV*3];out.uvs=new float[totalV*2];out.normals=new float[totalV*3];out.indices=new int[totalI];
        ArrayList<Integer> idx=new ArrayList<>(totalI);int vo=0;
        for(Part p:parts){for(int i=0;i<p.vs.size();i++){float[] v=p.vs.get(i);out.vertices[(vo+i)*3]=v[0];out.vertices[(vo+i)*3+1]=v[1];out.vertices[(vo+i)*3+2]=v[2];float[] t=p.uv.get(i);out.uvs[(vo+i)*2]=t[0];out.uvs[(vo+i)*2+1]=1f-t[1];}
            // Preserve material/texture assignment while flattening geometry parts.
            LinkedHashMap<Integer,ArrayList<Integer>> byMat=new LinkedHashMap<>();
            for(Tri t:p.tris){if(t.a>=p.vs.size()||t.b>=p.vs.size()||t.c>=p.vs.size())continue;ArrayList<Integer> a=byMat.get(t.mat);if(a==null){a=new ArrayList<>();byMat.put(t.mat,a);}a.add(vo+t.a);a.add(vo+t.b);a.add(vo+t.c);}
            for(Map.Entry<Integer,ArrayList<Integer>> e:byMat.entrySet()){int first=idx.size();idx.addAll(e.getValue());String tex=e.getKey()>=0&&e.getKey()<p.mats.size()?p.mats.get(e.getKey()):"";out.groups.add(new DrawGroup(first,e.getValue().size(),e.getKey(),tex));}
            vo+=p.vs.size();
        }
        for(int i=0;i<idx.size();i++)out.indices[i]=idx.get(i);
        float max=0;for(int i=0;i<out.vertices.length;i++)max=Math.max(max,Math.abs(out.vertices[i]));if(max<1e-7f)max=1;out.scale=1f/max;for(int i=0;i<out.vertices.length;i++)out.vertices[i]*=out.scale;
        for(int i=0;i<out.indices.length;i+=3){int a=out.indices[i],b=out.indices[i+1],c=out.indices[i+2];float ax=out.vertices[a*3],ay=out.vertices[a*3+1],az=out.vertices[a*3+2],bx=out.vertices[b*3],by=out.vertices[b*3+1],bz=out.vertices[b*3+2],cx=out.vertices[c*3],cy=out.vertices[c*3+1],cz=out.vertices[c*3+2];float ux=bx-ax,uy=by-ay,uz=bz-az,vx=cx-ax,vy=cy-ay,vz=cz-az;float nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;for(int k:new int[]{a,b,c}){out.normals[k*3]+=nx;out.normals[k*3+1]+=ny;out.normals[k*3+2]+=nz;}}
        for(int i=0;i<out.vertexCount;i++){float x=out.normals[i*3],y=out.normals[i*3+1],z=out.normals[i*3+2],l=(float)Math.sqrt(x*x+y*y+z*z);if(l>1e-7){out.normals[i*3]=x/l;out.normals[i*3+1]=y/l;out.normals[i*3+2]=z/l;}else out.normals[i*3+2]=1;}
        return out;
    }

    static void scan(R r,int limit,ArrayList<Part> parts){while(r.p+12<=limit){int start=r.p;C c=chunk(r,limit);if(c==null)break;if(c.type==GEOMETRY){Part p=parseGeometryChunk(r.b,c);if(p!=null&&!p.vs.isEmpty())parts.add(p);}else if(c.len>=12&&c.type!=STRING)scan(new R(Arrays.copyOfRange(r.b,c.data,c.end)),c.len,parts);r.p=c.end;if(r.p<=start)break;}}
    static void rawGeometryScan(byte[] data,ArrayList<Part> parts){final int V=0x1803ffff;for(int p=0;p+12<=data.length;p+=4){int type=u32(data,p),len=u32(data,p+4),ver=u32(data,p+8);if(type!=GEOMETRY||ver!=V||len<12||len>8_000_000||p+12+len>data.length)continue;C c=new C();c.type=type;c.len=len;c.ver=ver;c.data=p+12;c.end=p+12+len;Part part=parseGeometryChunk(data,c);if(part!=null&&!part.vs.isEmpty())parts.add(part);}}

    static Part parseGeometryChunk(byte[] data,C geom){R r=new R(data);r.p=geom.data;Part p=new Part();boolean gotStruct=false;while(r.p+12<=geom.end){C c=chunk(r,geom.end);if(c==null)break;if(c.type==STRUCT&&!gotStruct){parseStruct(r.b,c,p);gotStruct=true;}else if(c.type==MATERIAL_LIST){parseMaterialList(r.b,c,p);}r.p=c.end;}if(!gotStruct)return null;if(p.vs.isEmpty()&&p.nativeGeometry)return p;if(p.vs.isEmpty())return null;while(p.mats.size()<256)p.mats.add("");return p;}

    static void parseStruct(byte[] data,C c,Part out){R r=new R(data);r.p=c.data;if(r.p+16>c.end)return;int flags=r.i(),nt=r.i(),nv=r.i(),morph=r.i();if((flags & NativeGeometryInspector.GEOMETRY_NATIVE_FLAG)!=0){out.nativeGeometry=true;return;}if(nv<=0||nt<0||nv>300000||nt>500000)return;if(r.p+nt*8>c.end)return;for(int i=0;i<nt;i++){int a=r.u16(),b=r.u16(),mat=r.u16(),d=r.u16();out.tris.add(new Tri(a,b,d,mat));}boolean prelit=(flags&0x8)!=0,tex=(flags&0x4)!=0,tex2=(flags&0x80)!=0;if(prelit){if(r.p+nv*4>c.end)return;r.skip(nv*4);}int sets=tex2?2:(tex?1:0);if(r.p+nv*8*sets>c.end)return;for(int i=0;i<nv;i++)out.uv.add(sets>0?new float[]{r.f(),r.f()}:new float[]{0,0});if(sets>1)r.skip(nv*8*(sets-1));if(r.p+24>c.end)return;r.skip(16);int hasV=r.i(),hasN=r.i();if(hasV==0||r.p+nv*12>c.end)return;for(int i=0;i<nv;i++)out.vs.add(new float[]{r.f(),r.f(),r.f()});}

    static void parseMaterialList(byte[] data,C c,Part out){R r=new R(data);r.p=c.data;int count=0;while(r.p+12<=c.end){C x=chunk(r,c.end);if(x==null)break;if(x.type==STRUCT){R s=new R(data);s.p=x.data;if(s.p+4<=x.end){count=s.i();for(int i=0;i<count&&s.p+4<=x.end;i++)s.i();}}else if(x.type==MATERIAL){String tex=parseMaterial(data,x);out.mats.add(tex);}r.p=x.end;}while(out.mats.size()<count)out.mats.add("");}
    static String parseMaterial(byte[] data,C c){R r=new R(data);r.p=c.data;while(r.p+12<=c.end){C x=chunk(r,c.end);if(x==null)break;if(x.type==0x06)return parseTextureChunk(data,x);r.p=x.end;}return "";}
    static String parseTextureChunk(byte[] data,C c){R r=new R(data);r.p=c.data;while(r.p+12<=c.end){C x=chunk(r,c.end);if(x==null)break;if(x.type==STRING){String s=readCString(data,x.data,x.end);if(!s.isEmpty())return s;}r.p=x.end;}return "";}
    static String readStringChunk(byte[] data,int limit,int start){R r=new R(data);r.p=start;while(r.p+12<=limit){C x=chunk(r,limit);if(x==null)break;if(x.type==STRING){String s=readCString(data,x.data,x.end);if(!s.isEmpty())return s;}r.p=x.end;}return "";}
    static String readCString(byte[] b,int a,int e){int n=0;while(a+n<e&&b[a+n]!=0)n++;if(n==0)return "";return new String(b,a,n,StandardCharsets.ISO_8859_1).trim();}
    static int u32(byte[] b,int p){return(b[p]&255)|((b[p+1]&255)<<8)|((b[p+2]&255)<<16)|((b[p+3]&255)<<24);}
}
