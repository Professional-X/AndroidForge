plugins { id("com.android.application") }

android { namespace = "com.ogurchik.pubgassistant"; compileSdk = 35
    defaultConfig { applicationId = "com.ogurchik.pubgassistant"; minSdk = 24; targetSdk = 35; versionCode = 3; versionName = "3.0" }
}
