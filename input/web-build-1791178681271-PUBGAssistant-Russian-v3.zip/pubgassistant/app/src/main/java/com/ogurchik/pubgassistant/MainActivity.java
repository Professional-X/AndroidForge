package com.ogurchik.pubgassistant;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.graphics.drawable.GradientDrawable;import android.hardware.*;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
 int gold=Color.rgb(225,184,74), olive=Color.rgb(93,112,52), dark=Color.rgb(12,16,10), panel=Color.rgb(25,32,20), panel2=Color.rgb(34,42,26), text=Color.rgb(244,241,224), muted=Color.rgb(178,184,155); LinearLayout root,results; Spinner style,distance; Switch gyro; TextView info,subtitle;
 int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
 TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextColor(text);t.setTextSize(sp);t.setPadding(dp(12),dp(8),dp(12),dp(8));return t;}
 GradientDrawable box(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));g.setStroke(dp(1),Color.rgb(62,72,42));return g;}
 @Override public void onCreate(Bundle b){super.onCreate(b);build();}
 void build(){
  ScrollView sv=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(10),dp(16),dp(22));root.setBackgroundResource(R.drawable.bg);sv.addView(root);setContentView(sv);
  TextView title=tv("PUBG MOBILE",28);title.setTextColor(gold);title.setTypeface(null,1);root.addView(title);
  subtitle=tv("СЕНСА ПОМОЩНИК  •  v3.0",13);subtitle.setTextColor(muted);root.addView(subtitle);
  addSpace(4);
  info=tv("Определяем устройство…",15);info.setBackground(box(panel,14));root.addView(info,new LinearLayout.LayoutParams(-1,dp(128)));
  addSpace(10);
  TextView sec=tv("🎯  ПОДБОР СЕНСИТИВИТИ",19);sec.setTextColor(gold);sec.setTypeface(null,1);root.addView(sec);
  LinearLayout gyroRow=new LinearLayout(this);gyroRow.setGravity(Gravity.CENTER_VERTICAL);gyroRow.setPadding(dp(12),dp(4),dp(8),dp(4));gyroRow.setBackground(box(panel2,12));
  TextView gt=tv("🌀  Гироскоп",16);gyroRow.addView(gt,new LinearLayout.LayoutParams(0,dp(58),1));gyro=new Switch(this);gyro.setText("ВКЛ");gyro.setTextColor(text);gyro.setChecked(hasGyro());gyroRow.addView(gyro);root.addView(gyroRow);
  addSpace(8);
  root.addView(label("Стиль игры"));style=spin(new String[]{"Спокойный — контроль","Сбалансированный — универсальный","Агрессивный — быстрый контроль"});root.addView(style);
  root.addView(label("Основная дистанция"));distance=spin(new String[]{"Смешанная","Ближняя","Средняя","Дальняя"});root.addView(distance);
  addSpace(8);
  Button go=button("🎯  ПОДОБРАТЬ ЛУЧШУЮ СЕНСУ",gold,dark);root.addView(go);go.setOnClickListener(v->calculate());
  results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);root.addView(results);
  Button reset=button("↻  ПЕРЕСЧИТАТЬ",olive,Color.WHITE);root.addView(reset);reset.setOnClickListener(v->calculate());
  Button about=button("ℹ  КАК ЭТО РАБОТАЕТ",Color.rgb(49,60,36),text);root.addView(about);about.setOnClickListener(v->about());
  detect();
 }
 TextView label(String s){TextView t=tv(s,14);t.setTextColor(muted);return t;}
 void addSpace(int h){Space s=new Space(this);root.addView(s,new LinearLayout.LayoutParams(1,dp(h)));}
 Spinner spin(String[] a){Spinner s=new Spinner(this);ArrayAdapter<String>x=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a){@Override public View getView(int p,android.view.View c,android.view.ViewGroup parent){TextView t=(TextView)super.getView(p,c,parent);t.setTextColor(text);t.setTextSize(15);t.setPadding(dp(12),dp(10),dp(8),dp(10));return t;}};s.setAdapter(x);s.setBackground(box(panel2,10));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(50));lp.setMargins(0,0,0,dp(7));s.setLayoutParams(lp);return s;}
 Button button(String s,int color,int tc){Button b=new Button(this);b.setText(s);b.setTextColor(tc);b.setTextSize(14);b.setTypeface(null,1);b.setAllCaps(false);b.setBackground(box(color,12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(56));p.setMargins(0,dp(6),0,0);b.setLayoutParams(p);return b;}
 boolean hasGyro(){SensorManager sm=(SensorManager)getSystemService(SENSOR_SERVICE);return sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)!=null;}
 void detect(){String model=Build.MANUFACTURER+" "+Build.MODEL;float hz=60;try{hz=getWindowManager().getDefaultDisplay().getRefreshRate();}catch(Exception ignored){} String g=hasGyro()?"ЕСТЬ ✓":"НЕТ ✕";String density=String.format(Locale.US,"%.0f",getResources().getDisplayMetrics().density);info.setText("  📱  ТЕЛЕФОН\n  "+model+"\n\n  🖥️  "+getResources().getDisplayMetrics().widthPixels+" × "+getResources().getDisplayMetrics().heightPixels+"   •   "+String.format(Locale.US,"%.0f",hz)+" Гц   •   DPI ×"+density+"\n  🌀  Гироскоп: "+g+"   •   Android "+Build.VERSION.RELEASE);}
 void calculate(){int base=gyro.isChecked()?300:100;String st=style.getSelectedItem().toString(),di=distance.getSelectedItem().toString();if(st.startsWith("Спокой"))base-=18;if(st.startsWith("Агрессив"))base+=25;if(di.equals("Ближняя"))base+=22;if(di.equals("Дальняя"))base-=22;int[] vals={clamp(base+18),clamp(base+5),clamp(base-18),clamp(base-48),clamp(base-115),clamp(base-175)};String[] names={gyro.isChecked()?"Гироскоп":"ADS", "Red Dot / Коллиматор","2x","3x","4x","6x / 8x"};results.removeAllViews();addResultHeader();for(int i=0;i<vals.length;i++){TextView r=tv("  "+names[i],16);r.setTextColor(text);r.setGravity(Gravity.CENTER_VERTICAL);r.setBackground(box(panel,10));TextView v=tv(String.valueOf(vals[i]),18);v.setTextColor(gold);v.setTypeface(null,1);v.setGravity(Gravity.CENTER);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(3),dp(8),dp(3));row.addView(r,new LinearLayout.LayoutParams(0,dp(50),1));row.addView(v,new LinearLayout.LayoutParams(dp(70),dp(44)));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(56));rp.setMargins(0,dp(3),0,0);results.addView(row,rp);}}
 int clamp(int v){return Math.min(400,Math.max(50,v));}
 void addResultHeader(){TextView h=tv("✓  ГОТОВЫЙ ПРОФИЛЬ",19);h.setTextColor(gold);h.setTypeface(null,1);results.addView(h);TextView n=tv("Значения рассчитаны по выбранному режиму и датчикам телефона.",13);n.setTextColor(muted);results.addView(n);}
 void about(){new AlertDialog.Builder(this).setTitle("PUBG Сенса Помощник").setMessage("Приложение автоматически определяет модель телефона, экран и наличие гироскопа, затем рассчитывает стартовый профиль чувствительности.\n\nЭто помощник: он не изменяет настройки PUBG Mobile напрямую. После подбора перенеси значения в игру и при необходимости сделай небольшую корректировку.").setPositiveButton("Понятно",null).show();}
}
