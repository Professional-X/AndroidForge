package com.anandnet.harmonymusic;

import org.schabi.newpipe.extractor.NewPipe;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.downloader.Downloader;
import org.schabi.newpipe.extractor.downloader.Request;
import org.schabi.newpipe.extractor.downloader.Response;
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.stream.StreamInfo;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Small Android-only adapter around NewPipe Extractor.
 *
 * It deliberately exposes only the audio information Harmony already consumes,
 * so the Flutter layer does not need to know which extractor produced the URL.
 */
public final class NewPipeBridge {
    private static volatile boolean initialized = false;

    private NewPipeBridge() {
    }

    private static synchronized void ensureInitialized() {
        if (initialized) {
            return;
        }

        NewPipe.init(new HarmonyDownloader());
        initialized = true;
    }

    public static Map<String, Object> resolveStreamUrl(String videoId) throws Exception {
        ensureInitialized();

        final String url = toYouTubeUrl(videoId);
        final StreamInfo info = StreamInfo.getInfo(ServiceList.YouTube, url);
        final List<AudioStream> streams = new ArrayList<>(info.getAudioStreams());

        if (streams.isEmpty()) {
            throw new IOException("NewPipe returned no audio streams");
        }

        // Keep the Dart-side quality selectors deterministic.
        Collections.sort(streams, new Comparator<AudioStream>() {
            @Override
            public int compare(AudioStream a, AudioStream b) {
                return Integer.compare(safeBitrate(a), safeBitrate(b));
            }
        });

        final List<Map<String, Object>> audioFormats = new ArrayList<>();

        for (AudioStream stream : streams) {
            if (!stream.isUrl()) {
                continue;
            }

            final String streamUrl = stream.getContent();
            if (streamUrl == null || streamUrl.isEmpty()) {
                continue;
            }

            final String codec = stream.getCodec() == null ? "" : stream.getCodec();
            final String formatName =
                    stream.getFormat() == null ? "" : stream.getFormat().getName();

            final Map<String, Object> item = new HashMap<>();
            item.put("itag", stream.getItag());
            item.put("audioCodec",
                    (codec.contains("mp4a") || formatName.equalsIgnoreCase("m4a"))
                            ? "Codec.mp4a"
                            : "Codec.opus");
            item.put("bitrate", safeBitrate(stream));
            item.put("duration", info.getDuration() * 1000L);
            item.put("loudnessDb", 0.0);
            item.put("url", streamUrl);
            item.put("size", 0L);
            audioFormats.add(item);
        }

        if (audioFormats.isEmpty()) {
            throw new IOException("NewPipe returned no usable audio URLs");
        }

        final Map<String, Object> result = new HashMap<>();
        result.put("playable", true);
        result.put("statusMSG", "OK");
        result.put("source", "newpipe");
        result.put("audioFormats", audioFormats);
        return result;
    }

    private static int safeBitrate(AudioStream stream) {
        try {
            return Math.max(stream.getBitrate(), stream.getAverageBitrate());
        } catch (Throwable ignored) {
            return 0;
        }
    }

    private static String toYouTubeUrl(String videoId) {
        if (videoId == null) {
            return "";
        }

        String value = videoId.trim();
        if (value.startsWith("http://") || value.startsWith("https://")) {
            return value;
        }

        // youtube_explode_dart is commonly passed an 11-character ID here.
        return "https://www.youtube.com/watch?v=" + value;
    }

    /**
     * Minimal downloader required by NewPipe Extractor. It intentionally does
     * not share the youtube_explode_dart HTTP client.
     */
    private static final class HarmonyDownloader extends Downloader {
        private static final String USER_AGENT =
                "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 "
                        + "(KHTML, like Gecko) Chrome/140.0 Mobile Safari/537.36";

        @Override
        public Response execute(Request request) throws IOException, ReCaptchaException {
            HttpURLConnection connection = null;

            try {
                connection = (HttpURLConnection) new URL(request.url()).openConnection();
                connection.setRequestMethod(request.httpMethod());
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(15000);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("User-Agent", USER_AGENT);

                final Map<String, List<String>> headers = request.headers();
                if (headers != null) {
                    for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
                        final List<String> values = entry.getValue();
                        if (values == null) {
                            continue;
                        }
                        for (String value : values) {
                            connection.addRequestProperty(entry.getKey(), value);
                        }
                    }
                }

                final byte[] data = request.dataToSend();
                if (data != null && data.length > 0) {
                    connection.setDoOutput(true);
                    connection.getOutputStream().write(data);
                }

                final int code = connection.getResponseCode();

                if (code == 429) {
                    throw new ReCaptchaException(
                            "YouTube rate limit / challenge response", request.url());
                }

                final InputStream input = code >= 400
                        ? connection.getErrorStream()
                        : connection.getInputStream();

                String body = "";
                if (input != null) {
                    body = readUtf8(input);
                }

                final Map<String, List<String>> responseHeaders =
                        connection.getHeaderFields();

                return new Response(
                        code,
                        connection.getResponseMessage(),
                        responseHeaders,
                        body,
                        connection.getURL().toString()
                );
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }

        private static String readUtf8(InputStream input) throws IOException {
            try (InputStream stream = input;
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                final byte[] buffer = new byte[8192];
                int count;
                while ((count = stream.read(buffer)) != -1) {
                    output.write(buffer, 0, count);
                }
                return output.toString(StandardCharsets.UTF_8.name());
            }
        }
    }
}
