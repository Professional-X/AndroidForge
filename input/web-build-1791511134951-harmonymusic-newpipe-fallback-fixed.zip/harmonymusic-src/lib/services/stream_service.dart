import 'dart:io';

import 'package:flutter/services.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart';

class StreamProvider {
  final bool playable;
  final List<Audio>? audioFormats;
  final String statusMSG;

  StreamProvider({
    required this.playable,
    this.audioFormats,
    this.statusMSG = "",
  });

  static const MethodChannel _newPipeChannel = MethodChannel('newpipe_bridge');

  /// Primary extractor:
  ///   youtube_explode_dart
  ///
  /// Fallback:
  ///   NewPipe Extractor after a short timeout or any extraction failure.
  ///
  /// The returned StreamProvider shape stays exactly the same, so callers,
  /// player code and quality selectors do not need to know which extractor won.
  static Future<StreamProvider> fetch(String videoId) async {
    final yt = YoutubeExplode();

    try {
      try {
        final res = await yt.videos.streamsClient
            .getManifest(videoId)
            .timeout(const Duration(seconds: 7));

        final audio = res.audioOnly;

        if (audio.isNotEmpty) {
          return StreamProvider(
            playable: true,
            statusMSG: "OK",
            audioFormats: audio
                .map(
                  (e) => Audio(
                    itag: e.tag,
                    audioCodec:
                        e.audioCodec.contains('mp') ? Codec.mp4a : Codec.opus,
                    bitrate: e.bitrate.bitsPerSecond,
                    duration: e.duration ?? 0,
                    loudnessDb: e.loudnessDb,
                    url: e.url.toString(),
                    size: e.size.totalBytes,
                  ),
                )
                .toList(),
          );
        }

        throw StateError("youtube_explode_dart returned no audio streams");
      } catch (_) {
        // YouTube frequently rate-limits the primary extractor. Do not make
        // the user retry manually. NewPipe takes over transparently.
        try {
          final result = await _newPipeChannel.invokeMapMethod<String, dynamic>(
            'resolveStreamUrl',
            {'videoId': videoId},
          );

          if (result != null && result['playable'] == true) {
            final rawFormats = (result['audioFormats'] as List?) ?? const [];

            final formats = rawFormats
                .whereType<Map>()
                .map(
                  (json) => Audio.fromJson(
                    Map<String, dynamic>.from(json),
                  ),
                )
                .toList();

            if (formats.isNotEmpty) {
              return StreamProvider(
                playable: true,
                audioFormats: formats,
                statusMSG: "OK",
              );
            }
          }

          return StreamProvider(
            playable: false,
            statusMSG: "Unable to extract audio",
          );
        } catch (fallbackError) {
          return StreamProvider(
            playable: false,
            statusMSG: _friendlyFallbackError(fallbackError),
          );
        }
      }
    } finally {
      yt.close();
    }
  }

  static String _friendlyFallbackError(Object error) {
    final message = error.toString();
    if (message.contains("429") ||
        message.toLowerCase().contains("rate limit") ||
        message.toLowerCase().contains("challenge")) {
      return "YouTube is temporarily rate-limited";
    }
    return "Unable to fetch audio";
  }

  Audio? get highestQualityAudio =>
      audioFormats?.lastWhere(
        (item) => item.itag == 251 || item.itag == 140,
        orElse: () => audioFormats!.first,
      );

  Audio? get highestBitrateMp4aAudio =>
      audioFormats?.lastWhere(
        (item) => item.itag == 140 || item.itag == 139,
        orElse: () => audioFormats!.first,
      );

  Audio? get highestBitrateOpusAudio =>
      audioFormats?.lastWhere(
        (item) => item.itag == 251 || item.itag == 250,
        orElse: () => audioFormats!.first,
      );

  Audio? get lowQualityAudio =>
      audioFormats?.lastWhere(
        (item) => item.itag == 249 || item.itag == 139,
        orElse: () => audioFormats!.first,
      );

  Map<String, dynamic> get hmStreamingData {
    return {
      "playable": playable,
      "statusMSG": statusMSG,
      "lowQualityAudio": lowQualityAudio?.toJson(),
      "highQualityAudio": highestQualityAudio?.toJson(),
    };
  }
}

class Audio {
  final int itag;
  final Codec audioCodec;
  final int bitrate;
  final int duration;
  final int size;
  final double loudnessDb;
  final String url;

  Audio({
    required this.itag,
    required this.audioCodec,
    required this.bitrate,
    required this.duration,
    required this.loudnessDb,
    required this.url,
    required this.size,
  });

  Map<String, dynamic> toJson() => {
        "itag": itag,
        "audioCodec": audioCodec.toString(),
        "bitrate": bitrate,
        "loudnessDb": loudnessDb,
        "url": url,
        "approxDurationMs": duration,
        "size": size,
      };

  factory Audio.fromJson(dynamic json) => Audio(
        audioCodec: (json["audioCodec"] as String).contains("mp4a")
            ? Codec.mp4a
            : Codec.opus,
        itag: json['itag'],
        duration: json["approxDurationMs"] ?? json["duration"] ?? 0,
        bitrate: json["bitrate"] ?? 0,
        loudnessDb: (json['loudnessDb'])?.toDouble() ?? 0.0,
        url: json['url'],
        size: json["size"] ?? 0,
      );
}

enum Codec { mp4a, opus }
