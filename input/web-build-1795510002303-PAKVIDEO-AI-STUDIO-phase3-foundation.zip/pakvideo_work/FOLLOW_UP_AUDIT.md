# PAKVIDEO AI STUDIO — Follow-up source audit

Date: 2026-11-23

## Additional defects found and corrected

1. **Stale free-tier attestation after credential changes**
   - Replacing the Gemini API key now clears the previous free-tier confirmation.
   - Changing the HTTPS proxy URL now clears the previous free-tier confirmation.
   - The invalidation is applied in both `SettingsViewModel` and `SettingsStore`, so it is not limited to one UI path.
   - The Settings explanation now says that changing the key or proxy requires confirmation again.

2. **Billing-safety claims were too strong**
   - The app can block paid-only/unsupported model IDs and paid fallbacks, but it cannot inspect Google Cloud billing or guarantee zero charges for a project with billing enabled.
   - Settings and documentation now state that the user's confirmation is an attestation, not a billing check. Strict zero-charge use requires billing disabled, or Gemini left unconfigured for local-only drafts.
   - The README and shared contract no longer claim that every paid endpoint is technically blocked.

3. **Incorrect network documentation**
   - Phase 1+2 can make an optional Gemini text-generation network call. The manifest comment and contract now say so; they no longer imply that Phase 1+2 is entirely offline.

4. **Gemini provider status display**
   - The provider row now reflects the actual guard result: enabled only when the configured Gemini key/proxy and free-tier attestation pass the app-side checks. Its status text explicitly says billing itself is not verified.

## Checks run after these edits

- Parsed all 8 XML files successfully.
- Checked all 61 `R.string.*` references: no missing English or Urdu resources.
- Static source assertions passed for key-change invalidation, proxy-change invalidation, dynamic Gemini provider status, manifest network wording, and the billing-verification disclaimer.
- Attempted `./gradlew test`; it could not start because the environment could not resolve `services.gradle.org` (`UnknownHostException`). The Gradle 8.7 distribution is not cached here.

## Verification limits

- No full Android Gradle build or official Gradle test suite was completed for this follow-up revision.
- The earlier 114 targeted-test report applies to the previous source snapshot, not automatically to these latest edits.
- No new APK was built. The APK files from the earlier Muse build are not rebuilt artifacts for this source tree.
- No installation or runtime test on a physical Android device has been performed.

## Billing limitation

The app cannot technically inspect a Google Cloud project's billing state or enforce a zero-charge guarantee against a billing-enabled project. The allowlist prevents selecting unsupported or paid-only model IDs; it does not change Google's pricing tier for an allowed model. Keep billing disabled, or leave Gemini unconfigured and use local drafts if zero API charges are mandatory.
