# Firebase setup (optional — for later phases)

Firebase is **NOT required for Phase 1+2**. The app works fully
offline/local. These instructions prepare the Firebase AI Logic route
that later phases use for Gemini integration. Do them only when you are
ready for that phase.

## 1. Create a Firebase project

1. Go to https://console.firebase.google.com/ and sign in with the Google
   account that owns the app.
2. Click **Add project** (or **Create a project**).
3. Name it e.g. `pakvideo-ai-studio`. Google Analytics is optional.
4. Click **Create project** and wait for it to finish.

## 2. Register the Android app

1. In the Firebase console, click the Android icon (**Add app → Android**).
2. **Android package name:** `com.pakvideo.aistudio` (exactly this — it
   must match the app's `applicationId`).
3. **App nickname:** `PAKVIDEO AI STUDIO` (optional).
4. **Debug signing certificate SHA-1:** optional for now; add it later
   when you enable Google sign-in (Android Studio → Gradle → signing
   report shows it).
5. Click **Register app**.

## 3. Add the config file

1. Download `google-services.json` from the Firebase console.
2. Copy it into the `app/` folder of this project
   (`pakvideo-ai-studio/app/google-services.json`).
3. **Do NOT commit this file.** It is already in `.gitignore`. It
   contains your project's client configuration, not a secret key, but
   keep it local to this machine.

## 4. Enable Firebase AI Logic (Gemini)

1. In the Firebase console, go to **Build → Firebase AI Logic**
   (formerly Vertex AI in Firebase).
2. Click **Get started** and follow the setup.
3. The Firebase AI Logic SDK lets the app call Gemini models through
   Firebase instead of a raw API key. The later-phase integration will
   use it; Phase 1+2 uses the direct Gemini REST client with your own
   free key instead (see `docs/API_CONFIGURATION.md`).

## 5. (Optional) Authentication and Firestore

Later phases may add Firebase Authentication and Cloud Firestore for
syncing projects. When that phase starts:

- Enable the sign-in methods you want under **Build → Authentication
  → Sign-in method** (e.g. Google).
- Create a Firestore database under **Build → Firestore Database** and
  set security rules so each user can only read/write their own
  documents. Never ship open rules (`allow read, write: if true`).

## Checklist

- [ ] Firebase project created
- [ ] Android app registered with package `com.pakvideo.aistudio`
- [ ] `google-services.json` placed in `app/` (not committed)
- [ ] Firebase AI Logic enabled (when the later phase needs it)
