# API configuration (free Gemini key)

The app's only external AI call in Phase 1+2 is Gemini **text**
generation (Story Agent). It uses your own free Gemini API key. Without
a key, the app uses clearly-labelled local drafts and nothing is sent
to any server.

## 1. Get a free API key

1. Go to https://aistudio.google.com/app/apikey and sign in with your
   Google account.
2. Click **Create API key**.
3. If asked, create or select a Google Cloud project. **Do not enable
   billing.** The free tier is enough for text generation in this app.
   Important: the app can restrict which model IDs it calls, but it
   cannot inspect your Google Cloud billing state or force Google to
   apply free-tier pricing. If billing is enabled on the project, the
   same model request may be billed at the paid-tier rate. Keep billing
   disabled if you require zero API charges.
4. Copy the key (it starts with `AIza`).

## 2. Enter the key in the app

1. Open PAKVIDEO AI STUDIO → **Settings**.
2. Paste the key into the **API key** field and tap **Save API key**.
3. Turn on **Free-tier confirmation** and read what it says: you are
   confirming the key belongs to a project with billing DISABLED.
4. The health line changes to "Gemini ready — direct mode, free-tier
   confirmed" only after BOTH the key and the confirmation
   are set. A key alone is not enough — the app refuses to treat a key
   as proof of free quota (see section 5).

The key is stored only in EncryptedSharedPreferences on your device
(`pakvideo_secure_prefs`). It is never written to source code, never
logged, never placed in a URL, and never leaves the device except in
the `x-goog-api-key` header of your own Gemini requests (or not at all,
if you use the proxy in section 6).

## 3. Model

- **Default model:** `gemini-3.8-flash` — the newest stable Flash,
  explicitly named by Google for new projects, free tier "Free of
  charge" (verified 2026-11-23). The old default `gemini-2.0-flash`
  was RETIRED on 2026-06-01; requests to it fail.
- **Model allowlist:** the app only ever calls
  `gemini-3.8-flash`, `gemini-3.6-flash` and `gemini-3.5-flash-lite`
  (see `GeminiModels` in the source), which currently list free-tier
  availability. Any other model name typed in Settings is refused and
  the app falls back to a local draft. This prevents accidentally
  selecting a paid-only or unsupported model; it does NOT guarantee
  that a request to an allowed model is free if the Google Cloud project
  has billing enabled. Google applies pricing according to the project
  tier. Keep billing disabled for a zero-charge setup.
- Change the model in **Settings → Gemini model**. Use only model
  names published in Google's own documentation — the app never invents
  model identifiers. Google retires models often: if a request fails
  with a model error, check the pricing page
  (https://ai.google.dev/gemini-api/docs/pricing) and pick a current
  free-tier model.
- If a request fails (wrong model name, quota exhausted, no network),
  the Story Agent falls back to a local draft. Nothing is faked.

## 4. Free-tier limits (what to expect)

- Google's free tier has per-minute and per-day request limits. If you
  hit one, generation fails, the app falls back to a local draft, and
  the attempt is recorded in the guard log. Wait a few minutes and try
  again. **Never enable billing to work around a limit** — the app's
  free-only policy forbids it.
- Keep the key private. If it leaks, delete it at
  https://aistudio.google.com/app/apikey and create a new one, then
  replace it in Settings (or tap **Clear API key** first).

## 5. What the app CANNOT verify (read this)

A key alone does not prove free usage. The key only proves you pasted
a key — it says nothing about whether the Google Cloud project behind
it has billing enabled, and **this app cannot check that**: Google's
public API exposes no endpoint that reports a project's billing status.
API responses and quota errors are not a reliable billing-state check.

That is why the app requires the **Free-tier confirmation** toggle in
Settings: it is YOUR attestation that the project has billing disabled
and only the free tier is in use. It is a confirmation, not a check.
This app cannot technically enforce a zero-billing guarantee against a
misconfigured or billing-enabled Google Cloud project.
The app will not call Gemini until you confirm. If you are not sure
your project is billing-free, check it in the Google Cloud Console
(Billing page) before confirming — or leave the toggle off and use
local drafts.

The recommended control for production use is the server-side proxy
(section 6): the key lives on your server, the server enforces
free-tier-only calls, and the device never holds a key at all.

## 6. Server-side proxy (recommended for production)

If you run your own small server, you can keep the key off the device
entirely:

1. On your server, accept `POST /v1beta/models/<model>:generateContent`
   with the same JSON body the Gemini API expects, add your key as the
   `x-goog-api-key` header, forward the request to
   `https://generativelanguage.googleapis.com`, and return Google's
   response unchanged. **Your proxy MUST hold its own server-side key
   and enforce free-tier-only use** — for example: allow only the
   free-tier models (`gemini-3.8-flash`, `gemini-3.6-flash`,
   `gemini-3.5-flash-lite`), reject requests that would exceed the free
   quota, and never forward a request to a paid model. The app cannot
   verify what your proxy does; the free-tier confirmation in the app
   is your attestation that the proxy is set up this way.
2. In the app, open **Settings → Gemini proxy (optional)** and paste
   your server's base URL (for example `https://my-server.example.com`).
3. The app now sends Gemini requests to your proxy and sends **no API
   key from the device** — not even when a key is saved in the app.
   You do not need a key saved in the app at all in this mode — but
   the free-tier confirmation is still required, because the guard
   still has to know the calls are free-tier only. The health line
   reads "Gemini ready — proxy mode, free-tier confirmed (no key on
   this device)".

The proxy URL is stored in plain preferences (it is not a secret).
Leave the field empty to use the direct Google endpoint with the
device key in the header.

## 7. Revoke / remove the key

- In the app: **Settings → Clear API key**. The app immediately returns
  to local drafts. Clearing the key also clears the free-tier
  confirmation — a replacement key may belong to a different project
  and must be confirmed again.
- At Google: delete the key at
  https://aistudio.google.com/app/apikey.


## Proxy URL validation

The Android app accepts only an HTTPS proxy base URL with a valid host. URLs
containing credentials, query strings, or fragments are rejected. A configured
but invalid proxy is blocked by the free-budget guard; it is never silently
interpreted as direct Google mode. The proxy must still enforce free-only use
server-side — the app cannot verify the proxy's billing configuration.
