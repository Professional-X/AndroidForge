# PAKVIDEO AI STUDIO

An AI-agent-powered video production system for Android — hybrid autonomous
mode, strictly free (no paid APIs, no paid subscriptions, ever), Urdu +
English interface.

You describe a video idea. The Master Orchestrator plans the production,
the Story Agent writes the script, the Director Agent builds the
storyboard, the Character Agent keeps faces and clothes consistent, and
the plan waits for your approval before any generation step.

## Phase 1 + 2 — what is built

- **Android project** (Kotlin 2.0.21, Jetpack Compose, Material 3, Room,
  Navigation Compose). Package `com.pakvideo.aistudio`, minSdk 26,
  targetSdk 34.
- **Home, Agent Chat, Production Workspace, My Creations, Settings**
  screens (dark cinematic theme, gold accent).
- **12-state production workflow** with enforced legal transitions:
  IDLE → PLANNING → SCRIPTING → STORYBOARDING → AWAITING_APPROVAL →
  IMAGE_GENERATION → VIDEO_GENERATION → VOICE_GENERATION → EDITING →
  QUALITY_CHECK → COMPLETED, plus FAILED (recoverable).
- **Master Orchestrator** — drives the pipeline, retries recoverable
  failures (max 3), pauses for plan approval, honestly fails when a
  generation provider is unavailable. Never fakes media.
- **Story / Director / Character Consistency agents** — real planning,
  scene and character logic (Urdu + English).
- **FreeBudgetGuard** — every external generation passes through it.
  All paid or unsupported remote providers are disabled. Gemini is only attempted after the user confirms a billing-free project; this is an attestation, not an independent quota verification;
  Veo and Muse providers stay disabled (no supported official free API).
  A Gemini key alone is NOT proof of free quota: the guard also requires
  the user's explicit free-tier confirmation in Settings (the key must
  belong to a billing-free project). The app cannot verify a project's
  billing status — that limitation is documented in
  `docs/API_CONFIGURATION.md`.
- **Room persistence** — projects, scenes, characters, event history and
  error logs survive interruption; a failed project resumes. Database v3
  (migration 1→2 adds `scenes.visualPrompt`,
  `characters.isMainCharacter`, `characters.mentionCount`; migration 2→3
  adds `projects.genre`; existing rows are preserved — see `MigrationTest`).
- **Real Gemini text integration** — `GeminiApiClient` calls the official
  `generativelanguage.googleapis.com` endpoint with the user's own free
  API key (stored only in EncryptedSharedPreferences, never in source,
  never logged, never in a URL — it travels as the `x-goog-api-key`
  header). An optional server-side proxy keeps the key off the device
  entirely (recommended for production). No key, or no free-tier
  confirmation → clearly-labelled local drafts, and the orchestrator
  records in the event log and the approval whether the story came from
  real Gemini or a local fallback.
- **Story / Director / Character Consistency agents** — real planning,
  scene and character logic (Urdu + English). The Director derives
  camera, lighting, location, atmosphere and a one-sentence visual
  prompt from each scene's own text — no fixed template cycling. The
  Character agent identifies real main characters (dialogue + mention
  counts) and fills details only from words actually in the story,
  labelled as story evidence; anything unknown stays explicitly
  "Not specified in the story".
- **Unit tests** — state machine, guard, all agents, orchestrator,
  Robolectric Room persistence and migration tests, and a regression
  test for every pre-Phase 3 fix.

## Project structure

```
pakvideo-ai-studio/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── gradle/wrapper/                      # Gradle 8.7 wrapper
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/pakvideo/aistudio/
│       │   ├── MainActivity.kt
│       │   ├── data/local/              # Room: entities, DAOs, database
│       │   ├── data/preferences/        # SettingsStore (encrypted key)
│       │   ├── data/remote/             # GeminiApiClient
│       │   ├── data/repository/         # ProjectRepository + impl
│       │   ├── di/                      # AppContainer
│       │   ├── domain/agents/           # Orchestrator, Story, Director, Character
│       │   ├── domain/guard/            # FreeBudgetGuard, ProviderRegistry
│       │   ├── domain/model/            # ProjectState, plans, approvals
│       │   ├── domain/statemachine/     # ProductionStateMachine
│       │   └── ui/                      # theme, navigation, viewmodels, screens
│       └── res/values/ + res/values-ur/ # English + Urdu strings
│   └── src/test/java/com/pakvideo/aistudio/   # unit tests
├── docs/
│   ├── FIREBASE_SETUP.md
│   └── API_CONFIGURATION.md
├── CONTRACT.md                          # layer contract (source of truth)
└── README.md
```

## Open in Android Studio

Requirements: Android Studio Hedgehog or newer, JDK 17, Android SDK
platform 34 + build-tools 34.0.0.

1. Open Android Studio → **Open** → select this folder.
2. Let Gradle sync (first sync downloads dependencies).
3. Run on an emulator or device (minSdk 26, Android 8.0+).

## Build an APK

- **Debug APK:** Android Studio → **Build → Build App Bundle(s) / APK(s)
  → Build APK(s)**, or `./gradlew assembleDebug`. Output:
  `app/build/outputs/apk/debug/app-debug.apk`.
- **Release APK:** `./gradlew assembleRelease` (add your signing config
  in `app/build.gradle.kts` first; minification is off by default).
- **Unit tests:** `./gradlew testDebugUnitTest` (reports under
  `app/build/reports/tests/`), or right-click a test class → Run.

## API configuration (free Gemini key)

See [docs/API_CONFIGURATION.md](docs/API_CONFIGURATION.md). Short version:
get a free key at Google AI Studio, paste it in **Settings → API key**
inside the app, then turn on **Free-tier confirmation** (you confirm the
key belongs to a project with billing DISABLED — the app cannot verify
billing status, so a key alone never enables Gemini). The key lives only
in EncryptedSharedPreferences and travels as the `x-goog-api-key` header,
never in a URL; a server-side proxy (Settings → Gemini proxy) keeps the
key off the device entirely, and in proxy mode no local key is needed at
all (confirmation only). Without an eligible key/proxy or without the
confirmation, the app uses clearly-labelled local drafts. The default model is
`gemini-3.8-flash` (changeable in Settings, but only free-tier models
from the app's allowlist are ever called — never a paid-only model). This model allowlist does not itself guarantee zero charges: Google pricing also depends on the Cloud project's billing tier. Keep billing disabled, or leave Gemini unconfigured for strict local-only use.

## Firebase (optional, later phases)

See [docs/FIREBASE_SETUP.md](docs/FIREBASE_SETUP.md). Firebase is NOT
required for Phase 1+2. The app supports local/offline drafts; optional Gemini text generation uses a network connection when configured and confirmed. Firebase AI
Logic is the planned route for later-phase Gemini integration; the
instructions show how to add `google-services.json` when that phase
starts. The file is git-ignored and is never committed.

## Verification status (honest) — independent third review corrections

The current source tree includes the third-review corrections listed below.
The previous Muse build log and 115-test report belong to the earlier ZIP,
not this edited source tree, and must not be treated as proof for this version.

- **Pure Kotlin compile check:** the changed domain pipeline classes
  (`Models`, `CharacterConsistencyAgent`, `DirectorAgent`, `ProviderRegistry`,
  `FreeBudgetGuard`, `ProxyUrlValidator`, `ProductionStateMachine`,
  `StoryAgent`, and `MasterOrchestrator`) compiled successfully with Kotlin
  1.9.0 and the locally available coroutines library, using minimal test
  doubles for Android/Room data classes and repository interfaces.
- **Executable pure checks:** passed checks for 20 narration beats plus
  dialogue producing 11 scenes, preservation of every beat, Urdu name
  extraction without repeated-role false positives, HTTPS proxy validation,
  and the `user-confirmed-unverified` quota audit label.
- **Full Android Gradle build/tests:** NOT RUN. This environment has no
  installed Android SDK or cached Gradle 8.7 distribution, and the wrapper
  could not download Gradle because network DNS access is unavailable.
  Therefore no new APK is claimed or supplied from this review.
- **Real-device test:** NOT RUN. Install and test the newly built APK on
  the Infinix device after building on a machine with Android Studio/SDK.

Corrections in this source revision:

1. Saved script now contains title, hook, full narration and every dialogue
   speaker/line.
2. Director storyboard includes all narration sentences and all dialogue
   lines; the previous 8-scene truncation is removed. Since the data model
   stores narration and dialogue separately, narration beats are placed
   before dialogue beats; original interleaving is not available to restore.
3. Resume rebuild clears the project's prior generated scenes and character
   rows before writing the replacement, preventing sequential retries from
   accumulating duplicates.
4. Gemini quota audit records `user-confirmed-unverified`, never a false
   verified `free` status. Local-only providers are labelled `local-only`.
5. Proxy URLs must be valid HTTPS URLs without credentials, query strings
   or fragments; invalid configured proxies are blocked rather than silently
   falling back to direct-key mode.
6. Urdu narration name detection no longer treats any repeated role noun as
   a character. It accepts explicit Urdu name markers and dialogue speaker
   labels; mixed Urdu/English stories run both detectors.
7. Workspace character sheets are editable and users can add a missing
   character manually (important for Urdu narration where names cannot be
   inferred safely from capitalization). Saving edits updates the project
   JSON snapshot and matching scene prompt identity text.

This is a source-level correction pass, not a verified release build. Do not
start Phase 3 until a full Android build, full unit test run, and phone test
have passed on a machine with the Android SDK.

## Free-only policy

Paid-only model IDs and paid fallbacks are blocked, and the app never
changes or enables Google Cloud billing. Gemini calls are gated by a
user confirmation that the configured Cloud project has billing disabled.
That confirmation is not a technical billing check: if billing is enabled,
Google may charge for the same allowed model. Strict zero-charge use
requires billing to remain disabled or Gemini to stay unconfigured. The
guard records each attempt (provider, model, result, quota status); Gemini
audit entries say `user-confirmed-unverified`, not verified-free. Local
drafts work offline; unsupported image/video providers remain blocked.

## What is intentionally NOT here (Phase 1+2)

- No Video Generator or Editor screens (Phase 4/5). No buttons pretend
  to generate video or images.
- No image/video/voice generation. Approving a plan ends the production
  honestly with "Image generation arrives in Phase 3."
- No Firebase code in the app. The only external AI network call is the optional Gemini text client
  (only when the user configured a key or HTTPS proxy and confirmed the
  free-tier setup).

## Next: Phase 3

Real image generation using verified supported free services, wired
through the same FreeBudgetGuard and provider registry.


## Phase 3 implementation status (foundation)

Phase 3 now has a provider-neutral image generation contract, persisted per-scene
image tasks (Room v3 -> v4 migration), a prompt builder that injects only the
approved character sheets referenced by a scene, and a Workspace Images tab.
All provider adapters are intentionally disabled until a real supported API is
implemented and configured. Therefore the current app can prepare and track an
image task, but it cannot yet generate images. No fake output is shown.

The next Phase 3 work is a real provider adapter, secure credential handling,
image download/validation into app-private storage, retry controls, and a visual
gallery. This foundation has not yet been validated by a full Android Gradle
build or on-device test.
