package com.pakvideo.aistudio.domain.image

import com.pakvideo.aistudio.data.local.CharacterEntity
import com.pakvideo.aistudio.data.local.SceneEntity
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SceneImagePromptBuilderTest {
    @Test fun includesSceneDirectionAndReferencedApprovedCharacterSheet() {
        val scene = SceneEntity(
            id = 7, projectId = "p", orderIndex = 0, title = "Market", description = "A traveler finds a purse",
            location = "Old market", lighting = "Warm sunset", atmosphere = "Hopeful", characterRefs = "Ali",
            visualPrompt = "Wide cinematic shot"
        )
        val ali = CharacterEntity(
            id = 1, projectId = "p", name = "Ali", age = 30,
            appearance = "average build", clothing = "brown kurta", facialFeatures = "short beard"
        )
        val prompt = SceneImagePromptBuilder.build(scene, listOf(ali))
        assertTrue(prompt.contains("A traveler finds a purse"))
        assertTrue(prompt.contains("Ali"))
        assertTrue(prompt.contains("brown kurta"))
        assertTrue(prompt.contains("short beard"))
    }

    @Test fun doesNotLeakUnreferencedCharacterSheets() {
        val scene = SceneEntity(id = 1, projectId = "p", orderIndex = 0, title = "Road", description = "Empty road", characterRefs = "Ali")
        val other = CharacterEntity(id = 2, projectId = "p", name = "Bilal", clothing = "red coat")
        val prompt = SceneImagePromptBuilder.build(scene, listOf(other))
        assertFalse(prompt.contains("Bilal"))
        assertFalse(prompt.contains("red coat"))
    }

    @Test fun disabledProviderNeverPretendsToGenerate() = kotlinx.coroutines.runBlocking {
        val provider = DisabledImageProvider(ImageProviderId.GEMINI_IMAGEN, "not configured")
        assertFalse(provider.isAvailable())
        val result = provider.generate(ImageGenerationRequest("p", 1, "prompt"))
        assertTrue(result is ImageGenerationResult.Unavailable)
    }
}
