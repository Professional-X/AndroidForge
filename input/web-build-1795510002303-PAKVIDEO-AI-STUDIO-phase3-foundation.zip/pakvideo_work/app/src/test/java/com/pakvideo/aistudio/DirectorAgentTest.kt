package com.pakvideo.aistudio

import com.pakvideo.aistudio.domain.agents.CharacterConsistencyAgent
import com.pakvideo.aistudio.domain.agents.DirectorAgent
import com.pakvideo.aistudio.domain.model.CharacterSheet
import com.pakvideo.aistudio.domain.model.DialogueLine
import com.pakvideo.aistudio.domain.model.StoryDraft
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DirectorAgentTest {

    private val agent = DirectorAgent()

    private fun draft(
        narration: String,
        dialogue: List<DialogueLine> = emptyList()
    ) = StoryDraft(
        title = "Test story",
        hook = "Hook",
        narration = narration,
        dialogue = dialogue,
        language = "en",
        isLocalDraft = true
    )

    @Test
    fun sixSentencesBecomeThreeScenes() {
        val story = draft(
            "First sentence. Second sentence. Third sentence. " +
                "Fourth sentence. Fifth sentence. Sixth sentence."
        )
        val scenes = agent.planScenes(story, emptyList())
        assertEquals(3, scenes.size)
        assertEquals(0, scenes[0].orderIndex)
        assertEquals("Scene 1", scenes[0].title)
        assertEquals("Scene 3", scenes[2].title)
    }

    @Test
    fun oneSentenceBecomesOneScene() {
        val scenes = agent.planScenes(draft("Only one sentence."), emptyList())
        assertEquals(1, scenes.size)
    }

    @Test
    fun scenesAreNotTruncatedAtEight() {
        val narration = (1..20).joinToString(" ") { "Sentence number $it." }
        val scenes = agent.planScenes(draft(narration), emptyList())
        assertEquals(10, scenes.size)
        assertTrue(scenes.last().description.contains("Sentence number 20"))
    }

    @Test
    fun emptyNarrationFallsBackToTitle() {
        val scenes = agent.planScenes(draft(""), emptyList())
        assertEquals(1, scenes.size)
        assertEquals("Test story", scenes[0].description)
    }

    @Test
    fun characterNamesAreMatchedToSceneText() {
        val ahmed = CharacterSheet("Ahmed", 30, "Tall", "White kurta", "Sharp nose")
        val sara = CharacterSheet("Sara", 25, "Short", "Blue dress", "Round face")
        val story = draft("Ahmed walked into the garden. Sara was waiting there.")
        val scenes = agent.planScenes(story, listOf(ahmed, sara))
        assertEquals(1, scenes.size)
        assertTrue(scenes[0].characterNames.contains("Ahmed"))
        assertTrue(scenes[0].characterNames.contains("Sara"))
    }

    // ---- Regression tests for Fix 3: story-derived direction, no fixed
    // template cycling. The old test asserted Wide/Medium/Close-up
    // cycling; that behaviour is exactly what was removed.

    @Test
    fun firstSceneIsWideEstablishingShot() {
        val scenes = agent.planScenes(
            draft("The village woke up. The sun rose over the fields."),
            emptyList()
        )
        assertEquals("Wide establishing shot", scenes[0].cameraAngle)
        assertEquals("Slow pan left", scenes[0].cameraMovement)
    }

    @Test
    fun speakingSceneGetsCloseUpOnSpeaker() {
        val ahmed = CharacterSheet("Ahmed", 30, "Tall", "White kurta", "Sharp nose")
        val story = draft(
            "The village woke up. The sun rose over the fields. " +
                "Ahmed said he would stay and help everyone. The people listened quietly.",
            dialogue = listOf(DialogueLine("Ahmed", "I will stay and help."))
        )
        val scenes = agent.planScenes(story, listOf(ahmed))
        // Scene 1 establishes the world; scene 2 is where Ahmed speaks.
        assertEquals("Wide establishing shot", scenes[0].cameraAngle)
        assertEquals("Close-up on the speaker", scenes[1].cameraAngle)
        assertEquals("Static", scenes[1].cameraMovement)
    }

    @Test
    fun actionSceneGetsDynamicWideTrackingShot() {
        val scenes = agent.planScenes(
            draft(
                "The village woke up. The sun rose over the fields. " +
                    "The thief ran through the market and leapt over the carts. " +
                    "The guards chased him down the street."
            ),
            emptyList()
        )
        assertEquals("Dynamic wide action shot", scenes[1].cameraAngle)
        assertEquals("Tracking", scenes[1].cameraMovement)
    }

    @Test
    fun nightSceneGetsMoonlitLighting() {
        val scenes = agent.planScenes(
            draft("Ahmed entered the palace at midnight. The moon lit the courtyard."),
            emptyList()
        )
        assertEquals("Moonlit night", scenes[0].lighting)
    }

    @Test
    fun locationComesFromSceneText() {
        val scenes = agent.planScenes(
            draft("Ahmed walked into the forest. The trees were tall and dark."),
            emptyList()
        )
        assertEquals("Forest", scenes[0].location)
    }

    @Test
    fun unnamedLocationIsMarkedNotSpecified() {
        val scenes = agent.planScenes(
            draft("Ahmed thought about the plan. It was a simple plan."),
            emptyList()
        )
        assertEquals("Location not specified in the story", scenes[0].location)
    }

    @Test
    fun sorrowfulSceneGetsSorrowfulAtmosphere() {
        val scenes = agent.planScenes(
            draft("Ahmed wept over the loss. Tears fell as the village mourned."),
            emptyList()
        )
        assertEquals("Sorrowful", scenes[0].atmosphere)
    }

    @Test
    fun visualPromptCombinesSceneDirection() {
        val ahmed = CharacterSheet("Ahmed", 30, "Tall", "White kurta", "Sharp nose")
        val scenes = agent.planScenes(
            draft("Ahmed entered the palace at midnight. The moon lit the courtyard."),
            listOf(ahmed)
        )
        val prompt = scenes[0].visualPrompt
        assertTrue(prompt.isNotEmpty())
        assertTrue(prompt.contains("Ahmed"))
        assertTrue(prompt.contains("Royal palace"))
        assertTrue(prompt.contains("Moonlit night"))
    }

    @Test
    fun identicalScenesDoNotJustCycleTemplates() {
        // Two plain non-opening scenes with no cues get the same neutral
        // direction, not alternating template values. (The opening scene
        // is legitimately different: it establishes the world.)
        val narration = (1..6).joinToString(" ") { "Plain sentence $it." }
        val scenes = agent.planScenes(draft(narration), emptyList())
        assertEquals(3, scenes.size)
        assertEquals(scenes[1].cameraAngle, scenes[2].cameraAngle)
        assertEquals(scenes[1].lighting, scenes[2].lighting)
        assertEquals(scenes[1].atmosphere, scenes[2].atmosphere)
    }


    @Test
    fun allNarrationSentencesAndDialogueAreIncludedWithoutEightSceneCap() {
        val narration = (1..20).joinToString(" ") { "Ahmed walked to place $it." }
        val story = draft(narration).copy(
            dialogue = listOf(
                com.pakvideo.aistudio.domain.model.DialogueLine("Ahmed", "Where are we?"),
                com.pakvideo.aistudio.domain.model.DialogueLine("Sara", "At the river.")
            )
        )
        val scenes = agent.planScenes(story, emptyList())
        assertTrue("20 narration beats + 2 dialogue beats must exceed 8 scenes", scenes.size > 8)
        val allDescriptions = scenes.joinToString(" ") { it.description }
        for (index in 1..20) assertTrue(allDescriptions.contains("place $index"))
        assertTrue(allDescriptions.contains("Ahmed: Where are we?"))
        assertTrue(allDescriptions.contains("Sara: At the river."))
        assertTrue(scenes.any { "Ahmed" in it.characterNames })
        assertTrue(scenes.any { "Sara" in it.characterNames })
    }

    // ---- Regression tests for the second review, Fix 4 + Fix 5: the
    // visual prompt carries the APPROVED character sheet (same text in
    // every scene), and the storyboard is labelled rule-based.

    @Test
    fun visualPromptCarriesApprovedCharacterSheet() {
        val ahmed = CharacterSheet(
            "Ahmed", 35,
            "From the story: \"white beard\"",
            "From the story: \"white robe\"",
            "From the story: \"sharp nose\""
        )
        val scenes = agent.planScenes(
            draft("Ahmed entered the palace at midnight. Ahmed bowed low."),
            listOf(ahmed)
        )
        val prompt = scenes[0].visualPrompt
        assertTrue(prompt.contains("Ahmed"))
        assertTrue(prompt.contains("35 years old"))
        assertTrue(prompt.contains("white beard"))
        assertTrue(prompt.contains("white robe"))
        assertTrue(prompt.contains("sharp nose"))
        // All six parts: identity, action, location, lighting, mood, camera.
        assertTrue(prompt.contains("Royal palace"))
        assertTrue(prompt.contains("Moonlit night"))
        assertTrue(prompt.contains("Calm mood"))
        assertTrue(prompt.contains("wide establishing shot"))
    }

    @Test
    fun sameCharacterDescriptionIsReusedInEveryScene() {
        val ahmed = CharacterSheet(
            "Ahmed", 35,
            "From the story: \"white beard\"",
            "From the story: \"white robe\"",
            "Not specified in the story — add details in Workspace"
        )
        val scenes = agent.planScenes(
            draft(
                "Ahmed entered the palace. Ahmed bowed low. " +
                    "Ahmed walked to the garden. Ahmed sat under a tree."
            ),
            listOf(ahmed)
        )
        assertEquals(2, scenes.size)
        val description = "Ahmed, 35 years old (From the story: \"white beard\"; " +
            "From the story: \"white robe\"; " +
            "Not specified in the story — add details in Workspace)"
        assertTrue(scenes[0].visualPrompt.contains(description))
        assertTrue(scenes[1].visualPrompt.contains(description))
    }

    @Test
    fun unknownCharacterDetailsStayMarkedInVisualPrompt() {
        val sara = CharacterSheet(
            "Sara", 0,
            CharacterConsistencyAgent.NOT_SPECIFIED,
            CharacterConsistencyAgent.NOT_SPECIFIED,
            CharacterConsistencyAgent.NOT_SPECIFIED
        )
        val scenes = agent.planScenes(
            draft("Sara waited by the well. Sara looked at the sky."),
            listOf(sara)
        )
        assertTrue(scenes[0].visualPrompt.contains("Sara"))
        assertTrue(
            scenes[0].visualPrompt.contains("Not specified in the story")
        )
        assertFalse(scenes[0].visualPrompt.contains("years old"))
    }

    @Test
    fun directionLabelSaysRuleBasedNotAiGenerated() {
        assertTrue(DirectorAgent.DIRECTION_LABEL.contains("Rule-based"))
        assertTrue(DirectorAgent.DIRECTION_LABEL.contains("not AI-generated"))
        assertFalse(DirectorAgent.DIRECTION_LABEL.contains("AI director"))
    }

    @Test
    fun mentionsNameIsWholeWordAndCaseInsensitive() {
        assertTrue(agent.mentionsName("Ahmed walked home.", "ahmed"))
        assertTrue(agent.mentionsName("AHMED walked home.", "Ahmed"))
        // "Al" must not match "also" or "wall".
        assertFalse(agent.mentionsName("He also walked to the wall.", "Al"))
        assertTrue(agent.mentionsName("Al walked home.", "Al"))
    }
}
