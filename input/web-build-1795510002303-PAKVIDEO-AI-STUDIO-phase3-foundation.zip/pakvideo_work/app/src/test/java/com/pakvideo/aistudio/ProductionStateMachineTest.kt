package com.pakvideo.aistudio

import com.pakvideo.aistudio.domain.model.ProjectState
import com.pakvideo.aistudio.domain.statemachine.ProductionStateMachine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProductionStateMachineTest {

    private val machine = ProductionStateMachine()

    @Test
    fun idleToPlanningIsLegal() {
        assertEquals(ProjectState.PLANNING, machine.transition(ProjectState.IDLE, ProjectState.PLANNING))
    }

    @Test
    fun completedIsTerminal() {
        for (target in ProjectState.values()) {
            assertFalse(machine.canTransition(ProjectState.COMPLETED, target))
        }
    }

    @Test
    fun failedCanOnlyGoToIdleOrPlanning() {
        assertTrue(machine.canTransition(ProjectState.FAILED, ProjectState.IDLE))
        assertTrue(machine.canTransition(ProjectState.FAILED, ProjectState.PLANNING))
        assertFalse(machine.canTransition(ProjectState.FAILED, ProjectState.SCRIPTING))
        assertFalse(machine.canTransition(ProjectState.FAILED, ProjectState.COMPLETED))
    }

    @Test(expected = IllegalStateException::class)
    fun illegalTransitionThrows() {
        machine.transition(ProjectState.IDLE, ProjectState.COMPLETED)
    }

    @Test
    fun illegalTransitionMessageNamesBothStates() {
        try {
            machine.transition(ProjectState.SCRIPTING, ProjectState.VIDEO_GENERATION)
            throw AssertionError("Expected IllegalStateException")
        } catch (e: IllegalStateException) {
            assertEquals("Illegal transition: SCRIPTING -> VIDEO_GENERATION", e.message)
        }
    }

    @Test
    fun fullPhaseOnePathIsLegal() {
        var state = ProjectState.IDLE
        state = machine.transition(state, ProjectState.PLANNING)
        state = machine.transition(state, ProjectState.SCRIPTING)
        state = machine.transition(state, ProjectState.STORYBOARDING)
        state = machine.transition(state, ProjectState.AWAITING_APPROVAL)
        assertEquals(ProjectState.AWAITING_APPROVAL, state)
    }

    @Test
    fun approvalCanReturnToPlanningOrScripting() {
        assertTrue(machine.canTransition(ProjectState.AWAITING_APPROVAL, ProjectState.PLANNING))
        assertTrue(machine.canTransition(ProjectState.AWAITING_APPROVAL, ProjectState.SCRIPTING))
    }

    @Test
    fun anyNonTerminalStateCanFailOrCancel() {
        val states = listOf(
            ProjectState.PLANNING,
            ProjectState.SCRIPTING,
            ProjectState.STORYBOARDING,
            ProjectState.IMAGE_GENERATION,
            ProjectState.VIDEO_GENERATION,
            ProjectState.VOICE_GENERATION,
            ProjectState.EDITING,
            ProjectState.QUALITY_CHECK
        )
        for (state in states) {
            assertTrue("$state -> FAILED", machine.canTransition(state, ProjectState.FAILED))
            assertTrue("$state -> IDLE", machine.canTransition(state, ProjectState.IDLE))
        }
    }
}
