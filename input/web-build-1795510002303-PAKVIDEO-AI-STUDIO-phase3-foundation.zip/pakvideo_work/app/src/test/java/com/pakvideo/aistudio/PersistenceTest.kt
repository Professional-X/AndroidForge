package com.pakvideo.aistudio

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.pakvideo.aistudio.data.local.AppDatabase
import com.pakvideo.aistudio.data.local.ProjectEntity
import com.pakvideo.aistudio.data.repository.ProjectRepositoryImpl
import com.pakvideo.aistudio.domain.agents.CharacterConsistencyAgent
import com.pakvideo.aistudio.domain.agents.DirectorAgent
import com.pakvideo.aistudio.domain.agents.MasterOrchestrator
import com.pakvideo.aistudio.domain.agents.StoryAgent
import com.pakvideo.aistudio.domain.guard.FreeBudgetGuard
import com.pakvideo.aistudio.domain.model.ProjectState
import com.pakvideo.aistudio.domain.statemachine.ProductionStateMachine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Real Room persistence test on the JVM (Robolectric): insert a project,
 * reload it by id, update its state, and resume it through the real
 * orchestrator. Room DAO unit tests on plain JUnit are NOT possible (they
 * need an Android runtime); Robolectric provides it.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PersistenceTest {

    private lateinit var db: AppDatabase

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun insertReloadUpdateAndResume() = runTest {
        val repository = ProjectRepositoryImpl(
            db.projectDao(),
            db.sceneDao(),
            db.characterDao(),
            db.taskEventDao()
        )
        val guard = FreeBudgetGuard({ null })
        val orchestrator = MasterOrchestrator(
            repository,
            ProductionStateMachine(),
            StoryAgent(guard),
            DirectorAgent(),
            CharacterConsistencyAgent(),
            guard
        )

        val now = System.currentTimeMillis()
        repository.createProject(
            ProjectEntity(
                id = "p1",
                name = "Persistence test",
                userPrompt = "A kind farmer plants a magic seed.",
                createdAt = now,
                updatedAt = now
            )
        )

        val loaded = repository.getProject("p1")
        assertNotNull(loaded)
        assertEquals("Persistence test", loaded?.name)

        repository.updateProjectState("p1", ProjectState.FAILED, "simulated failure")
        assertEquals("FAILED", repository.getProject("p1")?.status)
        assertTrue(repository.getProject("p1")?.errorLog?.contains("simulated failure") == true)

        orchestrator.resume("p1")

        val resumed = repository.getProject("p1")
        assertEquals("AWAITING_APPROVAL", resumed?.status)
        assertTrue(resumed?.script?.isNotEmpty() == true)
        val scenes = repository.getScenes("p1").first()
        assertTrue(scenes.isNotEmpty())
        val events = repository.getEvents("p1").first()
        assertTrue(events.isNotEmpty())
    }
}
