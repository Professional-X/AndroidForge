package com.pakvideo.aistudio

import android.content.Context
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.pakvideo.aistudio.data.local.AppDatabase
import com.pakvideo.aistudio.data.local.CharacterEntity
import com.pakvideo.aistudio.data.local.MIGRATION_1_2
import com.pakvideo.aistudio.data.local.MIGRATION_2_3
import com.pakvideo.aistudio.data.local.MIGRATION_3_4
import com.pakvideo.aistudio.data.local.ProjectEntity
import com.pakvideo.aistudio.data.local.SceneEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Regression test for Fix 6: the v1 -> v2 Room migration must preserve
 * every existing row. A database is built with the exact v1 schema and
 * seeded, then opened with Room at v3 (which runs [MIGRATION_1_2] and
 * [MIGRATION_2_3]). Room itself validates the migrated schema against
 * the v3 entities, so a pass proves both the data and the schema
 * survived. The v2 -> v3 migration adds the project genre column with
 * the default 'ISLAMIC'.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MigrationTest {

    private lateinit var context: Context
    private val dbName = "migration-test.db"

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        context.deleteDatabase(dbName)
    }

    @After
    fun tearDown() {
        context.deleteDatabase(dbName)
    }

    /** Creates the exact v1 schema (as Room generated it in Phase 1-2). */
    private class V1Callback : SupportSQLiteOpenHelper.Callback(1) {
        override fun onCreate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `projects` (`id` TEXT NOT NULL, " +
                    "`name` TEXT NOT NULL, `userPrompt` TEXT NOT NULL, " +
                    "`script` TEXT NOT NULL DEFAULT '', " +
                    "`characterDescriptions` TEXT NOT NULL DEFAULT '', " +
                    "`status` TEXT NOT NULL DEFAULT 'IDLE', " +
                    "`errorLog` TEXT NOT NULL DEFAULT '', " +
                    "`createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, " +
                    "PRIMARY KEY(`id`))"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `scenes` (`id` INTEGER PRIMARY KEY " +
                    "AUTOINCREMENT NOT NULL, `projectId` TEXT NOT NULL, " +
                    "`orderIndex` INTEGER NOT NULL, `title` TEXT NOT NULL, " +
                    "`description` TEXT NOT NULL, " +
                    "`cameraAngle` TEXT NOT NULL DEFAULT '', " +
                    "`cameraMovement` TEXT NOT NULL DEFAULT '', " +
                    "`lighting` TEXT NOT NULL DEFAULT '', " +
                    "`location` TEXT NOT NULL DEFAULT '', " +
                    "`atmosphere` TEXT NOT NULL DEFAULT '', " +
                    "`characterRefs` TEXT NOT NULL DEFAULT '', " +
                    "`status` TEXT NOT NULL DEFAULT 'IDLE', " +
                    "FOREIGN KEY(`projectId`) REFERENCES `projects`(`id`) " +
                    "ON UPDATE NO ACTION ON DELETE CASCADE)"
            )
            db.execSQL(
                "CREATE INDEX IF NOT EXISTS `index_scenes_projectId` " +
                    "ON `scenes` (`projectId`)"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `characters` (`id` INTEGER PRIMARY KEY " +
                    "AUTOINCREMENT NOT NULL, `projectId` TEXT NOT NULL, " +
                    "`name` TEXT NOT NULL, `age` INTEGER NOT NULL DEFAULT 0, " +
                    "`appearance` TEXT NOT NULL DEFAULT '', " +
                    "`clothing` TEXT NOT NULL DEFAULT '', " +
                    "`facialFeatures` TEXT NOT NULL DEFAULT '', " +
                    "`referenceImagePath` TEXT, " +
                    "FOREIGN KEY(`projectId`) REFERENCES `projects`(`id`) " +
                    "ON UPDATE NO ACTION ON DELETE CASCADE)"
            )
            db.execSQL(
                "CREATE INDEX IF NOT EXISTS `index_characters_projectId` " +
                    "ON `characters` (`projectId`)"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `task_events` (`id` INTEGER PRIMARY KEY " +
                    "AUTOINCREMENT NOT NULL, `projectId` TEXT NOT NULL, " +
                    "`timestamp` INTEGER NOT NULL, `state` TEXT NOT NULL, " +
                    "`message` TEXT NOT NULL, `type` TEXT NOT NULL, " +
                    "FOREIGN KEY(`projectId`) REFERENCES `projects`(`id`) " +
                    "ON UPDATE NO ACTION ON DELETE CASCADE)"
            )
            db.execSQL(
                "CREATE INDEX IF NOT EXISTS `index_task_events_projectId` " +
                    "ON `task_events` (`projectId`)"
            )
        }

        override fun onUpgrade(
            db: SupportSQLiteDatabase,
            oldVersion: Int,
            newVersion: Int
        ) {
            // Not used: the v1 helper never upgrades; Room runs the migration.
        }
    }

    private fun createV1DatabaseWithSeed() {
        val helper = FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context)
                .name(dbName)
                .callback(V1Callback())
                .build()
        )
        val db = helper.writableDatabase
        db.execSQL(
            "INSERT INTO projects (id, name, userPrompt, script, " +
                "characterDescriptions, status, errorLog, createdAt, updatedAt) " +
                "VALUES ('p1', 'Old project', 'A kind farmer.', 'Some script.', " +
                "'[\"Ahmed\"]', 'AWAITING_APPROVAL', '', 1000, 2000)"
        )
        db.execSQL(
            "INSERT INTO scenes (projectId, orderIndex, title, description, " +
                "cameraAngle, cameraMovement, lighting, location, atmosphere, " +
                "characterRefs, status) VALUES ('p1', 0, 'Scene 1', " +
                "'The farmer planted a seed.', 'Wide shot', 'Static', " +
                "'Bright daylight', 'Village', 'Calm', 'Ahmed', 'IDLE')"
        )
        db.execSQL(
            "INSERT INTO characters (projectId, name, age, appearance, " +
                "clothing, facialFeatures, referenceImagePath) VALUES " +
                "('p1', 'Ahmed', 35, 'Tall', 'White kurta', 'Sharp nose', NULL)"
        )
        db.execSQL(
            "INSERT INTO task_events (projectId, timestamp, state, message, type) " +
                "VALUES ('p1', 1500, 'AWAITING_APPROVAL', 'Plan ready', 'APPROVAL')"
        )
        db.close()
        helper.close()
    }

    /** Creates the exact v2 schema (v1 + the three v2 columns). */
    private class V2Callback : SupportSQLiteOpenHelper.Callback(2) {
        override fun onCreate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `projects` (`id` TEXT NOT NULL, " +
                    "`name` TEXT NOT NULL, `userPrompt` TEXT NOT NULL, " +
                    "`script` TEXT NOT NULL DEFAULT '', " +
                    "`characterDescriptions` TEXT NOT NULL DEFAULT '', " +
                    "`status` TEXT NOT NULL DEFAULT 'IDLE', " +
                    "`errorLog` TEXT NOT NULL DEFAULT '', " +
                    "`createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, " +
                    "PRIMARY KEY(`id`))"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `scenes` (`id` INTEGER PRIMARY KEY " +
                    "AUTOINCREMENT NOT NULL, `projectId` TEXT NOT NULL, " +
                    "`orderIndex` INTEGER NOT NULL, `title` TEXT NOT NULL, " +
                    "`description` TEXT NOT NULL, " +
                    "`cameraAngle` TEXT NOT NULL DEFAULT '', " +
                    "`cameraMovement` TEXT NOT NULL DEFAULT '', " +
                    "`lighting` TEXT NOT NULL DEFAULT '', " +
                    "`location` TEXT NOT NULL DEFAULT '', " +
                    "`atmosphere` TEXT NOT NULL DEFAULT '', " +
                    "`characterRefs` TEXT NOT NULL DEFAULT '', " +
                    "`visualPrompt` TEXT NOT NULL DEFAULT '', " +
                    "`status` TEXT NOT NULL DEFAULT 'IDLE', " +
                    "FOREIGN KEY(`projectId`) REFERENCES `projects`(`id`) " +
                    "ON UPDATE NO ACTION ON DELETE CASCADE)"
            )
            db.execSQL(
                "CREATE INDEX IF NOT EXISTS `index_scenes_projectId` " +
                    "ON `scenes` (`projectId`)"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `characters` (`id` INTEGER PRIMARY KEY " +
                    "AUTOINCREMENT NOT NULL, `projectId` TEXT NOT NULL, " +
                    "`name` TEXT NOT NULL, `age` INTEGER NOT NULL DEFAULT 0, " +
                    "`appearance` TEXT NOT NULL DEFAULT '', " +
                    "`clothing` TEXT NOT NULL DEFAULT '', " +
                    "`facialFeatures` TEXT NOT NULL DEFAULT '', " +
                    "`isMainCharacter` INTEGER NOT NULL DEFAULT 0, " +
                    "`mentionCount` INTEGER NOT NULL DEFAULT 0, " +
                    "`referenceImagePath` TEXT, " +
                    "FOREIGN KEY(`projectId`) REFERENCES `projects`(`id`) " +
                    "ON UPDATE NO ACTION ON DELETE CASCADE)"
            )
            db.execSQL(
                "CREATE INDEX IF NOT EXISTS `index_characters_projectId` " +
                    "ON `characters` (`projectId`)"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `task_events` (`id` INTEGER PRIMARY KEY " +
                    "AUTOINCREMENT NOT NULL, `projectId` TEXT NOT NULL, " +
                    "`timestamp` INTEGER NOT NULL, `state` TEXT NOT NULL, " +
                    "`message` TEXT NOT NULL, `type` TEXT NOT NULL, " +
                    "FOREIGN KEY(`projectId`) REFERENCES `projects`(`id`) " +
                    "ON UPDATE NO ACTION ON DELETE CASCADE)"
            )
            db.execSQL(
                "CREATE INDEX IF NOT EXISTS `index_task_events_projectId` " +
                    "ON `task_events` (`projectId`)"
            )
        }

        override fun onUpgrade(
            db: SupportSQLiteDatabase,
            oldVersion: Int,
            newVersion: Int
        ) {
            // Not used: the v2 helper never upgrades; Room runs the migration.
        }
    }

    private fun createV2DatabaseWithSeed() {
        val helper = FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context)
                .name(dbName)
                .callback(V2Callback())
                .build()
        )
        val db = helper.writableDatabase
        db.execSQL(
            "INSERT INTO projects (id, name, userPrompt, script, " +
                "characterDescriptions, status, errorLog, createdAt, updatedAt) " +
                "VALUES ('p1', 'Old project', 'A kind farmer.', 'Some script.', " +
                "'[\"Ahmed\"]', 'AWAITING_APPROVAL', '', 1000, 2000)"
        )
        db.execSQL(
            "INSERT INTO scenes (projectId, orderIndex, title, description, " +
                "cameraAngle, cameraMovement, lighting, location, atmosphere, " +
                "characterRefs, visualPrompt, status) VALUES ('p1', 0, 'Scene 1', " +
                "'The farmer planted a seed.', 'Wide shot', 'Static', " +
                "'Bright daylight', 'Village', 'Calm', 'Ahmed', " +
                "'Photorealistic cinematic wide shot of Ahmed.', 'IDLE')"
        )
        db.execSQL(
            "INSERT INTO characters (projectId, name, age, appearance, " +
                "clothing, facialFeatures, isMainCharacter, mentionCount, " +
                "referenceImagePath) VALUES " +
                "('p1', 'Ahmed', 35, 'Tall', 'White kurta', 'Sharp nose', 1, 7, NULL)"
        )
        db.execSQL(
            "INSERT INTO task_events (projectId, timestamp, state, message, type) " +
                "VALUES ('p1', 1500, 'AWAITING_APPROVAL', 'Plan ready', 'APPROVAL')"
        )
        db.close()
        helper.close()
    }

    @Test
    fun v1ToV2PreservesAllRows() = runTest {
        createV1DatabaseWithSeed()

        val roomDb = Room.databaseBuilder(context, AppDatabase::class.java, dbName)
            .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
            .allowMainThreadQueries()
            .build()
        try {
            val project = roomDb.projectDao().getById("p1")
            assertNotNull(project)
            assertEquals("Old project", project?.name)
            assertEquals("A kind farmer.", project?.userPrompt)
            assertEquals("Some script.", project?.script)
            assertEquals("AWAITING_APPROVAL", project?.status)
            // v2 -> v3 adds the genre column; pre-v3 rows read as ISLAMIC.
            assertEquals("ISLAMIC", project?.genre)

            val scenes = roomDb.sceneDao().getByProject("p1").first()
            assertEquals(1, scenes.size)
            assertEquals("Scene 1", scenes[0].title)
            assertEquals("The farmer planted a seed.", scenes[0].description)
            assertEquals("Wide shot", scenes[0].cameraAngle)
            assertEquals("Village", scenes[0].location)
            // New column exists with its default on migrated rows.
            assertEquals("", scenes[0].visualPrompt)

            val characters = roomDb.characterDao().getByProject("p1").first()
            assertEquals(1, characters.size)
            assertEquals("Ahmed", characters[0].name)
            assertEquals(35, characters[0].age)
            assertEquals("White kurta", characters[0].clothing)
            assertFalse(characters[0].isMainCharacter)
            assertEquals(0, characters[0].mentionCount)

            val events = roomDb.taskEventDao().getByProject("p1").first()
            assertEquals(1, events.size)
            assertEquals("Plan ready", events[0].message)
        } finally {
            roomDb.close()
        }
    }

    @Test
    fun v2ToV3PreservesAllRowsAndDefaultsGenre() = runTest {
        createV2DatabaseWithSeed()

        val roomDb = Room.databaseBuilder(context, AppDatabase::class.java, dbName)
            .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
            .allowMainThreadQueries()
            .build()
        try {
            val project = roomDb.projectDao().getById("p1")
            assertNotNull(project)
            assertEquals("Old project", project?.name)
            assertEquals("ISLAMIC", project?.genre)

            val scenes = roomDb.sceneDao().getByProject("p1").first()
            assertEquals(1, scenes.size)
            assertEquals(
                "Photorealistic cinematic wide shot of Ahmed.",
                scenes[0].visualPrompt
            )

            val characters = roomDb.characterDao().getByProject("p1").first()
            assertEquals(1, characters.size)
            assertTrue(characters[0].isMainCharacter)
            assertEquals(7, characters[0].mentionCount)

            // A new project can store a non-default genre.
            val now = System.currentTimeMillis()
            roomDb.projectDao().insert(
                ProjectEntity(
                    id = "p2",
                    name = "Horror project",
                    userPrompt = "A haunted haveli.",
                    genre = "HORROR",
                    createdAt = now,
                    updatedAt = now
                )
            )
            assertEquals("HORROR", roomDb.projectDao().getById("p2")?.genre)
        } finally {
            roomDb.close()
        }
    }

    @Test
    fun newColumnsRoundTripAfterMigration() = runTest {
        createV1DatabaseWithSeed()

        val roomDb = Room.databaseBuilder(context, AppDatabase::class.java, dbName)
            .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
            .allowMainThreadQueries()
            .build()
        try {
            val now = System.currentTimeMillis()
            roomDb.projectDao().insert(
                ProjectEntity(
                    id = "p2",
                    name = "New project",
                    userPrompt = "A brave sailor.",
                    createdAt = now,
                    updatedAt = now
                )
            )
            roomDb.sceneDao().insert(
                SceneEntity(
                    projectId = "p2",
                    orderIndex = 0,
                    title = "Scene 1",
                    description = "The sailor left the harbour.",
                    visualPrompt = "Photorealistic cinematic wide shot of the sailor."
                )
            )
            roomDb.characterDao().insert(
                CharacterEntity(
                    projectId = "p2",
                    name = "Sailor",
                    age = 28,
                    appearance = "From the story: \"tall\"",
                    clothing = "Not specified in the story — add details in Workspace",
                    facialFeatures = "Not specified in the story — add details in Workspace",
                    isMainCharacter = true,
                    mentionCount = 7
                )
            )
            val scenes = roomDb.sceneDao().getByProject("p2").first()
            assertEquals(
                "Photorealistic cinematic wide shot of the sailor.",
                scenes[0].visualPrompt
            )
            val characters = roomDb.characterDao().getByProject("p2").first()
            assertTrue(characters[0].isMainCharacter)
            assertEquals(7, characters[0].mentionCount)
        } finally {
            roomDb.close()
        }
    }
}
