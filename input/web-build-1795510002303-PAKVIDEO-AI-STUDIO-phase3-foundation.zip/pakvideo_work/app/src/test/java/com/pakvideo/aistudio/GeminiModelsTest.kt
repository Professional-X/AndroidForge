package com.pakvideo.aistudio

import com.pakvideo.aistudio.data.remote.GeminiModels
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Regression tests for the second review, Fix 1: the Gemini model list.
 * `gemini-2.0-flash` was retired 2026-06-01; the default is now the
 * newest stable Flash with a documented free tier, verified 2026-11-23
 * against Google's pricing page and deprecations page.
 */
class GeminiModelsTest {

    @Test
    fun defaultModelIsCurrentFreeTierFlash() {
        assertEquals("gemini-3.8-flash", GeminiModels.DEFAULT_MODEL)
        assertTrue(GeminiModels.isFreeTierModel(GeminiModels.DEFAULT_MODEL))
    }

    @Test
    fun allowlistHasExactlyTheThreeNewProjectSafeModels() {
        assertEquals(
            setOf("gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite"),
            GeminiModels.FREE_TIER_MODELS
        )
    }

    @Test
    fun retiredTwoPointZeroFlashIsNotFreeTier() {
        assertFalse(GeminiModels.isFreeTierModel("gemini-2.0-flash"))
        assertFalse(GeminiModels.isFreeTierModel("gemini-2.0-flash-001"))
        assertFalse(GeminiModels.isFreeTierModel("gemini-2.0-flash-lite"))
    }

    @Test
    fun restrictedTwoPointFiveModelsAreNotFreeTier() {
        // Google limits the 2.5 models to users who actively used them
        // in the past; new projects get a 404, so they are not usable.
        assertFalse(GeminiModels.isFreeTierModel("gemini-2.5-flash"))
        assertFalse(GeminiModels.isFreeTierModel("gemini-2.5-flash-lite"))
        assertFalse(GeminiModels.isFreeTierModel("gemini-2.5-pro"))
    }

    @Test
    fun paidModelsAreNotFreeTier() {
        assertFalse(GeminiModels.isFreeTierModel("gemini-4-argon"))
        assertFalse(GeminiModels.isFreeTierModel("gemini-3.1-pro"))
        assertFalse(GeminiModels.isFreeTierModel("gemini-1.5-pro"))
    }

    @Test
    fun unknownAndBlankModelsAreNotFreeTier() {
        assertFalse(GeminiModels.isFreeTierModel("gemini-9.9-flash"))
        assertFalse(GeminiModels.isFreeTierModel(""))
        assertFalse(GeminiModels.isFreeTierModel("   "))
    }

    @Test
    fun surroundingWhitespaceIsIgnored() {
        assertTrue(GeminiModels.isFreeTierModel("  gemini-3.8-flash  "))
    }
}
