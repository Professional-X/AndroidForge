package com.pakvideo.aistudio

import com.pakvideo.aistudio.domain.guard.FreeBudgetGuard
import com.pakvideo.aistudio.domain.guard.GuardDecision
import com.pakvideo.aistudio.domain.guard.ProviderId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FreeBudgetGuardTest {

    private fun confirmedGuard(key: String? = "test-key-123") =
        FreeBudgetGuard({ key }, { true })

    @Test
    fun geminiTextBlockedWithoutKey() {
        val guard = FreeBudgetGuard({ null }, { true })
        val decision = guard.check(ProviderId.GEMINI_TEXT)
        assertTrue(decision is GuardDecision.Blocked)
        assertFalse(guard.hasFreeQuota(ProviderId.GEMINI_TEXT))
    }

    @Test
    fun geminiTextBlockedWithBlankKey() {
        val guard = FreeBudgetGuard({ "   " }, { true })
        assertTrue(guard.check(ProviderId.GEMINI_TEXT) is GuardDecision.Blocked)
    }

    @Test
    fun geminiTextAllowedWithKeyAndConfirmation() {
        val guard = confirmedGuard()
        val decision = guard.check(ProviderId.GEMINI_TEXT)
        assertTrue(decision is GuardDecision.Allowed)
        assertTrue(guard.hasFreeQuota(ProviderId.GEMINI_TEXT))
    }

    @Test
    fun geminiTextBlockedWithKeyButNoConfirmation() {
        // Regression (Fix 1): a key alone is NOT proof of free quota.
        val guard = FreeBudgetGuard({ "test-key-123" }, { false })
        val decision = guard.check(ProviderId.GEMINI_TEXT)
        assertTrue(decision is GuardDecision.Blocked)
        assertFalse(guard.hasFreeQuota(ProviderId.GEMINI_TEXT))
        val reason = (decision as GuardDecision.Blocked).reason
        assertTrue(reason.contains("not confirmed"))
    }

    @Test
    fun geminiTextBlockedWithKeyAndNoConfirmationProvider() {
        // No confirmation provider at all == not confirmed.
        val guard = FreeBudgetGuard({ "test-key-123" })
        assertTrue(guard.check(ProviderId.GEMINI_TEXT) is GuardDecision.Blocked)
        assertFalse(guard.hasFreeQuota(ProviderId.GEMINI_TEXT))
    }

    @Test
    fun confirmationWithoutKeyStillBlocked() {
        val guard = FreeBudgetGuard({ null }, { true })
        assertTrue(guard.check(ProviderId.GEMINI_TEXT) is GuardDecision.Blocked)
    }

    // ---- Regression tests for the second review, Fix 2: proxy mode
    // needs NO local key, only the free-tier confirmation. A saved
    // device key is never required — and never sent — in proxy mode.

    @Test
    fun proxyModeAllowedWithoutLocalKeyWhenConfirmed() {
        val guard = FreeBudgetGuard({ null }, { true }, { "https://proxy.example.com" })
        assertTrue(guard.isProxyMode())
        val decision = guard.check(ProviderId.GEMINI_TEXT)
        assertTrue(decision is GuardDecision.Allowed)
        assertTrue(guard.hasFreeQuota(ProviderId.GEMINI_TEXT))
    }

    @Test
    fun proxyModeBlockedWithoutConfirmation() {
        val guard = FreeBudgetGuard({ null }, { false }, { "https://proxy.example.com" })
        val decision = guard.check(ProviderId.GEMINI_TEXT)
        assertTrue(decision is GuardDecision.Blocked)
        assertFalse(guard.hasFreeQuota(ProviderId.GEMINI_TEXT))
        val reason = (decision as GuardDecision.Blocked).reason
        assertTrue(reason.contains("proxy"))
        assertTrue(reason.contains("not confirmed"))
    }

    @Test
    fun proxyModeAllowedWithSavedKeyToo() {
        // A key saved on the device does not break proxy mode; the
        // guard simply does not need it.
        val guard = FreeBudgetGuard(
            { "device-key-123" }, { true }, { "https://proxy.example.com" }
        )
        assertTrue(guard.check(ProviderId.GEMINI_TEXT) is GuardDecision.Allowed)
    }

    @Test
    fun blankProxyUrlMeansDirectMode() {
        val guard = FreeBudgetGuard({ null }, { true }, { "   " })
        assertFalse(guard.isProxyMode())
        assertTrue(guard.check(ProviderId.GEMINI_TEXT) is GuardDecision.Blocked)
    }

    @Test
    fun proxyModeUnconfirmedRecordsUnverifiedQuotaStatus() {
        val guard = FreeBudgetGuard({ null }, { false }, { "https://proxy.example.com" })
        guard.check(ProviderId.GEMINI_TEXT)
        assertEquals("user-confirmed-unverified", guard.attempts[0].quotaStatus)
        assertEquals("Blocked", guard.attempts[0].result)
    }

    @Test
    fun unconfirmedKeyRecordsUnverifiedQuotaStatus() {
        val guard = FreeBudgetGuard({ "test-key-123" }, { false })
        guard.check(ProviderId.GEMINI_TEXT)
        assertEquals("user-confirmed-unverified", guard.attempts[0].quotaStatus)
        assertEquals("Blocked", guard.attempts[0].result)
    }


    @Test
    fun invalidHttpProxyIsBlockedEvenWhenConfirmed() {
        val guard = FreeBudgetGuard({ null }, { true }, { "http://proxy.example.com" })
        val decision = guard.check(ProviderId.GEMINI_TEXT)
        assertTrue(decision is GuardDecision.Blocked)
        assertEquals(
            FreeBudgetGuard.INVALID_PROXY_URL_MESSAGE,
            (decision as GuardDecision.Blocked).reason
        )
        assertFalse(guard.hasFreeQuota(ProviderId.GEMINI_TEXT))
    }

    @Test
    fun veoVideoAlwaysBlockedWithQuotaMessage() {
        val guard = confirmedGuard()
        val decision = guard.check(ProviderId.VEO_VIDEO)
        assertTrue(decision is GuardDecision.Blocked)
        assertEquals(
            FreeBudgetGuard.NO_FREE_QUOTA_MESSAGE,
            (decision as GuardDecision.Blocked).reason
        )
        assertFalse(guard.hasFreeQuota(ProviderId.VEO_VIDEO))
    }

    @Test
    fun museProvidersAlwaysBlocked() {
        val guard = confirmedGuard()
        assertTrue(guard.check(ProviderId.MUSE_IMAGE) is GuardDecision.Blocked)
        assertTrue(guard.check(ProviderId.MUSE_VIDEO) is GuardDecision.Blocked)
        assertFalse(guard.hasFreeQuota(ProviderId.MUSE_IMAGE))
        assertFalse(guard.hasFreeQuota(ProviderId.MUSE_VIDEO))
    }

    @Test
    fun imageGenerationBlockedUntilPhaseThree() {
        val guard = confirmedGuard()
        val decision = guard.check(ProviderId.IMAGE_GENERATION) as GuardDecision.Blocked
        assertEquals("Image generation arrives in Phase 3.", decision.reason)
    }

    @Test
    fun localOnlyUrduTtsIsAllowed() {
        val guard = FreeBudgetGuard()
        assertTrue(guard.check(ProviderId.URDU_TTS) is GuardDecision.Allowed)
        assertTrue(guard.hasFreeQuota(ProviderId.URDU_TTS))
    }

    @Test
    fun everyCheckRecordsAnAttempt() {
        val guard = confirmedGuard("key")
        assertEquals(0, guard.attempts.size)
        guard.check(ProviderId.GEMINI_TEXT)
        guard.check(ProviderId.VEO_VIDEO)
        assertEquals(2, guard.attempts.size)
        assertEquals(ProviderId.GEMINI_TEXT, guard.attempts[0].provider)
        assertEquals("Allowed", guard.attempts[0].result)
        assertEquals("user-confirmed-unverified", guard.attempts[0].quotaStatus)
        assertEquals(ProviderId.VEO_VIDEO, guard.attempts[1].provider)
        assertEquals("Blocked", guard.attempts[1].result)
        assertEquals("none", guard.attempts[1].quotaStatus)
    }
}
