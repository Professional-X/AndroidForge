package com.pakvideo.aistudio

import com.pakvideo.aistudio.data.local.ProjectEntity
import com.pakvideo.aistudio.data.remote.GeminiApiClient
import com.pakvideo.aistudio.data.remote.GeminiModels
import com.pakvideo.aistudio.domain.agents.CharacterConsistencyAgent
import com.pakvideo.aistudio.domain.agents.DirectorAgent
import com.pakvideo.aistudio.domain.agents.MasterOrchestrator
import com.pakvideo.aistudio.domain.agents.StoryAgent
import com.pakvideo.aistudio.domain.guard.FreeBudgetGuard
import com.pakvideo.aistudio.domain.model.ProjectState
import com.pakvideo.aistudio.domain.statemachine.ProductionStateMachine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class MasterOrchestratorTest {

    private lateinit var repository: FakeProjectRepository
    private lateinit var orchestrator: MasterOrchestrator

    @Before
    fun setUp() {
        repository = FakeProjectRepository()
        val guard = FreeBudgetGuard({ null })
        orchestrator = MasterOrchestrator(
            repository,
            ProductionStateMachine(),
            StoryAgent(guard),
            DirectorAgent(),
            CharacterConsistencyAgent(),
            guard
        )
    }

    private suspend fun createProject(
        id: String = "p1",
        prompt: String = "A kind farmer plants a magic seed.",
        genre: String = "ISLAMIC"
    ): String {
        val now = System.currentTimeMillis()
        repository.createProject(
            ProjectEntity(
                id = id,
                name = "Test production",
                userPrompt = prompt,
                genre = genre,
                createdAt = now,
                updatedAt = now
            )
        )
        return id
    }

    @Test
    fun startProductionEndsAtAwaitingApproval() = runTest {
        val id = createProject()
        orchestrator.startProduction(id)
        assertEquals("AWAITING_APPROVAL", repository.getProject(id)?.status)
        assertTrue(repository.getProject(id)?.script?.isNotEmpty() == true)
        assertTrue(repository.getScenes(id).first().isNotEmpty())
        assertNotNull(orchestrator.pendingApproval.value)
        assertEquals(id, orchestrator.pendingApproval.value?.projectId)
    }

    @Test
    fun approveFailsHonestlyWhenImageGenerationUnavailable() = runTest {
        val id = createProject()
        orchestrator.startProduction(id)
        val approvalId = orchestrator.pendingApproval.value?.id ?: error("No pending approval")
        orchestrator.approve(approvalId)
        assertEquals("FAILED", repository.getProject(id)?.status)
        assertTrue(repository.getProject(id)?.errorLog?.contains("Phase 3") == true)
    }

    @Test
    fun rejectReturnsToPlanning() = runTest {
        val id = createProject()
        orchestrator.startProduction(id)
        val approvalId = orchestrator.pendingApproval.value?.id ?: error("No pending approval")
        orchestrator.reject(approvalId)
        assertEquals("PLANNING", repository.getProject(id)?.status)
    }

    @Test
    fun cancelFromPlanningGoesToIdle() = runTest {
        val id = createProject()
        repository.updateProjectState(id, ProjectState.PLANNING)
        orchestrator.cancel(id)
        assertEquals("IDLE", repository.getProject(id)?.status)
    }

    @Test
    fun resumeFromFailedRunsToApprovalAgain() = runTest {
        val id = createProject()
        repository.updateProjectState(id, ProjectState.FAILED, "simulated failure")
        orchestrator.resume(id)
        assertEquals("AWAITING_APPROVAL", repository.getProject(id)?.status)
    }

    @Test(expected = IllegalStateException::class)
    fun startProductionFromCompletedThrows() = runTest {
        val id = createProject()
        repository.updateProjectState(id, ProjectState.COMPLETED)
        orchestrator.startProduction(id)
    }

    // ---- Regression tests for Fix 5: the orchestrator clearly
    // distinguishes a real Gemini story from a local fallback draft,
    // in the event log and in the approval the user sees.

    private class FakeGeminiClient(private val response: String) : GeminiApiClient() {
        override suspend fun generateText(
            apiKey: String,
            model: String,
            prompt: String,
            proxyBaseUrl: String?
        ): Result<String> = Result.success(response)
    }

    private fun geminiOrchestrator(): MasterOrchestrator {
        val guard = FreeBudgetGuard({ "key" }, { true })
        val storyAgent = StoryAgent(
            guard,
            FakeGeminiClient(
                "Title: The Kind Farmer\n" +
                    "Hook: One seed changed a whole village.\n" +
                    "Narration: The farmer planted a single seed. " +
                    "The seed grew into a great tree. " +
                    "The village never went hungry again.\n" +
                    "Dialogue:\n" +
                    "Farmer: This tree is for everyone.\n" +
                    "Child: Thank you, farmer!\n"
            ),
            { "key" },
            { GeminiModels.DEFAULT_MODEL }
        )
        return MasterOrchestrator(
            repository,
            ProductionStateMachine(),
            storyAgent,
            DirectorAgent(),
            CharacterConsistencyAgent(),
            guard
        )
    }

    @Test
    fun geminiStoryIsLabelledRealGeminiInEventsAndApproval() = runTest {
        val id = createProject()
        val gemini = geminiOrchestrator()
        gemini.startProduction(id)
        val events = repository.getEvents(id).first()
        assertTrue(events.any { it.message.contains("real Gemini generation") })
        assertFalse(events.any { it.message.contains("LOCAL fallback") })
        val approval = gemini.pendingApproval.value
        assertNotNull(approval)
        assertTrue(approval!!.description.contains("real Gemini generation"))
        // The persisted scenes carry the story-derived visual prompts.
        val scenes = repository.getScenes(id).first()
        assertTrue(scenes.isNotEmpty())
        assertTrue(scenes.all { it.visualPrompt.isNotEmpty() })
    }

    @Test
    fun localFallbackIsLabelledLocalFallbackInEventsAndApproval() = runTest {
        val id = createProject()
        orchestrator.startProduction(id)
        val events = repository.getEvents(id).first()
        assertTrue(events.any { it.message.contains("LOCAL fallback draft") })
        assertFalse(events.any { it.message.contains("real Gemini generation") })
        val approval = orchestrator.pendingApproval.value
        assertNotNull(approval)
        assertTrue(approval!!.description.contains("LOCAL fallback draft"))
    }


    @Test
    fun savedScriptContainsEveryDialogueSpeakerAndLine() = runTest {
        val id = createProject()
        val gemini = geminiOrchestrator()
        gemini.startProduction(id)
        val script = repository.getProject(id)?.script.orEmpty()
        assertTrue(script.contains("Dialogue"))
        assertTrue(script.contains("Farmer: This tree is for everyone."))
        assertTrue(script.contains("Child: Thank you, farmer!"))
    }

    @Test
    fun resumeReplacesScenesAndCharactersInsteadOfDuplicatingThem() = runTest {
        val id = createProject(
            prompt = "Ahmed entered the palace. Ahmed spoke to Sara. Sara smiled."
        )
        orchestrator.startProduction(id)
        val firstSceneCount = repository.getScenes(id).first().size
        val firstCharacterCount = repository.getCharacters(id).first().size
        assertTrue(firstSceneCount > 0)
        assertTrue(firstCharacterCount > 0)
        repository.updateProjectState(id, ProjectState.FAILED, "simulated interrupted run")
        orchestrator.resume(id)
        assertEquals(firstSceneCount, repository.getScenes(id).first().size)
        assertEquals(firstCharacterCount, repository.getCharacters(id).first().size)
        assertEquals(
            repository.getScenes(id).first().map { it.orderIndex }.distinct().size,
            repository.getScenes(id).first().size
        )
    }

    // ---- Regression tests for the second review, Fix 3 + Fix 4:
    // genre flows through the pipeline, narration-only characters
    // are persisted, and their approved appearance reaches the scene
    // prompts.

    @Test
    fun narrationOnlyCharactersPersistedWithAppearanceInPrompts() = runTest {
        val id = createProject(
            prompt = "Ahmed, with a white beard, walked into the palace. Ahmed bowed low."
        )
        orchestrator.startProduction(id)
        val characters = repository.getCharacters(id).first()
        assertTrue(characters.any { it.name == "Ahmed" })
        val ahmed = characters.first { it.name == "Ahmed" }
        assertTrue(ahmed.appearance.contains("white beard"))
        val scenes = repository.getScenes(id).first()
        assertTrue(scenes.isNotEmpty())
        assertTrue(
            scenes.any { it.visualPrompt.contains("white beard") }
        )
        assertTrue(
            scenes.any { it.visualPrompt.contains("Ahmed") }
        )
    }

    @Test
    fun horrorGenreAndRuleBasedLabelAppearInApproval() = runTest {
        val id = createProject(
            prompt = "A haunted haveli at midnight.",
            genre = "HORROR"
        )
        orchestrator.startProduction(id)
        val approval = orchestrator.pendingApproval.value
        assertNotNull(approval)
        assertTrue(approval!!.description.contains("Horror"))
        assertTrue(approval.description.contains("Rule-based"))
        assertTrue(approval.description.contains("not AI-generated"))
        val events = repository.getEvents(id).first()
        assertTrue(events.any { it.message.contains("Horror") })
    }
}
