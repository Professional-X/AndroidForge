package com.pakvideo.aistudio

import com.pakvideo.aistudio.domain.agents.CharacterConsistencyAgent
import com.pakvideo.aistudio.domain.model.DialogueLine
import com.pakvideo.aistudio.domain.model.StoryDraft
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CharacterConsistencyAgentTest {

    private val agent = CharacterConsistencyAgent()

    private fun draft(
        narration: String = "Some narration.",
        dialogue: List<DialogueLine> = emptyList()
    ) = StoryDraft(
        title = "Test story",
        hook = "Hook",
        narration = narration,
        dialogue = dialogue,
        language = "en",
        isLocalDraft = true
    )

    @Test
    fun deriveCharactersFromDialogueSpeakers() {
        val story = draft(
            dialogue = listOf(
                DialogueLine("Ahmed", "Hello."),
                DialogueLine("Sara", "Hi."),
                DialogueLine("Ahmed", "How are you?"),
                DialogueLine("Narrator", "They talked.")
            )
        )
        val sheets = agent.deriveCharacters(story)
        assertEquals(listOf("Ahmed", "Sara"), sheets.map { it.name })
        assertEquals(0, sheets[0].age)
        assertTrue(sheets[0].appearance.contains("Not specified in the story"))
    }

    @Test
    fun emptyDialogueDerivesNoCharacters() {
        val sheets = agent.deriveCharacters(draft(dialogue = emptyList()))
        assertTrue(sheets.isEmpty())
    }

    @Test
    fun createSheetKeepsAllFields() {
        val sheet = agent.createSheet("Ahmed", 30, "Tall", "White kurta", "Sharp nose")
        assertEquals("Ahmed", sheet.name)
        assertEquals(30, sheet.age)
        assertEquals("Tall", sheet.appearance)
        assertEquals("White kurta", sheet.clothing)
        assertEquals("Sharp nose", sheet.facialFeatures)
    }

    @Test
    fun identicalSheetsHaveNoChanges() {
        val original = agent.createSheet("Ahmed", 30, "Tall", "White kurta", "Sharp nose")
        val updated = agent.createSheet("Ahmed", 30, "Tall", "White kurta", "Sharp nose")
        assertTrue(agent.checkConsistency(original, updated).isEmpty())
    }

    @Test
    fun changedFieldsAreListed() {
        val original = agent.createSheet("Ahmed", 30, "Tall", "White kurta", "Sharp nose")
        val updated = agent.createSheet("Ahmed", 31, "Tall", "Black kurta", "Sharp nose")
        val changes = agent.checkConsistency(original, updated)
        assertTrue(changes.contains("clothing changed"))
        assertTrue(changes.contains("age changed"))
        assertEquals(2, changes.size)
    }

    @Test
    fun reuseSheetForSceneEmbedsIdentity() {
        val sheet = agent.createSheet("Ahmed", 30, "Tall", "White kurta", "Sharp nose")
        val text = agent.reuseSheetForScene(sheet, 2)
        assertTrue(text.contains("Ahmed"))
        assertTrue(text.contains("White kurta"))
        assertTrue(text.contains("Sharp nose"))
        assertTrue(text.contains("2"))
    }

    // ---- Regression tests for Fix 4: real main characters, evidence
    // only, never invented details.

    @Test
    fun frequentSpeakerIsMainCharacter() {
        val story = draft(
            narration = "Ahmed walked into the garden. Ahmed looked around. " +
                "Ahmed smiled at the flowers.",
            dialogue = listOf(
                DialogueLine("Ahmed", "Hello."),
                DialogueLine("Sara", "Hi."),
                DialogueLine("Ahmed", "How are you?")
            )
        )
        val sheets = agent.deriveCharacters(story)
        val ahmed = sheets.first { it.name == "Ahmed" }
        val sara = sheets.first { it.name == "Sara" }
        assertTrue(ahmed.isMainCharacter)
        assertEquals(5, ahmed.mentionCount) // 2 dialogue lines + 3 narration mentions
        assertFalse(sara.isMainCharacter)
        assertEquals(1, sara.mentionCount)
    }

    @Test
    fun evidenceFromStoryIsQuotedAndLabelled() {
        val story = draft(
            narration = "The old man Ahmed, with a white beard, wore a white robe. " +
                "Ahmed entered the palace.",
            dialogue = listOf(DialogueLine("Ahmed", "Peace be upon you."))
        )
        val sheets = agent.deriveCharacters(story)
        val ahmed = sheets.first()
        assertTrue(ahmed.appearance.contains("From the story:"))
        assertTrue(ahmed.appearance.contains("white beard"))
        assertTrue(ahmed.clothing.contains("From the story:"))
        assertTrue(ahmed.clothing.contains("white robe"))
    }

    @Test
    fun noEvidenceMeansNotSpecifiedNeverInvented() {
        val story = draft(
            narration = "Ahmed walked into the garden.",
            dialogue = listOf(DialogueLine("Ahmed", "Hello."))
        )
        val ahmed = agent.deriveCharacters(story).first()
        assertEquals(
            CharacterConsistencyAgent.NOT_SPECIFIED,
            ahmed.appearance
        )
        assertEquals(
            CharacterConsistencyAgent.NOT_SPECIFIED,
            ahmed.clothing
        )
        assertEquals(
            CharacterConsistencyAgent.NOT_SPECIFIED,
            ahmed.facialFeatures
        )
        // Nothing invented: no guessed age, height or garment anywhere.
        assertEquals(0, ahmed.age)
    }

    @Test
    fun otherCharactersDetailsDoNotLeakOntoThisSheet() {
        val story = draft(
            narration = "Sara wore a red dress and a crown. Ahmed stood nearby.",
            dialogue = listOf(
                DialogueLine("Ahmed", "Hello."),
                DialogueLine("Sara", "Hi.")
            )
        )
        val sheets = agent.deriveCharacters(story)
        val ahmed = sheets.first { it.name == "Ahmed" }
        assertFalse(ahmed.clothing.contains("dress"))
        assertFalse(ahmed.clothing.contains("crown"))
        assertTrue(ahmed.clothing.contains("Not specified in the story"))
    }

    @Test
    fun explicitAgeNearNameIsExtracted() {
        val story = draft(
            narration = "Ahmed, a 35-year-old farmer, walked into the field.",
            dialogue = listOf(DialogueLine("Ahmed", "Good morning."))
        )
        val ahmed = agent.deriveCharacters(story).first()
        assertEquals(35, ahmed.age)
    }

    @Test
    fun vagueOldManDoesNotBecomeANumber() {
        val story = draft(
            narration = "The old man Ahmed walked slowly into the village.",
            dialogue = listOf(DialogueLine("Ahmed", "Good morning."))
        )
        val ahmed = agent.deriveCharacters(story).first()
        assertEquals(0, ahmed.age)
        assertTrue(ahmed.appearance.contains("old man"))
    }

    // ---- Regression tests for the second review, Fix 4: characters
    // are identified from the narration too, so a story with no
    // dialogue still has its characters — and the approved sheet is
    // rendered in one fixed format for scene prompts.

    @Test
    fun narrationOnlyCharactersAreIdentifiedWithoutDialogue() {
        val story = draft(
            narration = "Ahmed walked into the garden. Ahmed looked around. " +
                "Sara was waiting by the well. Sara waved at Ahmed.",
            dialogue = emptyList()
        )
        val sheets = agent.deriveCharacters(story)
        assertEquals(listOf("Ahmed", "Sara"), sheets.map { it.name })
    }

    @Test
    fun narrationOnlyRepeatedCharacterIsMain() {
        val story = draft(
            narration = "Ahmed walked into the garden. Ahmed looked around. " +
                "Ahmed smiled at the flowers.",
            dialogue = emptyList()
        )
        val sheets = agent.deriveCharacters(story)
        assertEquals(1, sheets.size)
        assertEquals("Ahmed", sheets[0].name)
        assertTrue(sheets[0].isMainCharacter)
        assertEquals(3, sheets[0].mentionCount)
    }

    @Test
    fun narrationWithNoNamesStillDerivesNoCharacters() {
        val story = draft(
            narration = "The village woke up slowly. The sun rose over the fields.",
            dialogue = emptyList()
        )
        assertTrue(agent.deriveCharacters(story).isEmpty())
    }


    @Test
    fun repeatedUrduRoleNounIsNotMisclassifiedAsPersonalName() {
        val names = agent.extractNarrationNames("بادشاہ نے حکم دیا۔ بادشاہ محل میں گیا۔ بادشاہ واپس آیا۔")
        assertFalse(names.contains("بادشاہ"))
    }

    @Test
    fun explicitUrduNameMarkerCanIdentifyNarrationOnlyCharacter() {
        val names = agent.extractNarrationNames("اس شخص کا نام احمد تھا۔ پھر احمد گھر چلا گیا۔")
        assertTrue(names.contains("احمد"))
    }

    @Test
    fun mixedUrduAndEnglishNarrationStillFindsLatinNames() {
        val names = agent.extractNarrationNames("اس شخص کا نام احمد تھا۔ Ahmed reached the old city. Ahmed met a guide.")
        assertTrue(names.contains("Ahmed"))
        assertTrue(names.contains("احمد"))
    }

    @Test
    fun narrationAppearanceIsPreservedOnTheSheet() {
        val story = draft(
            narration = "Ahmed, with a white beard and a black robe, entered the palace. " +
                "Ahmed bowed deeply.",
            dialogue = emptyList()
        )
        val ahmed = agent.deriveCharacters(story).first()
        assertTrue(ahmed.appearance.contains("white beard"))
        assertTrue(ahmed.clothing.contains("black robe"))
    }

    @Test
    fun describeForPromptRendersTheApprovedSheet() {
        val sheet = agent.createSheet(
            "Ahmed", 35, "From the story: \"white beard\"",
            "From the story: \"white robe\"",
            CharacterConsistencyAgent.NOT_SPECIFIED,
            isMainCharacter = true,
            mentionCount = 5
        )
        val text = agent.describeForPrompt(sheet)
        assertTrue(text.contains("Ahmed"))
        assertTrue(text.contains("35 years old"))
        assertTrue(text.contains("white beard"))
        assertTrue(text.contains("white robe"))
        // Unknown details stay visibly unknown in the prompt.
        assertTrue(text.contains("Not specified in the story"))
    }

    @Test
    fun describeForPromptOmitsAgeWhenUnknown() {
        val sheet = agent.createSheet(
            "Sara", 0, "Tall",
            CharacterConsistencyAgent.NOT_SPECIFIED,
            CharacterConsistencyAgent.NOT_SPECIFIED
        )
        val text = agent.describeForPrompt(sheet)
        assertFalse(text.contains("years old"))
        assertTrue(text.contains("Sara"))
    }
}
