package com.pakvideo.aistudio

import com.pakvideo.aistudio.data.remote.GeminiApiClient
import com.pakvideo.aistudio.data.remote.GeminiModels
import com.pakvideo.aistudio.domain.agents.StoryAgent
import com.pakvideo.aistudio.domain.agents.StorySource
import com.pakvideo.aistudio.domain.guard.FreeBudgetGuard
import com.pakvideo.aistudio.domain.model.StoryGenre
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StoryAgentTest {

    private class FakeGeminiClient(
        private val response: String?,
        private val fail: Boolean = false
    ) : GeminiApiClient() {
        var lastProxyBaseUrl: String? = "not-called"
            private set
        var lastApiKey: String? = "not-called"
            private set
        var lastModel: String? = "not-called"
            private set
        var lastPrompt: String? = null
            private set
        var callCount: Int = 0
            private set

        override suspend fun generateText(
            apiKey: String,
            model: String,
            prompt: String,
            proxyBaseUrl: String?
        ): Result<String> {
            lastProxyBaseUrl = proxyBaseUrl
            lastApiKey = apiKey
            lastModel = model
            lastPrompt = prompt
            callCount++
            return if (fail) {
                Result.failure(IllegalStateException("simulated Gemini failure"))
            } else {
                Result.success(response ?: "")
            }
        }
    }

    private fun confirmedGuard(key: String? = "key") =
        FreeBudgetGuard({ key }, { true })

    @Test
    fun detectLanguageUrduScript() {
        val agent = StoryAgent(FreeBudgetGuard())
        assertEquals("ur", agent.detectLanguage("ایک اچھی کہانی سناؤ"))
    }

    @Test
    fun detectLanguageEnglish() {
        val agent = StoryAgent(FreeBudgetGuard())
        assertEquals("en", agent.detectLanguage("Tell me a good story"))
    }

    @Test
    fun noKeyProducesLocalDraft() = runTest {
        val agent = StoryAgent(FreeBudgetGuard({ null }, { true }))
        val draft = agent.createStory("A kind farmer", "en")
        assertTrue(draft.isLocalDraft)
        assertTrue(draft.title.isNotEmpty())
        assertTrue(draft.narration.isNotEmpty())
    }

    @Test
    fun keyWithoutConfirmationProducesLocalDraft() = runTest {
        // Regression (Fix 1): a key without the free-tier confirmation
        // must NOT reach Gemini.
        val client = FakeGeminiClient("Title: Should not be used\nNarration: No.")
        val agent = StoryAgent(
            FreeBudgetGuard({ "key" }, { false }),
            client,
            { "key" },
            { GeminiModels.DEFAULT_MODEL }
        )
        val draft = agent.createStory("A kind farmer", "en")
        assertTrue(draft.isLocalDraft)
        assertEquals(StorySource.LOCAL_FALLBACK, agent.lastStorySource)
        assertEquals("not-called", client.lastProxyBaseUrl)
        assertEquals(0, client.callCount)
    }

    @Test
    fun geminiSuccessProducesRealDraft() = runTest {
        val response = "Title: The Kind Farmer\n" +
            "Hook: One seed changed a whole village.\n" +
            "Narration: The farmer planted a single seed.\n\n" +
            "The seed grew into a great tree.\n\n" +
            "The village never went hungry again.\n" +
            "Dialogue:\n" +
            "Farmer: This tree is for everyone.\n" +
            "Child: Thank you, farmer!\n"
        val client = FakeGeminiClient(response)
        val agent = StoryAgent(
            confirmedGuard(),
            client,
            { "key" },
            { GeminiModels.DEFAULT_MODEL }
        )
        val draft = agent.createStory("A kind farmer", "en")
        assertFalse(draft.isLocalDraft)
        assertEquals("The Kind Farmer", draft.title)
        assertEquals("One seed changed a whole village.", draft.hook)
        assertEquals(2, draft.dialogue.size)
        assertEquals("Farmer", draft.dialogue[0].speaker)
    }

    @Test
    fun geminiFailureFallsBackToLocalDraft() = runTest {
        val client = FakeGeminiClient(response = null, fail = true)
        val agent = StoryAgent(
            confirmedGuard(),
            client,
            { "key" },
            { GeminiModels.DEFAULT_MODEL }
        )
        val draft = agent.createStory("A kind farmer", "en")
        assertTrue(draft.isLocalDraft)
    }

    @Test
    fun geminiGarbageResponseFallsBackToLocalDraft() = runTest {
        val client = FakeGeminiClient(response = "   \n\n  ")
        val agent = StoryAgent(
            confirmedGuard(),
            client,
            { "key" },
            { GeminiModels.DEFAULT_MODEL }
        )
        val draft = agent.createStory("A kind farmer", "en")
        assertTrue(draft.isLocalDraft)
    }

    // ---- Regression tests for Fix 5: the agent reports where each
    // story came from, and why it fell back.

    @Test
    fun geminiSuccessReportsGeminiSource() = runTest {
        val client = FakeGeminiClient(
            "Title: The Kind Farmer\nHook: One seed.\n" +
                "Narration: The farmer planted a seed."
        )
        val agent = StoryAgent(
            confirmedGuard(),
            client,
            { "key" },
            { GeminiModels.DEFAULT_MODEL }
        )
        agent.createStory("A kind farmer", "en")
        assertEquals(StorySource.GEMINI, agent.lastStorySource)
        assertNull(agent.lastFallbackReason)
    }

    @Test
    fun noKeyReportsFallbackWithReason() = runTest {
        val agent = StoryAgent(FreeBudgetGuard({ null }, { true }))
        agent.createStory("A kind farmer", "en")
        assertEquals(StorySource.LOCAL_FALLBACK, agent.lastStorySource)
        val reason = agent.lastFallbackReason
        assertNotNull(reason)
        assertTrue(reason!!.contains("Gemini unavailable"))
    }

    @Test
    fun geminiFailureReportsFallbackWithReason() = runTest {
        val client = FakeGeminiClient(response = null, fail = true)
        val agent = StoryAgent(
            confirmedGuard(),
            client,
            { "key" },
            { GeminiModels.DEFAULT_MODEL }
        )
        agent.createStory("A kind farmer", "en")
        assertEquals(StorySource.LOCAL_FALLBACK, agent.lastStorySource)
        assertNotNull(agent.lastFallbackReason)
        assertTrue(agent.lastFallbackReason!!.contains("failed"))
    }

    @Test
    fun proxyUrlIsPassedToGeminiClient() = runTest {
        val client = FakeGeminiClient(
            "Title: The Kind Farmer\nHook: One seed.\n" +
                "Narration: The farmer planted a seed."
        )
        val agent = StoryAgent(
            confirmedGuard(),
            client,
            { "key" },
            { GeminiModels.DEFAULT_MODEL },
            { "https://my-proxy.example.com" }
        )
        agent.createStory("A kind farmer", "en")
        assertEquals("https://my-proxy.example.com", client.lastProxyBaseUrl)
    }

    // ---- Regression tests for the second review, Fix 2: proxy mode
    // works without a local key, and a device key is never sent to the
    // proxy — even when one is saved locally.

    @Test
    fun proxyModeWorksWithoutLocalKey() = runTest {
        val client = FakeGeminiClient(
            "Title: The Kind Farmer\nHook: One seed.\n" +
                "Narration: The farmer planted a seed."
        )
        val guard = FreeBudgetGuard({ null }, { true }, { "https://proxy.example.com" })
        val agent = StoryAgent(
            guard,
            client,
            { null },
            { GeminiModels.DEFAULT_MODEL },
            { "https://proxy.example.com" }
        )
        val draft = agent.createStory("A kind farmer", "en")
        assertFalse(draft.isLocalDraft)
        assertEquals(StorySource.GEMINI, agent.lastStorySource)
        assertEquals(1, client.callCount)
        assertEquals("https://proxy.example.com", client.lastProxyBaseUrl)
        assertEquals("", client.lastApiKey)
    }

    @Test
    fun proxyModeNeverSendsSavedDeviceKey() = runTest {
        val client = FakeGeminiClient(
            "Title: The Kind Farmer\nHook: One seed.\n" +
                "Narration: The farmer planted a seed."
        )
        // A key IS saved on the device, but a proxy is configured:
        // the key must still not be sent.
        val guard = FreeBudgetGuard({ "device-key-123" }, { true }, { "https://proxy.example.com" })
        val agent = StoryAgent(
            guard,
            client,
            { "device-key-123" },
            { GeminiModels.DEFAULT_MODEL },
            { "https://proxy.example.com" }
        )
        agent.createStory("A kind farmer", "en")
        assertEquals(1, client.callCount)
        assertEquals("", client.lastApiKey)
        assertFalse(client.lastApiKey!!.contains("device-key"))
    }

    @Test
    fun proxyModeWithoutConfirmationFallsBackWithoutCallingGemini() = runTest {
        val client = FakeGeminiClient("Title: Should not be used\nNarration: No.")
        val guard = FreeBudgetGuard({ null }, { false }, { "https://proxy.example.com" })
        val agent = StoryAgent(
            guard,
            client,
            { null },
            { GeminiModels.DEFAULT_MODEL },
            { "https://proxy.example.com" }
        )
        val draft = agent.createStory("A kind farmer", "en")
        assertTrue(draft.isLocalDraft)
        assertEquals(0, client.callCount)
        assertTrue(agent.lastFallbackReason!!.contains("proxy"))
    }

    // ---- Regression tests for the second review, Fix 1: only
    // free-tier models are ever called; anything else falls back
    // to a local draft with the reason recorded.

    @Test
    fun retiredModelIsRefusedAndFallsBack() = runTest {
        val client = FakeGeminiClient("Title: Should not be used\nNarration: No.")
        val agent = StoryAgent(
            confirmedGuard(),
            client,
            { "key" },
            { "gemini-2.0-flash" }
        )
        val draft = agent.createStory("A kind farmer", "en")
        assertTrue(draft.isLocalDraft)
        assertEquals(0, client.callCount)
        assertTrue(agent.lastFallbackReason!!.contains("gemini-2.0-flash"))
        assertTrue(agent.lastFallbackReason!!.contains("free-tier"))
    }

    @Test
    fun paidModelIsRefusedAndFallsBack() = runTest {
        val client = FakeGeminiClient("Title: Should not be used\nNarration: No.")
        val agent = StoryAgent(
            confirmedGuard(),
            client,
            { "key" },
            { "gemini-4-argon" }
        )
        val draft = agent.createStory("A kind farmer", "en")
        assertTrue(draft.isLocalDraft)
        assertEquals(0, client.callCount)
    }

    @Test
    fun noModelConfiguredUsesFreeTierDefault() = runTest {
        val client = FakeGeminiClient(
            "Title: The Kind Farmer\nHook: One seed.\n" +
                "Narration: The farmer planted a seed."
        )
        val agent = StoryAgent(confirmedGuard(), client, { "key" }, { null })
        val draft = agent.createStory("A kind farmer", "en")
        assertFalse(draft.isLocalDraft)
        assertEquals(GeminiModels.DEFAULT_MODEL, client.lastModel)
    }

    // ---- Regression tests for the second review, Fix 3: genres.
    // Every genre reaches the model prompt; "family-friendly" is gone.

    @Test
    fun everyGenreReachesTheGeminiPrompt() = runTest {
        for (genre in StoryGenre.entries) {
            val client = FakeGeminiClient(
                "Title: T\nHook: H.\nNarration: A story."
            )
            val agent = StoryAgent(
                confirmedGuard(),
                client,
                { "key" },
                { GeminiModels.DEFAULT_MODEL }
            )
            val draft = agent.createStory("A story idea", "en", genre)
            assertFalse(draft.isLocalDraft)
            assertEquals(genre, draft.genre)
            val prompt = client.lastPrompt ?: error("No prompt sent for $genre")
            assertTrue("Prompt for $genre must carry its guidance", prompt.contains(genre.promptGuidance))
            assertFalse("Prompt must not force family-friendly", prompt.contains("family-friendly"))
        }
    }

    @Test
    fun horrorLocalDraftKeepsGenreAndNoFamilyFriendlyRule() = runTest {
        // Guard blocks Gemini: the local draft must still carry the
        // user's horror genre, with no family-friendly restriction.
        val agent = StoryAgent(FreeBudgetGuard({ null }, { true }))
        val draft = agent.createStory("A haunted haveli", "en", StoryGenre.HORROR)
        assertTrue(draft.isLocalDraft)
        assertEquals(StoryGenre.HORROR, draft.genre)
        assertTrue(draft.narration.contains("horror"))
        assertFalse(draft.narration.contains("family-friendly"))
    }
}
