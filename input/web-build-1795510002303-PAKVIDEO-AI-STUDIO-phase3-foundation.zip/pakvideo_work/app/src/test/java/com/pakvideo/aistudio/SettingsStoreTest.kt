package com.pakvideo.aistudio

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.pakvideo.aistudio.data.preferences.SettingsStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Regression tests for Fix 1 and Fix 2 settings: the free-tier
 * confirmation defaults to false (a key alone never counts as free
 * quota) and the proxy URL defaults to empty (direct Google endpoint).
 * Only plain preferences are touched here — the encrypted key store is
 * never opened under Robolectric.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class SettingsStoreTest {

    private lateinit var store: SettingsStore

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.getSharedPreferences("pakvideo_prefs", Context.MODE_PRIVATE)
            .edit().clear().commit()
        store = SettingsStore(context)
    }

    @Test
    fun freeTierConfirmationDefaultsFalse() {
        assertFalse(store.isFreeTierConfirmed())
    }

    @Test
    fun freeTierConfirmationRoundTrips() {
        store.setFreeTierConfirmed(true)
        assertTrue(store.isFreeTierConfirmed())
        store.setFreeTierConfirmed(false)
        assertFalse(store.isFreeTierConfirmed())
    }

    @Test
    fun proxyUrlDefaultsEmpty() {
        assertEquals("", store.getGeminiProxyUrl())
    }

    @Test
    fun modelDefaultsToCurrentFreeTierFlash() {
        // Second review, Fix 1: gemini-2.0-flash was retired 2026-06-01.
        assertEquals("gemini-3.8-flash", store.getGeminiModel())
    }

    @Test
    fun modelRoundTrips() {
        store.setGeminiModel("gemini-3.6-flash")
        assertEquals("gemini-3.6-flash", store.getGeminiModel())
        store.setGeminiModel("gemini-3.8-flash")
        assertEquals("gemini-3.8-flash", store.getGeminiModel())
    }

    @Test
    fun proxyUrlRoundTripsAndTrims() {
        store.setGeminiProxyUrl("https://my-proxy.example.com/")
        assertEquals("https://my-proxy.example.com/", store.getGeminiProxyUrl())
        store.setGeminiProxyUrl("  https://x.example.com  ")
        assertEquals("https://x.example.com", store.getGeminiProxyUrl())
        store.setGeminiProxyUrl("")
        assertEquals("", store.getGeminiProxyUrl())
    }
}
