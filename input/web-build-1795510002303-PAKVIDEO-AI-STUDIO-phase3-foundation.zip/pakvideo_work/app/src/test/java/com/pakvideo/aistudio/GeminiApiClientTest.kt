package com.pakvideo.aistudio

import com.pakvideo.aistudio.data.remote.GeminiRequestBuilder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Regression tests for Fix 2 (Gemini key security): the key must never
 * appear in a URL, and in proxy mode no key is sent from the device at
 * all. These test the pure request builder, so no network is involved.
 */
class GeminiApiClientTest {


    @Test
    fun proxyUrlValidatorAcceptsHttpsAndRejectsHttpOrUnsafeComponents() {
        assertTrue(com.pakvideo.aistudio.data.remote.ProxyUrlValidator.isValidOrEmpty("https://proxy.example.com/base/"))
        assertTrue(com.pakvideo.aistudio.data.remote.ProxyUrlValidator.isValidOrEmpty(""))
        assertFalse(com.pakvideo.aistudio.data.remote.ProxyUrlValidator.isValidOrEmpty("http://proxy.example.com"))
        assertFalse(com.pakvideo.aistudio.data.remote.ProxyUrlValidator.isValidOrEmpty("https://user:pass@proxy.example.com"))
        assertFalse(com.pakvideo.aistudio.data.remote.ProxyUrlValidator.isValidOrEmpty("https://proxy.example.com?key=x"))
        assertFalse(com.pakvideo.aistudio.data.remote.ProxyUrlValidator.isValidOrEmpty("https://proxy.example.com/#fragment"))
    }


    @Test(expected = IllegalArgumentException::class)
    fun requestBuilderRejectsHttpProxy() {
        GeminiRequestBuilder.urlFor("gemini-3.8-flash", "http://proxy.example.com")
    }

    @Test
    fun directUrlHasNoKeyParameter() {
        val url = GeminiRequestBuilder.urlFor("gemini-3.8-flash", null)
        assertEquals(
            "https://generativelanguage.googleapis.com/v1beta/models/" +
                "gemini-3.8-flash:generateContent",
            url
        )
        assertFalse(url.contains("key="))
        assertFalse(url.contains("AIza"))
    }

    @Test
    fun directUrlEncodesModelName() {
        val url = GeminiRequestBuilder.urlFor("gemini-3.8-flash", null)
        assertTrue(url.contains("gemini-3.8-flash:generateContent"))
    }

    @Test
    fun directHeadersCarryKeyAsHeader() {
        val headers = GeminiRequestBuilder.headersFor("AIzaSecretKey123", null)
        assertEquals("AIzaSecretKey123", headers["x-goog-api-key"])
        assertEquals(1, headers.size)
    }

    @Test
    fun directHeadersEmptyWithoutKey() {
        assertTrue(GeminiRequestBuilder.headersFor(null, null).isEmpty())
        assertTrue(GeminiRequestBuilder.headersFor("   ", null).isEmpty())
    }

    @Test
    fun proxyUrlUsesProxyBaseAndNoKey() {
        val url = GeminiRequestBuilder.urlFor(
            "gemini-3.8-flash",
            "https://my-proxy.example.com/"
        )
        assertEquals(
            "https://my-proxy.example.com/v1beta/models/" +
                "gemini-3.8-flash:generateContent",
            url
        )
        assertFalse(url.contains("generativelanguage.googleapis.com"))
        assertFalse(url.contains("key="))
    }

    @Test
    fun proxyHeadersNeverContainKey() {
        val headers = GeminiRequestBuilder.headersFor(
            "AIzaSecretKey123",
            "https://my-proxy.example.com"
        )
        assertTrue(headers.isEmpty())
        assertFalse(headers.values.any { it.contains("AIza") })
    }

    @Test
    fun blankProxyFallsBackToDirectEndpoint() {
        val url = GeminiRequestBuilder.urlFor("gemini-3.8-flash", "   ")
        assertTrue(url.startsWith("https://generativelanguage.googleapis.com/"))
        val headers = GeminiRequestBuilder.headersFor("AIzaKey", "   ")
        assertEquals("AIzaKey", headers["x-goog-api-key"])
    }
}
