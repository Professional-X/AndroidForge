package com.pakvideo.aistudio

import com.pakvideo.aistudio.data.local.CharacterEntity
import com.pakvideo.aistudio.data.local.ProjectEntity
import com.pakvideo.aistudio.data.local.SceneEntity
import com.pakvideo.aistudio.data.local.TaskEventEntity
import com.pakvideo.aistudio.data.repository.ProjectRepository
import com.pakvideo.aistudio.domain.model.ProjectState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map

/**
 * In-memory [ProjectRepository] for JVM unit tests. Mirrors the contract
 * behaviour of [com.pakvideo.aistudio.data.repository.ProjectRepositoryImpl]:
 * [updateProjectState] stores `state.name` and appends error messages to
 * the error log. Room DAOs are NOT tested on the JVM (instrumented tests).
 */
class FakeProjectRepository : ProjectRepository {

    private val projectsFlow = MutableStateFlow<List<ProjectEntity>>(emptyList())
    private val scenesFlow = MutableStateFlow<List<SceneEntity>>(emptyList())
    private val charactersFlow = MutableStateFlow<List<CharacterEntity>>(emptyList())
    private val eventsFlow = MutableStateFlow<List<TaskEventEntity>>(emptyList())
    private var sceneIdCounter = 0L
    private var characterIdCounter = 0L
    private var eventIdCounter = 0L

    override suspend fun createProject(project: ProjectEntity): String {
        projectsFlow.value = projectsFlow.value + project
        return project.id
    }

    override suspend fun getProject(id: String): ProjectEntity? =
        projectsFlow.value.find { it.id == id }

    override fun getAllProjects(): Flow<List<ProjectEntity>> = projectsFlow

    override suspend fun updateProject(project: ProjectEntity) {
        projectsFlow.value = projectsFlow.value.map { if (it.id == project.id) project else it }
    }

    override suspend fun deleteProject(id: String) {
        projectsFlow.value = projectsFlow.value.filterNot { it.id == id }
    }

    override suspend fun renameProject(id: String, newName: String) {
        val current = getProject(id) ?: return
        updateProject(current.copy(name = newName, updatedAt = System.currentTimeMillis()))
    }

    override suspend fun updateProjectState(
        id: String,
        state: ProjectState,
        errorMessage: String?
    ) {
        val current = getProject(id) ?: return
        val newLog = if (errorMessage != null) {
            (current.errorLog + "\n[${System.currentTimeMillis()}] $errorMessage").trim()
        } else {
            current.errorLog
        }
        updateProject(
            current.copy(
                status = state.name,
                errorLog = newLog,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    override suspend fun updateScript(id: String, script: String) {
        val current = getProject(id) ?: return
        updateProject(current.copy(script = script, updatedAt = System.currentTimeMillis()))
    }

    override suspend fun addScene(scene: SceneEntity): Long {
        sceneIdCounter += 1
        scenesFlow.value = scenesFlow.value + scene.copy(id = sceneIdCounter)
        return sceneIdCounter
    }

    override fun getScenes(projectId: String): Flow<List<SceneEntity>> =
        scenesFlow.map { list -> list.filter { it.projectId == projectId } }

    override suspend fun updateScene(scene: SceneEntity) {
        scenesFlow.value = scenesFlow.value.map { if (it.id == scene.id) scene else it }
    }

    override suspend fun deleteScene(sceneId: Long) {
        scenesFlow.value = scenesFlow.value.filterNot { it.id == sceneId }
    }

    override suspend fun deleteProjectScenes(projectId: String) {
        scenesFlow.value = scenesFlow.value.filterNot { it.projectId == projectId }
    }

    override suspend fun addCharacter(character: CharacterEntity): Long {
        characterIdCounter += 1
        charactersFlow.value = charactersFlow.value + character.copy(id = characterIdCounter)
        return characterIdCounter
    }

    override fun getCharacters(projectId: String): Flow<List<CharacterEntity>> =
        charactersFlow.map { list -> list.filter { it.projectId == projectId } }

    override suspend fun updateCharacter(character: CharacterEntity) {
        charactersFlow.value = charactersFlow.value.map { if (it.id == character.id) character else it }
    }

    override suspend fun deleteCharacter(characterId: Long) {
        charactersFlow.value = charactersFlow.value.filterNot { it.id == characterId }
    }

    override suspend fun deleteProjectCharacters(projectId: String) {
        charactersFlow.value = charactersFlow.value.filterNot { it.projectId == projectId }
    }

    override suspend fun logEvent(event: TaskEventEntity) {
        eventIdCounter += 1
        eventsFlow.value = eventsFlow.value + event.copy(id = eventIdCounter)
    }

    override fun getEvents(projectId: String): Flow<List<TaskEventEntity>> =
        eventsFlow.map { list -> list.filter { it.projectId == projectId } }
}
