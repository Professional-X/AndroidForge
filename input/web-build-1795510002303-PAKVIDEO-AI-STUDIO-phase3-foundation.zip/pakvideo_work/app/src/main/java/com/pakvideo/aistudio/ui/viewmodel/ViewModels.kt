package com.pakvideo.aistudio.ui.viewmodel

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.pakvideo.aistudio.data.local.CharacterEntity
import com.pakvideo.aistudio.data.local.ProjectEntity
import com.pakvideo.aistudio.data.local.SceneEntity
import com.pakvideo.aistudio.data.local.TaskEventEntity
import com.pakvideo.aistudio.data.remote.GeminiModels
import com.pakvideo.aistudio.data.remote.ProxyUrlValidator
import com.pakvideo.aistudio.domain.agents.CharacterConsistencyAgent
import com.pakvideo.aistudio.di.AppContainer
import com.pakvideo.aistudio.domain.guard.ProviderId
import com.pakvideo.aistudio.domain.guard.ProviderInfo
import com.pakvideo.aistudio.domain.guard.ProviderRegistry
import com.pakvideo.aistudio.domain.model.ApprovalRequest
import com.pakvideo.aistudio.domain.image.ImageProviderId
import com.pakvideo.aistudio.domain.image.ImageTaskStatus
import com.pakvideo.aistudio.domain.model.StoryGenre
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(private val container: AppContainer) : ViewModel() {

    val projects: StateFlow<List<ProjectEntity>> = container.repository.getAllProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun createProject(
        name: String,
        prompt: String,
        genre: StoryGenre = StoryGenre.ISLAMIC
    ): String {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        viewModelScope.launch {
            container.repository.createProject(
                ProjectEntity(
                    id = id,
                    name = name.ifBlank { "Untitled production" },
                    userPrompt = prompt,
                    genre = genre.name,
                    createdAt = now,
                    updatedAt = now
                )
            )
        }
        return id
    }

    fun deleteProject(id: String) {
        viewModelScope.launch { container.repository.deleteProject(id) }
    }

    fun renameProject(id: String, newName: String) {
        viewModelScope.launch { container.repository.renameProject(id, newName) }
    }
}

class ProductionViewModel(
    private val container: AppContainer,
    private val projectId: String
) : ViewModel() {

    val project: StateFlow<ProjectEntity?> = container.repository.getAllProjects()
        .map { list -> list.find { it.id == projectId } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val scenes: StateFlow<List<SceneEntity>> = container.repository.getScenes(projectId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val characters: StateFlow<List<CharacterEntity>> = container.repository.getCharacters(projectId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val events: StateFlow<List<TaskEventEntity>> = container.repository.getEvents(projectId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingApproval: StateFlow<ApprovalRequest?> = container.orchestrator.pendingApproval

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun clearError() {
        _error.value = null
    }

    fun sendPrompt(prompt: String) {
        viewModelScope.launch {
            try {
                val current = container.repository.getProject(projectId)
                if (current != null && current.userPrompt != prompt) {
                    container.repository.updateProject(
                        current.copy(userPrompt = prompt, updatedAt = System.currentTimeMillis())
                    )
                }
                container.orchestrator.startProduction(projectId)
            } catch (e: Exception) {
                _error.value = e.message ?: "Production failed"
            }
        }
    }

    fun approve() {
        viewModelScope.launch {
            try {
                val id = pendingApproval.value?.id ?: return@launch
                container.orchestrator.approve(id)
            } catch (e: Exception) {
                _error.value = e.message ?: "Approve failed"
            }
        }
    }

    fun reject() {
        viewModelScope.launch {
            try {
                val id = pendingApproval.value?.id ?: return@launch
                container.orchestrator.reject(id)
            } catch (e: Exception) {
                _error.value = e.message ?: "Reject failed"
            }
        }
    }

    fun cancel() {
        viewModelScope.launch {
            try {
                container.orchestrator.cancel(projectId)
            } catch (e: Exception) {
                _error.value = e.message ?: "Cancel failed"
            }
        }
    }

    fun resume() {
        viewModelScope.launch {
            try {
                container.orchestrator.resume(projectId)
            } catch (e: Exception) {
                _error.value = e.message ?: "Resume failed"
            }
        }
    }
}

class WorkspaceViewModel(
    private val container: AppContainer,
    private val projectId: String
) : ViewModel() {

    val project: StateFlow<ProjectEntity?> = container.repository.getAllProjects()
        .map { list -> list.find { it.id == projectId } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val scenes: StateFlow<List<SceneEntity>> = container.repository.getScenes(projectId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val characters: StateFlow<List<CharacterEntity>> = container.repository.getCharacters(projectId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val imageTasks = container.imageTaskManager.observe(projectId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _imageMessage = MutableStateFlow<String?>(null)
    val imageMessage: StateFlow<String?> = _imageMessage

    fun prepareImageTask(sceneId: Long) {
        viewModelScope.launch {
            try {
                val task = container.imageTaskManager.prepare(projectId, sceneId, ImageProviderId.GEMINI_IMAGEN)
                val result = container.imageTaskManager.generate(task.id)
                _imageMessage.value = when (result) {
                    is com.pakvideo.aistudio.domain.image.ImageGenerationResult.Success -> "Image generated and saved."
                    is com.pakvideo.aistudio.domain.image.ImageGenerationResult.Failure -> result.message
                    is com.pakvideo.aistudio.domain.image.ImageGenerationResult.Unavailable -> "Image provider unavailable: ${result.reason}"
                }
            } catch (e: Exception) {
                _imageMessage.value = e.message ?: "Could not create image task"
            }
        }
    }

    fun clearImageMessage() { _imageMessage.value = null }

    fun updateScript(script: String) {
        viewModelScope.launch { container.repository.updateScript(projectId, script) }
    }

    fun updateScene(scene: SceneEntity) {
        viewModelScope.launch { container.repository.updateScene(scene) }
    }

    fun addCharacter(name: String) {
        val cleanName = name.trim()
        if (cleanName.isBlank() || cleanName.equals("Narrator", ignoreCase = true) ||
            characters.value.any { it.name.equals(cleanName, ignoreCase = true) }
        ) return
        viewModelScope.launch {
            val notSpecified = CharacterConsistencyAgent.NOT_SPECIFIED
            val entity = CharacterEntity(
                projectId = projectId,
                name = cleanName,
                age = 0,
                appearance = notSpecified,
                clothing = notSpecified,
                facialFeatures = notSpecified,
                isMainCharacter = false,
                mentionCount = 0
            )
            val id = container.repository.addCharacter(entity)
            val saved = entity.copy(id = id)
            val currentSheets = characters.value.filterNot {
                it.id == id || it.name.equals(cleanName, ignoreCase = true)
            }
            saveCharacterSnapshot(currentSheets + saved)

            // Add the user-supplied identity to any scene that mentions the name.
            val agent = CharacterConsistencyAgent()
            val identity = agent.describeForPrompt(
                agent.createSheet(cleanName, 0, notSpecified, notSpecified, notSpecified)
            )
            container.repository.getScenes(projectId).first().forEach { scene ->
                if (agent.mentionsName(scene.description, cleanName)) {
                    val refs = (scene.characterRefs.split(", ").map { it.trim() } + cleanName)
                        .filter { it.isNotBlank() }.distinct().joinToString(", ")
                    val prompt = if (scene.visualPrompt.contains("of the main subject")) {
                        scene.visualPrompt.replace("of the main subject", "of $identity")
                    } else {
                        "Character identity: $identity. ${scene.visualPrompt}"
                    }
                    container.repository.updateScene(
                        scene.copy(characterRefs = refs, visualPrompt = prompt)
                    )
                }
            }
        }
    }

    fun updateCharacter(character: CharacterEntity) {
        viewModelScope.launch {
            val old = characters.value.firstOrNull { it.id == character.id }
            container.repository.updateCharacter(character)
            val updatedSheets = characters.value.map { if (it.id == character.id) character else it }
            saveCharacterSnapshot(updatedSheets)
            if (old != null) {
                val agent = CharacterConsistencyAgent()
                val oldSheet = agent.createSheet(old.name, old.age, old.appearance, old.clothing,
                    old.facialFeatures, old.isMainCharacter, old.mentionCount)
                val newSheet = agent.createSheet(character.name, character.age, character.appearance,
                    character.clothing, character.facialFeatures, character.isMainCharacter,
                    character.mentionCount)
                val oldPromptText = agent.describeForPrompt(oldSheet)
                val newPromptText = agent.describeForPrompt(newSheet)
                container.repository.getScenes(projectId).first().forEach { scene ->
                    val refs = scene.characterRefs.split(", ").map { it.trim() }
                    if (old.name in refs || scene.visualPrompt.contains(oldPromptText)) {
                        val updatedRefs = refs.map { if (it == old.name) character.name else it }
                            .distinct().joinToString(", ")
                        val updatedPrompt = if (scene.visualPrompt.contains(oldPromptText))
                            scene.visualPrompt.replace(oldPromptText, newPromptText)
                        else scene.visualPrompt
                        container.repository.updateScene(
                            scene.copy(characterRefs = updatedRefs, visualPrompt = updatedPrompt)
                        )
                    }
                }
            }
        }
    }

    private suspend fun saveCharacterSnapshot(sheets: List<CharacterEntity>) {
        val currentProject = container.repository.getProject(projectId) ?: return
        val json = sheets.joinToString(prefix = "[", postfix = "]", separator = ",") { sheet ->
            "{\"name\":\"${escapeJson(sheet.name)}\"," +
                "\"age\":${sheet.age},\"appearance\":\"${escapeJson(sheet.appearance)}\"," +
                "\"clothing\":\"${escapeJson(sheet.clothing)}\"," +
                "\"facialFeatures\":\"${escapeJson(sheet.facialFeatures)}\"," +
                "\"isMainCharacter\":${sheet.isMainCharacter},\"mentionCount\":${sheet.mentionCount}}"
        }
        container.repository.updateProject(
            currentProject.copy(characterDescriptions = json, updatedAt = System.currentTimeMillis())
        )
    }

    private fun escapeJson(value: String): String = value
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace("\t", "\\t")
}

class CreationsViewModel(private val container: AppContainer) : ViewModel() {

    val projects: StateFlow<List<ProjectEntity>> = container.repository.getAllProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun renameProject(id: String, newName: String) {
        viewModelScope.launch { container.repository.renameProject(id, newName) }
    }

    fun deleteProject(id: String) {
        viewModelScope.launch { container.repository.deleteProject(id) }
    }
}

class SettingsViewModel(private val container: AppContainer) : ViewModel() {

    private val _language = MutableStateFlow(container.settingsStore.getLanguage())
    val language: StateFlow<String> = _language

    private val _apiKeyPresent = MutableStateFlow(false)
    val apiKeyPresent: StateFlow<Boolean> = _apiKeyPresent

    val providers: List<ProviderInfo> = ProviderRegistry.all()

    private val _storageInfo = MutableStateFlow("")
    val storageInfo: StateFlow<String> = _storageInfo

    private val _geminiModel = MutableStateFlow(GeminiModels.DEFAULT_MODEL)
    val geminiModel: StateFlow<String> = _geminiModel

    // Free-tier attestation: the user confirms the key belongs to a
    // billing-free project. Default false — a key alone never counts
    // as free quota (see FreeBudgetGuard).
    private val _freeTierConfirmed = MutableStateFlow(false)
    val freeTierConfirmed: StateFlow<Boolean> = _freeTierConfirmed

    // Optional server-side Gemini proxy base URL. Empty = direct Google
    // endpoint with the device key in the header.
    private val _geminiProxyUrl = MutableStateFlow("")
    val geminiProxyUrl: StateFlow<String> = _geminiProxyUrl

    private val _proxyUrlError = MutableStateFlow<String?>(null)
    val proxyUrlError: StateFlow<String?> = _proxyUrlError

    // Provider health for Gemini text generation. The Settings screen
    // resolves geminiHealthy + the proxy URL into the ready-direct /
    // ready-proxy / needs-confirmation / not-configured strings.
    private val _geminiHealthy = MutableStateFlow(false)
    val geminiHealthy: StateFlow<Boolean> = _geminiHealthy

    init {
        viewModelScope.launch {
            _apiKeyPresent.value = container.settingsStore.getGeminiApiKey() != null
            _storageInfo.value = container.settingsStore.getStorageInfo()
            _geminiModel.value = container.settingsStore.getGeminiModel()
            _freeTierConfirmed.value = container.settingsStore.isFreeTierConfirmed()
            _geminiProxyUrl.value = container.settingsStore.getGeminiProxyUrl()
            refreshGeminiHealth()
        }
    }

    private fun refreshGeminiHealth() {
        // The guard alone decides health: in proxy mode no local key is
        // needed, so requiring a key here would wrongly report proxy
        // setups as unhealthy.
        _geminiHealthy.value =
            container.guard.hasFreeQuota(ProviderId.GEMINI_TEXT)
    }

    fun setLanguage(code: String) {
        container.settingsStore.setLanguage(code)
        _language.value = code
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(code))
    }

    fun saveApiKey(key: String) {
        val cleanedKey = key.trim()
        if (cleanedKey.isBlank()) return
        val previousKey = container.settingsStore.getGeminiApiKey()
        // A confirmation belongs to one specific key/project. Replacing
        // the key invalidates that attestation; never carry it forward.
        if (previousKey != cleanedKey) {
            container.settingsStore.setFreeTierConfirmed(false)
            _freeTierConfirmed.value = false
        }
        container.settingsStore.saveGeminiApiKey(cleanedKey)
        _apiKeyPresent.value = true
        refreshGeminiHealth()
    }

    fun clearApiKey() {
        container.settingsStore.clearGeminiApiKey()
        // A new key belongs to a possibly different project, so the
        // free-tier attestation does not carry over: the user must
        // confirm again for the next key.
        container.settingsStore.setFreeTierConfirmed(false)
        _apiKeyPresent.value = false
        _freeTierConfirmed.value = false
        refreshGeminiHealth()
    }

    fun setGeminiModel(model: String) {
        container.settingsStore.setGeminiModel(model)
        _geminiModel.value = model
    }

    fun setFreeTierConfirmed(confirmed: Boolean) {
        container.settingsStore.setFreeTierConfirmed(confirmed)
        _freeTierConfirmed.value = confirmed
        refreshGeminiHealth()
    }

    fun setGeminiProxyUrl(url: String) {
        if (!ProxyUrlValidator.isValidOrEmpty(url)) {
            _proxyUrlError.value = "Use a valid HTTPS URL. HTTP, credentials, query strings and fragments are not allowed."
            return
        }
        val previousProxy = container.settingsStore.getGeminiProxyUrl()
        container.settingsStore.setGeminiProxyUrl(url)
        val savedProxy = container.settingsStore.getGeminiProxyUrl()
        if (previousProxy != savedProxy) {
            // A proxy may use a different server-side project/key. The
            // previous free-tier attestation must not authorize it.
            container.settingsStore.setFreeTierConfirmed(false)
            _freeTierConfirmed.value = false
        }
        _geminiProxyUrl.value = savedProxy
        _proxyUrlError.value = null
        refreshGeminiHealth()
    }

    fun refreshStorageInfo() {
        _storageInfo.value = container.settingsStore.getStorageInfo()
    }

    fun deleteAllProjects() {
        viewModelScope.launch {
            val all: Flow<List<ProjectEntity>> = container.repository.getAllProjects()
            for (project in all.first()) {
                container.repository.deleteProject(project.id)
            }
            refreshStorageInfo()
        }
    }
}

class ViewModelFactory(private val container: AppContainer) {

    fun home(): ViewModelProvider.Factory = factoryOf { HomeViewModel(container) }

    fun production(projectId: String): ViewModelProvider.Factory =
        factoryOf { ProductionViewModel(container, projectId) }

    fun workspace(projectId: String): ViewModelProvider.Factory =
        factoryOf { WorkspaceViewModel(container, projectId) }

    fun creations(): ViewModelProvider.Factory = factoryOf { CreationsViewModel(container) }

    fun settings(): ViewModelProvider.Factory = factoryOf { SettingsViewModel(container) }

    private fun <T : ViewModel> factoryOf(creator: () -> T): ViewModelProvider.Factory =
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <V : ViewModel> create(modelClass: Class<V>): V = creator() as V
        }
}
