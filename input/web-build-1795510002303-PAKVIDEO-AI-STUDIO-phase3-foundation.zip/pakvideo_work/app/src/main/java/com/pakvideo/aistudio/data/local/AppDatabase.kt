package com.pakvideo.aistudio.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * v1 -> v2: adds only new columns with defaults, so every existing row
 * survives untouched:
 * - scenes.visualPrompt TEXT NOT NULL DEFAULT ''
 * - characters.isMainCharacter INTEGER NOT NULL DEFAULT 0
 * - characters.mentionCount INTEGER NOT NULL DEFAULT 0
 *
 * v3 -> v4: adds image_tasks for durable per-scene image generation state.
 *
 * v2 -> v3: adds only one new column with a default, so every existing
 * row survives untouched:
 * - projects.genre TEXT NOT NULL DEFAULT 'ISLAMIC' (the user's chosen
 *   story genre; rows created before v3 read back as ISLAMIC).
 *
 * No table is dropped, no column is removed or renamed, no row is
 * deleted. [fallbackToDestructiveMigration] stays only as a last-resort
 * safety net for unknown future versions; Room uses these migrations
 * for 1 -> 2 and 2 -> 3.
 */
val MIGRATION_1_2: Migration = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "ALTER TABLE scenes ADD COLUMN visualPrompt TEXT NOT NULL DEFAULT ''"
        )
        db.execSQL(
            "ALTER TABLE characters ADD COLUMN isMainCharacter INTEGER NOT NULL DEFAULT 0"
        )
        db.execSQL(
            "ALTER TABLE characters ADD COLUMN mentionCount INTEGER NOT NULL DEFAULT 0"
        )
    }
}

val MIGRATION_2_3: Migration = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "ALTER TABLE projects ADD COLUMN genre TEXT NOT NULL DEFAULT 'ISLAMIC'"
        )
    }
}

val MIGRATION_3_4: Migration = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS image_tasks (
            id TEXT NOT NULL PRIMARY KEY,
            projectId TEXT NOT NULL,
            sceneId INTEGER NOT NULL,
            providerId TEXT NOT NULL,
            prompt TEXT NOT NULL,
            status TEXT NOT NULL,
            outputPath TEXT,
            mimeType TEXT,
            width INTEGER NOT NULL DEFAULT 0,
            height INTEGER NOT NULL DEFAULT 0,
            errorCode TEXT,
            errorMessage TEXT,
            retryable INTEGER NOT NULL DEFAULT 0,
            createdAt INTEGER NOT NULL,
            updatedAt INTEGER NOT NULL
        )""")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_image_tasks_projectId ON image_tasks(projectId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_image_tasks_sceneId ON image_tasks(sceneId)")
    }
}

@Database(
    entities = [ProjectEntity::class, SceneEntity::class, CharacterEntity::class, TaskEventEntity::class, ImageTaskEntity::class],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun projectDao(): ProjectDao
    abstract fun sceneDao(): SceneDao
    abstract fun characterDao(): CharacterDao
    abstract fun taskEventDao(): TaskEventDao
    abstract fun imageTaskDao(): ImageTaskDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pakvideo.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                    .fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
