package com.pakvideo.aistudio.data.repository

import com.pakvideo.aistudio.data.local.CharacterDao
import com.pakvideo.aistudio.data.local.CharacterEntity
import com.pakvideo.aistudio.data.local.ProjectDao
import com.pakvideo.aistudio.data.local.ProjectEntity
import com.pakvideo.aistudio.data.local.SceneDao
import com.pakvideo.aistudio.data.local.SceneEntity
import com.pakvideo.aistudio.data.local.TaskEventDao
import com.pakvideo.aistudio.data.local.TaskEventEntity
import com.pakvideo.aistudio.domain.model.ProjectState
import kotlinx.coroutines.flow.Flow

class ProjectRepositoryImpl(
    private val projectDao: ProjectDao,
    private val sceneDao: SceneDao,
    private val characterDao: CharacterDao,
    private val taskEventDao: TaskEventDao
) : ProjectRepository {

    override suspend fun createProject(project: ProjectEntity): String {
        projectDao.insert(project)
        return project.id
    }

    override suspend fun getProject(id: String): ProjectEntity? {
        return projectDao.getById(id)
    }

    override fun getAllProjects(): Flow<List<ProjectEntity>> {
        return projectDao.getAll()
    }

    override suspend fun updateProject(project: ProjectEntity) {
        projectDao.update(project)
    }

    override suspend fun deleteProject(id: String) {
        projectDao.deleteById(id)
    }

    override suspend fun renameProject(id: String, newName: String) {
        projectDao.rename(id, newName, System.currentTimeMillis())
    }

    override suspend fun updateProjectState(id: String, state: ProjectState, errorMessage: String?) {
        val project = projectDao.getById(id) ?: return
        val now = System.currentTimeMillis()
        val errorLog = if (errorMessage != null) {
            val line = "[$now] $errorMessage"
            if (project.errorLog.isEmpty()) line else "${project.errorLog}\n$line"
        } else {
            project.errorLog
        }
        projectDao.updateState(id, state.name, errorLog, now)
    }

    override suspend fun updateScript(id: String, script: String) {
        projectDao.updateScript(id, script, System.currentTimeMillis())
    }

    override suspend fun addScene(scene: SceneEntity): Long {
        return sceneDao.insert(scene)
    }

    override fun getScenes(projectId: String): Flow<List<SceneEntity>> {
        return sceneDao.getByProject(projectId)
    }

    override suspend fun updateScene(scene: SceneEntity) {
        sceneDao.update(scene)
    }

    override suspend fun deleteScene(sceneId: Long) {
        sceneDao.deleteById(sceneId)
    }

    override suspend fun addCharacter(character: CharacterEntity): Long {
        return characterDao.insert(character)
    }

    override fun getCharacters(projectId: String): Flow<List<CharacterEntity>> {
        return characterDao.getByProject(projectId)
    }

    override suspend fun updateCharacter(character: CharacterEntity) {
        characterDao.update(character)
    }

    override suspend fun deleteCharacter(characterId: Long) {
        characterDao.deleteById(characterId)
    }

    override suspend fun deleteProjectCharacters(projectId: String) {
        characterDao.deleteByProject(projectId)
    }

    override suspend fun deleteProjectScenes(projectId: String) {
        sceneDao.deleteByProject(projectId)
    }

    override suspend fun logEvent(event: TaskEventEntity) {
        taskEventDao.insert(event)
    }

    override fun getEvents(projectId: String): Flow<List<TaskEventEntity>> {
        return taskEventDao.getByProject(projectId)
    }
}
