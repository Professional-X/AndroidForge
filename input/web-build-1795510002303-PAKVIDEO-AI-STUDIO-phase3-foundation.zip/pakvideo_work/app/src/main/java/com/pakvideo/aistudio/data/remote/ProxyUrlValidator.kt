package com.pakvideo.aistudio.data.remote

import java.net.URI

/** Strict validation for an optional server-side proxy base URL. */
object ProxyUrlValidator {
    fun isValidOrEmpty(value: String?): Boolean {
        val candidate = value?.trim().orEmpty()
        if (candidate.isEmpty()) return true
        return try {
            val uri = URI(candidate)
            uri.isAbsolute &&
                uri.scheme.equals("https", ignoreCase = true) &&
                !uri.host.isNullOrBlank() &&
                uri.rawUserInfo == null &&
                uri.rawQuery == null &&
                uri.rawFragment == null &&
                (uri.port == -1 || uri.port in 1..65535)
        } catch (_: Exception) {
            false
        }
    }
}

