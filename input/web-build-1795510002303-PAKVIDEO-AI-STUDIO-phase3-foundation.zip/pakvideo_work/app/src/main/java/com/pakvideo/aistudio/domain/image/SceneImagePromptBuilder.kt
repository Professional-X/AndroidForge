package com.pakvideo.aistudio.domain.image

import com.pakvideo.aistudio.data.local.CharacterEntity
import com.pakvideo.aistudio.data.local.SceneEntity

/** Builds a reviewable prompt from approved scene direction and explicit character sheets only. */
object SceneImagePromptBuilder {
    fun build(scene: SceneEntity, characters: List<CharacterEntity>, style: String = "cinematic, high detail"): String {
        val referenced = scene.characterRefs.split(',', '،', ';')
            .map(String::trim).filter(String::isNotBlank).toSet()
        val sheets = characters.filter { it.name in referenced }.map { character ->
            buildString {
                append(character.name)
                if (character.age > 0) append(", age ${character.age}")
                if (character.appearance.isNotBlank()) append(", ${character.appearance}")
                if (character.facialFeatures.isNotBlank()) append(", facial features: ${character.facialFeatures}")
                if (character.clothing.isNotBlank()) append(", clothing: ${character.clothing}")
            }
        }
        return buildString {
            append("Create one coherent still image for this storyboard scene. ")
            append("Scene: ${scene.title}. ${scene.description}. ")
            if (scene.visualPrompt.isNotBlank()) append("Visual direction: ${scene.visualPrompt}. ")
            if (scene.location.isNotBlank()) append("Location: ${scene.location}. ")
            if (scene.lighting.isNotBlank()) append("Lighting: ${scene.lighting}. ")
            if (scene.atmosphere.isNotBlank()) append("Atmosphere: ${scene.atmosphere}. ")
            if (sheets.isNotEmpty()) append("Keep these approved character designs consistent: ${sheets.joinToString("; ")}. ")
            append("Style: $style. Maintain visual continuity; do not add text, captions, logos, or watermarks.")
        }
    }
}
