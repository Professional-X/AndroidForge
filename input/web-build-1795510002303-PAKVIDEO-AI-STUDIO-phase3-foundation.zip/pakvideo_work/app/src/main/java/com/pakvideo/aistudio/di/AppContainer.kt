package com.pakvideo.aistudio.di

import android.content.Context
import com.pakvideo.aistudio.data.local.AppDatabase
import com.pakvideo.aistudio.data.preferences.SettingsStore
import com.pakvideo.aistudio.data.remote.GeminiApiClient
import com.pakvideo.aistudio.data.repository.ProjectRepository
import com.pakvideo.aistudio.data.repository.ProjectRepositoryImpl
import com.pakvideo.aistudio.domain.agents.CharacterConsistencyAgent
import com.pakvideo.aistudio.domain.agents.DirectorAgent
import com.pakvideo.aistudio.domain.agents.MasterOrchestrator
import com.pakvideo.aistudio.domain.agents.StoryAgent
import com.pakvideo.aistudio.domain.guard.FreeBudgetGuard
import com.pakvideo.aistudio.domain.statemachine.ProductionStateMachine
import com.pakvideo.aistudio.domain.image.DisabledImageProvider
import com.pakvideo.aistudio.domain.image.ImageProviderId
import com.pakvideo.aistudio.domain.image.ImageTaskManager

class AppContainer(context: Context) {

    private val appContext = context.applicationContext

    val settingsStore: SettingsStore by lazy { SettingsStore(appContext) }

    val database: AppDatabase by lazy { AppDatabase.getInstance(appContext) }

    val repository: ProjectRepository by lazy {
        ProjectRepositoryImpl(
            database.projectDao(),
            database.sceneDao(),
            database.characterDao(),
            database.taskEventDao()
        )
    }

    val stateMachine: ProductionStateMachine by lazy { ProductionStateMachine() }

    /** Providers remain explicitly disabled until a real, supported API adapter is configured. */
    val imageTaskManager: ImageTaskManager by lazy {
        ImageTaskManager(
            database.imageTaskDao(), database.sceneDao(), database.characterDao(),
            listOf(
                DisabledImageProvider(ImageProviderId.GEMINI_IMAGEN, "Gemini/Imagen adapter is not implemented yet"),
                DisabledImageProvider(ImageProviderId.GENERIC_REMOTE, "No remote image provider is configured"),
                DisabledImageProvider(ImageProviderId.LOCAL, "No on-device image model is installed")
            )
        )
    }

    val geminiClient: GeminiApiClient by lazy { GeminiApiClient() }

    val guard: FreeBudgetGuard by lazy {
        FreeBudgetGuard(
            { settingsStore.getGeminiApiKey() },
            { settingsStore.isFreeTierConfirmed() },
            { settingsStore.getGeminiProxyUrl() }
        )
    }

    val storyAgent: StoryAgent by lazy {
        StoryAgent(
            guard,
            geminiClient,
            { settingsStore.getGeminiApiKey() },
            { settingsStore.getGeminiModel() },
            { settingsStore.getGeminiProxyUrl() }
        )
    }

    val directorAgent: DirectorAgent by lazy { DirectorAgent() }

    val characterAgent: CharacterConsistencyAgent by lazy { CharacterConsistencyAgent() }

    val orchestrator: MasterOrchestrator by lazy {
        MasterOrchestrator(repository, stateMachine, storyAgent, directorAgent, characterAgent, guard)
    }
}
