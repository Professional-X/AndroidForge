package com.pakvideo.aistudio.ui.theme

import androidx.compose.ui.graphics.Color

// Dark cinematic palette (exact values from CONTRACT.md).
val Background = Color(0xFF0B0B10)
val Surface = Color(0xFF17171F)
val SurfaceVariant = Color(0xFF1F1F2A)
val PrimaryGold = Color(0xFFD9A441)
val OnPrimary = Color(0xFF1A1206)
val SecondaryBlue = Color(0xFF7FB3D5)
val ErrorRed = Color(0xFFCF6679)
val OnBackground = Color(0xFFF2F2F5)
val OnSurface = Color(0xFFE8E8EC)
val Outline = Color(0xFF3A3A48)
