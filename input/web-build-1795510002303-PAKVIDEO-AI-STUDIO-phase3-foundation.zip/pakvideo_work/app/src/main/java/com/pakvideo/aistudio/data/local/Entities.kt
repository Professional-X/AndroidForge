package com.pakvideo.aistudio.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String, // UUID
    val name: String,
    val userPrompt: String,
    val script: String = "",
    val characterDescriptions: String = "", // JSON of List<CharacterSheet>, may be empty
    val status: String = "IDLE", // ProjectState.name
    val errorLog: String = "",
    // Story genre (StoryGenre.name, v3). Default ISLAMIC for rows created
    // before v3; unknown stored values read back as ISLAMIC.
    val genre: String = "ISLAMIC",
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "scenes",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("projectId")]
)
data class SceneEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: String,
    val orderIndex: Int,
    val title: String,
    val description: String,
    val cameraAngle: String = "",
    val cameraMovement: String = "",
    val lighting: String = "",
    val location: String = "",
    val atmosphere: String = "",
    val characterRefs: String = "",
    // One-sentence visual direction from the DirectorAgent (v2).
    val visualPrompt: String = "",
    val status: String = "IDLE"
)

@Entity(
    tableName = "characters",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("projectId")]
)
data class CharacterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: String,
    val name: String,
    val age: Int = 0,
    val appearance: String = "",
    val clothing: String = "",
    val facialFeatures: String = "",
    // Main character (speaks repeatedly / mentioned often) vs supporting (v2).
    val isMainCharacter: Boolean = false,
    // Dialogue lines + narration mentions of this name in the story (v2).
    val mentionCount: Int = 0,
    val referenceImagePath: String? = null
)

@Entity(
    tableName = "task_events",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("projectId")]
)
data class TaskEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: String,
    val timestamp: Long,
    val state: String, // ProjectState.name at the time
    val message: String,
    val type: String // "INFO" | "ERROR" | "APPROVAL"
)
