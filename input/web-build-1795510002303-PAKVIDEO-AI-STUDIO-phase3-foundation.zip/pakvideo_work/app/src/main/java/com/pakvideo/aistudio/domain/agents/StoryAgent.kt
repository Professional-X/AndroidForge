package com.pakvideo.aistudio.domain.agents

import com.pakvideo.aistudio.data.remote.GeminiApiClient
import com.pakvideo.aistudio.data.remote.GeminiModels
import com.pakvideo.aistudio.domain.guard.FreeBudgetGuard
import com.pakvideo.aistudio.domain.guard.GuardDecision
import com.pakvideo.aistudio.domain.guard.ProviderId
import com.pakvideo.aistudio.domain.model.DialogueLine
import com.pakvideo.aistudio.domain.model.StoryDraft
import com.pakvideo.aistudio.domain.model.StoryGenre

/**
 * Where the last story created by this agent came from. The orchestrator
 * reads [lastStorySource] / [lastFallbackReason] after every
 * [createStory] call and records them in the event log and the approval
 * description, so a real Gemini story and a local fallback draft are
 * never confused — in the UI, in the logs, or in the saved script's
 * history.
 */
enum class StorySource {
    GEMINI,
    LOCAL_FALLBACK
}

/**
 * Builds a story draft from the user's prompt, in the user's chosen
 * [StoryGenre].
 *
 * [createStory] first asks the [FreeBudgetGuard] about
 * [ProviderId.GEMINI_TEXT]. The guard allows Gemini in two modes:
 * - DIRECT: the user entered their own free Gemini API key AND confirmed
 *   in Settings that the key belongs to a billing-free project.
 * - PROXY: a server-side proxy is configured — no local key is needed,
 *   but the free-tier confirmation is still required (the proxy must
 *   enforce free-only use with its own server-side key; the app cannot
 *   verify that either).
 * When the guard allows it and a [geminiClient] is present, the story is
 * generated with the real Gemini API and returned with
 * [StoryDraft.isLocalDraft] = false and [lastStorySource] =
 * [StorySource.GEMINI]. On ANY Gemini failure — or when the guard blocks
 * — it falls back to a clearly-labelled LOCAL draft
 * ([StoryDraft.isLocalDraft] = true, [lastStorySource] =
 * [StorySource.LOCAL_FALLBACK], [lastFallbackReason] set): an outline
 * written around the user's own prompt. A local draft is never model
 * output and must never be presented as such. Local drafts are built
 * entirely on-device and make no network call.
 *
 * The model is never chosen silently: only models on
 * [GeminiModels.FREE_TIER_MODELS] are ever called. A configured model
 * outside that list (for example a paid model, or a retired one like
 * `gemini-2.0-flash`) is refused with a recorded reason and the local
 * draft is used instead.
 *
 * Genre: the prompt asks Gemini for the user's selected genre
 * ([StoryGenre.promptGuidance]). There is NO family-friendly-only rule
 * in this agent — suspense and horror are supported genres. Provider
 * safety restrictions still apply: the app never asks the model to
 * bypass them, and the model enforces its own safety rules.
 *
 * When [proxyBaseUrlProvider] returns a non-blank URL, Gemini requests
 * go to that server-side proxy instead of Google directly, and NO API
 * key is sent from the device (see [GeminiApiClient]) — not even when
 * the user happens to have a key saved locally.
 */
class StoryAgent(
    private val guard: FreeBudgetGuard,
    private val geminiClient: GeminiApiClient? = null,
    private val apiKeyProvider: (() -> String?)? = null,
    private val modelProvider: (() -> String?)? = null,
    private val proxyBaseUrlProvider: (() -> String?)? = null
) {

    var lastStorySource: StorySource = StorySource.LOCAL_FALLBACK
        private set

    /**
     * Why the last story fell back to a local draft, or null when the
     * last story came from Gemini. Never contains an API key.
     */
    var lastFallbackReason: String? = null
        private set

    fun detectLanguage(prompt: String): String {
        return if (prompt.any { it in '\u0600'..'\u06FF' }) "ur" else "en"
    }

    suspend fun createStory(
        userPrompt: String,
        language: String,
        genre: StoryGenre = StoryGenre.ISLAMIC
    ): StoryDraft {
        val decision = guard.check(ProviderId.GEMINI_TEXT)
        if (decision is GuardDecision.Allowed) {
            val proxyBaseUrl = proxyBaseUrlProvider?.invoke()?.trim()?.takeIf { it.isNotEmpty() }
            val isProxy = proxyBaseUrl != null
            val model = modelProvider?.invoke()?.ifBlank { null } ?: GeminiModels.DEFAULT_MODEL
            if (!GeminiModels.isFreeTierModel(model)) {
                lastStorySource = StorySource.LOCAL_FALLBACK
                lastFallbackReason = "Model '$model' is not on the app's free-tier " +
                    "list (verified ${GeminiModels.LIST_VERIFIED}). Only free-tier " +
                    "models are used; change the model in Settings."
                return localDraft(userPrompt, language, genre)
            }
            if (geminiClient != null) {
                // Proxy mode: never send a device key — pass an empty key
                // (the client sends no key header at all for a proxy).
                // Direct mode: the guard already ensured a key exists.
                val keyForCall = if (isProxy) "" else apiKeyProvider?.invoke().orEmpty()
                if (isProxy || keyForCall.isNotBlank()) {
                    val (geminiDraft, failureReason) = tryGeminiStory(
                        userPrompt, language, genre, keyForCall, model, proxyBaseUrl
                    )
                    if (geminiDraft != null) {
                        lastStorySource = StorySource.GEMINI
                        lastFallbackReason = null
                        return geminiDraft
                    }
                    lastStorySource = StorySource.LOCAL_FALLBACK
                    lastFallbackReason = failureReason
                    return localDraft(userPrompt, language, genre)
                }
            }
            lastStorySource = StorySource.LOCAL_FALLBACK
            lastFallbackReason = if (isProxy) {
                "Gemini client is not configured"
            } else if (apiKeyProvider?.invoke().isNullOrBlank()) {
                "Gemini API key is missing"
            } else {
                "Gemini client is not configured"
            }
            return localDraft(userPrompt, language, genre)
        }
        lastStorySource = StorySource.LOCAL_FALLBACK
        lastFallbackReason = if (decision is GuardDecision.Blocked) {
            "Gemini unavailable: ${decision.reason}"
        } else {
            "Gemini unavailable"
        }
        return localDraft(userPrompt, language, genre)
    }

    /**
     * Returns the parsed Gemini story, or (null, reason) when Gemini
     * could not produce one. The reason never contains the API key.
     */
    private suspend fun tryGeminiStory(
        userPrompt: String,
        language: String,
        genre: StoryGenre,
        apiKey: String,
        model: String,
        proxyBaseUrl: String?
    ): Pair<StoryDraft?, String?> {
        val languageName = if (language == "ur") "Urdu" else "English"
        val prompt = "Write an original short story in $languageName based on this idea: " +
            "\"$userPrompt\". Make it ${genre.promptGuidance}. " +
            "Reply in exactly this format:\n" +
            "Title: <story title>\n" +
            "Hook: <one gripping opening sentence>\n" +
            "Narration: <three short paragraphs, separated by blank lines>\n" +
            "Dialogue:\n" +
            "<Speaker>: <line>\n" +
            "<Speaker>: <line>\n" +
            "Keep the story original and under 400 words."
        val result = geminiClient?.generateText(apiKey, model, prompt, proxyBaseUrl)
            ?: return null to "Gemini client is not configured"
        val text = result.getOrNull()
            ?: return null to "Gemini request failed: ${result.exceptionOrNull()?.message}"
        val parsed = parseGeminiStory(text, language, genre)
            ?: return null to "Gemini response had no usable story"
        return parsed to null
    }

    /**
     * Parses the strict Title/Hook/Narration/Dialogue format. Returns null
     * when the response has no usable title and narration, so the caller
     * falls back to the local draft.
     */
    private fun parseGeminiStory(text: String, language: String, genre: StoryGenre): StoryDraft? {
        var title = ""
        var hook = ""
        val narrationLines = mutableListOf<String>()
        val dialogue = mutableListOf<DialogueLine>()
        var inDialogue = false
        var inNarration = false
        for (rawLine in text.lines()) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue
            when {
                line.startsWith("Title:", ignoreCase = true) -> {
                    title = line.substringAfter(":").trim()
                    inDialogue = false
                    inNarration = false
                }
                line.startsWith("Hook:", ignoreCase = true) -> {
                    hook = line.substringAfter(":").trim()
                    inDialogue = false
                    inNarration = false
                }
                line.startsWith("Narration:", ignoreCase = true) -> {
                    val rest = line.substringAfter(":").trim()
                    if (rest.isNotEmpty()) narrationLines.add(rest)
                    inNarration = true
                    inDialogue = false
                }
                line.startsWith("Dialogue:", ignoreCase = true) -> {
                    inDialogue = true
                    inNarration = false
                }
                inDialogue -> {
                    val speaker = line.substringBefore(":").trim()
                    val spoken = line.substringAfter(":", "").trim()
                    if (speaker.isNotEmpty() && spoken.isNotEmpty() && speaker.length <= 30) {
                        dialogue.add(DialogueLine(speaker, spoken))
                    }
                }
                inNarration -> narrationLines.add(line)
                title.isEmpty() -> title = line
                else -> narrationLines.add(line)
            }
        }
        val narration = narrationLines.joinToString("\n\n")
        if (title.isEmpty() && narration.isEmpty()) return null
        return StoryDraft(
            title = title.ifEmpty { "Untitled story" },
            hook = hook,
            narration = narration,
            dialogue = dialogue,
            language = language,
            isLocalDraft = false,
            genre = genre
        )
    }

    private fun localDraft(
        userPrompt: String,
        language: String,
        genre: StoryGenre = StoryGenre.ISLAMIC
    ): StoryDraft {
        val topic = userPrompt.trim()
        val title = topic.take(60).ifEmpty { "Untitled story" }

        val hookPrefix = if (language == "ur") "ہک: " else "Hook: "
        val firstClause = firstClause(topic)
        val hook = hookPrefix + firstClause

        val genreLabel = genre.displayName.lowercase()
        val narration = listOf(
            "Local draft outline for a $genreLabel story: $topic. " +
                "This opening sets up the story and introduces the main idea.",
            "The story then develops the idea from the prompt, building on " +
                "\"$topic\" step by step.",
            "Finally, the story closes with a simple ending that reflects on " +
                "\"$topic\"."
        ).joinToString("\n\n")

        return StoryDraft(
            title = title,
            hook = hook,
            narration = narration,
            dialogue = emptyList<DialogueLine>(),
            language = language,
            isLocalDraft = true,
            genre = genre
        )
    }

    /**
     * First clause of the prompt: up to the first sentence terminator
     * ('.', '!', '?', '۔', '؟'), or the first 80 characters if there is
     * no terminator.
     */
    private fun firstClause(prompt: String): String {
        val terminators = setOf('.', '!', '?', '۔', '؟')
        val endIndex = prompt.indexOfFirst { it in terminators }
        val clause = if (endIndex >= 0) prompt.substring(0, endIndex).trim() else prompt.trim()
        return clause.take(80)
    }
}
