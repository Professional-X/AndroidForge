package com.pakvideo.aistudio.data.preferences

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.pakvideo.aistudio.data.remote.GeminiModels
import com.pakvideo.aistudio.data.remote.ProxyUrlValidator

class SettingsStore(context: Context) {

    private val appContext = context.applicationContext

    private val securePrefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(appContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            appContext,
            "pakvideo_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    private val plainPrefs: SharedPreferences by lazy {
        appContext.getSharedPreferences("pakvideo_prefs", Context.MODE_PRIVATE)
    }

    fun saveGeminiApiKey(key: String) {
        val cleanedKey = key.trim()
        val previousKey = getGeminiApiKey()
        securePrefs.edit().putString("gemini_api_key", cleanedKey).apply()
        // The user's free-tier attestation applies to one key/project only.
        // A replacement key must be confirmed again before any API call.
        if (previousKey != cleanedKey) setFreeTierConfirmed(false)
    }

    fun getGeminiApiKey(): String? {
        return securePrefs.getString("gemini_api_key", null)
    }

    fun clearGeminiApiKey() {
        securePrefs.edit().remove("gemini_api_key").apply()
    }

    fun getGeminiModel(): String {
        return plainPrefs.getString("gemini_model", GeminiModels.DEFAULT_MODEL)
            ?: GeminiModels.DEFAULT_MODEL
    }

    fun setGeminiModel(model: String) {
        plainPrefs.edit().putString("gemini_model", model).apply()
    }

    /**
     * Free-tier attestation for the stored Gemini key (plain prefs, NOT a
     * secret — it is only a boolean the user toggles in Settings).
     *
     * Default false: a key alone never counts as free quota. The user must
     * explicitly confirm the key belongs to a project with billing
     * DISABLED. This is an attestation, not a verification — the app has
     * no way to check a project's billing status (see FreeBudgetGuard).
     */
    fun isFreeTierConfirmed(): Boolean {
        return plainPrefs.getBoolean("gemini_free_tier_confirmed", false)
    }

    fun setFreeTierConfirmed(confirmed: Boolean) {
        plainPrefs.edit().putBoolean("gemini_free_tier_confirmed", confirmed).apply()
    }

    /**
     * Optional server-side Gemini proxy base URL (plain prefs, NOT a
     * secret). When set, the app sends Gemini requests to
     * `<proxy>/v1beta/models/<model>:generateContent` and never sends an
     * API key from the device — the proxy injects the key server-side.
     * Empty means direct Google endpoint with the device key in the
     * `x-goog-api-key` header. Production use should prefer the proxy.
     */
    fun getGeminiProxyUrl(): String {
        return plainPrefs.getString("gemini_proxy_url", "") ?: ""
    }

    fun setGeminiProxyUrl(url: String) {
        require(ProxyUrlValidator.isValidOrEmpty(url)) {
            "Proxy URL must be a valid HTTPS URL without credentials, query or fragment."
        }
        val cleanedUrl = url.trim()
        val previousUrl = getGeminiProxyUrl()
        plainPrefs.edit().putString("gemini_proxy_url", cleanedUrl).apply()
        // A different proxy may use a different cloud project/key. Do not
        // carry the old free-tier attestation to the new endpoint.
        if (previousUrl != cleanedUrl) setFreeTierConfirmed(false)
    }

    fun setLanguage(code: String) {
        plainPrefs.edit().putString("language", code).apply()
    }

    fun getLanguage(): String {
        return plainPrefs.getString("language", "en") ?: "en"
    }

    fun isFreeOnlyMode(): Boolean {
        return true
    }

    fun getStorageInfo(): String {
        return try {
            val filesDir = appContext.filesDir
            val dbFile = appContext.getDatabasePath("pakvideo.db")
            val dbInfo = if (dbFile.exists()) {
                "Database: ${dbFile.absolutePath} (${dbFile.length()} bytes)"
            } else {
                "Database: not created yet"
            }
            "Files dir: ${filesDir.absolutePath}\n$dbInfo"
        } catch (e: Exception) {
            "Storage info unavailable"
        }
    }
}
