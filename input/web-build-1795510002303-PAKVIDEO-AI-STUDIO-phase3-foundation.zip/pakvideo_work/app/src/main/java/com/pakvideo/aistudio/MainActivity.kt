package com.pakvideo.aistudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.pakvideo.aistudio.di.AppContainer
import com.pakvideo.aistudio.ui.navigation.NavGraph
import com.pakvideo.aistudio.ui.theme.PakVideoTheme
import com.pakvideo.aistudio.ui.viewmodel.ViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = AppContainer(applicationContext)
        val factory = ViewModelFactory(container)
        setContent {
            PakVideoTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    NavGraph(container = container, factory = factory)
                }
            }
        }
    }
}
