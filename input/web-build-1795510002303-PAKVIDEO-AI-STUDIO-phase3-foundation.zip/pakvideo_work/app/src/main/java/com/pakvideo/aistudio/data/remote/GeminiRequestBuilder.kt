package com.pakvideo.aistudio.data.remote

import java.net.URLEncoder

/** Pure, testable Gemini endpoint and authentication-header construction. */
object GeminiRequestBuilder {

    private const val DIRECT_BASE = "https://generativelanguage.googleapis.com"

    fun urlFor(model: String, proxyBaseUrl: String?): String {
        val encodedModel = URLEncoder.encode(model, "UTF-8")
        require(ProxyUrlValidator.isValidOrEmpty(proxyBaseUrl)) {
            "Proxy URL must be a valid HTTPS URL without credentials, query or fragment."
        }
        val base = proxyBaseUrl?.trim()?.trimEnd('/')?.takeIf { it.isNotEmpty() } ?: DIRECT_BASE
        return "$base/v1beta/models/$encodedModel:generateContent"
    }

    /**
     * Headers for the request. Direct mode returns the key header;
     * proxy mode returns no key header (the proxy owns the key).
     * The returned map never contains the key under any other name.
     */
    fun headersFor(apiKey: String?, proxyBaseUrl: String?): Map<String, String> {
        require(ProxyUrlValidator.isValidOrEmpty(proxyBaseUrl)) {
            "Proxy URL must be a valid HTTPS URL without credentials, query or fragment."
        }
        val isProxy = !proxyBaseUrl.isNullOrBlank()
        return if (isProxy) {
            emptyMap()
        } else {
            val key = apiKey?.takeIf { it.isNotBlank() } ?: return emptyMap()
            mapOf("x-goog-api-key" to key)
        }
    }
}

