package com.pakvideo.aistudio.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.pakvideo.aistudio.R
import com.pakvideo.aistudio.domain.guard.ProviderInfo
import com.pakvideo.aistudio.domain.guard.ProviderStatus
import com.pakvideo.aistudio.domain.model.ApprovalRequest

@Composable
fun StatusChip(status: String) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = MaterialTheme.shapes.small
    ) {
        Text(
            text = status,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
fun ApprovalCard(
    approval: ApprovalRequest,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = stringResource(R.string.plan_approval_title),
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = approval.description, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(12.dp))
            Row {
                Button(onClick = onApprove) {
                    Text(text = stringResource(R.string.approve))
                }
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedButton(onClick = onReject) {
                    Text(text = stringResource(R.string.reject))
                }
            }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(vertical = 8.dp)
    )
}

@Composable
fun ProviderRow(provider: ProviderInfo) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = provider.displayName,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = when (provider.status) {
                    ProviderStatus.ENABLED -> "Enabled"
                    ProviderStatus.DISABLED -> "Disabled"
                    ProviderStatus.LOCAL_ONLY -> "Local only"
                },
                style = MaterialTheme.typography.labelLarge,
                color = when (provider.status) {
                    ProviderStatus.ENABLED -> MaterialTheme.colorScheme.primary
                    ProviderStatus.DISABLED -> MaterialTheme.colorScheme.error
                    ProviderStatus.LOCAL_ONLY -> MaterialTheme.colorScheme.secondary
                }
            )
        }
        Text(
            text = provider.reason,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
        )
        provider.model?.let { model ->
            Text(
                text = model,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
    }
}
