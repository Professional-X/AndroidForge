package com.pakvideo.aistudio.domain.guard

enum class ProviderId {
    GEMINI_TEXT, IMAGE_GENERATION, VEO_VIDEO, MUSE_IMAGE, MUSE_VIDEO, URDU_TTS, LOCAL_EDITING
}

enum class ProviderStatus { ENABLED, DISABLED, LOCAL_ONLY }

data class ProviderInfo(
    val id: ProviderId,
    val displayName: String,
    val status: ProviderStatus,
    val reason: String,
    val model: String? = null
)

/**
 * Static provider table for Phase 1-2.
 *
 * model is null because the Gemini model is selected dynamically in
 * Settings. Gemini text is conditionally available through FreeBudgetGuard;
 * image/video providers remain disabled, and Urdu TTS is local-only.
 */
object ProviderRegistry {

    private val providers: List<ProviderInfo> = listOf(
        ProviderInfo(
            id = ProviderId.GEMINI_TEXT,
            displayName = "Gemini Text",
            status = ProviderStatus.DISABLED,
            reason = "Conditionally available after a key or HTTPS proxy is configured and free-tier use is confirmed."
        ),
        ProviderInfo(
            id = ProviderId.IMAGE_GENERATION,
            displayName = "Image Generation",
            status = ProviderStatus.DISABLED,
            reason = "Image generation arrives in Phase 3."
        ),
        ProviderInfo(
            id = ProviderId.VEO_VIDEO,
            displayName = "Veo Video",
            status = ProviderStatus.DISABLED,
            reason = "No free generation quota available."
        ),
        ProviderInfo(
            id = ProviderId.MUSE_IMAGE,
            displayName = "Muse Image",
            status = ProviderStatus.DISABLED,
            reason = "No supported official API available."
        ),
        ProviderInfo(
            id = ProviderId.MUSE_VIDEO,
            displayName = "Muse Video",
            status = ProviderStatus.DISABLED,
            reason = "No supported official API available."
        ),
        ProviderInfo(
            id = ProviderId.URDU_TTS,
            displayName = "Urdu TTS",
            status = ProviderStatus.LOCAL_ONLY,
            reason = "Local Android TTS fallback only (Phase 5)."
        ),
        ProviderInfo(
            id = ProviderId.LOCAL_EDITING,
            displayName = "Local Editing",
            status = ProviderStatus.DISABLED,
            reason = "Local editing arrives in Phase 5."
        )
    )

    fun all(): List<ProviderInfo> = providers

    fun get(id: ProviderId): ProviderInfo =
        providers.first { it.id == id }
}
