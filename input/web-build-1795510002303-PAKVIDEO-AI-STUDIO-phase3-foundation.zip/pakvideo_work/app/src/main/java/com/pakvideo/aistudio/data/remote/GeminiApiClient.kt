package com.pakvideo.aistudio.data.remote

import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Minimal Gemini API client (official REST endpoint, no new dependencies:
 * HttpURLConnection + org.json are built into Android).
 *
 * The API key is supplied by the caller on every call — this class never
 * stores, logs or hardcodes a key, never puts it in a URL, and never
 * includes it (or the request URL) in an error message. When
 * [proxyBaseUrl] is set, the key is not sent at all: the server-side
 * proxy authenticates instead. All failures surface as
 * [Result.failure]; callers fall back to local behaviour. The class and
 * [generateText] are open so tests can substitute a fake client.
 */
open class GeminiApiClient {

    open suspend fun generateText(
        apiKey: String,
        model: String,
        prompt: String,
        proxyBaseUrl: String? = null
    ): Result<String> {
        return withContext(Dispatchers.IO) {
            try {
                val url = URL(GeminiRequestBuilder.urlFor(model, proxyBaseUrl))
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/json")
                    for ((name, value) in GeminiRequestBuilder.headersFor(apiKey, proxyBaseUrl)) {
                        setRequestProperty(name, value)
                    }
                    connectTimeout = 30000
                    readTimeout = 30000
                    doOutput = true
                }
                val body = JSONObject().apply {
                    put(
                        "contents",
                        JSONArray().put(
                            JSONObject().put(
                                "parts",
                                JSONArray().put(JSONObject().put("text", prompt))
                            )
                        )
                    )
                }.toString()
                OutputStreamWriter(connection.outputStream, "UTF-8").use { it.write(body) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = BufferedReader(InputStreamReader(stream, "UTF-8")).use { it.readText() }
                connection.disconnect()
                if (code !in 200..299) {
                    // Deliberately no URL, no key, no response body: an error
                    // body could echo back request details.
                    return@withContext Result.failure(
                        IllegalStateException("Gemini request failed: HTTP $code")
                    )
                }
                val text = JSONObject(response)
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                Result.success(text)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
}
