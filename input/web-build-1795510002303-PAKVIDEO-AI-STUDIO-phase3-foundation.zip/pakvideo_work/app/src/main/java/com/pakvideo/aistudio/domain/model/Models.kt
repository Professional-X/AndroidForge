package com.pakvideo.aistudio.domain.model

enum class ProjectState {
    IDLE, PLANNING, AWAITING_APPROVAL, SCRIPTING, STORYBOARDING,
    IMAGE_GENERATION, VIDEO_GENERATION, VOICE_GENERATION,
    EDITING, QUALITY_CHECK, COMPLETED, FAILED
}

data class DialogueLine(val speaker: String, val line: String)

/**
 * Story genres the user can pick per project. The genre steers the
 * story's tone and structure — it is NOT a content filter. Provider
 * safety restrictions still apply (the model enforces its own safety
 * rules; the app never asks it to bypass them), but the app itself does
 * not force every story to be family-friendly: suspense and horror are
 * legitimate genres here. The stored name is the enum name
 * ("ISLAMIC", "HORROR", ...); unknown stored names read back as
 * [ISLAMIC].
 */
enum class StoryGenre(
    /** Short English display name (UI localises it via strings). */
    val displayName: String,
    /** Direction line sent to Gemini (and reflected in local drafts). */
    val promptGuidance: String
) {
    ISLAMIC(
        "Islamic",
        "an Islamic story rooted in faith, good character and timeless moral lessons"
    ),
    MORAL(
        "Moral",
        "a moral story where a clear ethical choice and its consequences drive the plot"
    ),
    DOCUMENTARY(
        "Documentary",
        "a documentary-style story that explains a real subject clearly, with facts and wonder"
    ),
    SUSPENSE(
        "Suspense",
        "a suspense story with tension, mystery and a surprising turn"
    ),
    HORROR(
        "Horror",
        "a horror story with an eerie atmosphere and frightening moments"
    ),
    ACTION(
        "Action",
        "an action story with fast movement, chases and daring feats"
    ),
    ADVENTURE(
        "Adventure",
        "an adventure story with a journey, discovery and danger overcome"
    );

    companion object {
        fun fromStoredName(name: String?): StoryGenre {
            if (name.isNullOrBlank()) return ISLAMIC
            return entries.firstOrNull { it.name == name.trim().uppercase() } ?: ISLAMIC
        }
    }
}

data class StoryDraft(
    val title: String,
    val hook: String,
    val narration: String,
    val dialogue: List<DialogueLine>,
    val language: String,
    val isLocalDraft: Boolean,
    val genre: StoryGenre = StoryGenre.ISLAMIC
)

data class ScenePlan(
    val orderIndex: Int,
    val title: String,
    val description: String,
    val cameraAngle: String,
    val cameraMovement: String,
    val lighting: String,
    val location: String,
    val atmosphere: String,
    val characterNames: List<String>,
    // One-sentence visual direction derived from this scene's own text
    // (camera + subject + location + lighting + mood). Empty only for
    // plans built by older code; the DirectorAgent always fills it.
    val visualPrompt: String = ""
)

data class CharacterSheet(
    val name: String,
    val age: Int, // age 0 = unknown
    val appearance: String,
    val clothing: String,
    val facialFeatures: String,
    // True when the character is a main character: speaks in dialogue
    // and is mentioned repeatedly. Derived, never set by hand.
    val isMainCharacter: Boolean = false,
    // Dialogue lines + narration mentions of this name in the story.
    val mentionCount: Int = 0
)

data class ProductionPlan(
    val projectId: String,
    val title: String,
    val story: StoryDraft,
    val scenes: List<ScenePlan>,
    val characters: List<CharacterSheet>
)

enum class ApprovalType {
    PLAN_APPROVAL, STORY_CONCEPT_CHANGE, MAJOR_CHARACTER_CHANGE,
    REMOVE_IMPORTANT_SCENE, MAJOR_CREATIVE_ALTERNATIVE
}

data class ApprovalRequest(
    val id: String,
    val projectId: String,
    val type: ApprovalType,
    val description: String,
    val createdAt: Long
)
