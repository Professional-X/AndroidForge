package com.pakvideo.aistudio.domain.image

/** Provider contract. Implementations must return only after validating and saving real image bytes. */
interface ImageGenerationProvider {
    val id: ImageProviderId
    suspend fun isAvailable(): Boolean
    suspend fun generate(request: ImageGenerationRequest): ImageGenerationResult
}

/** Explicitly disabled until a supported, configured API adapter is implemented. */
class DisabledImageProvider(
    override val id: ImageProviderId,
    private val reason: String
) : ImageGenerationProvider {
    override suspend fun isAvailable(): Boolean = false
    override suspend fun generate(request: ImageGenerationRequest): ImageGenerationResult =
        ImageGenerationResult.Unavailable(id, reason)
}
