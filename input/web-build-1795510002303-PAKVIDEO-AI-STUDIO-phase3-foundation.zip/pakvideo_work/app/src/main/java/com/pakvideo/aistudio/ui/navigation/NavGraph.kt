package com.pakvideo.aistudio.ui.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pakvideo.aistudio.di.AppContainer
import com.pakvideo.aistudio.ui.screens.AgentChatScreen
import com.pakvideo.aistudio.ui.screens.HomeScreen
import com.pakvideo.aistudio.ui.screens.MyCreationsScreen
import com.pakvideo.aistudio.ui.screens.SettingsScreen
import com.pakvideo.aistudio.ui.screens.WorkspaceScreen
import com.pakvideo.aistudio.ui.viewmodel.CreationsViewModel
import com.pakvideo.aistudio.ui.viewmodel.HomeViewModel
import com.pakvideo.aistudio.ui.viewmodel.ProductionViewModel
import com.pakvideo.aistudio.ui.viewmodel.SettingsViewModel
import com.pakvideo.aistudio.ui.viewmodel.ViewModelFactory
import com.pakvideo.aistudio.ui.viewmodel.WorkspaceViewModel

@Composable
fun NavGraph(container: AppContainer, factory: ViewModelFactory) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            val vm: HomeViewModel = viewModel(factory = factory.home())
            HomeScreen(
                viewModel = vm,
                onOpenChat = { projectId -> navController.navigate("chat/$projectId") },
                onOpenCreations = { navController.navigate("creations") },
                onOpenSettings = { navController.navigate("settings") }
            )
        }
        composable(
            route = "chat/{projectId}",
            arguments = listOf(navArgument("projectId") { type = NavType.StringType })
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getString("projectId") ?: return@composable
            val vm: ProductionViewModel = viewModel(factory = factory.production(projectId))
            AgentChatScreen(
                viewModel = vm,
                onOpenWorkspace = { navController.navigate("workspace/$projectId") },
                onBack = { navController.popBackStack() }
            )
        }
        composable(
            route = "workspace/{projectId}",
            arguments = listOf(navArgument("projectId") { type = NavType.StringType })
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getString("projectId") ?: return@composable
            val vm: WorkspaceViewModel = viewModel(factory = factory.workspace(projectId))
            WorkspaceScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() }
            )
        }
        composable("creations") {
            val vm: CreationsViewModel = viewModel(factory = factory.creations())
            MyCreationsScreen(
                viewModel = vm,
                onOpenChat = { projectId -> navController.navigate("chat/$projectId") },
                onBack = { navController.popBackStack() }
            )
        }
        composable("settings") {
            val vm: SettingsViewModel = viewModel(factory = factory.settings())
            SettingsScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
