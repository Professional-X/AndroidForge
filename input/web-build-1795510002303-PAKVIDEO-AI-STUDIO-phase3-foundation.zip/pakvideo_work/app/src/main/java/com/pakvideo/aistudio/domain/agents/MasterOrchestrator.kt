package com.pakvideo.aistudio.domain.agents

import com.pakvideo.aistudio.data.local.CharacterEntity
import com.pakvideo.aistudio.data.local.ProjectEntity
import com.pakvideo.aistudio.data.local.SceneEntity
import com.pakvideo.aistudio.data.local.TaskEventEntity
import com.pakvideo.aistudio.data.repository.ProjectRepository
import com.pakvideo.aistudio.domain.guard.FreeBudgetGuard
import com.pakvideo.aistudio.domain.guard.GuardDecision
import com.pakvideo.aistudio.domain.guard.ProviderId
import com.pakvideo.aistudio.domain.model.ApprovalRequest
import com.pakvideo.aistudio.domain.model.ApprovalType
import com.pakvideo.aistudio.domain.model.ProjectState
import com.pakvideo.aistudio.domain.model.StoryGenre
import com.pakvideo.aistudio.domain.statemachine.ProductionStateMachine
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Runs the Phase 1-2 production pipeline:
 *
 * PLANNING -> SCRIPTING (Gemini story, or a clearly-labelled local
 * fallback draft when Gemini is unavailable) -> STORYBOARDING (scenes +
 * characters) -> AWAITING_APPROVAL, then STOPS for the user. The story
 * source (real Gemini vs local fallback) is logged as an event and
 * stated in the approval description.
 *
 * No image, video or voice generation happens in Phase 1-2: approving a
 * plan still ends in FAILED with an honest message, never a faked asset.
 * Every state change is persisted via [ProjectRepository.updateProjectState]
 * and recorded as a [TaskEventEntity].
 */
class MasterOrchestrator(
    private val repository: ProjectRepository,
    private val stateMachine: ProductionStateMachine,
    private val storyAgent: StoryAgent,
    private val directorAgent: DirectorAgent,
    private val characterAgent: CharacterConsistencyAgent,
    private val guard: FreeBudgetGuard
) {

    companion object {
        const val MAX_RETRIES = 3
    }

    private val _pendingApproval = MutableStateFlow<ApprovalRequest?>(null)
    val pendingApproval: StateFlow<ApprovalRequest?> = _pendingApproval

    suspend fun startProduction(projectId: String) {
        val project = repository.getProject(projectId)
            ?: throw IllegalArgumentException("Project not found: $projectId")
        var currentState = stateOf(project)
        if (currentState != ProjectState.IDLE &&
            currentState != ProjectState.FAILED &&
            currentState != ProjectState.PLANNING
        ) {
            throw IllegalStateException("Cannot start production from state $currentState")
        }

        try {
            // PLANNING -> PLANNING is illegal, so skip the transition when
            // already PLANNING (e.g. after resume) and continue.
            currentState = moveTo(projectId, currentState, ProjectState.PLANNING)

            // 1. PLANNING: build a one-line plan summary, log it.
            val genre = StoryGenre.fromStoredName(project.genre)
            val planSummary =
                "Production plan for '${project.name}' (${genre.displayName} story): " +
                    "story and storyboard."
            logEvent(projectId, currentState, planSummary, "INFO")

            // 2. -> SCRIPTING: story draft, saved as the script. The
            // source is recorded right after creation (Fix 5): a real
            // Gemini story and a local fallback draft are never confused.
            currentState = moveTo(projectId, currentState, ProjectState.SCRIPTING)
            val language = storyAgent.detectLanguage(project.userPrompt)
            val story = withRetry(projectId, currentState) {
                storyAgent.createStory(project.userPrompt, language, genre)
            }
            val storySourceLabel = when (storyAgent.lastStorySource) {
                StorySource.GEMINI ->
                    "Story source: real Gemini generation"
                StorySource.LOCAL_FALLBACK ->
                    "Story source: LOCAL fallback draft — Gemini unavailable " +
                        "(${storyAgent.lastFallbackReason ?: "no reason recorded"}). " +
                        "The draft is an outline around the user's prompt, not model output."
            }
            logEvent(projectId, currentState, storySourceLabel, "INFO")
            val scriptText = buildScriptText(story)
            withRetry(projectId, currentState) {
                repository.updateScript(projectId, scriptText)
            }

            // 3. -> STORYBOARDING: scenes + characters, persisted.
            currentState = moveTo(projectId, currentState, ProjectState.STORYBOARDING)
            val characters = withRetry(projectId, currentState) {
                characterAgent.deriveCharacters(story)
            }
            val scenes = withRetry(projectId, currentState) {
                directorAgent.planScenes(story, characters)
            }
            // Rebuild is idempotent: clear prior generated rows before writing
            // the complete replacement. A later resume clears any partial set.
            repository.deleteProjectScenes(projectId)
            repository.deleteProjectCharacters(projectId)
            for (scene in scenes) {
                withRetry(projectId, currentState) {
                    repository.addScene(
                        SceneEntity(
                            projectId = projectId,
                            orderIndex = scene.orderIndex,
                            title = scene.title,
                            description = scene.description,
                            cameraAngle = scene.cameraAngle,
                            cameraMovement = scene.cameraMovement,
                            lighting = scene.lighting,
                            location = scene.location,
                            atmosphere = scene.atmosphere,
                            characterRefs = scene.characterNames.joinToString(", "),
                            visualPrompt = scene.visualPrompt,
                            status = "IDLE"
                        )
                    )
                }
            }
            for (sheet in characters) {
                withRetry(projectId, currentState) {
                    repository.addCharacter(
                        CharacterEntity(
                            projectId = projectId,
                            name = sheet.name,
                            age = sheet.age,
                            appearance = sheet.appearance,
                            clothing = sheet.clothing,
                            facialFeatures = sheet.facialFeatures,
                            isMainCharacter = sheet.isMainCharacter,
                            mentionCount = sheet.mentionCount
                        )
                    )
                }
            }
            // Keep the project's characterDescriptions in step with the sheets.
            val latest = repository.getProject(projectId) ?: project
            val characterDescriptions = characters.joinToString(
                prefix = "[", postfix = "]", separator = ","
            ) { sheet ->
                "{\"name\":\"${jsonEscape(sheet.name)}\",\"age\":${sheet.age}," +
                    "\"appearance\":\"${jsonEscape(sheet.appearance)}\"," +
                    "\"clothing\":\"${jsonEscape(sheet.clothing)}\"," +
                    "\"facialFeatures\":\"${jsonEscape(sheet.facialFeatures)}\"," +
                    "\"isMainCharacter\":${sheet.isMainCharacter}," +
                    "\"mentionCount\":${sheet.mentionCount}}"
            }
            repository.updateProject(
                latest.copy(
                    characterDescriptions = characterDescriptions,
                    updatedAt = System.currentTimeMillis()
                )
            )

            // 4. -> AWAITING_APPROVAL: expose the plan approval and STOP.
            // The approval description states the story source and the
            // genre, and that the storyboard is rule-based (keyword
            // derived, not AI-generated direction), so the user sees in
            // the approval card exactly what they are approving.
            currentState = moveTo(projectId, currentState, ProjectState.AWAITING_APPROVAL)
            val finalSummary =
                "Plan for '${story.title}' (${genre.displayName} story): " +
                    "${scenes.size} scenes, ${characters.size} characters. " +
                    "$storySourceLabel. ${DirectorAgent.DIRECTION_LABEL} " +
                    "Review the plan before image generation."
            val approval = ApprovalRequest(
                id = UUID.randomUUID().toString(),
                projectId = projectId,
                type = ApprovalType.PLAN_APPROVAL,
                description = finalSummary,
                createdAt = System.currentTimeMillis()
            )
            _pendingApproval.value = approval
            logEvent(projectId, currentState, finalSummary, "APPROVAL")
        } catch (e: Exception) {
            // Final retry failure: fail the production honestly.
            val message = e.message ?: "Production failed"
            logEvent(projectId, currentState, message, "ERROR")
            try {
                moveTo(projectId, currentState, ProjectState.FAILED, errorMessage = message)
            } catch (ignored: Exception) {
                // State was already terminal; the ERROR event above stands.
            }
            throw e
        }
    }

    suspend fun approve(approvalId: String) {
        val pending = _pendingApproval.value
            ?: throw IllegalStateException("No pending approval")
        val project = repository.getProject(pending.projectId)
            ?: throw IllegalArgumentException("Project not found: ${pending.projectId}")
        val currentState = stateOf(project)
        if (currentState != ProjectState.AWAITING_APPROVAL || pending.id != approvalId) {
            throw IllegalStateException("No matching pending approval: $approvalId")
        }

        _pendingApproval.value = null
        var state = moveTo(pending.projectId, currentState, ProjectState.IMAGE_GENERATION)

        // Phase 1-2: image generation is not available. Never fake an image.
        val reason = when (val decision = guard.check(ProviderId.IMAGE_GENERATION)) {
            is GuardDecision.Blocked -> decision.reason
            is GuardDecision.Allowed -> "Image generation arrives in Phase 3."
        }
        logEvent(pending.projectId, state, reason, "ERROR")
        state = moveTo(pending.projectId, state, ProjectState.FAILED, errorMessage = reason)
    }

    suspend fun reject(approvalId: String) {
        val pending = _pendingApproval.value
            ?: throw IllegalStateException("No pending approval")
        val project = repository.getProject(pending.projectId)
            ?: throw IllegalArgumentException("Project not found: ${pending.projectId}")
        val currentState = stateOf(project)
        if (currentState != ProjectState.AWAITING_APPROVAL || pending.id != approvalId) {
            throw IllegalStateException("No matching pending approval: $approvalId")
        }

        _pendingApproval.value = null
        val state = moveTo(pending.projectId, currentState, ProjectState.PLANNING)
        logEvent(
            pending.projectId,
            state,
            "Plan rejected by user — awaiting revised prompt",
            "INFO"
        )
    }

    suspend fun cancel(projectId: String) {
        val project = repository.getProject(projectId)
            ?: throw IllegalArgumentException("Project not found: $projectId")
        val currentState = stateOf(project)
        if (currentState == ProjectState.COMPLETED ||
            currentState == ProjectState.FAILED ||
            currentState == ProjectState.IDLE
        ) {
            throw IllegalStateException("Cannot cancel production from state $currentState")
        }

        _pendingApproval.value = null
        val state = moveTo(projectId, currentState, ProjectState.IDLE)
        logEvent(projectId, state, "Production cancelled by user", "INFO")
    }

    suspend fun resume(projectId: String) {
        val project = repository.getProject(projectId)
            ?: throw IllegalArgumentException("Project not found: $projectId")
        val currentState = stateOf(project)
        if (currentState != ProjectState.FAILED) {
            throw IllegalStateException("Cannot resume production from state $currentState")
        }

        moveTo(projectId, currentState, ProjectState.PLANNING)
        startProduction(projectId)
    }

    internal fun buildScriptText(story: com.pakvideo.aistudio.domain.model.StoryDraft): String =
        buildString {
            append(story.title)
            append("\n\nHook\n")
            append(story.hook)
            append("\n\nNarration\n")
            append(story.narration)
            append("\n\nDialogue\n")
            if (story.dialogue.isEmpty()) {
                append("No dialogue")
            } else {
                story.dialogue.forEach { line ->
                    append(line.speaker)
                    append(": ")
                    append(line.line)
                    append('\n')
                }
            }
        }

    private fun jsonEscape(value: String): String = value
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace("\t", "\\t")

    /**
     * Runs [block] up to [MAX_RETRIES] times, logging each failure as a
     * TaskEvent ERROR. Rethrows the last failure.
     */
    private suspend fun <T> withRetry(
        projectId: String,
        state: ProjectState,
        block: suspend () -> T
    ): T {
        var lastError: Exception? = null
        for (attempt in 1..MAX_RETRIES) {
            try {
                return block()
            } catch (e: Exception) {
                lastError = e
                logEvent(
                    projectId,
                    state,
                    "Attempt $attempt of $MAX_RETRIES failed: ${e.message}",
                    "ERROR"
                )
            }
        }
        throw lastError ?: IllegalStateException("Retry failed")
    }

    /**
     * Moves the project to [to] via the state machine (skipping the call
     * when already there), persists the new state and logs an INFO event.
     */
    private suspend fun moveTo(
        projectId: String,
        from: ProjectState,
        to: ProjectState,
        errorMessage: String? = null
    ): ProjectState {
        if (from == to) return from
        val next = stateMachine.transition(from, to)
        repository.updateProjectState(projectId, next, errorMessage)
        logEvent(projectId, next, "State changed to ${next.name}", "INFO")
        return next
    }

    private suspend fun logEvent(
        projectId: String,
        state: ProjectState,
        message: String,
        type: String
    ) {
        repository.logEvent(
            TaskEventEntity(
                projectId = projectId,
                timestamp = System.currentTimeMillis(),
                state = state.name,
                message = message,
                type = type
            )
        )
    }

    private fun stateOf(project: ProjectEntity): ProjectState {
        return ProjectState.valueOf(project.status)
    }
}
