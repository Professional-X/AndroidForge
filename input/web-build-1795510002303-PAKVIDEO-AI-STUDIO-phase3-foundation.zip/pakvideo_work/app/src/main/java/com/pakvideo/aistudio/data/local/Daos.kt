package com.pakvideo.aistudio.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(project: ProjectEntity): Long

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getById(id: String): ProjectEntity?

    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun getAll(): Flow<List<ProjectEntity>>

    @Update
    suspend fun update(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteById(id: String)

    @Delete
    suspend fun delete(project: ProjectEntity)

    @Query("UPDATE projects SET status = :status, errorLog = :errorLog, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateState(id: String, status: String, errorLog: String, updatedAt: Long)

    @Query("UPDATE projects SET script = :script, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateScript(id: String, script: String, updatedAt: Long)

    @Query("UPDATE projects SET name = :name, updatedAt = :updatedAt WHERE id = :id")
    suspend fun rename(id: String, name: String, updatedAt: Long)
}

@Dao
interface SceneDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(scene: SceneEntity): Long

    @Query("SELECT * FROM scenes WHERE id = :id")
    suspend fun getById(id: Long): SceneEntity?

    @Query("SELECT * FROM scenes WHERE projectId = :projectId ORDER BY orderIndex ASC")
    fun getByProject(projectId: String): Flow<List<SceneEntity>>

    @Update
    suspend fun update(scene: SceneEntity)

    @Query("DELETE FROM scenes WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM scenes WHERE projectId = :projectId")
    suspend fun deleteByProject(projectId: String)

    @Delete
    suspend fun delete(scene: SceneEntity)
}

@Dao
interface CharacterDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(character: CharacterEntity): Long

    @Query("SELECT * FROM characters WHERE id = :id")
    suspend fun getById(id: Long): CharacterEntity?

    @Query("SELECT * FROM characters WHERE projectId = :projectId ORDER BY id ASC")
    fun getByProject(projectId: String): Flow<List<CharacterEntity>>

    @Update
    suspend fun update(character: CharacterEntity)

    @Query("DELETE FROM characters WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM characters WHERE projectId = :projectId")
    suspend fun deleteByProject(projectId: String)

    @Delete
    suspend fun delete(character: CharacterEntity)
}

@Dao
interface TaskEventDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: TaskEventEntity): Long

    @Query("SELECT * FROM task_events WHERE id = :id")
    suspend fun getById(id: Long): TaskEventEntity?

    @Query("SELECT * FROM task_events WHERE projectId = :projectId ORDER BY timestamp DESC")
    fun getByProject(projectId: String): Flow<List<TaskEventEntity>>

    @Update
    suspend fun update(event: TaskEventEntity)

    @Query("DELETE FROM task_events WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Delete
    suspend fun delete(event: TaskEventEntity)
}

@Dao
interface ImageTaskDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: ImageTaskEntity)

    @Query("SELECT * FROM image_tasks WHERE projectId = :projectId ORDER BY createdAt ASC")
    fun getByProject(projectId: String): Flow<List<ImageTaskEntity>>

    @Query("SELECT * FROM image_tasks WHERE id = :id")
    suspend fun getById(id: String): ImageTaskEntity?

    @Query("SELECT * FROM image_tasks WHERE sceneId = :sceneId ORDER BY createdAt DESC LIMIT 1")
    suspend fun latestForScene(sceneId: Long): ImageTaskEntity?

    @Query("DELETE FROM image_tasks WHERE projectId = :projectId")
    suspend fun deleteByProject(projectId: String)
}
