package com.pakvideo.aistudio.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val PakVideoColorScheme = darkColorScheme(
    primary = PrimaryGold,
    onPrimary = OnPrimary,
    secondary = SecondaryBlue,
    background = Background,
    onBackground = OnBackground,
    surface = Surface,
    onSurface = OnSurface,
    surfaceVariant = SurfaceVariant,
    error = ErrorRed,
    outline = Outline
)

@Composable
fun PakVideoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = PakVideoColorScheme,
        typography = PakVideoTypography,
        content = content
    )
}
