package com.pakvideo.aistudio.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "image_tasks", indices = [Index("projectId"), Index("sceneId")])
data class ImageTaskEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val sceneId: Long,
    val providerId: String,
    val prompt: String,
    val status: String,
    val outputPath: String? = null,
    val mimeType: String? = null,
    val width: Int = 0,
    val height: Int = 0,
    val errorCode: String? = null,
    val errorMessage: String? = null,
    val retryable: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)
