package com.pakvideo.aistudio.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pakvideo.aistudio.R
import com.pakvideo.aistudio.domain.model.ProjectState
import com.pakvideo.aistudio.ui.components.ApprovalCard
import com.pakvideo.aistudio.ui.components.StatusChip
import com.pakvideo.aistudio.ui.viewmodel.ProductionViewModel

@Composable
fun AgentChatScreen(
    viewModel: ProductionViewModel,
    onOpenWorkspace: () -> Unit,
    onBack: () -> Unit
) {
    val project by viewModel.project.collectAsStateWithLifecycle()
    val events by viewModel.events.collectAsStateWithLifecycle()
    val pendingApproval by viewModel.pendingApproval.collectAsStateWithLifecycle()
    val error by viewModel.error.collectAsStateWithLifecycle()
    var prompt by remember { mutableStateOf("") }
    val state = project?.status?.let { runCatching { ProjectState.valueOf(it) }.getOrNull() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = null
                )
            }
            Text(
                text = project?.name ?: stringResource(R.string.agent_chat),
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.weight(1f)
            )
            state?.let { StatusChip(status = it.name) }
        }
        Spacer(modifier = Modifier.height(8.dp))

        error?.let { message ->
            Text(
                text = "${stringResource(R.string.error)}: $message",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium
            )
            TextButton(onClick = { viewModel.clearError() }) {
                Text(text = stringResource(R.string.retry))
            }
        }

        pendingApproval?.let { approval ->
            ApprovalCard(
                approval = approval,
                onApprove = { viewModel.approve() },
                onReject = { viewModel.reject() }
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Agent reasoning summary: the production event log, newest first.
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(events.sortedByDescending { it.timestamp }) { event ->
                Text(
                    text = "[${event.state}] ${event.message}",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
        }

        Row(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                label = { Text(text = stringResource(R.string.prompt_hint)) },
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(onClick = {
                if (prompt.isNotBlank()) {
                    viewModel.sendPrompt(prompt)
                    prompt = ""
                }
            }) {
                Text(text = stringResource(R.string.send))
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = { viewModel.cancel() },
                enabled = state != null &&
                    state != ProjectState.IDLE &&
                    state != ProjectState.COMPLETED &&
                    state != ProjectState.FAILED
            ) {
                Text(text = stringResource(R.string.cancel))
            }
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedButton(
                onClick = { viewModel.resume() },
                enabled = state == ProjectState.FAILED
            ) {
                Text(text = stringResource(R.string.resume))
            }
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedButton(onClick = onOpenWorkspace) {
                Text(text = stringResource(R.string.workspace))
            }
        }
    }
}
