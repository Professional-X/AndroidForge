package com.pakvideo.aistudio.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pakvideo.aistudio.R
import com.pakvideo.aistudio.domain.guard.ProviderId
import com.pakvideo.aistudio.domain.guard.ProviderStatus
import com.pakvideo.aistudio.ui.components.ProviderRow
import com.pakvideo.aistudio.ui.components.SectionTitle
import com.pakvideo.aistudio.ui.viewmodel.SettingsViewModel

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onBack: () -> Unit
) {
    val language by viewModel.language.collectAsStateWithLifecycle()
    val apiKeyPresent by viewModel.apiKeyPresent.collectAsStateWithLifecycle()
    val storageInfo by viewModel.storageInfo.collectAsStateWithLifecycle()
    val geminiModel by viewModel.geminiModel.collectAsStateWithLifecycle()
    val geminiHealthy by viewModel.geminiHealthy.collectAsStateWithLifecycle()
    val freeTierConfirmed by viewModel.freeTierConfirmed.collectAsStateWithLifecycle()
    val geminiProxyUrl by viewModel.geminiProxyUrl.collectAsStateWithLifecycle()
    val proxyUrlError by viewModel.proxyUrlError.collectAsStateWithLifecycle()
    var apiKeyInput by remember { mutableStateOf("") }
    var modelInput by remember(geminiModel) { mutableStateOf(geminiModel) }
    var proxyInput by remember(geminiProxyUrl) { mutableStateOf(geminiProxyUrl) }
    var showDeleteAllDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = null
                )
            }
            Text(
                text = stringResource(R.string.settings),
                style = MaterialTheme.typography.titleLarge
            )
        }

        SectionTitle(text = stringResource(R.string.language))
        Row(verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = language == "en", onClick = { viewModel.setLanguage("en") })
            Text(text = "English")
            RadioButton(selected = language == "ur", onClick = { viewModel.setLanguage("ur") })
            Text(text = "اردو")
        }

        SectionTitle(text = stringResource(R.string.free_only_mode))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = true, onCheckedChange = {}, enabled = false)
            Text(
                text = stringResource(R.string.free_only_mode_locked),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        SectionTitle(text = stringResource(R.string.storage))
        Text(text = storageInfo, style = MaterialTheme.typography.bodyMedium)
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedButton(onClick = { viewModel.refreshStorageInfo() }) {
            Text(text = stringResource(R.string.retry))
        }

        SectionTitle(text = stringResource(R.string.providers))
        viewModel.providers.forEach { provider ->
            val displayedProvider = if (provider.id == ProviderId.GEMINI_TEXT) {
                provider.copy(
                    status = if (geminiHealthy) ProviderStatus.ENABLED else ProviderStatus.DISABLED,
                    reason = if (geminiHealthy) {
                        "Ready — Gemini is configured and user-confirmed; billing status is not verified by the app."
                    } else {
                        "Blocked — configure a key or HTTPS proxy and confirm free-tier-only use."
                    }
                )
            } else provider
            ProviderRow(provider = displayedProvider)
        }

        SectionTitle(text = stringResource(R.string.api_key))
        Text(
            text = if (apiKeyPresent) {
                stringResource(R.string.key_configured)
            } else {
                stringResource(R.string.key_not_configured)
            },
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = apiKeyInput,
            onValueChange = { apiKeyInput = it },
            label = { Text(text = stringResource(R.string.api_key_hint)) },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row {
            Button(onClick = {
                if (apiKeyInput.isNotBlank()) {
                    viewModel.saveApiKey(apiKeyInput)
                    apiKeyInput = ""
                }
            }) {
                Text(text = stringResource(R.string.save_api_key))
            }
            Spacer(modifier = Modifier.padding(horizontal = 4.dp))
            OutlinedButton(onClick = { viewModel.clearApiKey() }) {
                Text(text = stringResource(R.string.clear_api_key))
            }
        }

        SectionTitle(text = stringResource(R.string.free_tier_confirm))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(
                checked = freeTierConfirmed,
                onCheckedChange = { viewModel.setFreeTierConfirmed(it) }
            )
            Text(
                text = stringResource(R.string.free_tier_confirm_text),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        SectionTitle(text = stringResource(R.string.gemini_proxy))
        Text(
            text = stringResource(R.string.gemini_proxy_text),
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = proxyInput,
            onValueChange = { proxyInput = it },
            label = { Text(text = stringResource(R.string.gemini_proxy_hint)) },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { viewModel.setGeminiProxyUrl(proxyInput) }) {
            Text(text = stringResource(R.string.save_proxy))
        }
        if (proxyUrlError != null) {
            Text(
                text = proxyUrlError.orEmpty(),
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }

        SectionTitle(text = stringResource(R.string.gemini_model))
        Text(
            text = when {
                // Healthy: the guard allows Gemini. Proxy mode needs no
                // local key, so the text must not claim a key is set.
                geminiHealthy && geminiProxyUrl.isNotBlank() ->
                    stringResource(R.string.gemini_ready_proxy)
                geminiHealthy ->
                    stringResource(R.string.gemini_ready_direct)
                // Unhealthy but something is configured: the missing
                // piece is the free-tier confirmation, not a key.
                apiKeyPresent || geminiProxyUrl.isNotBlank() ->
                    stringResource(R.string.gemini_needs_confirmation)
                else -> stringResource(R.string.key_not_configured)
            },
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = modelInput,
            onValueChange = { modelInput = it },
            label = { Text(text = stringResource(R.string.gemini_model_hint)) },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {
            if (modelInput.isNotBlank()) {
                viewModel.setGeminiModel(modelInput.trim())
            }
        }) {
            Text(text = stringResource(R.string.save))
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.gemini_model_free_list),
            style = MaterialTheme.typography.bodyMedium
        )

        SectionTitle(text = stringResource(R.string.privacy))
        OutlinedButton(onClick = { showDeleteAllDialog = true }) {
            Text(text = stringResource(R.string.delete_all_projects))
        }
    }

    if (showDeleteAllDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            title = { Text(text = stringResource(R.string.delete_all_projects)) },
            text = { Text(text = stringResource(R.string.delete_all_projects)) },
            confirmButton = {
                Button(onClick = {
                    viewModel.deleteAllProjects()
                    showDeleteAllDialog = false
                }) {
                    Text(text = stringResource(R.string.delete))
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteAllDialog = false }) {
                    Text(text = stringResource(R.string.cancel))
                }
            }
        )
    }
}
