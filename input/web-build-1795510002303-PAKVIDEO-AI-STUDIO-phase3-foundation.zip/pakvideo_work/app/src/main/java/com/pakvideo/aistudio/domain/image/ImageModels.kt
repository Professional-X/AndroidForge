package com.pakvideo.aistudio.domain.image

/** Persisted lifecycle for one scene image. No state implies an image exists. */
enum class ImageTaskStatus { QUEUED, GENERATING, SUCCEEDED, FAILED, CANCELLED }

enum class ImageProviderId { GEMINI_IMAGEN, GENERIC_REMOTE, LOCAL }

data class ImageGenerationRequest(
    val projectId: String,
    val sceneId: Long,
    val prompt: String,
    val aspectRatio: String = "16:9",
    val referenceImagePaths: List<String> = emptyList(),
    val seed: Long? = null
)

data class GeneratedImage(
    /** Absolute app-private file path. Must point to an existing image file. */
    val localPath: String,
    val mimeType: String,
    val width: Int,
    val height: Int,
    val provider: ImageProviderId,
    val providerModel: String
)

sealed interface ImageGenerationResult {
    data class Success(val image: GeneratedImage) : ImageGenerationResult
    data class Failure(val code: String, val message: String, val retryable: Boolean) : ImageGenerationResult
    data class Unavailable(val provider: ImageProviderId, val reason: String) : ImageGenerationResult
}
