package com.pakvideo.aistudio.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pakvideo.aistudio.R
import com.pakvideo.aistudio.data.local.ProjectEntity
import com.pakvideo.aistudio.ui.components.StatusChip
import com.pakvideo.aistudio.ui.viewmodel.CreationsViewModel

@Composable
fun MyCreationsScreen(
    viewModel: CreationsViewModel,
    onOpenChat: (String) -> Unit,
    onBack: () -> Unit
) {
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    var renameTarget by remember { mutableStateOf<ProjectEntity?>(null) }
    var renameText by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<ProjectEntity?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = null
                )
            }
            Text(
                text = stringResource(R.string.creations),
                style = MaterialTheme.typography.titleLarge
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        if (projects.isEmpty()) {
            Text(
                text = stringResource(R.string.no_projects_yet),
                style = MaterialTheme.typography.bodyMedium
            )
        } else {
            LazyColumn {
                items(projects) { project ->
                    Card(
                        onClick = { onOpenChat(project.id) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = project.name,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            StatusChip(status = project.status)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row {
                                OutlinedButton(onClick = {
                                    renameTarget = project
                                    renameText = project.name
                                }) {
                                    Text(text = stringResource(R.string.rename))
                                }
                                Spacer(
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                )
                                OutlinedButton(onClick = { deleteTarget = project }) {
                                    Text(text = stringResource(R.string.delete))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    renameTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text(text = stringResource(R.string.rename)) },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    label = { Text(text = stringResource(R.string.project_name_hint)) },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (renameText.isNotBlank()) {
                        viewModel.renameProject(target.id, renameText)
                    }
                    renameTarget = null
                }) {
                    Text(text = stringResource(R.string.rename))
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { renameTarget = null }) {
                    Text(text = stringResource(R.string.cancel))
                }
            }
        )
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text(text = stringResource(R.string.delete)) },
            text = { Text(text = target.name) },
            confirmButton = {
                Button(onClick = {
                    viewModel.deleteProject(target.id)
                    deleteTarget = null
                }) {
                    Text(text = stringResource(R.string.delete))
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { deleteTarget = null }) {
                    Text(text = stringResource(R.string.cancel))
                }
            }
        )
    }
}
