package com.pakvideo.aistudio.domain.statemachine

import com.pakvideo.aistudio.domain.model.ProjectState

/**
 * Guards every production state change.
 *
 * Only the transitions listed in [legalTransitions] are allowed; anything else
 * is rejected with an [IllegalStateException].
 */
class ProductionStateMachine {

    private val legalTransitions: Map<ProjectState, Set<ProjectState>> = mapOf(
        ProjectState.IDLE to setOf(ProjectState.PLANNING),
        ProjectState.PLANNING to setOf(
            ProjectState.SCRIPTING, ProjectState.AWAITING_APPROVAL,
            ProjectState.FAILED, ProjectState.IDLE
        ),
        ProjectState.AWAITING_APPROVAL to setOf(
            ProjectState.SCRIPTING, ProjectState.PLANNING,
            ProjectState.IMAGE_GENERATION, ProjectState.FAILED, ProjectState.IDLE
        ),
        ProjectState.SCRIPTING to setOf(
            ProjectState.STORYBOARDING, ProjectState.AWAITING_APPROVAL,
            ProjectState.FAILED, ProjectState.IDLE
        ),
        ProjectState.STORYBOARDING to setOf(
            ProjectState.IMAGE_GENERATION, ProjectState.AWAITING_APPROVAL,
            ProjectState.FAILED, ProjectState.IDLE
        ),
        ProjectState.IMAGE_GENERATION to setOf(
            ProjectState.VIDEO_GENERATION, ProjectState.AWAITING_APPROVAL,
            ProjectState.FAILED, ProjectState.IDLE
        ),
        ProjectState.VIDEO_GENERATION to setOf(
            ProjectState.VOICE_GENERATION, ProjectState.AWAITING_APPROVAL,
            ProjectState.FAILED, ProjectState.IDLE
        ),
        ProjectState.VOICE_GENERATION to setOf(
            ProjectState.EDITING, ProjectState.FAILED, ProjectState.IDLE
        ),
        ProjectState.EDITING to setOf(
            ProjectState.QUALITY_CHECK, ProjectState.FAILED, ProjectState.IDLE
        ),
        ProjectState.QUALITY_CHECK to setOf(
            ProjectState.COMPLETED, ProjectState.EDITING,
            ProjectState.FAILED, ProjectState.IDLE
        ),
        ProjectState.COMPLETED to emptySet(),
        ProjectState.FAILED to setOf(ProjectState.IDLE, ProjectState.PLANNING)
    )

    fun canTransition(from: ProjectState, to: ProjectState): Boolean {
        return legalTransitions[from]?.contains(to) == true
    }

    fun transition(from: ProjectState, to: ProjectState): ProjectState {
        if (!canTransition(from, to)) {
            throw IllegalStateException("Illegal transition: $from -> $to")
        }
        return to
    }
}
