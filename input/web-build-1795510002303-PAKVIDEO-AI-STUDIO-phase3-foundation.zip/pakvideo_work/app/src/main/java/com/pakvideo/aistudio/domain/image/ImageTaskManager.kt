package com.pakvideo.aistudio.domain.image

import com.pakvideo.aistudio.data.local.CharacterDao
import com.pakvideo.aistudio.data.local.ImageTaskDao
import com.pakvideo.aistudio.data.local.ImageTaskEntity
import com.pakvideo.aistudio.data.local.SceneDao
import java.io.File
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

/** Coordinates durable tasks. No provider is selected implicitly and no placeholder image is created. */
class ImageTaskManager(
    private val tasks: ImageTaskDao,
    private val scenes: SceneDao,
    private val characters: CharacterDao,
    private val providers: List<ImageGenerationProvider>,
    private val now: () -> Long = System::currentTimeMillis
) {
    fun observe(projectId: String): Flow<List<ImageTaskEntity>> = tasks.getByProject(projectId)

    suspend fun prepare(projectId: String, sceneId: Long, providerId: ImageProviderId): ImageTaskEntity {
        val scene = scenes.getById(sceneId) ?: error("Scene not found")
        require(scene.projectId == projectId) { "Scene does not belong to this project" }
        val characterSheets = characters.getByProject(projectId).first()
        val prompt = SceneImagePromptBuilder.build(scene, characterSheets)
        val timestamp = now()
        return ImageTaskEntity(
            id = UUID.randomUUID().toString(), projectId = projectId, sceneId = sceneId,
            providerId = providerId.name, prompt = prompt, status = ImageTaskStatus.QUEUED.name,
            createdAt = timestamp, updatedAt = timestamp
        ).also { tasks.upsert(it) }
    }

    suspend fun generate(taskId: String): ImageGenerationResult {
        val task = tasks.getById(taskId) ?: return ImageGenerationResult.Failure("TASK_NOT_FOUND", "Image task not found", false)
        val providerId = runCatching { ImageProviderId.valueOf(task.providerId) }.getOrNull()
            ?: return fail(task, "UNKNOWN_PROVIDER", "Unknown image provider", false)
        val provider = providers.firstOrNull { it.id == providerId }
            ?: return unavailable(task, providerId, "Provider adapter is not installed")
        if (!provider.isAvailable()) return unavailable(task, providerId, "Provider is not configured or is disabled")
        tasks.upsert(task.copy(status = ImageTaskStatus.GENERATING.name, errorCode = null, errorMessage = null, updatedAt = now()))
        val providerResult = try {
            provider.generate(ImageGenerationRequest(task.projectId, task.sceneId, task.prompt))
        } catch (e: Exception) {
            return fail(task, "PROVIDER_EXCEPTION", e.message ?: "Image provider failed", true)
        }
        return when (val result = providerResult) {
            is ImageGenerationResult.Success -> {
                val file = File(result.image.localPath)
                if (!file.isFile || file.length() <= 0L || !result.image.mimeType.startsWith("image/")) {
                    fail(task, "INVALID_PROVIDER_OUTPUT", "Provider returned no valid image file", false)
                } else {
                    tasks.upsert(task.copy(status = ImageTaskStatus.SUCCEEDED.name, outputPath = file.absolutePath,
                        mimeType = result.image.mimeType, width = result.image.width, height = result.image.height,
                        updatedAt = now()))
                    result
                }
            }
            is ImageGenerationResult.Failure -> {
                fail(task, result.code, result.message, result.retryable)
                result
            }
            is ImageGenerationResult.Unavailable -> unavailable(task, result.provider, result.reason)
        }
    }

    private suspend fun fail(task: ImageTaskEntity, code: String, message: String, retryable: Boolean): ImageGenerationResult.Failure {
        tasks.upsert(task.copy(status = ImageTaskStatus.FAILED.name, errorCode = code, errorMessage = message,
            retryable = retryable, updatedAt = now()))
        return ImageGenerationResult.Failure(code, message, retryable)
    }

    private suspend fun unavailable(task: ImageTaskEntity, provider: ImageProviderId, reason: String): ImageGenerationResult.Unavailable {
        tasks.upsert(task.copy(status = ImageTaskStatus.FAILED.name, errorCode = "PROVIDER_UNAVAILABLE",
            errorMessage = reason, retryable = false, updatedAt = now()))
        return ImageGenerationResult.Unavailable(provider, reason)
    }
}
