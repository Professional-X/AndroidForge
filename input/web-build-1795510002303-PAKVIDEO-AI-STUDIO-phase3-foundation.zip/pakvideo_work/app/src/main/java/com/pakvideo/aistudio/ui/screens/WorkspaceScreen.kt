package com.pakvideo.aistudio.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pakvideo.aistudio.R
import com.pakvideo.aistudio.ui.viewmodel.WorkspaceViewModel

@Composable
fun WorkspaceScreen(
    viewModel: WorkspaceViewModel,
    onBack: () -> Unit
) {
    val project by viewModel.project.collectAsStateWithLifecycle()
    val scenes by viewModel.scenes.collectAsStateWithLifecycle()
    val characters by viewModel.characters.collectAsStateWithLifecycle()
    var selectedTab by remember { mutableIntStateOf(0) }
    var scriptText by remember(project?.id) { mutableStateOf(project?.script ?: "") }

    val tabs = listOf(
        stringResource(R.string.script),
        stringResource(R.string.storyboard),
        stringResource(R.string.characters),
        stringResource(R.string.scene_prompts),
        stringResource(R.string.images)
    )

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(16.dp)) {
            androidx.compose.foundation.layout.Row {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = null
                    )
                }
                Text(
                    text = project?.name ?: stringResource(R.string.workspace),
                    style = MaterialTheme.typography.titleLarge
                )
            }
        }
        TabRow(selectedTabIndex = selectedTab) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(text = title) }
                )
            }
        }
        when (selectedTab) {
            0 -> {
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = scriptText,
                        onValueChange = { scriptText = it },
                        label = { Text(text = stringResource(R.string.script)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = { viewModel.updateScript(scriptText) }) {
                        Text(text = stringResource(R.string.send))
                    }
                }
            }
            1 -> {
                LazyColumn(modifier = Modifier.padding(16.dp)) {
                    item {
                        // The storyboard is rule-based (keyword-derived),
                        // not AI-generated direction — the label stays on
                        // the output (see DirectorAgent.DIRECTION_LABEL).
                        Text(
                            text = stringResource(R.string.rule_based_storyboard),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                    items(scenes) { scene ->
                        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "${scene.orderIndex + 1}. ${scene.title}",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(text = scene.description, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    text = "Camera: ${scene.cameraAngle}, ${scene.cameraMovement}",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = "Lighting: ${scene.lighting} | Location: ${scene.location}",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = "Atmosphere: ${scene.atmosphere}",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                if (scene.characterRefs.isNotBlank()) {
                                    Text(
                                        text = "Characters: ${scene.characterRefs}",
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                if (scene.visualPrompt.isNotBlank()) {
                                    Text(
                                        text = "Visual prompt: ${scene.visualPrompt}",
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                    }
                }
            }
            2 -> {
                LazyColumn(modifier = Modifier.padding(16.dp)) {
                    item {
                        var newCharacterName by remember { mutableStateOf("") }
                        Text(
                            text = "Review and edit character details before approving the plan. Unknown details are not guessed.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        OutlinedTextField(
                            value = newCharacterName,
                            onValueChange = { newCharacterName = it },
                            label = { Text("Add a missing character name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = {
                                viewModel.addCharacter(newCharacterName)
                                newCharacterName = ""
                            },
                            enabled = newCharacterName.isNotBlank()
                        ) {
                            Text("Add character")
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                    items(characters, key = { it.id }) { character ->
                        var editedName by remember(character.id) { mutableStateOf(character.name) }
                        var editedAge by remember(character.id) {
                            mutableStateOf(if (character.age > 0) character.age.toString() else "")
                        }
                        var editedAppearance by remember(character.id) { mutableStateOf(character.appearance) }
                        var editedClothing by remember(character.id) { mutableStateOf(character.clothing) }
                        var editedFace by remember(character.id) { mutableStateOf(character.facialFeatures) }
                        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = if (character.isMainCharacter) {
                                        "Main character (${character.mentionCount} mentions)"
                                    } else {
                                        "Supporting character (${character.mentionCount} mentions)"
                                    },
                                    style = MaterialTheme.typography.bodySmall
                                )
                                OutlinedTextField(
                                    value = editedName,
                                    onValueChange = { editedName = it },
                                    label = { Text("Character name") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = editedAge,
                                    onValueChange = { editedAge = it.filter(Char::isDigit).take(3) },
                                    label = { Text("Age (optional)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = editedAppearance,
                                    onValueChange = { editedAppearance = it },
                                    label = { Text("Appearance") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = editedClothing,
                                    onValueChange = { editedClothing = it },
                                    label = { Text("Clothing") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = editedFace,
                                    onValueChange = { editedFace = it },
                                    label = { Text("Facial features") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = {
                                        if (editedName.isNotBlank()) {
                                            viewModel.updateCharacter(
                                                character.copy(
                                                    name = editedName.trim(),
                                                    age = editedAge.toIntOrNull() ?: 0,
                                                    appearance = editedAppearance.trim(),
                                                    clothing = editedClothing.trim(),
                                                    facialFeatures = editedFace.trim()
                                                )
                                            )
                                        }
                                    },
                                    enabled = editedName.isNotBlank()
                                ) {
                                    Text("Save character sheet")
                                }
                            }
                        }
                    }
                }
            }
            3 -> {
                LazyColumn(modifier = Modifier.padding(16.dp)) {
                    item {
                        Text(
                            text = stringResource(R.string.rule_based_storyboard),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                    items(scenes) { scene ->
                        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Scene ${scene.orderIndex + 1}: ${scene.title}",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = if (scene.visualPrompt.isNotBlank()) {
                                        scene.visualPrompt
                                    } else {
                                        // Rows created before v2 have no stored
                                        // visual prompt; compose one from the
                                        // stored direction fields instead.
                                        "${scene.description} Camera: ${scene.cameraAngle}, " +
                                            "${scene.cameraMovement}. Lighting: ${scene.lighting}. " +
                                            "Location: ${scene.location}. Atmosphere: " +
                                            "${scene.atmosphere}. Characters: ${scene.characterRefs}."
                                    },
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }
            }
            4 -> {
                val imageTasks by viewModel.imageTasks.collectAsStateWithLifecycle()
                val imageMessage by viewModel.imageMessage.collectAsStateWithLifecycle()
                LazyColumn(modifier = Modifier.padding(16.dp)) {
                    item {
                        Text(
                            text = "Phase 3 image pipeline foundation. Providers are currently disabled; preparing a task does not generate an image.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        if (!imageMessage.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = imageMessage!!, color = MaterialTheme.colorScheme.error)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                    items(scenes, key = { "scene-${it.id}" }) { scene ->
                        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(text = "Scene ${scene.orderIndex + 1}: ${scene.title}", style = MaterialTheme.typography.titleMedium)
                                Text(text = scene.visualPrompt.ifBlank { scene.description })
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(onClick = { viewModel.prepareImageTask(scene.id) }) {
                                    Text(text = stringResource(R.string.prepare_image_task))
                                }
                                imageTasks.filter { it.sceneId == scene.id }.forEach { task ->
                                    Text(text = "${task.status}: ${task.errorMessage ?: task.outputPath ?: "No output yet"}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
