package com.pakvideo.aistudio.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pakvideo.aistudio.R
import com.pakvideo.aistudio.domain.guard.ProviderRegistry
import com.pakvideo.aistudio.domain.model.StoryGenre
import com.pakvideo.aistudio.ui.components.ProviderRow
import com.pakvideo.aistudio.ui.components.SectionTitle
import com.pakvideo.aistudio.ui.components.StatusChip
import com.pakvideo.aistudio.ui.viewmodel.HomeViewModel

/** Localised name for a story genre. */
@Composable
fun genreName(genre: StoryGenre): String {
    return stringResource(
        when (genre) {
            StoryGenre.ISLAMIC -> R.string.genre_islamic
            StoryGenre.MORAL -> R.string.genre_moral
            StoryGenre.DOCUMENTARY -> R.string.genre_documentary
            StoryGenre.SUSPENSE -> R.string.genre_suspense
            StoryGenre.HORROR -> R.string.genre_horror
            StoryGenre.ACTION -> R.string.genre_action
            StoryGenre.ADVENTURE -> R.string.genre_adventure
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onOpenChat: (String) -> Unit,
    onOpenCreations: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    var showNewDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var newPrompt by remember { mutableStateOf("") }
    var newGenre by remember { mutableStateOf(StoryGenre.ISLAMIC) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = stringResource(R.string.app_name),
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = { showNewDialog = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = stringResource(R.string.new_production))
        }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(
            onClick = onOpenCreations,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = stringResource(R.string.my_projects))
        }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(
            onClick = onOpenSettings,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = stringResource(R.string.settings))
        }
        Spacer(modifier = Modifier.height(24.dp))
        SectionTitle(text = stringResource(R.string.continue_project))
        if (projects.isEmpty()) {
            Text(
                text = stringResource(R.string.no_projects_yet),
                style = MaterialTheme.typography.bodyMedium
            )
        } else {
            projects.forEach { project ->
                Card(
                    onClick = { onOpenChat(project.id) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = project.name, style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = genreName(StoryGenre.fromStoredName(project.genre)),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        StatusChip(status = project.status)
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
        SectionTitle(text = stringResource(R.string.ai_studio_tools))
        ProviderRegistry.all().forEach { provider ->
            ProviderRow(provider = provider)
        }
    }

    if (showNewDialog) {
        AlertDialog(
            onDismissRequest = { showNewDialog = false },
            title = { Text(text = stringResource(R.string.new_production)) },
            text = {
                Column {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text(text = stringResource(R.string.project_name_hint)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newPrompt,
                        onValueChange = { newPrompt = it },
                        label = { Text(text = stringResource(R.string.prompt_hint)) },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.genre),
                        style = MaterialTheme.typography.titleSmall
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    FlowRow {
                        StoryGenre.entries.forEach { genre ->
                            FilterChip(
                                selected = newGenre == genre,
                                onClick = { newGenre = genre },
                                label = { Text(text = genreName(genre)) },
                                modifier = Modifier.padding(end = 4.dp, bottom = 4.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val id = viewModel.createProject(newName, newPrompt, newGenre)
                    newName = ""
                    newPrompt = ""
                    newGenre = StoryGenre.ISLAMIC
                    showNewDialog = false
                    onOpenChat(id)
                }) {
                    Text(text = stringResource(R.string.send))
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showNewDialog = false }) {
                    Text(text = stringResource(R.string.cancel))
                }
            }
        )
    }
}
