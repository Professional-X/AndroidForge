package com.pakvideo.aistudio.data.repository

import com.pakvideo.aistudio.data.local.CharacterEntity
import com.pakvideo.aistudio.data.local.ProjectEntity
import com.pakvideo.aistudio.data.local.SceneEntity
import com.pakvideo.aistudio.data.local.TaskEventEntity
import com.pakvideo.aistudio.domain.model.ProjectState
import kotlinx.coroutines.flow.Flow

/**
 * Contract for project persistence. Implemented by [ProjectRepositoryImpl].
 * Definition is verbatim from the project CONTRACT.md.
 */
interface ProjectRepository {
    suspend fun createProject(project: ProjectEntity): String
    suspend fun getProject(id: String): ProjectEntity?
    fun getAllProjects(): Flow<List<ProjectEntity>>
    suspend fun updateProject(project: ProjectEntity)
    suspend fun deleteProject(id: String)
    suspend fun renameProject(id: String, newName: String)
    suspend fun updateProjectState(id: String, state: ProjectState, errorMessage: String? = null)
    suspend fun updateScript(id: String, script: String)
    suspend fun addScene(scene: SceneEntity): Long
    fun getScenes(projectId: String): Flow<List<SceneEntity>>
    suspend fun updateScene(scene: SceneEntity)
    suspend fun deleteScene(sceneId: Long)
    suspend fun addCharacter(character: CharacterEntity): Long
    fun getCharacters(projectId: String): Flow<List<CharacterEntity>>
    suspend fun updateCharacter(character: CharacterEntity)
    suspend fun deleteCharacter(characterId: Long)
    suspend fun deleteProjectCharacters(projectId: String)
    suspend fun deleteProjectScenes(projectId: String)
    suspend fun logEvent(event: TaskEventEntity)
    fun getEvents(projectId: String): Flow<List<TaskEventEntity>>
}
