package com.pakvideo.aistudio.domain.guard

import com.pakvideo.aistudio.data.remote.ProxyUrlValidator

sealed class GuardDecision {
    data class Allowed(val provider: ProviderId) : GuardDecision()
    data class Blocked(val provider: ProviderId, val reason: String) : GuardDecision()
}

data class GuardAttempt(
    val provider: ProviderId,
    val model: String?,
    val result: String,
    val quotaStatus: String,
    val timestamp: Long
)

/**
 * Free-budget guard: no generation may run without free quota.
 *
 * An API key is NOT proof of free quota. A Gemini API key only proves the
 * user pasted a key — it says nothing about whether the Google Cloud
 * project behind it has billing enabled, and this app cannot verify that
 * from the device: Google's public API exposes no endpoint that reports a
 * project's billing status. API responses and quota errors do not give
 * this app a reliable billing-state check. So the guard requires an
 * explicit free-tier confirmation by the user
 * ([freeTierConfirmedProvider]): the user attests in Settings that the
 * calls are free-tier only. Until it holds, Gemini text stays
 * [GuardDecision.Blocked] and callers fall back to local drafts. The
 * confirmation is a user attestation, not a verification. The guard
 * cannot technically prevent charges if the configured Google Cloud
 * project has billing enabled; zero-charge use requires billing to stay
 * disabled (or Gemini to remain unconfigured). This limitation is
 * documented in docs/API_CONFIGURATION.md and in the Settings screen.
 *
 * Two modes, both gated on the same confirmation:
 * - DIRECT (no proxy configured): the device holds a key, so the guard
 *   requires a non-blank key ([apiKeyProvider]) AND the confirmation.
 * - PROXY ([proxyBaseUrlProvider] returns a non-blank URL): the key
 *   lives on the user's server, so NO local key is required — only the
 *   confirmation. The device never sends a key to the proxy (see
 *   [com.pakvideo.aistudio.data.remote.GeminiApiClient]). The proxy
 *   itself must hold its own server-side key and enforce free-only
 *   usage; the app cannot verify that either, which is exactly why the
 *   confirmation is still required in proxy mode.
 *
 * Every other provider follows its registry status: ENABLED or LOCAL_ONLY
 * providers are [GuardDecision.Allowed], DISABLED providers are
 * [GuardDecision.Blocked]. Every [check] call records an attempt in
 * [attempts] so blocked generation is always auditable.
 */
class FreeBudgetGuard(
    private val apiKeyProvider: (() -> String?)? = null,
    private val freeTierConfirmedProvider: (() -> Boolean)? = null,
    private val proxyBaseUrlProvider: (() -> String?)? = null
) {

    private val _attempts = mutableListOf<GuardAttempt>()

    val attempts: List<GuardAttempt>
        get() = _attempts.toList()

    /** True when a server-side proxy is configured (non-blank URL). */
    fun isProxyMode(): Boolean = !proxyBaseUrlProvider?.invoke().isNullOrBlank()

    fun check(provider: ProviderId): GuardDecision {
        val info = ProviderRegistry.get(provider)
        val decision: GuardDecision = if (provider == ProviderId.GEMINI_TEXT) {
            when {
                // A configured but invalid proxy must never silently fall back
                // to direct mode or be treated as an eligible endpoint.
                isProxyMode() && !ProxyUrlValidator.isValidOrEmpty(proxyBaseUrlProvider?.invoke()) ->
                    GuardDecision.Blocked(provider, INVALID_PROXY_URL_MESSAGE)
                // Proxy mode: no local key needed, confirmation required.
                isProxyMode() && freeTierConfirmedProvider?.invoke() != true ->
                    GuardDecision.Blocked(provider, FREE_TIER_NOT_CONFIRMED_PROXY_MESSAGE)
                isProxyMode() -> GuardDecision.Allowed(provider)
                // Direct mode: key AND confirmation required.
                apiKeyProvider?.invoke().isNullOrBlank() ->
                    GuardDecision.Blocked(provider, info.reason)
                freeTierConfirmedProvider?.invoke() != true ->
                    GuardDecision.Blocked(provider, FREE_TIER_NOT_CONFIRMED_MESSAGE)
                else -> GuardDecision.Allowed(provider)
            }
        } else {
            when (info.status) {
                ProviderStatus.ENABLED, ProviderStatus.LOCAL_ONLY ->
                    GuardDecision.Allowed(provider)
                ProviderStatus.DISABLED ->
                    GuardDecision.Blocked(provider, info.reason)
            }
        }
        val result = if (decision is GuardDecision.Allowed) "Allowed" else "Blocked"
        val quotaStatus = when {
            provider == ProviderId.GEMINI_TEXT && isProxyMode() &&
                ProxyUrlValidator.isValidOrEmpty(proxyBaseUrlProvider?.invoke()) ->
                "user-confirmed-unverified"
            provider == ProviderId.GEMINI_TEXT && !isProxyMode() &&
                !apiKeyProvider?.invoke().isNullOrBlank() ->
                "user-confirmed-unverified"
            provider == ProviderId.GEMINI_TEXT -> "none"
            decision is GuardDecision.Allowed -> "local-only"
            else -> "none"
        }
        recordAttempt(provider, info.model, result, quotaStatus)
        return decision
    }

    fun hasFreeQuota(provider: ProviderId): Boolean {
        return if (provider == ProviderId.GEMINI_TEXT) {
            if (isProxyMode()) {
                ProxyUrlValidator.isValidOrEmpty(proxyBaseUrlProvider?.invoke()) &&
                    freeTierConfirmedProvider?.invoke() == true
            } else {
                !apiKeyProvider?.invoke().isNullOrBlank() &&
                    freeTierConfirmedProvider?.invoke() == true
            }
        } else {
            when (ProviderRegistry.get(provider).status) {
                ProviderStatus.ENABLED, ProviderStatus.LOCAL_ONLY -> true
                ProviderStatus.DISABLED -> false
            }
        }
    }

    fun recordAttempt(provider: ProviderId, model: String?, result: String, quotaStatus: String) {
        _attempts.add(
            GuardAttempt(
                provider = provider,
                model = model,
                result = result,
                quotaStatus = quotaStatus,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    companion object {
        const val NO_FREE_QUOTA_MESSAGE = "No free generation quota available."
        const val FREE_TIER_NOT_CONFIRMED_MESSAGE =
            "Free-tier use is not confirmed for this key. Confirm in Settings " +
                "that the key belongs to a billing-free project; until then only " +
                "local drafts are used."
        const val INVALID_PROXY_URL_MESSAGE =
            "The configured Gemini proxy URL is invalid. Use a valid HTTPS URL."
        const val FREE_TIER_NOT_CONFIRMED_PROXY_MESSAGE =
            "Free-tier use is not confirmed for this proxy. Confirm in Settings " +
                "that the proxy enforces free-tier-only use with its own " +
                "server-side key; until then only local drafts are used."
    }
}
