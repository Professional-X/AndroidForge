package com.pakvideo.aistudio.data.remote

/**
 * The Gemini text models this app is allowed to call.
 *
 * Verified 2026-11-23 against Google's Gemini API pricing page (free-tier
 * column) and the official deprecations page:
 *
 * - `gemini-2.0-flash` (the old default) was RETIRED on 2026-06-01.
 *   Requests to it now fail. Google names `gemini-3.6-flash` as its
 *   replacement.
 * - `gemini-3.8-flash` is the newest stable Flash, explicitly named by
 *   Google for NEW projects, free tier "Free of charge", no shutdown
 *   announced. It is the default.
 * - `gemini-3.6-flash` is the designated replacement for 2.0 Flash and
 *   3.5 Flash, free tier "Free of charge", no shutdown announced.
 * - `gemini-3.5-flash-lite` is also named by Google for new projects,
 *   free tier "Free of charge".
 *
 * Deliberately NOT on the list, even though the pricing page shows a
 * free tier for them:
 * - `gemini-2.5-flash`, `gemini-2.5-flash-lite`, `gemini-2.5-pro`:
 *   Google limits them to users who actively used the 2.5 models in
 *   the past; new projects get a 404. Two of the three are deprecated
 *   and auto-route to newer models from 2026-12-01.
 * - `gemini-3.1-flash-lite`: free, but already scheduled to shut down
 *   2027-05-07.
 * - `gemini-4-hydrogen` (and other Gemini 4 models): too new to trust
 *   as a default; the free-tier status of the new lineup was still
 *   changing in November 2026.
 *
 * Google retires models often and changes free-tier access without
 * notice. This list is a snapshot dated above — when a call fails with
 * a model error, check the pricing page
 * (https://ai.google.dev/gemini-api/docs/pricing) and update this
 * list. The app NEVER silently switches to a model outside this list:
 * [com.pakvideo.aistudio.domain.agents.StoryAgent] refuses to call
 * Gemini with any other model and falls back to a local draft instead,
 * with the reason recorded. A paid model can therefore never be used
 * by accident — not even if the user types its name into Settings.
 */
object GeminiModels {

    /** Default model: newest stable Flash, free tier, named for new projects. */
    const val DEFAULT_MODEL = "gemini-3.8-flash"

    /** Models the app may call. Anything else falls back to a local draft. */
    val FREE_TIER_MODELS: Set<String> = setOf(
        "gemini-3.8-flash",
        "gemini-3.6-flash",
        "gemini-3.5-flash-lite"
    )

    /** Date this list was last verified against Google's pricing page. */
    const val LIST_VERIFIED = "2026-11-23"

    fun isFreeTierModel(model: String): Boolean {
        return model.trim() in FREE_TIER_MODELS
    }
}
