package com.pakvideo.aistudio.domain.agents

import com.pakvideo.aistudio.domain.model.CharacterSheet
import com.pakvideo.aistudio.domain.model.StoryDraft

/**
 * Keeps one character looking the same across every scene.
 *
 * Characters are identified from the story itself — from the NARRATION
 * as well as from dialogue speakers (except "Narrator"), in order of
 * first appearance. A story with no dialogue still has characters when
 * its narration names them; the list is empty only when the story names
 * nobody at all. A speaker is a MAIN character when they speak at
 * least twice or are mentioned at least three times in total (dialogue
 * + narration); anyone else is a supporting character. The counts are
 * stored on the sheet ([CharacterSheet.mentionCount]) so the call can
 * be checked.
 *
 * Physical details are NEVER invented. Appearance, clothing and facial
 * features are filled only from words actually written in the story near
 * the character's name, and are then labelled "From the story: ...".
 * Anything the story does not say stays explicitly marked
 * "Not specified in the story — add details in Workspace" — a guess is
 * never presented as a fact. Age comes only from an explicit number in
 * the story ("35-year-old"); otherwise it stays 0 (unknown).
 *
 * The approved sheet is the single source of truth for how a character
 * looks: [describeForPrompt] renders it in one fixed format, and the
 * DirectorAgent puts that exact text into every scene prompt where the
 * character appears — so the same description is reused word-for-word
 * across scenes, never rewritten per scene.
 */
class CharacterConsistencyAgent {

    fun createSheet(
        name: String,
        age: Int,
        appearance: String,
        clothing: String,
        facialFeatures: String,
        isMainCharacter: Boolean = false,
        mentionCount: Int = 0
    ): CharacterSheet {
        return CharacterSheet(
            name = name,
            age = age,
            appearance = appearance,
            clothing = clothing,
            facialFeatures = facialFeatures,
            isMainCharacter = isMainCharacter,
            mentionCount = mentionCount
        )
    }

    fun deriveCharacters(story: StoryDraft): List<CharacterSheet> {
        val dialogueSpeakers = story.dialogue
            .map { it.speaker }
            .filter { !it.equals("Narrator", ignoreCase = true) }
            .distinct()
        // Narration names first (first-appearance order), then any
        // dialogue-only speakers. A story with no dialogue still yields
        // its narration characters; the list is empty only when the
        // story names nobody at all.
        val narrationNames = extractNarrationNames(story.narration)
        val names = narrationNames +
            dialogueSpeakers.filter { it !in narrationNames }
        return names.map { name ->
            val dialogueLines = story.dialogue.count { it.speaker == name }
            val narrationMentions = countMentions(name, story.narration)
            val totalMentions = dialogueLines + narrationMentions
            val isMain = dialogueLines >= 2 || totalMentions >= 3
            val evidence = evidenceWindows(story, name)
            CharacterSheet(
                name = name,
                age = extractAge(name, story.narration),
                appearance = evidenceField(evidence, APPEARANCE_KEYWORDS),
                clothing = evidenceField(evidence, CLOTHING_KEYWORDS),
                facialFeatures = evidenceField(evidence, FACIAL_KEYWORDS),
                isMainCharacter = isMain,
                mentionCount = totalMentions
            )
        }
    }

    /**
     * The approved character sheet rendered in one fixed format for
     * scene prompts. The DirectorAgent uses exactly this text in every
     * scene where the character appears, so the same description is
     * reused word-for-word across scenes. Unknown fields keep their
     * "Not specified in the story" marker here too — the prompt never
     * invents a detail the sheet does not have.
     */
    fun describeForPrompt(sheet: CharacterSheet): String {
        val agePart = if (sheet.age > 0) ", ${sheet.age} years old" else ""
        return "${sheet.name}$agePart (${sheet.appearance}; " +
            "${sheet.clothing}; ${sheet.facialFeatures})"
    }

    fun checkConsistency(original: CharacterSheet, updated: CharacterSheet): List<String> {
        val changed = mutableListOf<String>()
        if (original.appearance != updated.appearance) changed.add("appearance changed")
        if (original.clothing != updated.clothing) changed.add("clothing changed")
        if (original.facialFeatures != updated.facialFeatures) changed.add("facial features changed")
        if (original.age != updated.age) changed.add("age changed")
        return changed
    }

    fun reuseSheetForScene(sheet: CharacterSheet, sceneIndex: Int): String {
        val role = if (sheet.isMainCharacter) "main character" else "supporting character"
        return "Scene $sceneIndex — ${sheet.name} ($role; ${sheet.clothing}; ${sheet.facialFeatures})"
    }

    /**
     * Names of characters mentioned in the narration, in order of first
     * appearance.
     *
     * Latin script: capitalised word sequences (one or two words, e.g.
     * "Ahmed", "King Ahmad"). A candidate counts as a name when it
     * appears at least twice in the narration, or at least once NOT at
     * the start of a sentence — a one-off sentence-initial capitalised
     * word ("Then", "One day") is usually not a name. Common words and
     * pronouns are excluded by [NAME_STOPWORDS].
     *
     * Urdu script has no capitalisation. To avoid mistaking repeated
     * role nouns (for example "بادشاہ") for personal names, narration-only
     * Urdu candidates are accepted only when introduced by an explicit
     * name marker such as "نام احمد تھا". Dialogue speaker labels remain
     * the most reliable source for Urdu character names.
     */
    fun extractNarrationNames(narration: String): List<String> {
        if (narration.isBlank()) return emptyList()
        // Run both detectors independently so a mixed Urdu/English story
        // does not suppress Latin-script names merely because Urdu appears.
        return (extractLatinNarrationNames(narration) + extractUrduNarrationNames(narration))
            .distinct()
            .sortedBy { name ->
                val index = narration.indexOf(name, ignoreCase = true)
                if (index >= 0) index else Int.MAX_VALUE
            }
    }

    private fun extractLatinNarrationNames(narration: String): List<String> {
        val sentences = narration
            .split('.', '!', '?', '۔', '؟')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
        // (name, firstIndex, midSentence, totalCount)
        val seen = linkedMapOf<String, Triple<Int, Boolean, Int>>()
        val wordSeq = Regex("\\b[A-Z][a-z]{1,}(?:\\s+[A-Z][a-z]{1,})?\\b")
        for (sentence in sentences) {
            for (match in wordSeq.findAll(sentence)) {
                val candidate = match.value
                val firstWord = candidate.substringBefore(" ")
                if (firstWord in NAME_STOPWORDS || candidate in NAME_STOPWORDS) continue
                val atStart = match.range.first == 0
                val prev = seen[candidate]
                val firstIndex = prev?.first ?: seen.size
                val midSentence = (prev?.second == true) || !atStart
                val count = (prev?.third ?: 0) + 1
                seen[candidate] = Triple(firstIndex, midSentence, count)
            }
        }
        return seen.entries
            .filter { (_, info) -> info.third >= 2 || info.second }
            .sortedBy { it.value.first }
            .map { it.key }
    }

    private fun extractUrduNarrationNames(narration: String): List<String> {
        val marker = Regex("(?:نام\\s*(?:ہے|تھا|تھی)?\\s*|کہلاتا\\s+تھا\\s+|کہلاتی\\s+تھی\\s*)([\\u0600-\\u06FF]{2,})")
        return marker.findAll(narration)
            .map { it.groupValues[1].trim() }
            .filter { it !in URDU_STOPWORDS }
            .distinct()
            .toList()
    }

    /**
     * Whole-word mention count of [name] in [text] (case-insensitive for
     * Latin script; plain count for Urdu script).
     */
    fun countMentions(name: String, text: String): Int {
        if (name.isBlank() || text.isBlank()) return 0
        return if (name.any { it in '\u0600'..'\u06FF' }) {
            text.split(name).size - 1
        } else {
            Regex("\\b${Regex.escape(name)}\\b", RegexOption.IGNORE_CASE)
                .findAll(text).count()
        }
    }

    /**
     * The text searched for evidence about [speaker]: windows around the
     * speaker's name in the narration and hook (40 chars before, 80
     * after), plus the speaker's own dialogue lines. Evidence is never
     * taken from a sentence about someone else — a detail about Sara
     * must not end up on Ahmed's sheet — so each window is clamped to
     * the name's own sentence: it starts after the previous sentence
     * terminator and ends at the next one.
     */
    private fun evidenceWindows(story: StoryDraft, speaker: String): String {
        val windows = mutableListOf<String>()
        // CharArray: lastIndexOfAny/indexOfAny take CharArray (or
        // Collection<String>), not a Set<Char>.
        val terminators = charArrayOf('.', '!', '?', '۔', '؟')
        for (text in listOf(story.narration, story.hook)) {
            for (range in nameOccurrences(text, speaker)) {
                var start = maxOf(0, range.first - 40)
                val prevTerm = text.lastIndexOfAny(terminators, range.first - 1)
                if (prevTerm >= 0) start = maxOf(start, prevTerm + 1)
                var end = minOf(text.length, range.last + 1 + 80)
                val nextTerm = text.indexOfAny(terminators, range.last + 1)
                if (nextTerm >= 0) end = minOf(end, nextTerm + 1)
                windows.add(text.substring(start, end))
            }
        }
        story.dialogue.filter { it.speaker == speaker }.forEach { windows.add(it.line) }
        return windows.joinToString(" ")
    }

    /**
     * Ranges where [name] occurs in [text]: whole-word match for Latin
     * script, plain substring match for Urdu script.
     */
    private fun nameOccurrences(text: String, name: String): List<IntRange> {
        if (name.isBlank() || text.isBlank()) return emptyList()
        return if (name.any { it in '\u0600'..'\u06FF' }) {
            val ranges = mutableListOf<IntRange>()
            var from = 0
            while (true) {
                val at = text.indexOf(name, from)
                if (at < 0) break
                ranges.add(at until at + name.length)
                from = at + name.length
            }
            ranges
        } else {
            Regex("\\b${Regex.escape(name)}\\b", RegexOption.IGNORE_CASE)
                .findAll(text).map { it.range }.toList()
        }
    }

    /**
     * Age from an explicit number near the character's name
     * ("35-year-old", "35 years old", "35 سال"); 0 when the story gives
     * no number. Descriptive words like "old man" never become a number.
     */
    private fun extractAge(name: String, narration: String): Int {
        for (range in nameOccurrences(narration, name)) {
            val window = narration.substring(
                range.first,
                minOf(narration.length, range.last + 1 + 80)
            )
            // The number may be joined to "year" by a hyphen ("35-year-old")
            // or a space ("35 years old", "35 year old").
            val latin = Regex("(\\d+)\\s*-?\\s*(?:years?\\s+old|year-old)", RegexOption.IGNORE_CASE)
                .find(window)
            if (latin != null) return latin.groupValues[1].toIntOrNull() ?: 0
            val urdu = Regex("(\\d+)\\s*سال").find(window)
            if (urdu != null) return urdu.groupValues[1].toIntOrNull() ?: 0
        }
        return 0
    }

    /**
     * First matching keyword in the evidence text, quoted exactly as
     * written and labelled as story evidence; [NOT_SPECIFIED] when the
     * story says nothing about this field.
     */
    private fun evidenceField(evidence: String, keywords: List<String>): String {
        for (keyword in keywords) {
            val found = findKeyword(evidence, keyword)
            if (found != null) return "From the story: \"$found\""
        }
        return NOT_SPECIFIED
    }

    /**
     * The keyword exactly as it appears in [text] (original casing for
     * Latin), or null. Latin keywords match at a word start so "old"
     * does not match "gold"; Urdu keywords match as substrings.
     */
    private fun findKeyword(text: String, keyword: String): String? {
        return if (keyword.any { it in '\u0600'..'\u06FF' }) {
            if (text.contains(keyword)) keyword else null
        } else {
            val match = Regex("\\b${Regex.escape(keyword)}", RegexOption.IGNORE_CASE)
                .find(text) ?: return null
            text.substring(match.range.first, match.range.last + 1)
        }
    }

    companion object {
        const val NOT_SPECIFIED = "Not specified in the story — add details in Workspace"

        /**
         * Capitalised words that are (almost) never a character's name:
         * sentence openers, pronouns, articles, common adjectives and
         * verbs. Used only by the narration-name heuristic.
         */
        private val NAME_STOPWORDS = setOf(
            "The", "A", "An", "And", "But", "Then", "When", "One", "Two",
            "Once", "Now", "Later", "Suddenly", "After", "Before", "While",
            "As", "If", "In", "On", "At", "To", "He", "She", "It", "They",
            "We", "You", "His", "Her", "Their", "This", "That", "There",
            "Here", "What", "Who", "Why", "How", "I", "My", "Our", "Your",
            "No", "Yes", "So", "For", "With", "From", "By", "Of", "Is",
            "Was", "Were", "Are", "Be", "Had", "Has", "Have", "Do", "Did",
            "Will", "Would", "Can", "Could", "Should", "May", "Might",
            "Must", "All", "Some", "Any", "Each", "Every", "First", "Last",
            "Next", "New", "Old", "Good", "Great", "Little", "Big", "Small"
        )

        /** Common Urdu grammatical words — never a character's name. */
        private val URDU_STOPWORDS = setOf(
            "اور", "ہے", "تھا", "تھے", "تھی", "نے", "کو", "سے", "میں",
            "پر", "کا", "کی", "کے", "کہ", "یہ", "وہ", "جو", "ایک",
            "بھی", "نہیں", "ہو", "ہوں", "ہیں", "کر", "کیا", "جب",
            "پھر", "اب", "اس", "ان", "تم", "ہم", "آپ", "اسے", "تو",
            "ہی", "یا", "لیکن", "بعد", "پہلے", "دن", "رات", "گھر",
            "آدمی", "عورت", "بچہ", "بچے", "لوگ", "سب", "کچھ", "کوئی",
            "اپنے", "اپنی", "اپنا", "جس", "جن", "تک", "لیے", "ساتھ",
            "اوپر", "نیچے", "اندر", "باہر", "بہت", "زیادہ", "کم"
        )

        private val APPEARANCE_KEYWORDS = listOf(
            "white beard", "black beard", "long hair", "tall", "short",
            "old man", "old woman", "young man", "young boy", "young girl",
            "little boy", "little girl", "blind", "strong", "thin",
            "سفید داڑھی", "کالی داڑھی", "لمبے بال", "لمبا", "چھوٹا",
            "بوڑھا", "بوڑھی", "جوان", "بچہ", "اندھا", "طاقتور", "دبلا"
        )
        private val CLOTHING_KEYWORDS = listOf(
            "white robe", "black robe", "kurta", "shawl", "crown", "armor",
            "turban", "dress", "uniform", "cloak",
            "سفید لباس", "کالا لباس", "کرتا", "شال", "تاج", "زرہ", "پگڑی", "لباس"
        )
        private val FACIAL_KEYWORDS = listOf(
            "sharp nose", "round face", "bright eyes", "wrinkled face",
            "kind eyes", "blue eyes", "brown eyes", "big eyes", "scar",
            "مسکراہٹ", "نشان"
        )
    }
}
