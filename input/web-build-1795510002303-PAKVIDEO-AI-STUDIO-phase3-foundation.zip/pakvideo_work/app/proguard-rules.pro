# PAKVIDEO AI STUDIO — ProGuard rules (Phase 1+2: minification is disabled,
# this file exists so the release build type reference resolves).
# Add your own rules here if minification is enabled later.
