# PAKVIDEO AI STUDIO — Phase 1+2 Shared Contract

Every layer subagent MUST read this file first and follow it exactly. Do not rename
packages, classes, methods, routes, or enum values listed here. If a signature below
conflicts with what seems natural, the contract wins.

## Project facts

- Root: `~/workspace/pakvideo-ai-studio/`
- Package: `com.pakvideo.aistudio`
- Namespace: `com.pakvideo.aistudio`
- minSdk 26, targetSdk 34, compileSdk 34, Kotlin 2.0.21, AGP 8.5.2, JVM target 17
- versionCode 1, versionName `0.1.0-phase1`
- NO Firebase in Phase 1-2. NO API keys in source. The only optional network call in Phase 1-2 is Gemini text generation, and it is blocked unless the user configures a key or HTTPS proxy and explicitly confirms free-tier-only use. All other generation providers remain disabled/local. INTERNET permission is used by the optional Gemini text client.
- Gradle Kotlin DSL. Room 2.6.1, Navigation Compose 2.8.x, Compose BOM 2024.09.00,
  lifecycle-viewmodel-compose 2.8.5, security-crypto 1.1.0-alpha06, coroutines 1.8.1.

## Colour palette (dark cinematic) — use these exact hex values everywhere

- Background `#0B0B10`, Surface `#17171F`, SurfaceVariant `#1F1F2A`
- Primary (gold) `#D9A441`, OnPrimary `#1A1206`
- Secondary `#7FB3D5`, Error `#CF6679`
- OnBackground `#F2F2F5`, OnSurface `#E8E8EC`, Outline `#3A3A48`

## Domain models — package `com.pakvideo.aistudio.domain.model`

```kotlin
enum class ProjectState {
    IDLE, PLANNING, AWAITING_APPROVAL, SCRIPTING, STORYBOARDING,
    IMAGE_GENERATION, VIDEO_GENERATION, VOICE_GENERATION,
    EDITING, QUALITY_CHECK, COMPLETED, FAILED
}

data class DialogueLine(val speaker: String, val line: String)
/** User-selected story genre (one per project, stored as the enum name on ProjectEntity.genre). The genre steers tone and structure; it is NOT a content filter — provider safety rules still apply, but the app does not force every story to be family-friendly. */
enum class StoryGenre(val displayName: String, val promptGuidance: String) {
    ISLAMIC("Islamic", "an Islamic story rooted in faith, good character and timeless moral lessons"),
    MORAL("Moral", "a moral story where a clear ethical choice and its consequences drive the plot"),
    DOCUMENTARY("Documentary", "a documentary-style story that explains a real subject clearly, with facts and wonder"),
    SUSPENSE("Suspense", "a suspense story with tension, mystery and a surprising turn"),
    HORROR("Horror", "a horror story with an eerie atmosphere and frightening moments"),
    ACTION("Action", "an action story with fast movement, chases and daring feats"),
    ADVENTURE("Adventure", "an adventure story with a journey, discovery and danger overcome");
    companion object { fun fromStoredName(name: String?): StoryGenre }
}
data class StoryDraft(
    val title: String, val hook: String, val narration: String,
    val dialogue: List<DialogueLine>, val language: String, val isLocalDraft: Boolean,
    val genre: StoryGenre = StoryGenre.ISLAMIC
)
data class ScenePlan(
    val orderIndex: Int, val title: String, val description: String,
    val cameraAngle: String, val cameraMovement: String, val lighting: String,
    val location: String, val atmosphere: String, val characterNames: List<String>,
    val visualPrompt: String = "" // one-sentence visual direction, derived from the scene text
)
data class CharacterSheet(
    val name: String, val age: Int, // age 0 = unknown
    val appearance: String, val clothing: String, val facialFeatures: String,
    val isMainCharacter: Boolean = false, val mentionCount: Int = 0
)
data class ProductionPlan(
    val projectId: String, val title: String, val story: StoryDraft,
    val scenes: List<ScenePlan>, val characters: List<CharacterSheet>
)
enum class ApprovalType {
    PLAN_APPROVAL, STORY_CONCEPT_CHANGE, MAJOR_CHARACTER_CHANGE,
    REMOVE_IMPORTANT_SCENE, MAJOR_CREATIVE_ALTERNATIVE
}
data class ApprovalRequest(
    val id: String, val projectId: String, val type: ApprovalType,
    val description: String, val createdAt: Long
)
```

## State machine — package `com.pakvideo.aistudio.domain.statemachine`

```kotlin
class ProductionStateMachine {
    fun canTransition(from: ProjectState, to: ProjectState): Boolean
    fun transition(from: ProjectState, to: ProjectState): ProjectState // throws IllegalStateException on illegal
}
```

Legal transitions (exactly these; nothing else):

- IDLE -> PLANNING
- PLANNING -> SCRIPTING, AWAITING_APPROVAL, FAILED, IDLE
- AWAITING_APPROVAL -> SCRIPTING, PLANNING, IMAGE_GENERATION, FAILED, IDLE
  (IMAGE_GENERATION is the approve path: `approve()` transitions here before
  the guard check; the earlier list omitted it, which made approval throw.)
- SCRIPTING -> STORYBOARDING, AWAITING_APPROVAL, FAILED, IDLE
- STORYBOARDING -> IMAGE_GENERATION, AWAITING_APPROVAL, FAILED, IDLE
- IMAGE_GENERATION -> VIDEO_GENERATION, AWAITING_APPROVAL, FAILED, IDLE
- VIDEO_GENERATION -> VOICE_GENERATION, AWAITING_APPROVAL, FAILED, IDLE
- VOICE_GENERATION -> EDITING, FAILED, IDLE
- EDITING -> QUALITY_CHECK, FAILED, IDLE
- QUALITY_CHECK -> COMPLETED, EDITING, FAILED, IDLE
- COMPLETED -> (terminal, no outgoing transitions)
- FAILED -> IDLE, PLANNING

Illegal transition error message: `"Illegal transition: $from -> $to"`.

## Data layer — package `com.pakvideo.aistudio.data.local` (Room) and `com.pakvideo.aistudio.data.repository`

Entities (Room, foreign keys with CASCADE delete, index on `projectId`):

```kotlin
@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String, // UUID
    val name: String,
    val userPrompt: String,
    val script: String = "",
    val characterDescriptions: String = "", // JSON of List<CharacterSheet>, may be empty
    val status: String = "IDLE", // ProjectState.name
    val errorLog: String = "",
    val genre: String = "ISLAMIC", // v3: StoryGenre.name; pre-v3 rows read as ISLAMIC
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "scenes", foreignKeys = [ForeignKey(entity = ProjectEntity::class, parentColumns = ["id"], childColumns = ["projectId"], onDelete = ForeignKey.CASCADE)], indices = [Index("projectId")])
data class SceneEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: String,
    val orderIndex: Int,
    val title: String,
    val description: String,
    val cameraAngle: String = "",
    val cameraMovement: String = "",
    val lighting: String = "",
    val location: String = "",
    val atmosphere: String = "",
    val characterRefs: String = "",
    val visualPrompt: String = "", // v2: one-sentence visual direction from the DirectorAgent
    val status: String = "IDLE"
)

@Entity(tableName = "characters", foreignKeys = [ForeignKey(entity = ProjectEntity::class, parentColumns = ["id"], childColumns = ["projectId"], onDelete = ForeignKey.CASCADE)], indices = [Index("projectId")])
data class CharacterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: String,
    val name: String,
    val age: Int = 0,
    val appearance: String = "",
    val clothing: String = "",
    val facialFeatures: String = "",
    val isMainCharacter: Boolean = false, // v2: speaks repeatedly / mentioned often
    val mentionCount: Int = 0, // v2: dialogue lines + narration mentions
    val referenceImagePath: String? = null
)

@Entity(tableName = "task_events", foreignKeys = [ForeignKey(entity = ProjectEntity::class, parentColumns = ["id"], childColumns = ["projectId"], onDelete = ForeignKey.CASCADE)], indices = [Index("projectId")])
data class TaskEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: String,
    val timestamp: Long,
    val state: String, // ProjectState.name at the time
    val message: String,
    val type: String // "INFO" | "ERROR" | "APPROVAL"
)
```

Database: `AppDatabase : RoomDatabase`, entities = [ProjectEntity, SceneEntity,
CharacterEntity, TaskEventEntity, ImageTaskEntity], version = 4, exportSchema = false.
Database name: `"pakvideo.db"`.

**v1 -> v2 migration** (`MIGRATION_1_2`, in `AppDatabase.kt`): adds only new
columns with defaults, so every existing row survives untouched:
`scenes.visualPrompt TEXT NOT NULL DEFAULT ''`,
`characters.isMainCharacter INTEGER NOT NULL DEFAULT 0`,
`characters.mentionCount INTEGER NOT NULL DEFAULT 0`. No table is dropped, no
column removed or renamed, no row deleted. A Robolectric `MigrationTest`
builds a v1 database, seeds it, opens it at v3 and verifies every row.

**v2 -> v3 migration** (`MIGRATION_2_3`): adds only
`projects.genre TEXT NOT NULL DEFAULT 'ISLAMIC'` (the user's chosen story
genre, `StoryGenre.name`; rows created before v3 read back as ISLAMIC).
`MigrationTest` also builds the exact v2 schema, seeds it, opens it at v3
and verifies every row plus the genre default.

**v3 -> v4 migration** (`MIGRATION_3_4`): creates the `image_tasks` table and
indexes. Existing projects, scenes, characters, and events are preserved.
Phase 3 introduces a provider-neutral `ImageGenerationProvider` contract,
explicitly disabled provider adapters until supported APIs are configured,
a reviewable scene prompt builder using approved character sheets, and durable
per-scene image task states. A task marked SUCCEEDED must reference a validated
non-empty local image file; unavailable providers never create placeholder images.

Repository interface — package `com.pakvideo.aistudio.data.repository`:

```kotlin
interface ProjectRepository {
    suspend fun createProject(project: ProjectEntity): String
    suspend fun getProject(id: String): ProjectEntity?
    fun getAllProjects(): Flow<List<ProjectEntity>>
    suspend fun updateProject(project: ProjectEntity)
    suspend fun deleteProject(id: String)
    suspend fun renameProject(id: String, newName: String)
    suspend fun updateProjectState(id: String, state: ProjectState, errorMessage: String? = null)
    suspend fun updateScript(id: String, script: String) // title + hook + narration + dialogue
    suspend fun addScene(scene: SceneEntity): Long
    fun getScenes(projectId: String): Flow<List<SceneEntity>>
    suspend fun updateScene(scene: SceneEntity)
    suspend fun deleteScene(sceneId: Long)
    suspend fun deleteProjectScenes(projectId: String)
    suspend fun addCharacter(character: CharacterEntity): Long
    fun getCharacters(projectId: String): Flow<List<CharacterEntity>>
    suspend fun updateCharacter(character: CharacterEntity)
    suspend fun deleteCharacter(characterId: Long)
    suspend fun deleteProjectCharacters(projectId: String)
    suspend fun logEvent(event: TaskEventEntity)
    fun getEvents(projectId: String): Flow<List<TaskEventEntity>>
}
```

`updateProjectState` stores `state.name`; when `errorMessage` is non-null it appends
the message to the project's `errorLog` (with timestamp) and updates `updatedAt`.

## FreeBudgetGuard + provider registry — package `com.pakvideo.aistudio.domain.guard`

```kotlin
enum class ProviderId { GEMINI_TEXT, IMAGE_GENERATION, VEO_VIDEO, MUSE_IMAGE, MUSE_VIDEO, URDU_TTS, LOCAL_EDITING }
enum class ProviderStatus { ENABLED, DISABLED, LOCAL_ONLY }
data class ProviderInfo(val id: ProviderId, val displayName: String, val status: ProviderStatus, val reason: String, val model: String? = null)
object ProviderRegistry {
    fun all(): List<ProviderInfo>
    fun get(id: ProviderId): ProviderInfo
}
sealed class GuardDecision {
    data class Allowed(val provider: ProviderId) : GuardDecision()
    data class Blocked(val provider: ProviderId, val reason: String) : GuardDecision()
}
data class GuardAttempt(val provider: ProviderId, val model: String?, val result: String, val quotaStatus: String, val timestamp: Long)
class FreeBudgetGuard(
    private val apiKeyProvider: (() -> String?)? = null,
    private val freeTierConfirmedProvider: (() -> Boolean)? = null,
    private val proxyBaseUrlProvider: (() -> String?)? = null
) {
    val attempts: List<GuardAttempt>
    fun isProxyMode(): Boolean // true when a non-blank proxy URL is configured
    fun check(provider: ProviderId): GuardDecision
    fun hasFreeQuota(provider: ProviderId): Boolean
    fun recordAttempt(provider: ProviderId, model: String?, result: String, quotaStatus: String)
    companion object {
        const val NO_FREE_QUOTA_MESSAGE = "No free generation quota available."
        const val FREE_TIER_NOT_CONFIRMED_MESSAGE = "Free-tier use is not confirmed for this key. Confirm in Settings that the key belongs to a billing-free project; until then only local drafts are used."
        const val FREE_TIER_NOT_CONFIRMED_PROXY_MESSAGE = "Free-tier use is not confirmed for this proxy. Confirm in Settings that the proxy enforces free-tier-only use with its own server-side key; until then only local drafts are used."
        const val INVALID_PROXY_URL_MESSAGE = "The configured Gemini proxy URL is invalid. Use a valid HTTPS URL."
    }
}
```
```

**A key is NOT proof of free quota.** For `GEMINI_TEXT` the guard requires
an explicit free-tier confirmation by the user
(`freeTierConfirmedProvider` — the Settings toggle where the user attests
the calls are free-tier only). Two modes:
- DIRECT (no proxy configured): a non-blank key AND the confirmation.
  Key without confirmation -> `Blocked` with
  `FREE_TIER_NOT_CONFIRMED_MESSAGE`, and the attempt is recorded with
  quota status `"user-confirmed-unverified"` (never `"free"`).
- PROXY (a non-blank proxy URL is configured): NO local key is required —
  only the confirmation. Without it -> `Blocked` with
  `FREE_TIER_NOT_CONFIRMED_PROXY_MESSAGE` (quota `"user-confirmed-unverified"`). The
  proxy must hold its own server-side key and enforce free-only use; the
  app cannot verify that either, which is exactly why the confirmation is
  still required in proxy mode.
This is a deliberate limitation, documented in `docs/API_CONFIGURATION.md`
and in the Settings screen: the app **cannot verify** a key's billing
status from the device — Google's public API exposes no endpoint that
reports a project's billing status, and the Gemini API only reports quota
errors after a chargeable call has already been attempted. The confirmation
is a user attestation, not a verification. The recommended production
control is a server-side proxy (see the Gemini section below): the key
lives on the server, the server enforces free-tier-only calls, and the
device never holds a key.

Provider table (model = null for ALL providers in Phase 1-2 — never invent model identifiers):

| ProviderId | displayName | status | reason |
|---|---|---|---|
| GEMINI_TEXT | Gemini Text | DISABLED | Disabled until you enter your own free Gemini API key in Settings. |
| IMAGE_GENERATION | Image Generation | DISABLED | Image generation arrives in Phase 3. |
| VEO_VIDEO | Veo Video | DISABLED | No free generation quota available. |
| MUSE_IMAGE | Muse Image | DISABLED | No supported official API available. |
| MUSE_VIDEO | Muse Video | DISABLED | No supported official API available. |
| URDU_TTS | Urdu TTS | LOCAL_ONLY | Local Android TTS fallback only (Phase 5). |
| LOCAL_EDITING | Local Editing | DISABLED | Local editing arrives in Phase 5. |

`check()`: ENABLED or LOCAL_ONLY -> Allowed; DISABLED -> Blocked(reason).
For `GEMINI_TEXT`: proxy mode -> confirmation only (no key needed);
direct mode -> no key -> Blocked(registry reason); key but no free-tier
confirmation -> Blocked(`FREE_TIER_NOT_CONFIRMED_MESSAGE`, quota `"user-confirmed-unverified"`);
key + confirmation -> Allowed (quota `"user-confirmed-unverified"`).
`hasFreeQuota()`: true only for ENABLED or LOCAL_ONLY, and for GEMINI_TEXT
only with confirmation (plus a key in direct mode). Every `check()` call
records an attempt via `recordAttempt()`.

## Agents — package `com.pakvideo.aistudio.domain.agents`

```kotlin
enum class StorySource { GEMINI, LOCAL_FALLBACK }

class StoryAgent(
    private val guard: FreeBudgetGuard,
    private val geminiClient: GeminiApiClient? = null,
    private val apiKeyProvider: (() -> String?)? = null,
    private val modelProvider: (() -> String?)? = null,
    private val proxyBaseUrlProvider: (() -> String?)? = null
) {
    val lastStorySource: StorySource // GEMINI or LOCAL_FALLBACK, for the last createStory call
    val lastFallbackReason: String? // why the last story fell back, null when it came from Gemini; never contains a key
    fun detectLanguage(prompt: String): String // "ur" if prompt contains Arabic-script chars U+0600-U+06FF, else "en"
    suspend fun createStory(userPrompt: String, language: String, genre: StoryGenre = StoryGenre.ISLAMIC): StoryDraft
}
```
`createStory` first calls `guard.check(ProviderId.GEMINI_TEXT)`. When Allowed
and a `geminiClient` is present, it generates with the real Gemini API and
returns the story with `isLocalDraft = false`,
`lastStorySource = GEMINI`, `lastFallbackReason = null`. On ANY Gemini failure
(request error, unparseable response) — or when the guard blocks, no key is
configured (direct mode), or no client exists — it builds a clearly-labelled
LOCAL draft (`isLocalDraft = true`, `lastStorySource = LOCAL_FALLBACK`,
`lastFallbackReason` set, e.g. "Gemini unavailable: ..." or "Gemini request
failed: ..."). A local draft is never model output: title = user prompt
trimmed to 60 chars; hook derived from the prompt's first clause; narration =
3 short paragraphs (setup / development / ending) built around the prompt
topic and labelled with the genre; dialogue = empty list. Never pretend the
draft is model output. Local drafts are built entirely on-device and make no
network call.
The model is never chosen silently: only models on
`GeminiModels.FREE_TIER_MODELS` (`gemini-3.8-flash`, `gemini-3.6-flash`,
`gemini-3.5-flash-lite`, verified 2026-11-23) are ever called; a configured
model outside that list — a paid model, or a retired one like
`gemini-2.0-flash` — is refused with a recorded reason and the local draft
is used instead. The default model is `GeminiModels.DEFAULT_MODEL`
(`gemini-3.8-flash`).
Genre: the Gemini prompt asks for the user's selected genre
(`StoryGenre.promptGuidance`). There is NO family-friendly-only rule —
suspense and horror are supported genres. Provider safety restrictions
still apply: the app never asks the model to bypass them.
When `proxyBaseUrlProvider` returns a non-blank URL, Gemini requests go to
that server-side proxy and no key is sent from the device — not even when a
key is saved locally. In proxy mode no local key is required at all; only
the free-tier confirmation is.

```kotlin
class DirectorAgent(
    private val characterAgent: CharacterConsistencyAgent = CharacterConsistencyAgent()
) {
    fun planScenes(story: StoryDraft, characters: List<CharacterSheet>): List<ScenePlan>
    fun deriveCamera(sceneText: String, isFirstScene: Boolean, sceneCharacters: List<String>, dialogueSpeakers: Set<String>): Pair<String, String>
    fun deriveLighting(sceneText: String): String
    fun deriveLocation(sceneText: String): String
    fun deriveAtmosphere(sceneText: String): String
    fun mentionsName(text: String, name: String): Boolean // whole-word, case-insensitive (Latin); substring (Urdu)
    companion object {
        const val DIRECTION_LABEL = "Rule-based storyboard — direction derived from keywords in the scene text, not AI-generated."
    }
}
```
**This is a RULE-BASED storyboard, not an AI director.** Every direction is
derived from the scene's own text by fixed keyword rules — no model is
called, nothing is generated by AI, and the same story always produces the
same plan. The label ([DIRECTION_LABEL]) is shown in the Workspace
storyboard and scene-prompts tabs and in the plan approval description;
this output must never be described as AI-generated direction.
Deterministic: split narration into sentences (on `.` `!` `?` `۔` `؟`) and
convert every dialogue line into a separate `Speaker: line` beat. Narration beats
precede dialogue beats because the data model stores them separately and does
not preserve their original interleaving. Group 2 beats per scene, minimum 1
scene, no fixed scene-count limit. Nothing cycles
through fixed templates — every direction is derived from the scene's own
text (English and Urdu cues both recognised, word-start matching for Latin
so "ran" does not match "grand"):
- location: the place named in the scene (palace, court, mosque, forest,
  river, sea, desert, mountain, battlefield, village, bazaar, garden,
  prison, cave, bridge, well, city, home), first match wins; when the scene
  names no place, "Location not specified in the story".
- lighting: night/midnight/moon -> "Moonlit night"; dawn/sunrise -> "Soft dawn
  light"; evening/sunset -> "Golden evening light"; lamp/lantern/candle ->
  "Warm lamplight"; storm/rain/thunder -> "Stormy overcast light"; otherwise
  the default "Bright daylight".
- camera (priority order): the opening scene establishes the world ("Wide
  establishing shot", "Slow pan left"); a scene where a character who has
  dialogue in the story appears -> "Close-up on the speaker", "Static";
  action words (runs, strikes, falls, chases, throws...) -> "Dynamic wide
  action shot", "Tracking"; emotion words (cries, weeps, smiles, tears...) ->
  "Close-up", "Slow push-in"; otherwise "Medium shot", "Static".
- atmosphere: danger/fear/enemy -> "Tense"; celebration/joy -> "Joyful";
  sorrow/tears/grief -> "Sorrowful"; hope/prayer/faith -> "Hopeful";
  otherwise "Calm".
- `visualPrompt`: one sentence combining character identity + scene
  action + location + lighting + atmosphere + camera, e.g.
  "Photorealistic cinematic wide establishing shot of Ahmed, 35 years
  old (From the story: \"white beard\"; From the story: \"white robe\";
  Not specified in the story — add details in Workspace), Ahmed entered
  the palace at midnight, in Royal palace, Moonlit night, Calm mood."
  Character identity comes from the APPROVED sheet, rendered by
  `CharacterConsistencyAgent.describeForPrompt` — the exact same text in
  every scene where the character appears, so the description is reused
  word-for-word across scenes. Unknown details keep their
  "Not specified in the story" marker in the prompt; the prompt never
  invents them. Stored on `SceneEntity.visualPrompt` (v2) and shown in
  the Workspace; ready to be used as an image prompt in Phase 3.
`characterNames` = characters whose names appear in the scene text
(whole-word, case-insensitive for Latin; substring for Urdu), plus explicit
non-Narrator dialogue speakers in that scene. Unknown speaker names remain
listed but do not receive invented character-sheet details.

```kotlin
class CharacterConsistencyAgent {
    fun createSheet(name: String, age: Int, appearance: String, clothing: String, facialFeatures: String, isMainCharacter: Boolean = false, mentionCount: Int = 0): CharacterSheet
    fun deriveCharacters(story: StoryDraft): List<CharacterSheet>
    fun extractNarrationNames(narration: String): List<String> // names mentioned in the narration, first-appearance order
    fun describeForPrompt(sheet: CharacterSheet): String // the approved sheet in one fixed format for scene prompts
    fun countMentions(name: String, text: String): Int // whole-word count, case-insensitive for Latin
    fun checkConsistency(original: CharacterSheet, updated: CharacterSheet): List<String> // human-readable list of changed fields, e.g. "clothing changed"
    fun reuseSheetForScene(sheet: CharacterSheet, sceneIndex: Int): String // reference text embedding name + role (main/supporting) + clothing + facial features for a scene prompt
    companion object { const val NOT_SPECIFIED = "Not specified in the story — add details in Workspace" }
}
```
`deriveCharacters`: characters are identified from the story itself — from
the NARRATION as well as from dialogue speakers (except "Narrator"), in
order of first appearance. A story with no dialogue still has characters
when its narration names them; the list is empty only when the story names
nobody at all. Narration names (Latin): capitalised word sequences that
appear at least twice, or at least once not at a sentence start, excluding
common words and pronouns. (Urdu has no capitalisation: narration-only names
are accepted only after explicit markers such as `نام احمد تھا`; repeated
role nouns are not treated as names. Dialogue speaker labels are also used.)
The Workspace lets the user review and edit each saved character sheet; edits
update matching visual prompts and the project JSON snapshot. A speaker is a
MAIN character when they speak at least twice or are mentioned at least
three times in total (dialogue lines + narration mentions, stored as
`mentionCount`); anyone else is a supporting character. Physical details
are NEVER invented: appearance, clothing and facial features are filled
only from words actually written in the story near the character's name —
searched inside the name's own sentence (40 chars before, 80 after) plus
the speaker's own dialogue lines, never from a sentence about someone
else — and are then labelled `From the story: "<exact words>"`. Anything
the story does not say stays `NOT_SPECIFIED`. Age comes only from an
explicit number near the name ("35-year-old", "35 years old", "35 سال");
descriptive words like "old man" never become a number, otherwise age
stays 0 (unknown). `describeForPrompt` renders the approved sheet in one
fixed format — `Name, <age> years old (appearance; clothing; facial
features)`, age omitted when unknown — and the DirectorAgent puts exactly
that text into every scene prompt where the character appears.

```kotlin
class MasterOrchestrator(
    private val repository: ProjectRepository,
    private val stateMachine: ProductionStateMachine,
    private val storyAgent: StoryAgent,
    private val directorAgent: DirectorAgent,
    private val characterAgent: CharacterConsistencyAgent,
    private val guard: FreeBudgetGuard
) {
    companion object { const val MAX_RETRIES = 3 }
    val pendingApproval: StateFlow<ApprovalRequest?>
    suspend fun startProduction(projectId: String)
    suspend fun approve(approvalId: String)
    suspend fun reject(approvalId: String)
    suspend fun cancel(projectId: String)
    suspend fun resume(projectId: String)
}
```

Orchestrator behaviour (Phase 1-2):

- `startProduction`: allowed only from IDLE, FAILED or PLANNING; loads the project
  (throws IllegalArgumentException if missing). Transitions IDLE/FAILED/PLANNING ->
  PLANNING (via state machine; PLANNING -> PLANNING is NOT a legal transition, so
  when already PLANNING skip the transition and continue). Then with retry
  (max MAX_RETRIES attempts, log each failure as a TaskEvent ERROR):
  1. PLANNING: build a one-line plan summary (including the project's
     genre, e.g. "(Horror story)"), log it.
  2. -> SCRIPTING: `storyAgent.createStory(prompt, detectLanguage(prompt),
     StoryGenre.fromStoredName(project.genre))`; save script text (title + hook +
     full narration + every dialogue speaker/line) via `repository.updateScript`.
     Immediately after creation, read `storyAgent.lastStorySource` /
     `lastFallbackReason` and log an INFO event stating the story source:
     "Story source: real Gemini generation", or "Story source: LOCAL fallback
     draft — Gemini unavailable (<reason>). The draft is an outline around
     the user's prompt, not model output." A real Gemini story and a local
     fallback draft are never confused — not in the event log, not in the
     approval.
  3. -> STORYBOARDING: derive characters via `characterAgent.deriveCharacters(story)`,
     then call `directorAgent.planScenes(story, characters)`. The Director includes
     every narration sentence and dialogue line (no scene-count cap). Before
     persisting the new result, clear the project's prior generated scenes and
     characters; then persist each scene (including `visualPrompt`) and each
     character (including `isMainCharacter` and `mentionCount`). This makes a
     sequential resume/rebuild idempotent instead of accumulating duplicates.
  4. -> AWAITING_APPROVAL: create `ApprovalRequest` (type PLAN_APPROVAL,
     description = plan summary + genre + story-source label + the
     rule-based storyboard label, e.g. "Plan for '...' (Horror story):
     3 scenes, 2 characters. Story source: real Gemini generation.
     Rule-based storyboard — direction derived from keywords in the scene
     text, not AI-generated. Review the plan before image generation."),
     expose via `pendingApproval`, log APPROVAL event, and STOP (wait for
     the user).
  On any step's final retry failure: transition to FAILED, store the error message,
  log ERROR event.
- `approve(approvalId)`: only when state is AWAITING_APPROVAL and the id matches the
  pending request. Clears pending approval, transitions to IMAGE_GENERATION, then
  checks `guard.check(ProviderId.IMAGE_GENERATION)` -> Blocked: log ERROR, transition
  to FAILED with that reason, and stop. (If it were Allowed, Phase 1-2 would still
  stop here: transition to FAILED with "Image generation arrives in Phase 3." —
  never fake a generated image.) Never ask for payment approval.
- `reject(approvalId)`: only from AWAITING_APPROVAL with matching id. Clears pending
  approval, transitions to PLANNING, logs "Plan rejected by user — awaiting revised
  prompt". The user can then send a revised prompt via `startProduction` again.
- `cancel(projectId)`: from any non-terminal state (not COMPLETED, not FAILED,
  not IDLE) transitions to IDLE via the state machine, clears pending approval,
  logs "Production cancelled by user".
- `resume(projectId)`: only from FAILED; transitions FAILED -> PLANNING and re-runs
  the `startProduction` flow.
- Every state change: `repository.updateProjectState(...)` + `repository.logEvent(...)`.

## Preferences — package `com.pakvideo.aistudio.data.preferences`

```kotlin
class SettingsStore(context: Context) {
    fun saveGeminiApiKey(key: String)   // EncryptedSharedPreferences ONLY
    fun getGeminiApiKey(): String?
    fun clearGeminiApiKey()
    fun setLanguage(code: String)       // "en" | "ur"
    fun getLanguage(): String
    fun isFreeOnlyMode(): Boolean       // ALWAYS true, locked
    fun getStorageInfo(): String
}
```
API key file name: `"pakvideo_secure_prefs"`. Plain prefs file name: `"pakvideo_prefs"`.

## DI — package `com.pakvideo.aistudio.di`

```kotlin
class AppContainer(context: Context) {
    val settingsStore: SettingsStore
    val database: AppDatabase
    val repository: ProjectRepository
    val stateMachine: ProductionStateMachine
    val guard: FreeBudgetGuard
    val storyAgent: StoryAgent
    val directorAgent: DirectorAgent
    val characterAgent: CharacterConsistencyAgent
    val orchestrator: MasterOrchestrator
}
```
Lazy vals, single instance each. Application context only (no Activity reference).

## UI — package `com.pakvideo.aistudio.ui.*`

- `MainActivity` (`com.pakvideo.aistudio.MainActivity`): ComponentActivity, `setContent`
  with `PakVideoTheme` + `NavGraph`. Creates `AppContainer(applicationContext)`.
- Navigation routes (exact strings): `"home"`, `"chat/{projectId}"`,
  `"workspace/{projectId}"`, `"creations"`, `"settings"`.
- ViewModels (package `ui.viewmodel`):
  - `HomeViewModel(container)`: `projects: Flow<List<ProjectEntity>>`;
    `createProject(name, prompt): String` (UUID, status IDLE, returns id);
    `deleteProject(id)`, `renameProject(id, newName)`.
  - `ProductionViewModel(container, projectId)`: `project`, `scenes`, `characters`,
    `events` flows; `pendingApproval: StateFlow<ApprovalRequest?>` (from orchestrator);
    `sendPrompt(prompt)` (updates prompt if needed, then `orchestrator.startProduction`);
    `approve()`, `reject()`, `cancel()`, `resume()` (delegate to orchestrator, using the
    pending approval id where applicable).
  - `WorkspaceViewModel(container, projectId)`: `project`, `scenes`, `characters`;
    `updateScript(script)`, `updateScene(scene)`, `updateCharacter(character)`,
    `addCharacter(name)`; character edits/additions update matching saved visual
    prompts and the project's character-sheet JSON snapshot.
  - `CreationsViewModel(container)`: `projects` flow; `renameProject`, `deleteProject`.
  - `SettingsViewModel(container)`: `language`, `apiKeyPresent: Boolean`,
    `providers: List<ProviderInfo>` (from ProviderRegistry), `storageInfo`,
    `geminiModel`, `geminiHealthy: Boolean` (true only with key + free-tier
    confirmation), `freeTierConfirmed: Boolean`, `geminiProxyUrl: String`;
    `setLanguage(code)`, `saveApiKey(key)`, `clearApiKey()` (also clears the
    free-tier confirmation), `setGeminiModel(model)`,
    `setFreeTierConfirmed(confirmed)`, `setGeminiProxyUrl(url)`.
  - `ViewModelFactory(container)` in `ui.viewmodel`: creates the above (needs
    projectId for Production/Workspace view models — factory methods
    `production(projectId)`, `workspace(projectId)` returning the ViewModel, used
    with `androidx.lifecycle.viewmodel.compose.viewModel`).
- Screens (package `ui.screens`): `HomeScreen`, `AgentChatScreen`,
  `WorkspaceScreen`, `MyCreationsScreen`, `SettingsScreen`. All use
  `stringResource(...)` — never hardcode user-visible English/Urdu text in Kotlin.
- Theme (package `ui.theme`): `Color.kt`, `Theme.kt`, `Type.kt` — Material 3 dark
  cinematic theme using the palette above.
- NO Video Generator screen and NO Editor screen in Phase 1-2 (Phase 4/5). No buttons
  that pretend to generate video/images.
- Home screen actions: New AI Production, Continue Project, My Projects, AI Studio
  Tools — each shows an honest status label (e.g. tools show provider availability).
- Agent Chat: prompt input (Urdu + English), agent reasoning summary text, current
  task status chip, approval card with Approve/Reject buttons, Cancel and Resume
  buttons.
- Settings: language switcher (English/Urdu), Free-only mode shown ON and locked
  (disabled switch, cannot be turned off), storage info, provider availability list,
  API key entry (saved only via SettingsStore), free-tier confirmation switch
  (attests the key belongs to a billing-free project; until confirmed, only
  local drafts are used), optional Gemini proxy URL field, Gemini model field,
  privacy controls (clear API key, delete all projects).

## Strings

`res/values/strings.xml` (English) and `res/values-ur/strings.xml` (Urdu). App name
`PAKVIDEO AI STUDIO` in both. Include at least: app_name, home, new_production,
continue_project, my_projects, ai_studio_tools, agent_chat, workspace, creations,
settings, prompt_hint, send, cancel, resume, approve, reject, status, language,
free_only_mode, free_only_mode_locked, storage, providers, api_key, api_key_hint,
save_api_key, clear_api_key, privacy, delete_all_projects, no_free_quota
("No free generation quota available."), project_name_hint, rename, delete,
script, storyboard, characters, scene_prompts, local_draft ("Local draft"),
plan_approval_title, no_projects_yet, error, retry.

## Tests — `app/src/test/java/com/pakvideo/aistudio/`

JUnit 4 + kotlinx-coroutines-test. Use a `FakeProjectRepository` (in-memory
implementation of the contract interface) — do NOT test Room DAOs on the JVM
(needs instrumented tests; note as TODO in README).
- Persistence tests use Robolectric (`testImplementation "org.robolectric:robolectric:4.11.1"`)
  with an in-memory Room database: insert a project, reload it by id, update its state,
  and resume it (FAILED -> PLANNING -> AWAITING_APPROVAL via the real orchestrator).
- Migration tests use Robolectric with a file database: build the exact v1 schema,
  seed rows, open with Room at v3 (`MIGRATION_1_2` + `MIGRATION_2_3`) and verify
  every row survives with the new columns at their defaults (`MigrationTest`),
  plus a v2-schema build opened at v3 (genre defaults to ISLAMIC, rows intact)
  and a round-trip of the new columns (including a HORROR-genre project).
- Regression tests for the pre-Phase 3 review, one file per fix:
  `FreeBudgetGuardTest` (key without confirmation is blocked, quota
  `"user-confirmed-unverified"`; proxy mode needs no key, only confirmation),
  `GeminiApiClientTest` (no key in any URL, proxy mode sends
  no key), `DirectorAgentTest` (story-derived camera/lighting/location/
  atmosphere/visual prompt with the approved character sheet, no template
  cycling; rule-based label), `CharacterConsistencyAgentTest`
  (main-character detection, story-quoted evidence, no invented details, no
  cross-character leaks, narration-only characters, `describeForPrompt`),
  `StoryAgentTest` + `MasterOrchestratorTest`
  (Gemini vs local-fallback source in events and approval; proxy mode
  without a local key; non-free-tier models refused; every genre reaches
  the prompt with no family-friendly rule; genre + rule-based label in the
  approval),
  `SettingsStoreTest` (confirmation defaults false, proxy URL defaults empty,
  model defaults to `gemini-3.8-flash`),
  `GeminiModelsTest` (default + allowlist; retired 2.0 and restricted 2.5
  models excluded; paid models excluded),
  `MigrationTest` (v1 and v2 rows preserved).

## Gemini API integration (added 2026-11-23, Phase 1-2 follow-up; hardened 2026-11-23, pre-Phase 3 review)

- Endpoint (official, documented): `https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent`
- Default model (real free-tier model, configurable in Settings): `gemini-3.8-flash`
  — the newest stable Flash, explicitly named by Google for new projects,
  free tier "Free of charge", no shutdown announced (verified 2026-11-23).
  `gemini-2.0-flash` (the old default) was RETIRED 2026-06-01 and must never
  be used again.
- **Free-tier model allowlist** (`data/remote/GeminiModels.kt`):
  `FREE_TIER_MODELS = {gemini-3.8-flash, gemini-3.6-flash, gemini-3.5-flash-lite}`
  (verified 2026-11-23 against Google's pricing page). Only these models are
  ever called. A configured model outside the list — a paid model, a retired
  model, or a restricted one (the 2.5 models are limited to users who actively
  used them in the past; new projects get a 404) — is refused by `StoryAgent`
  with a recorded reason, and the local draft is used instead. The app NEVER
  silently switches to a paid model. Google retires models often: when a call
  fails with a model error, check the pricing page and update the list.
- Key source ONLY: `SettingsStore.getGeminiApiKey()` (EncryptedSharedPreferences).
  Never hardcoded, never logged, never in source, **never in a URL**.
- `data/remote/GeminiApiClient.kt`:
  ```kotlin
  object GeminiRequestBuilder {
      fun urlFor(model: String, proxyBaseUrl: String?): String
      fun headersFor(apiKey: String?, proxyBaseUrl: String?): Map<String, String>
  }

  open class GeminiApiClient {
      open suspend fun generateText(
          apiKey: String,
          model: String,
          prompt: String,
          proxyBaseUrl: String? = null
      ): Result<String>
  }
  ```
  HttpURLConnection POST, `Content-Type: application/json`, **the key is sent
  as the `x-goog-api-key` request header, never as a `?key=` URL parameter**;
  30s connect/read timeouts, `org.json` parsing of
  `candidates[0].content.parts[0].text`; any failure -> `Result.failure`
  (error messages contain only the HTTP status — never the URL, the key, or
  the response body). Never log the key. No new main dependencies
  (HttpURLConnection + org.json are built into Android).
- **Server-side proxy (recommended for production):** when
  `SettingsStore.getGeminiProxyUrl()` returns a non-blank URL, requests go
  to `<proxy>/v1beta/models/<model>:generateContent` and NO key is sent from
  the device — the proxy injects the key server-side. The device never holds
  a key in proxy mode, and NO local key is required: proxy mode needs only
  the free-tier confirmation. The proxy itself MUST hold its own server-side
  key and enforce free-tier-only use; the app cannot verify that either,
  which is exactly why the confirmation is still required in proxy mode.
  `GeminiRequestBuilder` keeps the URL/header rules pure and unit-testable
  (`GeminiApiClientTest`).
- Proxy URLs must be HTTPS, include a valid host, and contain no credentials,
  query string or fragment; invalid URLs are rejected in Settings and blocked
  by the guard.
- `SettingsStore` additions: `fun getGeminiModel(): String` (default
  `"gemini-3.8-flash"`), `fun setGeminiModel(model: String)`;
  `fun isFreeTierConfirmed(): Boolean` / `fun setFreeTierConfirmed(Boolean)`
  (plain prefs, default false — the user's free-tier attestation, NOT a
  secret); `fun getGeminiProxyUrl(): String` /
  `fun setGeminiProxyUrl(url: String)` (plain prefs, default "", trimmed).
  Clearing the API key also clears the free-tier confirmation: a new key
  may belong to a different project and must be confirmed again.
- `FreeBudgetGuard` key-aware: constructor gains optional
  `apiKeyProvider: (() -> String?)? = null`,
  `freeTierConfirmedProvider: (() -> Boolean)? = null` and
  `proxyBaseUrlProvider: (() -> String?)? = null`.
  `check(GEMINI_TEXT)`: proxy mode -> confirmation only (no key needed,
  `FREE_TIER_NOT_CONFIRMED_PROXY_MESSAGE` when unconfirmed); direct mode ->
  no key -> `Blocked` with the registry reason; key but no confirmation ->
  `Blocked` with `FREE_TIER_NOT_CONFIRMED_MESSAGE`
  (quota status `"user-confirmed-unverified"`); key + confirmation -> `Allowed` (quota `"user-confirmed-unverified"`).
  `hasFreeQuota()` mirrors `check()`. All other providers unchanged.
  Every `check()` still records an attempt. See the guard section above for
  the documented limitation: **the app cannot verify a project's billing
  status** — the confirmation is an attestation, and the proxy is the
  recommended production control.
- `StoryAgent` constructor becomes:
  ```kotlin
  StoryAgent(
      guard: FreeBudgetGuard,
      geminiClient: GeminiApiClient? = null,
      apiKeyProvider: (() -> String?)? = null,
      modelProvider: (() -> String?)? = null,
      proxyBaseUrlProvider: (() -> String?)? = null
  )
  ```
  `createStory`: `guard.check(GEMINI_TEXT)`; if Allowed and a client is present
  -> check the configured model against `GeminiModels.FREE_TIER_MODELS`
  (refuse + local draft with a recorded reason when it is not on the list),
  then call the client with a story-writing prompt for the project's genre
  (ask for title, one-sentence hook, 3-paragraph narration, dialogue lines as
  `Speaker: line`; the prompt carries the genre guidance and NEVER a
  family-friendly-only rule); on success parse into `StoryDraft(isLocalDraft
  = false)`, `lastStorySource = GEMINI`, `lastFallbackReason = null`; on ANY
  failure -> fall back to the local draft path (never throw for Gemini
  failures), `lastStorySource = LOCAL_FALLBACK` with `lastFallbackReason` set.
  If the guard blocks / no client -> local draft path exactly as before. In
  proxy mode the call is made with an empty key (the client sends no key
  header at all for a proxy); in direct mode the guard already ensured a key
  exists.
- `AppContainer` additions: `val geminiClient: GeminiApiClient`; construct the
  guard as `FreeBudgetGuard({ settingsStore.getGeminiApiKey() }, { settingsStore.isFreeTierConfirmed() }, { settingsStore.getGeminiProxyUrl() })`
  and the story agent as `StoryAgent(guard, geminiClient, { settingsStore.getGeminiApiKey() }, { settingsStore.getGeminiModel() }, { settingsStore.getGeminiProxyUrl() })`.
- Provider health check (Settings): `SettingsViewModel` exposes
  `geminiModel: String`, `geminiHealthy: Boolean` (true only when the guard
  allows — key + free-tier confirmation in direct mode, confirmation only
  in proxy mode), `freeTierConfirmed: Boolean`, `geminiProxyUrl: String`,
  `fun setGeminiModel(model: String)`,
  `fun setFreeTierConfirmed(confirmed: Boolean)`,
  `fun setGeminiProxyUrl(url: String)` (also refreshes health). `SettingsScreen`
  shows a free-tier confirmation switch with the attestation text, a Gemini
  proxy URL field (with the proxy's own-key + free-only requirement), a
  Gemini model text field (default `gemini-3.8-flash`) with the free-tier
  model list, and a health status row that says "ready — direct" / "ready —
  proxy (no key on this device)" / "confirmation needed" / "not configured"
  instead of ever claiming a key is verified.
- `HomeViewModel.createProject(name, prompt, genre: StoryGenre = ISLAMIC)`;
  `HomeScreen`'s new-project dialog offers a genre picker (all 7 genres);
  project cards show the stored genre. `ProjectEntity.genre` persists it
  (v3 migration).
- Gradle: add `testImplementation "org.robolectric:robolectric:4.11.1"` for JVM
  Room persistence tests.
- Docs: `docs/FIREBASE_SETUP.md`, `docs/API_CONFIGURATION.md` (contents per the
  task brief, updated for header auth, the proxy option, the free-tier
  attestation and the billing-verification limits); `README.md` references both.

## Strings (additional keys for the Gemini follow-up)

gemini_model, gemini_model_hint, provider_health, key_configured,
key_not_configured. All must exist in both `values/strings.xml` and `values-ur/strings.xml`.

## Strings (additional keys for the pre-Phase 3 review)

free_tier_confirm, free_tier_confirm_text, gemini_proxy, gemini_proxy_text,
gemini_proxy_hint, save_proxy. All must exist in both `values/strings.xml`
and `values-ur/strings.xml`.

## Strings (additional keys for the second review, 2026-11-23)

genre, genre_islamic, genre_moral, genre_documentary, genre_suspense,
genre_horror, genre_action, genre_adventure, rule_based_storyboard,
gemini_model_free_list, gemini_ready_direct, gemini_ready_proxy,
gemini_needs_confirmation. All must exist in both `values/strings.xml`
and `values-ur/strings.xml`.

## Second review (2026-11-23) — fixes applied before Phase 3

The user independently reviewed the corrected ZIP/APK from the first
review and ordered these fixes; Phase 3 stays gated until they are
fixed and reviewed:

1. **Gemini model:** the default `gemini-2.0-flash` was retired
   2026-06-01. New default `gemini-3.8-flash` (newest stable Flash,
   free tier, named by Google for new projects). `GeminiModels`
   (`data/remote/GeminiModels.kt`) holds the verified free-tier
   allowlist (`gemini-3.8-flash`, `gemini-3.6-flash`,
   `gemini-3.5-flash-lite`, verified 2026-11-23); `StoryAgent` refuses
   any other model and falls back to a local draft. Never silently use
   a paid model.
2. **Proxy mode bug:** `FreeBudgetGuard` and `StoryAgent` required a
   local key even with a proxy configured. Fixed: direct mode needs key
   + confirmation; proxy mode needs confirmation only, never sends a
   device key to the proxy (empty key at the call site; no key header
   in the client). The proxy must hold its own server-side key and
   enforce free-only use — documented in the contract, the API guide
   and the Settings screen.
3. **Genres:** the hardcoded family-friendly-only instruction is
   removed. Seven user-selected genres (Islamic, moral, documentary,
   suspense, horror, action, adventure), chosen per project at
   creation, stored on `ProjectEntity.genre` (v3 migration), passed
   through the orchestrator to `StoryAgent`. Provider safety
   restrictions still apply; the app never asks the model to bypass
   them.
4. **Character consistency:** characters are identified from narration
   as well as dialogue; the list is empty only when the story names
   nobody. `describeForPrompt` renders the approved sheet in one fixed
   format; the DirectorAgent puts that exact text into every relevant
   scene's `visualPrompt`. Unknown details keep their marker.
5. **Director:** the storyboard is explicitly labelled rule-based
   (keyword-derived), not AI-generated — in the class KDoc, the
   `DIRECTION_LABEL` constant, the Workspace tabs and the plan
   approval. The visual prompt now carries character identity, scene
   action, location, atmosphere, lighting and camera direction.
6. **Free-tier safeguards:** no claim that the app can verify Google's
   billing status; paid-only model IDs and paid fallbacks are never
   selected; Gemini requests require a user attestation that billing is
   disabled. This attestation is not technical enforcement: if the Cloud
   project has billing enabled, Google may bill the same allowed model.
   Strict zero-charge use requires billing disabled or Gemini left
   unconfigured. Local drafts remain available offline without network.
7. **Verification:** regression tests for every correction (new
   `GeminiModelsTest`; proxy/genre/model tests in `StoryAgentTest` and
   `FreeBudgetGuardTest`; narration tests in
   `CharacterConsistencyAgentTest`; sheet-in-prompt tests in
   `DirectorAgentTest`; genre + narration tests in
   `MasterOrchestratorTest`; v2->v3 test in `MigrationTest`; model
   default in `SettingsStoreTest`); real build + full test run; the
   corrected ZIP, rebuilt APK and real logs are returned.
