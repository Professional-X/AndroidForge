# PAKVIDEO AI STUDIO — Third Review Corrections

## Scope

This revision edits the latest supplied Phase 1+2 ZIP. It does not start Phase 3.

## Corrections made

1. **Complete script persistence:** saved script now contains title, hook, full narration, and every dialogue speaker/line.
2. **Dialogue-aware storyboard:** all narration sentences and dialogue lines become storyboard beats. There is no eight-scene cap. The current data model stores narration and dialogue separately, so narration beats are placed before dialogue beats; the original interleaving cannot be reconstructed.
3. **Sequential resume idempotency:** generated scene and character rows for the project are cleared before the replacement storyboard is persisted. A failed partial run can be resumed without accumulating duplicate scene/character rows.
4. **Quota audit honesty:** Gemini audit entries use `user-confirmed-unverified`, never `free`; local-only providers use `local-only`.
5. **Proxy URL validation:** only valid HTTPS proxy base URLs are accepted. URLs with credentials, query strings, fragments, missing hosts, or invalid ports are rejected. Invalid configured proxies are blocked rather than treated as direct mode.
6. **Urdu character extraction:** repeated Urdu role nouns are no longer automatically classified as character names. Narration-only Urdu names require explicit name markers; dialogue speaker labels are used. Mixed Urdu/English narration is handled by both detectors and sorted by first appearance.
7. **Character sheet review/editing:** Workspace allows editing existing character sheets and adding missing characters manually. Changes update the project JSON snapshot and matching scene visual prompts.
8. **Documentation:** README and CONTRACT were updated for Room v3, dialogue persistence, unlimited scene grouping, proxy validation, character editing, and unverified quota labels.

## Verification completed

- 114 targeted test methods were executed using a local JUnit-compatible reflection harness:
  - CharacterConsistencyAgentTest + DirectorAgentTest: 41
  - FreeBudgetGuardTest: 18
  - GeminiApiClientTest: 9
  - StoryAgentTest: 19
  - MasterOrchestratorTest: 12
  - GeminiModelsTest: 7
  - ProductionStateMachineTest: 8
- The coroutine test wrapper used `runBlocking`; Android/Room repository entities and the Gemini network client were replaced by minimal test doubles for the pure domain/orchestrator test run. This is not the Gradle/JUnit/Robolectric full suite.
- Changed domain pipeline classes compiled with local Kotlin 1.9.0 and the locally available coroutines library, using test doubles for Android/Room repository classes.
- Actual GeminiApiClient + GeminiRequestBuilder + ProxyUrlValidator compiled with lightweight `org.json` stubs.
- Actual Room entity/DAO/repository interfaces and repository implementation compiled with lightweight Room annotation stubs.
- All 8 XML files parsed successfully.
- All 61 referenced `R.string.*` values exist in both English and Urdu resources.

## Not verified / remaining

- Full Android Gradle build and official Gradle test task were **not run**. The environment had no cached Gradle 8.7 distribution or Android SDK, and `./gradlew testDebugUnitTest` could not download Gradle because network DNS was unavailable (`UnknownHostException: services.gradle.org`).
- The Compose UI and Android SettingsStore were source-reviewed but not compiled against the real Android/Compose dependency graph in this environment.
- No new APK was built. The separate APK uploaded alongside the source ZIP is an earlier build; it was not modified or relabelled as the corrected app. The corrected source ZIP does not contain an APK.
- No installation or real-device test was performed on the Infinix phone.

## Required next verification

Open this ZIP in Android Studio on a machine with JDK 17, Android SDK 34, and network access; run `./gradlew clean testDebugUnitTest assembleDebug`; then install the newly built APK on the phone and test character editing, script dialogue persistence, resume behavior, and proxy URL validation. Phase 3 should remain blocked until those checks pass.

## Follow-up audit (2026-11-23)

A further source audit found and fixed stale free-tier confirmation after API-key/proxy changes, overstrong billing-safety wording, an incorrect claim that Phase 1+2 makes no network calls, and a static Gemini provider status row. Details and current verification limits are in `FOLLOW_UP_AUDIT.md`.

The latest follow-up edits passed XML/resource-reference/static-source checks. The official Gradle test task was attempted again but could not start because `services.gradle.org` could not be resolved in this environment. The earlier 114 targeted-test run belongs to the previous source snapshot and is not claimed as a test result for this latest revision. No APK was rebuilt.
