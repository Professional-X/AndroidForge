// Top-level build file for PAKVIDEO AI STUDIO (Phase 1+2).
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    // Compose Compiler plugin (required from Kotlin 2.0 when compose is
    // enabled); version declared here so the app module applies it
    // version-less.
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
    id("com.google.devtools.ksp") version "2.0.21-1.0.25" apply false
}
