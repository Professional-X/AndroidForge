package com.mixer.one.data

import android.content.Context

/**
 * Which look the volume overlay uses: the normal Nothing-style design or the glass variant.
 * Plain SharedPreferences so the overlay service can read it synchronously when it appears.
 */
object DesignPrefs {
    private const val FILE = "miXXer_design"
    private const val KEY_GLASS = "glass"

    fun isGlass(context: Context): Boolean =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_GLASS, false)

    fun setGlass(context: Context, glass: Boolean) {
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_GLASS, glass).apply()
    }
}
