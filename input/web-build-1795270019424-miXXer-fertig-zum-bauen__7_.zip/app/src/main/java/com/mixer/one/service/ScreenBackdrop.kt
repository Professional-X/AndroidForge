package com.mixer.one.service

import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.util.Log
import rikka.shizuku.Shizuku
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * A snapshot of the screen, used as the backdrop that the clear glass design refracts.
 *
 * An overlay window cannot read what is drawn behind it. With Shizuku the shell's `screencap`
 * can: it prints the raw frame (12-16 byte header, then RGBA pixels). The overlay is invisible
 * while this runs, so it is not part of the snapshot.
 */
object ScreenBackdrop {

    private const val TAG = "ScreenBackdrop"
    private const val FORMAT_RGBA_8888 = 1
    private const val FORMAT_RGBX_8888 = 2

    class Result(val bitmap: Bitmap, val inkDark: Boolean)

    /** Blocking (~100-300 ms): call from a background thread. Null if anything is not available. */
    fun capture(): Result? {
        return try {
            if (!Shizuku.pingBinder() ||
                Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED
            ) {
                Log.d(TAG, "Shizuku not usable, no snapshot")
                return null
            }
            val started = System.currentTimeMillis()
            val newProcess = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            newProcess.isAccessible = true
            val process = newProcess.invoke(null, arrayOf("screencap"), null, null) as Process
            val bytes = process.inputStream.readBytes()
            process.waitFor()
            val bitmap = decode(bytes) ?: return null
            Log.d(TAG, "snapshot ${bitmap.width}x${bitmap.height} in ${System.currentTimeMillis() - started} ms")
            Result(bitmap, inkDarkFor(bitmap))
        } catch (t: Throwable) {
            Log.w(TAG, "Snapshot failed: ${t.javaClass.simpleName}", t)
            null
        }
    }

    private fun decode(bytes: ByteArray): Bitmap? {
        if (bytes.size < 16) return null
        val head = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val w = head.getInt(0)
        val h = head.getInt(4)
        val format = head.getInt(8)
        if (w <= 0 || h <= 0 || (format != FORMAT_RGBA_8888 && format != FORMAT_RGBX_8888)) {
            Log.w(TAG, "Unsupported snapshot format: ${w}x$h format=$format")
            return null
        }
        val pixelBytes = w * h * 4
        val header = bytes.size - pixelBytes
        if (header !in 12..64) {
            Log.w(TAG, "Unexpected snapshot size: ${bytes.size} for ${w}x$h")
            return null
        }
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bitmap.copyPixelsFromBuffer(ByteBuffer.wrap(bytes, header, pixelBytes))
        return bitmap
    }

    private fun isBackdropBright(bitmap: Bitmap): Boolean = averageLuminance(bitmap) > 0.55f

    /** Dark ink on bright surroundings, white ink on dark surroundings. */
    private fun inkDarkFor(bitmap: Bitmap): Boolean = isBackdropBright(bitmap)

    /** Average luminance (0..1) of the area where the overlay appears (right side of the screen). */
    private fun averageLuminance(bitmap: Bitmap): Float {
        val w = bitmap.width
        val h = bitmap.height
        val landscape = w > h
        val x0 = if (landscape) (w * 0.55f).toInt() else (w * 0.35f).toInt()
        val y0 = if (landscape) (h * 0.05f).toInt() else (h * 0.20f).toInt()
        val y1 = if (landscape) (h * 0.95f).toInt() else (h * 0.75f).toInt()
        var sum = 0f
        var n = 0
        val steps = 24
        for (i in 0 until steps) {
            for (j in 0 until steps) {
                val x = x0 + (w - 1 - x0) * i / (steps - 1)
                val y = y0 + (y1 - y0) * j / (steps - 1)
                val c = bitmap.getPixel(x.coerceIn(0, w - 1), y.coerceIn(0, h - 1))
                sum += (0.2126f * Color.red(c) + 0.7152f * Color.green(c) + 0.0722f * Color.blue(c)) / 255f
                n++
            }
        }
        return sum / n
    }
}
