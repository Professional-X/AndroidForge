# Quick Launch v2.3.0

**The real Google Assistant alternative.** Full voice control, a searchable digital assistant gesture that finally works, better crash stability, and a streamlined UI.

## Headline: Voice control — trigger the assist gesture twice

This is the feature you were asking for:

1. **First trigger** (long-press home, corner swipe, or power button) opens the palette in typing mode.
2. **Second trigger** while the palette is already open switches to **voice listening mode**.
3. Speak naturally: `"play love me do"`, `"call mom"`, `"open gmail"`, `"what's my battery"`, `"weather"`, or anything you'd type.
4. Your words are searched and executed just like keyboard input — no account, no network, no ads.

**Setup:** Grant the microphone permission in Settings → Voice control. Then:
- Assistant gesture (the system one) — tap twice while open
- Or tap the mic button in the palette itself
- Or use the old zero-setup trigger (standard speech dialog, still supported)

This works with every installed app's search feature, and integrates seamlessly with Quick Launch's calculator, web search, apps, contacts, file search, and all other providers.

## Fixed

- **Digital assistant redirect button did nothing** — cast fragility left it silently broken. Now uses a context-unwrapping helper with guaranteed fallback.
- **Random crash while searching** — results are sorted by score (not grouped by category), so the same category header could appear twice, producing duplicate `LazyColumn` keys. Headers now include position, so this can't happen.
- **Palette not appearing on second assist-gesture tap** — it did, but there was no feedback. Now it intelligently switches to voice mode if you're already open.
- Removed stale "ask why is the sky blue" sample chip left over from the Ask AI feature.

## Changed

- **Package renamed** — `com.example.quicklaunch` → `com.profapps.quicklaunch` (required by Play Store). Existing installs must be uninstalled first.
- **Recents trimmed to 2** (was 5) — keeps pinned apps and sample commands visible.
- The mic button now has dual behavior: if you have mic permission and the palette is open, taps it to listen in-place; if not, falls back to the zero-setup speech dialog (closes palette, opens system UI).

## Added

- **Voice control interpreter** — `VoiceControlInterpreter` (new) handles speech recognition, permission checks, error recovery, and state management.
- **Voice control UI** — palette shows "Listening…" with a pulsing progress bar while the mic is active; mic button icon turns primary blue to indicate active listening; keyboard is disabled during voice input.
- **Voice control settings row** — new "Voice control" entry in Settings → Triggers, shows mic permission status, offers a one-tap grant button.
- **Quick info provider** — type `battery`, `time`, `date` for zero-permission instant answers.

## Under the hood

- `VoiceControlInterpreter.kt` — new, handles all speech recognition plumbing: SpeechRecognizer init, RecognitionListener contract, permission checks, error callbacks.
- `PaletteController` — now owns the voice interpreter, exposes `voiceIsListening`, `startVoiceInput()`, `stopVoiceInput()`, and `onDestroy()` for cleanup.
- `OverlayService.onStartCommand()` — now detects second assist-gesture tap (show action while already showing) and routes to `startVoiceInput()` instead of re-showing.
- `OverlayPanel.kt` — voice-aware text field: shows listening indicator instead of editable field while listening; mic button toggles between listen/stop states; displays mic color feedback.
- `SettingsViewModel` — new `micPermissionGranted` state and `isMicGranted()` check in `PermissionChecker`.
- All voice-related strings added; permission dialogs respect system defaults.

## Upgrading

Same as v2.2.0: the package name change means **uninstall the old version first**. Device permissions will need to be re-granted, but your settings are (never) synced anywhere — losing them on reinstall is expected and unavoidable until the app has a server (which it never will).

## Testing

Tested on:
- Pixel 4a, 5, 6 Pro (gesture assist gesture, voice recognition)
- Samsung S20, S21 (corner swipe assist gesture, voice recognition)
- OnePlus 9 (power-button assist gesture)
- Pixel emulator (voice recognition without gesture)
- Without overlay permission (fallback to in-app palette works smoothly)
- Without mic permission (mic button shows permission-denied error, fallback to zero-setup trigger works)

---

**Full Changelog**: v2.2.0...v2.3.0

## Changes

- New: `VoiceControlInterpreter.kt` (speech recognition, permission plumbing)
- `PaletteController`: voice state management, interpreter lifecycle
- `OverlayService.onStartCommand()`: detect second tap, route to voice
- `OverlayPanel`: voice-aware text field, listening indicator, mic button dual-mode
- `SettingsScreen.kt`: mic permission row, voice control trigger info
- `SettingsViewModel.kt`: `micPermissionGranted` state, `isMicGranted()` check
- `SearchFieldRow`: voice listening state, disabled text input during listening
- String resources: voice control labels, error messages, accessibility hints
- Version bumped: `2.2.0` (versionCode 7) → **`2.3.0`** (versionCode 8)
