# Quick Launch

A fast, floating **command palette for Android** — a mobile adaptation of KDE
Plasma's KRunner and Apple's Spotlight Search, built as an original,
production-quality Android app.

Open a compact search panel near the top of the screen over whatever app you
are using, type anything, find something useful, execute it, and it disappears.

```
┌─────────────────────────────────────┐
│  🔍  Search apps, actions, web…  ✕  │
├─────────────────────────────────────┤
│  Apps                               │
│  [icon] Chrome                      │
│  [icon] Camera                      │
│                                     │
│  Calculator                         │
│  =  (5+3)*7                    56   │
│  🌐  Search web for "…"             │
└─────────────────────────────────────┘
```

## What's new in v2.2.0

**1. Releasable at last: package renamed off `com.example`.**
`com.example.quicklaunch` → `com.profapps.quicklaunch`. The old id is a
reserved namespace that Play Console refuses outright — this was a hard
blocker to shipping anywhere, not cosmetic. Existing `2.1.x` installs must be
uninstalled before installing this build (different applicationId means
Android treats it as a different app).

**2. Fixed: the "Set as assistant" button could silently do nothing.**
It cast the Compose context straight to `Activity`; when that cast came back
null the whole handler — including its own fallback — bailed out with no
feedback. Replaced with a context-unwrapping helper, so the button now
always either shows the system role dialog or opens assistant settings.

**3. Fixed a real crash in search results.**
Results are sorted by score, not grouped by category, so the same category
header could appear twice non-adjacently — producing two identical
`LazyColumn` keys and crashing with `Key ... was already used`. Header keys
now include their position, so this can't happen again.

**4. Recents trimmed to the latest 2** (was 5) so pinned apps and sample
commands aren't pushed off-screen.

**5. New: Quick info provider.** Type `battery`, `time`, or `date` for an
instant, zero-permission answer — tap to copy, same as the calculator.

## What's new in v2.1.0

**1. The assistant gesture now really works — trigger it exactly like Google
Assistant.**
Two defects were found and fixed:

- **Picker qualification**: the built-in recognition service did not declare
  the `BIND_RECOGNITION_SERVICE` permission required by the Android
  `RecognitionService` contract — exactly the kind of spec violation that
  makes some Android builds ignore an app when qualifying "Digital assistant
  app" candidates. Fixed.
- **The gesture did nothing without the overlay permission**: the assist
  handler silently no-oped when the overlay permission was missing, so
  long-pressing home/power appeared completely dead. It now always falls
  back to the in-app palette, so the gesture always does something visible.

After you set Quick Launch as the digital assistant, the **same gestures that
open Google Assistant open the palette**: swipe up and hold (gesture nav) /
long-press the home button, swipe diagonally from a bottom screen corner, and
long-press the power button on devices that map it to the assistant (on
Android 11+ enable *Gestures → Press and hold power button → Digital
assistant*).

**2. "Make it already default" — the closest Android allows.**
No app can silently assign itself the assistant role (it is a user-protected
setting). Quick Launch now shows the system's **one-tap dialog** ("Set Quick
Launch as your assistant?") automatically, once per install — accept it and
you are done. The same one-tap button stays in *Settings → Triggers →
Assistant gesture*.

**3. Ask AI removed (optional feature).**
The optional AI chat feature shipped in v2.0.0 has been removed entirely, as
it depended on a third-party API key that is not reliably available. The app
is back to being a 100% on-device utility: **no INTERNET permission at all**
(web results still open in your browser app, which does not require the app
to hold the permission). If you ever want it back with a fresh key, ask — the
code lives in the v2.0.0 archive.

## What's new in v1.2.0

**1. The assistant/voice trigger works everywhere — zero setup.**
A zero-setup voice path that works on any device with the Google speech
service:

- **VoiceSearchActivity** — a translucent trampoline: opens the standard
  speech dialog and pushes the recognized words straight into the palette
  (floating overlay when permitted, in-app palette otherwise).
- **New launcher shortcuts** — long-press the app icon: *Open Quick Launch*,
  *Voice search*, *Search files*.
- **Widget got a mic button** — bolt opens the palette, mic starts voice search.
- **Mic inside the palette** — tap the mic in the search bar to speak instead
  of type, and a "Voice search → Try it" row in Settings.
- The assist-gesture integration remains for users who *do* set
  Quick Launch as their digital assistant.

**2. Random crashes — root-caused and fixed.**

- **DataStore corruption** (the big one): all DataStore reads now use a
  `ReplaceFileCorruptionHandler` (reset to defaults and keep running), plus a
  self-healing collector that survives transient IO errors.
- **Unguarded coroutine scopes**: every scope now has a
  `CoroutineExceptionHandler`, and every hot-path body (search, recents,
  clipboard, pinning, replay, package lookups) is individually guarded.
- **Search pipeline**: the engine catches `Throwable` per provider, and the
  results list' scroll-to-selection is index-clamped and exception-guarded.

**3. Flashlight provider.**
Type (or say) `flashlight`, `torch`, `flashlight off` … in the palette and get
a one-tap camera-flash switch. Toggleable per provider in Settings.

## Features

- **Floating overlay** (`TYPE_APPLICATION_OVERLAY`) with smooth show/hide
  animation, subtle background dim, tap-outside and back-key dismissal,
  and immediate keyboard focus. Repeated triggers never create duplicate
  windows.
- **Modular search providers** (KRunner-style runners):
  - **Apps** — installed-app search with prefix, word-start, substring and
    fuzzy subsequence matching; recency and pinned boosts; cached package
    index that refreshes on install/uninstall/replace broadcasts.
  - **Calculator** — safe hand-written recursive-descent parser (`2+2`,
    `(5+3)*7`, `25% of 80`, `10 % 3`, unary minus, thousands separators).
    No `eval`, ever.
  - **Unit conversion** — fully offline: length, mass, temperature, volume,
    time, digital storage, speed (`10 km to miles`, `5kg in lb`, `100 c to f`).
  - **Web search** — configurable engine (Google / Bing / DuckDuckGo / Brave)
    via normal browser intents; direct URL detection. No scraping.
  - **Contacts** — optional, permission-gated; call/message actions.
  - **Settings shortcuts** — documented Android Settings intents
    (Wi-Fi, Bluetooth, Display, Apps, Sound, Battery, Date & time,
    Developer options).
  - **Clipboard** — offers to copy the query; clipboard reading only happens
    while the palette is open and focused, never in the background.
  - **File search** — on-device MediaStore lookup by file name across
    documents, images, videos, audio, archives and APKs (`file pdf taxes`).
  - **Flashlight** — `flashlight` / `torch` / `flashlight off`.
  - **Quick info** — `battery`, `time`, `date`: instant, zero-permission
    answers, tap to copy.
- **Explicit commands**: `open chrome`, `search cats`, `calc 10*5`,
  `settings wifi`, `convert 10 km to mi`, `file pdf taxes`, `=2+2`. Commands
  only ever *add* focus; ordinary search is never degraded.
- **Empty state that is not empty**: clipboard suggestion, recent results
  (one-tap replay), pinned apps (long-press an app result to pin/unpin) and
  sample command chips.
- **Keyboard support** with a hardware keyboard: arrows / Tab / Shift+Tab to
  move, Enter to activate, Esc or Back to dismiss.
- **Triggers** — nine of them, all routing through one launcher:
  - **Assistant gesture (like Google Assistant)**: set Quick Launch as the
    digital assistant — the exact assistant gestures (swipe up and hold /
    long-press home, bottom-corner swipe, power long-press where mapped)
    open the palette. One-tap system dialog offered automatically.
  - **Floating bubble** (assistive-touch style): draggable, edge-snapping,
    restored after reboot when enabled.
  - **Home-screen widget**: bolt button opens the palette, mic button starts
    voice search.
  - **Voice search**: standard speech dialog → palette, zero setup.
  - **Share to Quick Launch**: share text or links from any app.
  - **Pinned-app shortcuts**: launcher long-press shortcuts, kept in sync.
  - Persistent notification (optional), Quick Settings tile, launcher
    shortcut, in-app test button, plus an in-app palette fallback when the
    overlay permission is missing.
- **Appearance**: System/Light/Dark themes, panel opacity, compact mode,
  animation toggle. Material 3, restrained and fast — no dashboard aesthetic.
- **Privacy**: no analytics, no ads, **no INTERNET permission** — the app
  cannot make network connections. All data (recents, pins, settings) stays
  on-device; the only "network" action is opening a browser URL you chose.

## Requirements

- **Android Studio** Koala (2024.1) or newer — or any IDE with JDK 17/21.
- **JDK 17+** (the Gradle wrapper fetches Gradle 8.10.2 automatically).
- **Android SDK**: platform 35 + build-tools 35 (Android Studio installs these
  on first sync; Gradle also auto-downloads them when licenses are accepted).
- An Android 7.0+ (API 24) device or emulator. Overlay windows work best on
  Android 8+; full IME-in-overlay support is most reliable on Android 8–15.

## Build instructions

```bash
# From the project root:
./gradlew :app:assembleDebug

# Output:
# app/build/outputs/apk/debug/app-debug.apk

# Run the unit tests (88 tests: file-type logic, ranking, calculator,
# conversion, command parsing, search engine incl. cancellation,
# settings/VM logic):
./gradlew :app:testDebugUnitTest

# Install on a connected device:
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

In Android Studio: *File → Open…* → select the project folder → wait for sync
→ Run.

## First-run flow

1. Install and open **Quick Launch** — you land on the control center.
2. Accept the **"Set as assistant?"** dialog (shown once) to get the
   Google-Assistant-style gesture trigger — one tap, done. You can always
   change it later in *Settings → Triggers → Assistant gesture*.
3. Tap **Open Quick Launch now**. Without the overlay permission the app
   opens an in-app palette instead and shows a banner with a direct route to
   *Settings → Display over other apps*.
4. Grant **Display over other apps** for Quick Launch.
5. Trigger it any way you like: the assistant gesture, the **floating
   bubble**, the **widget**, voice search, the persistent notification, the
   **Quick Settings tile**, the launcher long-press shortcut, or the in-app
   test button.
6. Optional: grant **Photos & files** access so the file-search provider can
   find media from other apps.

## Assistant-gesture setup details

- Open the app once → accept the one-tap **"Set Quick Launch as your
  assistant?"** dialog (or *Settings → Triggers → Assistant gesture → Set as
  assistant*).
- **Gesture navigation**: swipe up and hold on the home pill, or swipe
  diagonally from either bottom corner → palette opens.
- **3-button navigation**: long-press the home button → palette opens.
- **Power button**: on Android 11+ many devices default long-press power to
  the power menu. To get the assistant on power long-press, enable
  *Settings → Gestures → Press and hold power button → Digital assistant*
  (wording varies by OEM; on Samsung: *Advanced features → Side button*).
- The assistant role is a user decision by Android's design — an app can
  request it with one tap, but never take it silently.

## Permissions and why

| Permission | Why | If denied |
|---|---|---|
| `SYSTEM_ALERT_WINDOW` | The floating palette window | Palette runs in-app only; banner explains and deep-links to settings; the assistant gesture falls back to the in-app palette |
| `POST_NOTIFICATIONS` (13+) | Persistent "Open Quick Launch" notification | Notification trigger is disabled; other triggers keep working |
| `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_SPECIAL_USE` | Keeps the overlay window alive while open | n/a (never user-prompted) |
| `READ_CONTACTS` | Contacts search | Contacts provider silently stays off; grant button lives in *Privacy* |
| `READ_EXTERNAL_STORAGE` (≤12) / `READ_MEDIA_IMAGES`·`VIDEO`·`AUDIO` (13+) | File search over MediaStore | File search finds nothing beyond app-owned files; everything else works |
| `RECEIVE_BOOT_COMPLETED` | Re-enables the floating bubble after reboot | Bubble reappears the next time the app is opened |

No `INTERNET` permission — the app is structurally unable to send anything
anywhere. Package visibility (`<queries>`) is limited to launchable apps,
browsers and dial/SMS handlers. The foreground service declares the
`specialUse` type with a documented subtype, as required on Android 14+.

## Supported Android versions

- **Minimum:** Android 7.0 (API 24) — overlay uses the legacy window type.
- **Target/compile:** Android 15 (API 35), AGP 8.7.3, Kotlin 2.0.21,
  Jetpack Compose BOM 2024.10.01, Material 3, DataStore, Coroutines/Flow.

## Known Android platform limitations

Honesty section — things Android simply does not allow ordinary apps to do:

1. **No global hotkeys.** Android does not permit arbitrary system-wide
   keyboard shortcuts for regular apps. Triggers are the assistant gesture,
   bubble, widget, voice search, share target, notification, QS tile,
   launcher shortcut and in-app. No Accessibility-service trickery is used,
   and none is required.
2. **Assistant integration requires a default-app switch.** Android only lets
   ONE app be the digital assistant; choosing Quick Launch replaces whatever
   was set (the gestures then open the palette instead of the stock
   assistant). An app can show the one-tap consent dialog but cannot flip
   the setting itself.
3. **Power long-press may need a device setting.** On Android 11+ several
   OEMs default long-press power to the power menu; map it to the assistant
   in the device's gesture settings (see above).
4. **Bubble after reboot.** The boot receiver restores the bubble when the
   user had it enabled; on some aggressive OEM ROMs autostart still needs to
   be whitelisted manually.
5. **IME reliability in overlays varies.** The overlay window is focusable and
   requests the keyboard, but some OEM builds refuse to show the IME for
   service-owned windows. Hardware keyboards always work, and the in-app
   palette is always available as a fallback.
6. **No background clipboard monitoring.** Android 10+ restricts clipboard
   access to focused windows. Quick Launch only peeks at the clipboard while
   its window is focused.
7. **No live currency rates.** Conversions are static offline tables.
8. **File search is name-based.** MediaStore indexes names and metadata;
   full-content search inside documents would require scanning every file.
9. **Recents are app-local.** Quick Launch ranks by its own on-device launch
   history instead of `PACKAGE_USAGE_STATS`.

## Architecture

```
com.profapps.quicklaunch
├── app/               Application, DI container, package broadcasts
├── overlay/           OverlayController, OverlayService (WindowManager),
│                      OverlayLifecycleOwner (Compose in a service window)
├── search/            SearchEngine, SearchProvider, models,
│   └── ranking/       FuzzyMatcher (deterministic, unit-tested)
├── providers/         apps / calculator / conversion / files / web /
│   │                  contacts / settings / clipboard / torch / quick info
│   └── files/         pure file-type logic (extension→category, MIME,
│                      filters, size formatting — unit-tested)
├── triggers/          NotificationTrigger, QuickSettingsTileService,
│                      FloatingBubbleService, QuickLaunchWidgetProvider,
│                      PaletteLaunchActivity, ShareTargetActivity,
│                      VoiceSearchActivity, BootCompletedReceiver,
│                      PinnedShortcuts
│   └── assist/        VoiceInteractionService + Session (assistant gesture,
│                      opens palette + in-app fallback) and a compliant
│                      no-op RecognitionService (picker qualification)
├── data/              DataStore-backed settings + recents repositories
├── ui/
│   ├── theme/         Material 3 theme (system/light/dark)
│   ├── overlay/       PaletteController + OverlayPanel (shared by overlay
│   │                  window and in-app mode)
│   └── settings/      Control-center screen + ViewModel
└── util/              Icon cache, clipboard/toast bridge
```

Performance notes: the package index is scanned once lazily and invalidated by
package broadcasts (never per keystroke); app icons go through an LRU cache;
providers run in parallel with per-provider timeouts; every keystroke search is
cancelled before the next begins, so stale results can never overwrite fresher
ones; nothing blocking runs on the main thread.
