package com.profapps.quicklaunch.triggers

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.profapps.quicklaunch.MainActivity
import com.profapps.quicklaunch.overlay.OverlayController
import com.profapps.quicklaunch.QuickLaunchApp
import com.profapps.quicklaunch.R

/**
 * Owns both notification channels:
 *  - the optional persistent "Open Quick Launch" notification (a trigger), and
 *  - the quiet foreground-service notification shown only while the palette
 *    window is on screen.
 */
object NotificationTrigger {

    const val PERSISTENT_NOTIFICATION_ID = 41
    const val SERVICE_NOTIFICATION_ID = 42

    private const val CHANNEL_PERSISTENT = "quick_launch_trigger"
    private const val CHANNEL_SERVICE = "quick_launch_service"

    fun ensureChannels(context: Context) {
        val manager = NotificationManagerCompat.from(context)
        val persistent = NotificationChannel(
            CHANNEL_PERSISTENT,
            context.getString(R.string.notif_channel_persistent_name),
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = context.getString(R.string.notif_channel_persistent_desc)
            setShowBadge(false)
        }
        val service = NotificationChannel(
            CHANNEL_SERVICE,
            context.getString(R.string.notif_channel_service_name),
            NotificationManager.IMPORTANCE_MIN,
        ).apply {
            description = context.getString(R.string.notif_channel_service_desc)
            setShowBadge(false)
        }
        runCatching {
            manager.createNotificationChannel(persistent)
            manager.createNotificationChannel(service)
        }
    }

    /** Posts or cancels the persistent trigger notification. */
    fun updatePersistentNotification(context: Context, enabled: Boolean) {
        val manager = NotificationManagerCompat.from(context)
        if (!enabled) {
            manager.cancel(PERSISTENT_NOTIFICATION_ID)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            return // Cannot post; settings screen explains why.
        }
        runCatching { manager.notify(PERSISTENT_NOTIFICATION_ID, buildPersistent(context)) }
    }

    private fun buildPersistent(context: Context): Notification {
        val showIntent = OverlayController.showPendingIntent(context)
        val openAppIntent = PendingIntent.getActivity(
            context,
            2,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(context, CHANNEL_PERSISTENT)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle(context.getString(R.string.notif_persistent_title))
            .setContentText(context.getString(R.string.notif_persistent_text))
            .setContentIntent(showIntent)
            .addAction(0, context.getString(R.string.notif_open_action), showIntent)
            .setOngoing(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_SYSTEM)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .also { it.addAction(0, context.getString(R.string.settings_title), openAppIntent) }
            .build()
    }

    /** Minimal notification for the overlay foreground service. */
    fun serviceNotification(context: Context): Notification =
        NotificationCompat.Builder(context, CHANNEL_SERVICE)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle(context.getString(R.string.notif_service_title))
            .setContentText(context.getString(R.string.notif_service_text))
            .setOngoing(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
}
