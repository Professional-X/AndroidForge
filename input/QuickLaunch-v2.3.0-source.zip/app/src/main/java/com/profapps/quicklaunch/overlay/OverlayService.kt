package com.profapps.quicklaunch.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.ServiceCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import androidx.compose.ui.platform.ComposeView
import com.profapps.quicklaunch.AppContainer
import com.profapps.quicklaunch.MainActivity
import com.profapps.quicklaunch.QuickLaunchApp
import com.profapps.quicklaunch.R
import com.profapps.quicklaunch.triggers.NotificationTrigger
import com.profapps.quicklaunch.ui.overlay.OverlayPanel
import com.profapps.quicklaunch.ui.overlay.PaletteController
import com.profapps.quicklaunch.ui.theme.QuickLaunchTheme
import com.profapps.quicklaunch.util.UiBridge
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Owns the floating command palette window.
 *
 * Design notes:
 *  - The window is MATCH_PARENT with a translucent scrim; the panel itself is
 *    a compact Surface near the top. Taps on the scrim dismiss the palette.
 *  - The window is focusable so the text field can receive the IME and
 *    hardware-keyboard events.
 *  - Compose content is hosted through [OverlayLifecycleOwner], following the
 *    lifecycle contract required for ComposeView outside an Activity.
 *  - Repeated triggers hit the same window: [show] guards on [isShowing].
 */
class OverlayService : android.app.Service() {

    // The guard matters: an unhandled exception in a service-owned scope
    // kills the whole process — the exact "random crash" class we are fixing.
    private val serviceScope = CoroutineScope(
        SupervisorJob() + Dispatchers.Main.immediate +
            CoroutineExceptionHandler { _, t ->
                android.util.Log.e("QuickLaunch", "Overlay scope failure", t)
            },
    )

    private var windowManager: WindowManager? = null
    private var overlayView: ComposeView? = null
    private var lifecycleOwner: OverlayLifecycleOwner? = null
    private var controller: PaletteController? = null
    private var isShowing = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        enterForeground()
        when (intent?.action ?: OverlayController.ACTION_SHOW) {
            OverlayController.ACTION_SHOW -> {
                // If already showing, a second trigger (e.g. second assist gesture)
                // should start voice input instead of just re-showing.
                if (isShowing) {
                    controller?.startVoiceInput()
                } else {
                    show()
                    // Voice search and file shortcuts may pre-fill the query.
                    val prefill = intent?.getStringExtra(OverlayController.EXTRA_SHOW_QUERY)
                    if (!prefill.isNullOrBlank()) {
                        controller?.onQueryChange(prefill)
                    }
                }
            }
            OverlayController.ACTION_HIDE -> dismissAndStop()
            OverlayController.ACTION_TOGGLE -> if (isShowing) dismissAndStop() else show()
        }
        return START_NOT_STICKY
    }

    private fun enterForeground() {
        val type = if (Build.VERSION.SDK_INT >= 34) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        ServiceCompat.startForeground(
            this,
            NotificationTrigger.SERVICE_NOTIFICATION_ID,
            NotificationTrigger.serviceNotification(this),
            type,
        )
    }

    private fun show() {
        if (!Settings.canDrawOverlays(this)) {
            // Permission was revoked while running. Route to the app: it
            // explains the limitation and links to the system settings page.
            val intent = Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(MainActivity.EXTRA_MISSING_OVERLAY_PERMISSION, true)
            runCatching { startActivity(intent) }
            UiBridge.toast(this, getString(R.string.overlay_missing))
            dismissAndStop()
            return
        }
        if (isShowing) return
        addOverlayWindow()
    }

    @SuppressLint("RtlHardcoded")
    private fun addOverlayWindow() {
        if (isShowing) return
        val wm = windowManager ?: return

        val owner = OverlayLifecycleOwner()
        lifecycleOwner = owner
        owner.performRestore(null)
        owner.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)

        val container = (application as QuickLaunchApp).container
        val settings = container.settingsRepository.settings.value

        val metrics = resources.displayMetrics
        val density = metrics.density
        val sideMarginPx = (12 * density).roundToInt()
        val topInsetPx = statusBarHeightPx()

        val panelController = PaletteController(
            context = this,
            engine = container.searchEngine,
            recents = container.recentsRepository,
            settings = container.settingsRepository,
            appIndex = container.appIndex,
            scope = serviceScope,
            onDismiss = { dismiss() },
        )
        controller = panelController

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            windowType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or
                WindowManager.LayoutParams.FLAG_SPLIT_TOUCH,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        }

        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setContent {
                QuickLaunchTheme(themeMode = settings.themeMode) {
                    OverlayPanel(
                        controller = panelController,
                        topInsetPx = topInsetPx,
                        sideMarginPx = sideMarginPx,
                        opacity = settings.panelOpacity,
                        compact = settings.compactMode,
                        animationsEnabled = settings.animationsEnabled,
                        onDismiss = { dismiss() },
                    )
                }
            }
        }

        try {
            wm.addView(view, params)
            overlayView = view
            isShowing = true
            owner.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
            panelController.onPaletteShown()
        } catch (e: Exception) {
            // Window token issues (e.g. permission revoked mid-flight) land here.
            android.util.Log.e("QuickLaunch", "Could not add overlay window", e)
            cleanupWindow()
            dismissAndStop()
        }
    }

    private fun windowType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun statusBarHeightPx(): Int {
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resourceId > 0) resources.getDimensionPixelSize(resourceId) else 0
    }

    /** Plays the exit animation, then tears the window down. */
    fun dismiss() {
        val current = controller ?: run { dismissAndStop(); return }
        current.panelVisible.value = false
        serviceScope.launch {
            delay(140) // matches the panel's exit animation duration
            dismissAndStop()
        }
    }

    private fun dismissAndStop() {
        cleanupWindow()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun cleanupWindow() {
        val view = overlayView
        val owner = lifecycleOwner
        val ctrl = controller
        overlayView = null
        controller = null
        ctrl?.stopVoiceInput()
        ctrl?.onDestroy()
        if (view != null && owner != null) {
            owner.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
            try {
                windowManager?.removeViewImmediate(view)
            } catch (e: Exception) {
                // View already detached; nothing to do.
            }
            owner.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
            owner.clearViewModels()
        }
        isShowing = false
    }

    override fun onDestroy() {
        cleanupWindow()
        serviceScope.cancel()
        super.onDestroy()
    }
}
