package com.profapps.quicklaunch.providers.calculator

/**
 * A safe, hand-written recursive-descent arithmetic evaluator. No Eval, no
 * javascript, no reflection — just a tiny grammar:
 *
 *   expression := term (('+' | '-') term)*
 *   term       := factor (('*' | '/' | '%') factor)*
 *   factor     := number | '(' expression ')' | ('+'|'-') factor
 *
 * "X% of Y" is normalised to "(X/100)*Y" before tokenizing. '%' between
 * numbers is modulo.
 */
object ExpressionEvaluator {

    sealed interface MathResult {
        data class Success(val value: Double, val normalized: String) : MathResult
        data class Failure(val message: String) : MathResult
    }

    private const val ERR_DIV_ZERO = "Cannot divide by zero"
    private const val ERR_INVALID = "Invalid expression"

    fun evaluate(input: String): MathResult {
        val normalized = normalize(input)
        if (normalized.isEmpty()) return MathResult.Failure(ERR_INVALID)
        val tokens = tokenize(normalized) ?: return MathResult.Failure(ERR_INVALID)
        if (tokens.isEmpty()) return MathResult.Failure(ERR_INVALID)
        val parser = Parser(tokens)
        val value = parser.parseExpression() ?: return MathResult.Failure(ERR_INVALID)
        if (!parser.atEnd()) return MathResult.Failure(ERR_INVALID)
        return MathResult.Success(value, normalized)
    }

    /** True when the query is pure arithmetic and worth evaluating. */
    fun looksLikeMath(input: String): Boolean {
        val s = input.trim()
        if (s.isEmpty()) return false
        // "25% of 80" contains letters; allow this exact shape directly.
        if (PERCENT_OF_PATTERN.matches(s)) return true
        var hasDigit = false
        var hasOperator = false
        for (c in s) {
            when (c) {
                in '0'..'9' -> hasDigit = true
                '+', '-', '*', '/', '%', '(', ')' -> hasOperator = true
                '.', '×', '÷', '−', ' ', '\t', ',' -> Unit
                else -> return false // any letter or other symbol disqualifies
            }
        }
        return hasDigit && hasOperator
    }

    private val PERCENT_OF_PATTERN = Regex(
        "^\\d+(?:\\.\\d+)?\\s*%\\s*of\\s*\\d+(?:\\.\\d+)?$",
        RegexOption.IGNORE_CASE,
    )

    /** Formats a double for display: integers without decimals, else trimmed. */
    fun formatNumber(value: Double): String {
        if (value.isNaN() || value.isInfinite()) return "∞"
        val rounded = Math.rint(value * 1e9) / 1e9
        return if (rounded == Math.floor(rounded) && !rounded.isInfinite()) {
            formatGroups(rounded.toLong())
        } else {
            var text = java.math.BigDecimal(rounded)
                .setScale(6, java.math.RoundingMode.HALF_UP)
                .stripTrailingZeros()
                .toPlainString()
            if (text.length > 15) text = text.take(15).trimEnd('.', '0')
            text
        }
    }

    private fun formatGroups(value: Long): String {
        val negative = value < 0
        var digits = java.lang.Long.toString(if (negative) -value else value)
        val sb = StringBuilder()
        while (digits.length > 3) {
            sb.insert(0, "," + digits.substring(digits.length - 3))
            digits = digits.substring(0, digits.length - 3)
        }
        sb.insert(0, digits)
        return (if (negative) "-" else "") + sb.toString()
    }

    private fun normalize(input: String): String {
        var s = input.trim()
            .replace('×', '*')
            .replace('÷', '/')
            .replace('−', '-')
            .replace('\u00A0', ' ')
        // Strip thousands separators like 1,000,000 (comma between digits).
        s = s.replace(Regex("(?<=\\d),(?=\\d)"), "")
        // "25% of 80" -> "(25/100)*80"
        s = s.replace(Regex("(\\d+(?:\\.\\d+)?)\\s*%\\s*of\\s*", RegexOption.IGNORE_CASE)) {
            "(${it.groupValues[1]}/100)*"
        }
        // Trailing or leading stray '=' (users often type "2+2=").
        s = s.trimEnd('=', ' ')
        s = s.trimStart('=', ' ')
        return s.trim()
    }

    private sealed interface Token
    private data class Num(val value: Double) : Token
    private data class Op(val symbol: Char) : Token
    private data class Paren(val open: Boolean) : Token

    private fun tokenize(input: String): List<Token>? {
        val tokens = mutableListOf<Token>()
        var i = 0
        while (i < input.length) {
            val c = input[i]
            when {
                c.isWhitespace() -> i++
                c.isDigit() || (c == '.' && i + 1 < input.length && input[i + 1].isDigit()) -> {
                    val start = i
                    var seenDot = false
                    while (i < input.length && (input[i].isDigit() || input[i] == '.')) {
                        if (input[i] == '.') {
                            if (seenDot) return null
                            seenDot = true
                        }
                        i++
                    }
                    val text = input.substring(start, i)
                    val value = text.toDoubleOrNull() ?: return null
                    tokens.add(Num(value))
                }
                c == '(' -> { tokens.add(Paren(true)); i++ }
                c == ')' -> { tokens.add(Paren(false)); i++ }
                c == '+' || c == '-' || c == '*' || c == '/' || c == '%' -> {
                    tokens.add(Op(c)); i++
                }
                else -> return null
            }
        }
        return tokens
    }

    private class Parser(private val tokens: List<Token>) {
        private var pos = 0

        fun atEnd(): Boolean = pos >= tokens.size

        fun parseExpression(): Double? {
            var left = parseTerm() ?: return null
            while (!atEnd() && tokens[pos] is Op &&
                (tokens[pos] as Op).symbol.let { it == '+' || it == '-' }
            ) {
                val op = (tokens[pos++] as Op).symbol
                val right = parseTerm() ?: return null
                left = if (op == '+') left + right else left - right
            }
            return left
        }

        private fun parseTerm(): Double? {
            var left = parseFactor() ?: return null
            while (!atEnd() && tokens[pos] is Op) {
                val op = (tokens[pos] as Op).symbol
                if (op != '*' && op != '/' && op != '%') break
                pos++
                val right = parseFactor() ?: return null
                left = when (op) {
                    '*' -> left * right
                    '/' -> if (right == 0.0) return null else left / right
                    else -> if (right == 0.0) return null else {
                        val r = left % right
                        // Align remainder sign with the mathematical definition.
                        if (r != 0.0 && (r < 0) != (right < 0)) r + right else r
                    }
                }
            }
            return left
        }

        private fun parseFactor(): Double? {
            if (atEnd()) return null
            return when (val token = tokens[pos]) {
                is Num -> { pos++; token.value }
                is Paren -> {
                    if (!token.open) return null
                    pos++
                    val inner = parseExpression() ?: return null
                    if (atEnd() || tokens[pos] !is Paren || (tokens[pos] as Paren).open) {
                        return null
                    }
                    pos++
                    inner
                }
                is Op -> {
                    // Unary plus / minus binds tighter than * and /.
                    if (token.symbol == '+' || token.symbol == '-') {
                        pos++
                        val value = parseFactor() ?: return null
                        if (token.symbol == '-') -value else value
                    } else {
                        null
                    }
                }
            }
        }
    }
}
