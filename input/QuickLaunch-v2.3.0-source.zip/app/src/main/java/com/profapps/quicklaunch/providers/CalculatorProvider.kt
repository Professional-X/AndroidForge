package com.profapps.quicklaunch.providers

import android.content.Context
import com.profapps.quicklaunch.R
import com.profapps.quicklaunch.data.ProviderIds
import com.profapps.quicklaunch.providers.calculator.ExpressionEvaluator
import com.profapps.quicklaunch.search.CommandHint
import com.profapps.quicklaunch.search.ResultCategory
import com.profapps.quicklaunch.search.ResultIcon
import com.profapps.quicklaunch.search.SearchProvider
import com.profapps.quicklaunch.search.SearchQuery
import com.profapps.quicklaunch.search.SearchResult
import com.profapps.quicklaunch.search.ActionResult
import com.profapps.quicklaunch.util.UiBridge

/**
 * Inline calculator. Accepts explicit "calc …" / "=…" commands and plain
 * arithmetic that looks like math. Never uses eval-style evaluation.
 */
class CalculatorProvider(private val context: Context) : SearchProvider {

    override val id = ProviderIds.CALCULATOR
    override val displayName = "Calculator"

    override suspend fun search(query: SearchQuery): List<SearchResult> {
        val expression: String = when (val hint = query.hint) {
            is CommandHint.Calc -> hint.expression
            else -> if (ExpressionEvaluator.looksLikeMath(query.raw)) query.raw else return emptyList()
        }
        if (expression.isBlank() || expression.length > 80) return emptyList()

        val result = ExpressionEvaluator.evaluate(expression)
        val value = (result as? ExpressionEvaluator.MathResult.Success)?.value
            ?: return emptyList() // Invalid math silently yields no result row.

        val display = ExpressionEvaluator.formatNumber(value)
        // Copy the unformatted value: "1,200.5" is nicer to read but worse to paste.
        val rawCopy = value.toString()

        return listOf(
            SearchResult(
                id = "calc:${expression.lowercase()}",
                title = display,
                subtitle = expression.trim(),
                icon = ResultIcon.ResourceIcon(R.drawable.ic_calc),
                score = if (query.hint is CommandHint.Calc) 1.0f else 0.97f,
                category = ResultCategory.CALCULATOR,
                copyText = rawCopy,
                action = {
                    UiBridge.copy(context, rawCopy)
                    UiBridge.toast(context, context.getString(R.string.copied))
                    ActionResult.Stay
                },
            )
        )
    }
}
