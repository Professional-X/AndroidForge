package com.profapps.quicklaunch.data

import android.content.ComponentName

/** Theme preference for the palette and settings screens. */
enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Offline-configurable web search engines. No scraping — plain browser URLs. */
enum class WebEngine(val label: String, val queryUrl: String) {
    GOOGLE("Google", "https://www.google.com/search?q="),
    BING("Bing", "https://www.bing.com/search?q="),
    DUCKDUCKGO("DuckDuckGo", "https://duckduckgo.com/?q="),
    BRAVE("Brave", "https://search.brave.com/search?q=");

    fun urlFor(query: String): String = queryUrl + java.net.URLEncoder.encode(query, "UTF-8")
}

/** Stable ids of the built-in search providers, used by the settings toggles. */
object ProviderIds {
    const val APPS = "apps"
    const val CALCULATOR = "calculator"
    const val CONVERSION = "conversion"
    const val WEB = "web"
    const val CONTACTS = "contacts"
    const val SETTINGS = "settings"
    const val CLIPBOARD = "clipboard"
    const val FILES = "files"
    const val TORCH = "torch"
    const val QUICK_INFO = "quick_info"

    val ALL = listOf(APPS, CALCULATOR, CONVERSION, WEB, CONTACTS, SETTINGS, CLIPBOARD, FILES, TORCH, QUICK_INFO)
}

/**
 * Immutable snapshot of user preferences. Defaults keep every safe provider on
 * and the palette tuned for speed (short animations, high opacity).
 */
data class QuickLaunchSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val panelOpacity: Float = 0.94f,
    val compactMode: Boolean = false,
    val animationsEnabled: Boolean = true,
    val webEngine: WebEngine = WebEngine.GOOGLE,
    val enabledProviders: Set<String> = ProviderIds.ALL.toSet(),
    val pinnedApps: Set<String> = emptySet(),
    val notificationTriggerEnabled: Boolean = true,
    val recentsEnabled: Boolean = true,
    val bubbleTriggerEnabled: Boolean = false,
) {
    fun isProviderEnabled(id: String): Boolean = enabledProviders.contains(id)
}

/** A launchable installed app. */
data class AppEntry(
    val label: String,
    val packageName: String,
    val component: ComponentName,
) {
    val id: String get() = "app:${component.flattenToString()}"
}

/** A recently executed result, stored on-device only. */
data class RecentEntry(
    val id: String,
    val title: String,
    val subtitle: String?,
    val packageName: String?,
    val kind: String,
    val timestamp: Long,
    /** Provider-specific replay payload: package name, URL or intent action. */
    val payload: String = "",
) {
    companion object {
        const val KIND_APP = "app"
        const val KIND_WEB = "web"
        const val KIND_SETTINGS = "settings"
        const val KIND_CONTACT = "contact"
        const val KIND_FILE = "file"
        const val KIND_OTHER = "other"
    }
}
