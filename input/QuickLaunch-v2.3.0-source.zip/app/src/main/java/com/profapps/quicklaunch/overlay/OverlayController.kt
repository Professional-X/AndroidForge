package com.profapps.quicklaunch.overlay

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * Single entry point for every trigger (notification, tile, shortcut, test
 * button). Handles the overlay-permission check in one place and starts the
 * foreground service that owns the window.
 */
object OverlayController {

    const val ACTION_SHOW = "com.profapps.quicklaunch.action.SHOW_OVERLAY"
    const val ACTION_HIDE = "com.profapps.quicklaunch.action.HIDE_OVERLAY"
    const val ACTION_TOGGLE = "com.profapps.quicklaunch.action.TOGGLE_OVERLAY"
    /** Optional [show] extra: query text pre-filled into the palette. */
    const val EXTRA_SHOW_QUERY = "show_query"

    fun isPermissionGranted(context: Context): Boolean = Settings.canDrawOverlays(context)

    /** PendingIntent used by the persistent notification. */
    fun showPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, OverlayService::class.java).setAction(ACTION_SHOW)
        return PendingIntent.getService(
            context, 1, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    /**
     * Opens the palette if the overlay permission is granted; otherwise the
     * caller decides what fallback to show (the app explains and links to
     * Android settings). Optionally pre-fills the query — used by voice
     * results and the file-search shortcut.
     */
    fun show(context: Context, query: String? = null) {
        if (!isPermissionGranted(context)) return
        val intent = Intent(context, OverlayService::class.java).setAction(ACTION_SHOW)
        if (!query.isNullOrBlank()) {
            intent.putExtra(EXTRA_SHOW_QUERY, query)
        }
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            runCatching { context.startForegroundService(intent) }
        } else {
            runCatching { context.startService(intent) }
        }
    }

    fun hide(context: Context) {
        val intent = Intent(context, OverlayService::class.java).setAction(ACTION_HIDE)
        runCatching { context.startService(intent) }
    }
}
