package com.profapps.quicklaunch.triggers

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.ServiceCompat
import com.profapps.quicklaunch.R
import com.profapps.quicklaunch.overlay.OverlayController
import com.profapps.quicklaunch.util.UiBridge
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Assistive-Touch-style floating bubble: a small always-on-top circle that
 * follows the finger, snaps to the nearest screen edge and opens the command
 * palette on a tap. Reuses the overlay permission (SYSTEM_ALERT_WINDOW) that
 * the palette itself already needs, so there is no extra permission step.
 */
class FloatingBubbleService : Service() {

    private var windowManager: WindowManager? = null
    private var bubbleView: View? = null
    private var added = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action ?: ACTION_START) {
            ACTION_START -> {
                if (!Settings.canDrawOverlays(this)) {
                    UiBridge.toast(this, getString(R.string.overlay_missing))
                    stopSelf()
                    return START_NOT_STICKY
                }
                enterForeground()
                addBubble()
            }
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun enterForeground() {
        val type = if (Build.VERSION.SDK_INT >= 34) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        ServiceCompat.startForeground(
            this,
            NotificationTrigger.SERVICE_NOTIFICATION_ID + 1,
            NotificationTrigger.serviceNotification(this),
            type,
        )
    }

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun addBubble() {
        if (added || !Settings.canDrawOverlays(this)) return
        val wm = windowManager ?: return

        val sizePx = (BUBBLE_SIZE_DP * resources.displayMetrics.density).roundToInt()
        val view = ImageView(this).apply {
            setImageResource(R.drawable.ic_bolt)
            setBackgroundResource(R.drawable.bubble_background)
            setImageTintList(android.content.res.ColorStateList.valueOf(0xFFFFFFFF.toInt()))
            contentDescription = getString(R.string.bubble_cd)
            alpha = 0.92f
        }

        val params = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            windowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = (resources.displayMetrics.heightPixels * 0.4f).roundToInt()
        }

        view.setOnTouchListener(BubbleTouchListener(wm, view, params, sizePx))
        runCatching {
            wm.addView(view, params)
            bubbleView = view
            added = true
        }.onFailure {
            // Window token trouble (permission revoked mid-flight): bail out.
            stopSelf()
        }
    }

    private fun windowType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    /**
     * Handles tap vs. drag: a small movement opens the palette; a real drag
     * moves the bubble and snaps it to the nearest vertical edge on release.
     */
    private inner class BubbleTouchListener(
        private val wm: WindowManager,
        private val view: View,
        private val params: WindowManager.LayoutParams,
        private val sizePx: Int,
    ) : View.OnTouchListener {

        private var downRawX = 0f
        private var downRawY = 0f
        private var startParamsX = 0
        private var startParamsY = 0
        private var moved = false

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startParamsX = params.x
                    startParamsY = params.y
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (!moved && abs(dx) + abs(dy) > TOUCH_SLOP_PX) moved = true
                    if (moved) {
                        params.x = startParamsX + dx.roundToInt()
                        params.y = startParamsY + dy.roundToInt()
                        runCatching { wm.updateViewLayout(view, params) }
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        snapToEdge()
                    } else {
                        OverlayController.show(this@FloatingBubbleService)
                    }
                    return true
                }
                else -> return false
            }
        }

        /** Glue the bubble to the nearest left/right screen edge. */
        private fun snapToEdge() {
            val screenW = resources.displayMetrics.widthPixels
            val centerX = params.x + sizePx / 2f
            params.x = if (centerX < screenW / 2f) {
                0
            } else {
                max(0, screenW - sizePx)
            }
            val marginY = resources.displayMetrics.heightPixels
            params.y = params.y.coerceIn(0, marginY)
            runCatching { wm.updateViewLayout(view, params) }
        }
    }

    private fun removeBubble() {
        val view = bubbleView ?: return
        bubbleView = null
        added = false
        runCatching { windowManager?.removeViewImmediate(view) }
    }

    override fun onDestroy() {
        removeBubble()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.profapps.quicklaunch.action.START_BUBBLE"
        const val ACTION_STOP = "com.profapps.quicklaunch.action.STOP_BUBBLE"
        private const val BUBBLE_SIZE_DP = 48
        private const val TOUCH_SLOP_PX = 12f

        fun start(context: Context) {
            val intent = Intent(context, FloatingBubbleService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, FloatingBubbleService::class.java).setAction(ACTION_STOP),
            )
        }
    }
}
