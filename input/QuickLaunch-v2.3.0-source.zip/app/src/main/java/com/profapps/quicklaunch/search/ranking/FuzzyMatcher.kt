package com.profapps.quicklaunch.search.ranking

/**
 * Deterministic, testable fuzzy matcher — no machine learning, just layered
 * string heuristics ordered from strongest to weakest signal:
 *
 * 1. Exact match
 * 2. Prefix match
 * 3. Word-start match (handles "ch" -> "Chrome Store" and camelCase)
 * 4. Substring match
 * 5. Fuzzy subsequence with contiguity and word-start bonuses
 *
 * Optional usage and pinned boosts are added on top and the final score is
 * clamped to 1.0. Returning null means "no match at all".
 */
object FuzzyMatcher {

    enum class MatchKind { EXACT, PREFIX, WORD_START, SUBSTRING, SUBSEQUENCE }

    data class Match(val score: Float, val kind: MatchKind)

    // Characters that start a new "word" inside a label.
    private const val DELIMITERS = " ._-,/&()[]:;'\""

    private const val EXACT_SCORE = 1.0f
    private const val PREFIX_BASE = 0.88f
    private const val WORD_START_BASE = 0.74f
    private const val SUBSTRING_BASE = 0.58f
    private const val SUBSEQUENCE_BASE = 0.30f
    private const val SUBSEQUENCE_MAX = 0.52f

    fun match(
        query: String,
        target: String,
        usageBoost: Float = 0f,
        pinnedBoost: Float = 0f,
    ): Match? {
        val q = query.trim().lowercase()
        val t = target.lowercase()
        if (q.isEmpty() || t.isEmpty()) return null

        val (base, kind) = when {
            t == q -> EXACT_SCORE to MatchKind.EXACT
            t.startsWith(q) -> prefixScore(q) to MatchKind.PREFIX
            wordStartMatch(q, t) -> WORD_START_BASE to MatchKind.WORD_START
            t.contains(q) -> SUBSTRING_BASE to MatchKind.SUBSTRING
            else -> {
                val s = subsequenceScore(q, t) ?: return null
                s to MatchKind.SUBSEQUENCE
            }
        }
        val total = (base + usageBoost + pinnedBoost).coerceAtMost(1.0f)
        return Match(total, kind)
    }

    /** Longer queries that prefix-match are stronger signals. */
    private fun prefixScore(q: String): Float =
        PREFIX_BASE + (minOf(q.length, 8) / 8f) * 0.06f

    /**
     * True when every query token is a prefix of some target token
     * (tokens split on delimiters and camelCase humps), in order.
     */
    fun wordStartMatch(query: String, targetLower: String): Boolean {
        val qTokens = query.lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (qTokens.isEmpty()) return false
        val tTokens = tokenize(targetLower)
        var searchFrom = 0
        outer@ for (qt in qTokens) {
            for (i in searchFrom until tTokens.size) {
                if (tTokens[i].startsWith(qt)) {
                    searchFrom = i + 1
                    continue@outer
                }
            }
            return false
        }
        return true
    }

    /** Splits "ChromeStore beta.app" into ["chrome", "store", "beta", "app"]. */
    fun tokenize(targetLower: String): List<String> {
        val tokens = mutableListOf<String>()
        val current = StringBuilder()
        var previous: Char? = null
        for (c in targetLower) {
            val boundary = previous != null &&
                (DELIMITERS.contains(previous!!) || isHump(previous!!, c))
            if (previous != null && boundary && current.isNotEmpty()) {
                tokens.add(current.toString())
                current.clear()
            }
            if (!DELIMITERS.contains(c)) current.append(c.lowercaseChar())
            previous = c
        }
        if (current.isNotEmpty()) tokens.add(current.toString())
        return tokens
    }

    private fun isHump(previous: Char, current: Char): Boolean =
        previous.isLowerCase() && current.isUpperCase()

    /**
     * Greedy subsequence with small bonuses for contiguous runs and matches
     * at word starts. Deterministic and cheap: single pass per query char.
     */
    fun subsequenceScore(q: String, t: String): Float? {
        var fromIndex = 0
        var score = SUBSEQUENCE_BASE
        var lastMatch = -2
        for (qc in q) {
            val idx = t.indexOf(qc, fromIndex)
            if (idx < 0) return null
            if (idx == lastMatch + 1) score += 0.03f
            if (idx == 0 || DELIMITERS.contains(t[idx - 1]) ||
                (t[idx].isUpperCase() && t[idx - 1].isLowerCase())
            ) {
                score += 0.02f
            }
            lastMatch = idx
            fromIndex = idx + 1
        }
        // Prefer tight subsequences over sparse ones.
        score += (q.length.toFloat() / t.length) * 0.08f
        return score.coerceIn(SUBSEQUENCE_BASE, SUBSEQUENCE_MAX)
    }
}
