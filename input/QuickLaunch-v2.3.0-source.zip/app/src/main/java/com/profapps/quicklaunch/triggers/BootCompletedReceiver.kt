package com.profapps.quicklaunch.triggers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Restores the floating bubble after a reboot when the user had it enabled.
 * The setting is mirrored to plain SharedPreferences because DataStore cannot
 * be read synchronously from a receiver.
 */
class BootCompletedReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_BUBBLE_ENABLED, false)) {
            FloatingBubbleService.start(context)
        }
    }

    companion object {
        const val PREFS_NAME = "quick_launch_state"
        const val KEY_BUBBLE_ENABLED = "bubble_enabled"
    }
}
