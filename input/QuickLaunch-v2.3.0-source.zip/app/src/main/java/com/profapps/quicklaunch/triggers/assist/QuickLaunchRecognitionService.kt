package com.profapps.quicklaunch.triggers.assist

import android.content.Intent
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/**
 * Minimal no-op recognition service.
 *
 * Why this exists: the Android framework parser (VoiceInteractionServiceInfo)
 * refuses to qualify a third-party app as a selectable "Digital assistant"
 * unless its voice-interaction meta-data declares a `recognitionService`.
 * Without it, `supportsAssist` is silently forced to false and Quick Launch
 * never appears in Settings > Apps > Default apps > Digital assistant.
 *
 * We do not actually perform speech recognition here (the app never claims
 * the "voice input" role); the service simply satisfies the framework check.
 * If something ever binds it directly, we answer with a clean client error
 * instead of hanging.
 */
class QuickLaunchRecognitionService : RecognitionService() {

    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        runCatching { listener?.error(SpeechRecognizer.ERROR_CLIENT) }
    }

    override fun onCancel(listener: Callback?) {
        // Nothing to cancel: we never start listening.
    }

    override fun onStopListening(listener: Callback?) {
        // Nothing to stop: we never start listening.
    }
}
