package com.profapps.quicklaunch

import android.content.Context
import com.profapps.quicklaunch.data.RecentsRepository
import com.profapps.quicklaunch.data.SettingsRepository
import com.profapps.quicklaunch.data.appDataStore
import com.profapps.quicklaunch.providers.AppIndex
import com.profapps.quicklaunch.providers.AppsProvider
import com.profapps.quicklaunch.providers.ClipboardProvider
import com.profapps.quicklaunch.providers.CalculatorProvider
import com.profapps.quicklaunch.providers.ContactsProvider
import com.profapps.quicklaunch.providers.FileSearchProvider
import com.profapps.quicklaunch.providers.QuickInfoProvider
import com.profapps.quicklaunch.providers.SettingsProvider
import com.profapps.quicklaunch.providers.TorchProvider
import com.profapps.quicklaunch.providers.UnitConversionProvider
import com.profapps.quicklaunch.providers.WebSearchProvider
import com.profapps.quicklaunch.search.SearchEngine
import kotlinx.coroutines.CoroutineScope

/**
 * Hand-rolled dependency container. Small enough that a DI framework would be
 * ceremony, structured enough that every collaborator has one home.
 */
class AppContainer(context: Context, scope: CoroutineScope) {

    private val appContext = context.applicationContext

    val settingsRepository = SettingsRepository(appContext.appDataStore(), scope)
    val recentsRepository = RecentsRepository(appContext.appDataStore())
    val appIndex = AppIndex(appContext, scope)

    val searchEngine: SearchEngine = SearchEngine(
        providers = listOf(
            AppsProvider(appContext, appIndex, recentsRepository, settingsRepository),
            CalculatorProvider(appContext),
            UnitConversionProvider(appContext),
            WebSearchProvider(appContext, settingsRepository),
            ContactsProvider(appContext),
            SettingsProvider(appContext),
            ClipboardProvider(appContext),
            FileSearchProvider(appContext),
            TorchProvider(appContext),
            QuickInfoProvider(appContext),
        ),
        isEnabled = { id -> settingsRepository.settings.value.isProviderEnabled(id) },
    )
}
