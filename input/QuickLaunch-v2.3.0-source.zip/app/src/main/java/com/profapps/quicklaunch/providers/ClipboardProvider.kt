package com.profapps.quicklaunch.providers

import android.content.Context
import com.profapps.quicklaunch.R
import com.profapps.quicklaunch.data.ProviderIds
import com.profapps.quicklaunch.search.ActionResult
import com.profapps.quicklaunch.search.ResultCategory
import com.profapps.quicklaunch.search.ResultIcon
import com.profapps.quicklaunch.search.SearchProvider
import com.profapps.quicklaunch.search.SearchQuery
import com.profapps.quicklaunch.search.SearchResult
import com.profapps.quicklaunch.util.UiBridge

/**
 * Offers to copy the typed query (handy for reuse). Clipboard *reading* is not
 * done here — the palette only peeks at the clipboard while it is open and
 * focused, never in the background.
 */
class ClipboardProvider(private val context: Context) : SearchProvider {

    override val id = ProviderIds.CLIPBOARD
    override val displayName = "Clipboard"

    override suspend fun search(query: SearchQuery): List<SearchResult> {
        val raw = query.raw.trim()
        if (raw.isEmpty() || raw.length > 80) return emptyList()
        return listOf(
            SearchResult(
                id = "clipboard-copy:${raw.lowercase()}",
                title = context.getString(R.string.copy_query, raw),
                subtitle = null,
                icon = ResultIcon.ResourceIcon(R.drawable.ic_clipboard),
                score = 0.3f,
                category = ResultCategory.CLIPBOARD,
                copyText = raw,
                action = {
                    UiBridge.copy(context, raw)
                    UiBridge.toast(context, context.getString(R.string.copied))
                    ActionResult.Stay
                },
            )
        )
    }
}
