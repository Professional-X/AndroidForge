package com.profapps.quicklaunch.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Single DataStore instance for the app. Declared at the top level so both
 * repositories share the same file and we never create two stores for it.
 *
 * The corruption handler is critical: without it, a partially written settings
 * file (process killed mid-write — happens "randomly" on real devices) makes
 * every read throw and crashes the whole app. Instead we reset to defaults
 * and keep running.
 */
private val Context.quickLaunchDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "quick_launch_settings",
    corruptionHandler = ReplaceFileCorruptionHandler { emptyPreferences() },
)

/** Application-scoped accessor for the shared DataStore. */
fun Context.appDataStore(): DataStore<Preferences> = quickLaunchDataStore

/**
 * Preferences-backed settings store. Exposes a hot [StateFlow] so the search
 * engine can read the current snapshot synchronously without blocking IO.
 */
class SettingsRepository(
    private val dataStore: DataStore<Preferences>,
    scope: CoroutineScope,
) {

    private object Keys {
        val THEME = stringPreferencesKey("theme_mode")
        val OPACITY = floatPreferencesKey("panel_opacity")
        val COMPACT = booleanPreferencesKey("compact_mode")
        val ANIMATIONS = booleanPreferencesKey("animations_enabled")
        val WEB_ENGINE = stringPreferencesKey("web_engine")
        val ENABLED_PROVIDERS = stringSetPreferencesKey("enabled_providers")
        val PINNED_APPS = stringSetPreferencesKey("pinned_apps")
        val NOTIFICATION_TRIGGER = booleanPreferencesKey("notification_trigger")
        val RECENTS_ENABLED = booleanPreferencesKey("recents_enabled")
        val BUBBLE_TRIGGER = booleanPreferencesKey("bubble_trigger")
    }

    private val _settings = MutableStateFlow(QuickLaunchSettings())
    val settings: StateFlow<QuickLaunchSettings> = _settings.asStateFlow()

    init {
        scope.launch {
            // The collector must survive transient IO trouble: a failed read
            // falls back to the current in-memory settings and retries later
            // instead of crashing the process.
            while (currentCoroutineContext().isActive) {
                try {
                    dataStore.data.collect { prefs -> _settings.value = decode(prefs) }
                    break // Flow only completes when the scope is cancelled.
                } catch (e: CancellationException) {
                    throw e
                } catch (t: Throwable) {
                    delay(5_000)
                }
            }
        }
    }

    private fun decode(prefs: Preferences): QuickLaunchSettings {
        val current = _settings.value
        return QuickLaunchSettings(
            themeMode = prefs[Keys.THEME]?.let { stored ->
                ThemeMode.entries.firstOrNull { it.name == stored }
            } ?: current.themeMode,
            panelOpacity = (prefs[Keys.OPACITY] ?: current.panelOpacity).coerceIn(0.55f, 1f),
            compactMode = prefs[Keys.COMPACT] ?: current.compactMode,
            animationsEnabled = prefs[Keys.ANIMATIONS] ?: current.animationsEnabled,
            webEngine = prefs[Keys.WEB_ENGINE]?.let { stored ->
                WebEngine.entries.firstOrNull { it.name == stored }
            } ?: current.webEngine,
            enabledProviders = prefs[Keys.ENABLED_PROVIDERS] ?: current.enabledProviders,
            pinnedApps = prefs[Keys.PINNED_APPS] ?: current.pinnedApps,
            notificationTriggerEnabled = prefs[Keys.NOTIFICATION_TRIGGER]
                ?: current.notificationTriggerEnabled,
            recentsEnabled = prefs[Keys.RECENTS_ENABLED] ?: current.recentsEnabled,
            bubbleTriggerEnabled = prefs[Keys.BUBBLE_TRIGGER] ?: current.bubbleTriggerEnabled,
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        dataStore.edit { it[Keys.THEME] = mode.name }
    }

    suspend fun setPanelOpacity(value: Float) {
        dataStore.edit { it[Keys.OPACITY] = value.coerceIn(0.55f, 1f) }
    }

    suspend fun setCompactMode(enabled: Boolean) {
        dataStore.edit { it[Keys.COMPACT] = enabled }
    }

    suspend fun setAnimationsEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.ANIMATIONS] = enabled }
    }

    suspend fun setWebEngine(engine: WebEngine) {
        dataStore.edit { it[Keys.WEB_ENGINE] = engine.name }
    }

    suspend fun setProviderEnabled(id: String, enabled: Boolean) {
        dataStore.edit { prefs ->
            val updated = (prefs[Keys.ENABLED_PROVIDERS] ?: _settings.value.enabledProviders)
                .toMutableSet()
            if (enabled) updated.add(id) else updated.remove(id)
            prefs[Keys.ENABLED_PROVIDERS] = updated
        }
    }

    suspend fun setAppPinned(packageName: String, pinned: Boolean) {
        dataStore.edit { prefs ->
            val updated = (prefs[Keys.PINNED_APPS] ?: _settings.value.pinnedApps).toMutableSet()
            if (pinned) updated.add(packageName) else updated.remove(packageName)
            prefs[Keys.PINNED_APPS] = updated
        }
    }

    suspend fun setNotificationTriggerEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.NOTIFICATION_TRIGGER] = enabled }
    }

    suspend fun setRecentsEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.RECENTS_ENABLED] = enabled }
    }

    suspend fun setBubbleTriggerEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.BUBBLE_TRIGGER] = enabled }
    }
}
