package com.profapps.quicklaunch.providers.conversion

/**
 * Offline unit conversion with a small static table. No network, no live
 * currency rates — the provider never pretends to have data it does not.
 *
 * Supported dimensions: length, mass, temperature, volume, time,
 * digital storage, speed.
 */
object UnitConverter {

    sealed interface ConversionResult {
        data class Success(
            val inputDisplay: String,
            val outputDisplay: String,
            val rawOutput: Double,
            val outputUnitName: String,
        ) : ConversionResult

        data class Failure(val message: String) : ConversionResult
    }

    data class UnitDef(
        val canonical: String,
        val displayName: String,
        val aliases: Set<String>,
        /** How many base units one of this unit is worth. */
        val factorToBase: Double,
    )

    private fun unit(canonical: String, display: String, factor: Double, vararg aliases: String) =
        UnitDef(canonical, display, aliases.toSet() + canonical.lowercase(), factor)

    // Length (base: meter)
    private val length = listOf(
        unit("mm", "millimeters", 0.001, "millimeter", "millimetres", "millimetre"),
        unit("cm", "centimeters", 0.01, "centimeter", "centimetres", "centimetre"),
        unit("m", "meters", 1.0, "meter", "metre", "metres"),
        unit("km", "kilometers", 1000.0, "kilometer", "kilometre", "kilometres"),
        unit("in", "inches", 0.0254, "inch", "inches"),
        unit("ft", "feet", 0.3048, "foot"),
        unit("yd", "yards", 0.9144, "yard"),
        unit("mi", "miles", 1609.344, "mile"),
        unit("nmi", "nautical miles", 1852.0, "nauticalmile"),
    )

    // Mass (base: kilogram)
    private val mass = listOf(
        unit("mg", "milligrams", 0.000001, "milligram"),
        unit("g", "grams", 0.001, "gram"),
        unit("kg", "kilograms", 1.0, "kilogram", "kilo", "kilos"),
        unit("t", "tonnes", 1000.0, "tonne", "ton", "tons"),
        unit("oz", "ounces", 0.028349523125, "ounce"),
        unit("lb", "pounds", 0.45359237, "lbs", "pound"),
        unit("st", "stone", 6.35029318, "stones"),
    )

    // Temperature handled separately (non-linear)
    private val temperature = listOf(
        unit("c", "°C", 1.0, "celsius", "centigrade"),
        unit("f", "°F", 1.0, "fahrenheit"),
        unit("k", "K", 1.0, "kelvin"),
    )

    // Volume (base: liter)
    private val volume = listOf(
        unit("ml", "milliliters", 0.001, "millilitre", "milliliter"),
        unit("l", "liters", 1.0, "litre", "liter", "litres"),
        unit("m3", "cubic meters", 1000.0, "cubicmeter", "cubic_meter"),
        unit("tsp", "teaspoons", 0.00492892159375, "teaspoon"),
        unit("tbsp", "tablespoons", 0.01478676478125, "tablespoon"),
        unit("floz", "fluid ounces", 0.0295735295625, "fluidounce", "fluid_ounce"),
        unit("cup", "cups", 0.2365882365, "cups"),
        unit("pt", "pints", 0.473176473, "pint"),
        unit("qt", "quarts", 0.946352946, "quart"),
        unit("gal", "gallons", 3.785411784, "gallon"),
    )

    // Time (base: second)
    private val time = listOf(
        unit("ms", "milliseconds", 0.001, "millisecond"),
        unit("s", "seconds", 1.0, "second", "sec", "secs"),
        unit("min", "minutes", 60.0, "minute", "mins"),
        unit("h", "hours", 3600.0, "hour", "hr", "hrs"),
        unit("day", "days", 86400.0, "days"),
        unit("wk", "weeks", 604800.0, "week"),
    )

    // Digital storage (base: byte, decimal)
    private val dataUnits = listOf(
        unit("b", "bytes", 1.0, "byte"),
        unit("kb", "kilobytes", 1e3, "kilobyte"),
        unit("mb", "megabytes", 1e6, "megabyte"),
        unit("gb", "gigabytes", 1e9, "gigabyte"),
        unit("tb", "terabytes", 1e12, "terabyte"),
        unit("kib", "kibibytes", 1024.0, "kibibyte"),
        unit("mib", "mebibytes", 1048576.0, "mebibyte"),
        unit("gib", "gibibytes", 1073741824.0, "gibibyte"),
    )

    // Speed (base: km/h)
    private val speed = listOf(
        unit("kmh", "km/h", 1.0, "km/h", "kph", "kmph"),
        unit("mph", "mph", 1.609344, "mi/h"),
        unit("mps", "m/s", 3.6, "m/s"),
        unit("kn", "knots", 1.852, "knot", "kt"),
    )

    private val dimensions: Map<String, List<UnitDef>> = mapOf(
        "length" to length,
        "mass" to mass,
        "temperature" to temperature,
        "volume" to volume,
        "time" to time,
        "data" to dataUnits,
        "speed" to speed,
    )

    /** alias -> (dimensionId, unit) */
    private val aliasIndex: Map<String, Pair<String, UnitDef>> = buildMap {
        // Pass 1: explicit aliases win.
        for ((dim, units) in dimensions) {
            for (u in units) {
                for (alias in u.aliases) {
                    putIfAbsent(alias.lowercase(), dim to u)
                }
            }
        }
        // Pass 2: automatic plural forms for anything not explicitly mapped.
        val plurals = mutableListOf<Pair<String, Pair<String, UnitDef>>>()
        for ((dim, units) in dimensions) {
            for (u in units) {
                for (alias in u.aliases) {
                    val lower = alias.lowercase()
                    if (!lower.endsWith("s")) {
                        plurals.add(lower + "s" to (dim to u))
                    }
                }
            }
        }
        for ((plural, target) in plurals) {
            putIfAbsent(plural, target)
        }
    }

    private val pattern = Regex(
        "^\\s*([+-]?\\d+(?:\\.\\d+)?)\\s*([a-zA-Z°]+)\\s*" +
            "(?:to|in|as|into)\\s*([a-zA-Z°]+)\\s*$",
        RegexOption.IGNORE_CASE,
    )

    /** Returns null when the input does not look like a conversion at all. */
    fun convert(input: String): ConversionResult? {
        val match = pattern.matchEntire(input) ?: return null
        val value = match.groupValues[1].toDoubleOrNull()
            ?: return null
        val fromToken = match.groupValues[2].lowercase()
        val toToken = match.groupValues[3].lowercase()

        val from = aliasIndex[fromToken]
            ?: return ConversionResult.Failure("Unknown unit: ${match.groupValues[2]}")
        val to = aliasIndex[toToken]
            ?: return ConversionResult.Failure("Unknown unit: ${match.groupValues[3]}")

        if (from.first != to.first) {
            return ConversionResult.Failure("Cannot convert ${from.second.displayName} to ${to.second.displayName}")
        }

        val output: Double = if (from.first == "temperature") {
            convertTemperature(value, from.second.canonical, to.second.canonical)
        } else {
            value * from.second.factorToBase / to.second.factorToBase
        }

        val displayInput = trimNumber(value) + " " + from.second.displayName
        val displayOutput = trimNumber(output) + " " + to.second.displayName
        return ConversionResult.Success(displayInput, displayOutput, output, to.second.displayName)
    }

    private fun convertTemperature(value: Double, from: String, to: String): Double {
        val celsius = when (from) {
            "c" -> value
            "f" -> (value - 32.0) * 5.0 / 9.0
            else -> value - 273.15
        }
        return when (to) {
            "c" -> celsius
            "f" -> celsius * 9.0 / 5.0 + 32.0
            else -> celsius + 273.15
        }
    }

    private fun trimNumber(v: Double): String {
        if (v.isNaN() || v.isInfinite()) return "—"
        val rounded = Math.rint(v * 1e6) / 1e6
        return if (rounded == Math.floor(rounded) && !rounded.isInfinite()) {
            java.lang.Long.toString(rounded.toLong())
        } else {
            java.math.BigDecimal(rounded)
                .setScale(6, java.math.RoundingMode.HALF_UP)
                .stripTrailingZeros()
                .toPlainString()
        }
    }

    /** True when the string plausibly starts a conversion ("10 km to mi"). */
    fun looksLikeConversion(input: String): Boolean {
        val s = input.trim()
        if (s.length < 4) return false
        val m = pattern.matchEntire(s)
        if (m != null) {
            return aliasIndex.containsKey(m.groupValues[2].lowercase()) &&
                aliasIndex.containsKey(m.groupValues[3].lowercase())
        }
        return false
    }
}
