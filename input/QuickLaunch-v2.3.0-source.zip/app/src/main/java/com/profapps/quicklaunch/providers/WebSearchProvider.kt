package com.profapps.quicklaunch.providers

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.profapps.quicklaunch.R
import com.profapps.quicklaunch.data.ProviderIds
import com.profapps.quicklaunch.data.SettingsRepository
import com.profapps.quicklaunch.data.WebEngine
import com.profapps.quicklaunch.search.ActionResult
import com.profapps.quicklaunch.search.CommandHint
import com.profapps.quicklaunch.search.ResultCategory
import com.profapps.quicklaunch.search.ResultIcon
import com.profapps.quicklaunch.search.SearchProvider
import com.profapps.quicklaunch.search.SearchQuery
import com.profapps.quicklaunch.search.SearchResult
import com.profapps.quicklaunch.util.UiBridge

/**
 * Web search fallback. Builds a normal browser URL for the user's configured
 * engine — no scraping, no hidden network calls.
 */
class WebSearchProvider(
    private val context: Context,
    private val settings: SettingsRepository,
) : SearchProvider {

    override val id = ProviderIds.WEB
    override val displayName = "Web search"

    override suspend fun search(query: SearchQuery): List<SearchResult> {
        val term = when (val hint = query.hint) {
            is CommandHint.Web -> hint.term
            is CommandHint.None -> query.raw
            else -> return emptyList() // explicit app/calc/settings commands stay clean
        }
        if (term.isBlank() || term.length > 120) return emptyList()

        val engine = settings.settings.value.webEngine
        val results = mutableListOf<SearchResult>()

        // Direct URL detection — "example.com" opens as a URL, not a search.
        if (URL_REGEX.matches(term.trim())) {
            val url = if (term.startsWith("http", ignoreCase = true)) term else "https://$term"
            results.add(
                SearchResult(
                    id = "url:$url",
                    title = context.getString(R.string.open_url, term.trim()),
                    subtitle = url,
                    icon = ResultIcon.ResourceIcon(R.drawable.ic_open),
                    score = 0.85f,
                    category = ResultCategory.WEB,
                    recordable = true,
                    recordPayload = url,
                    action = { open(url) },
                )
            )
        }

        results.add(
            SearchResult(
                id = "web:${engine.name}:${term.lowercase()}",
                title = context.getString(R.string.search_web_for, term.trim()),
                subtitle = context.getString(R.string.web_engine_label, engine.label),
                icon = ResultIcon.ResourceIcon(R.drawable.ic_web),
                score = if (query.hint is CommandHint.Web) 1.0f else 0.42f,
                category = ResultCategory.WEB,
                recordable = true,
                recordPayload = engine.urlFor(term),
                action = { open(engine.urlFor(term)) },
            )
        )
        return results
    }

    private suspend fun open(url: String): ActionResult {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            ActionResult.Dismiss
        } catch (e: Exception) {
            UiBridge.toast(context, context.getString(R.string.no_browser))
            ActionResult.Stay
        }
    }

    private companion object {
        val URL_REGEX = Regex(
            "^(https?://\\S+|www\\.\\S+|[a-z0-9-]+(\\.[a-z0-9-]+)+(/\\S*)?)$",
            RegexOption.IGNORE_CASE,
        )
    }
}
