package com.profapps.quicklaunch.providers

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import com.profapps.quicklaunch.data.AppEntry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Cached index of launchable apps. The package list is scanned once (lazily)
 * and then kept in memory; package add/remove/replace broadcasts invalidate it.
 * This guarantees the search path never rescans PackageManager per keystroke.
 */
class AppIndex(private val context: Context, private val scope: CoroutineScope) {

    private val _apps = MutableStateFlow<List<AppEntry>>(emptyList())
    val apps: StateFlow<List<AppEntry>> = _apps.asStateFlow()

    private val mutex = Mutex()

    @Volatile
    private var loaded = false

    suspend fun getApps(): List<AppEntry> {
        if (!loaded) refresh()
        return _apps.value
    }

    suspend fun findByPackage(packageName: String): AppEntry? {
        val list = getApps()
        return list.firstOrNull { it.packageName == packageName }
    }

    suspend fun refresh() {
        if (loaded) return
        mutex.withLock {
            if (loaded) return@withLock
            val list = withContext(Dispatchers.IO) { loadApps() }
            _apps.value = list
            loaded = true
        }
    }

    /** Called from the package broadcast receiver in the Application class. */
    fun invalidate() {
        loaded = false
        scope.launch { refresh() }
    }

    private fun loadApps(): List<AppEntry> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolveInfos: List<ResolveInfo> = try {
            pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        } catch (e: Exception) {
            emptyList()
        }
        return resolveInfos.mapNotNull { ri ->
            val activityInfo = ri.activityInfo ?: return@mapNotNull null
            val label = runCatching { ri.loadLabel(pm)?.toString()?.trim() }.getOrNull()
            if (label.isNullOrEmpty()) return@mapNotNull null
            AppEntry(
                label = label,
                packageName = activityInfo.packageName,
                component = android.content.ComponentName(activityInfo.packageName, activityInfo.name),
            )
        }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }
}
