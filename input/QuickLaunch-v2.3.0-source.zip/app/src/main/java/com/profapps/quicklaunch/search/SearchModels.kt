package com.profapps.quicklaunch.search

import android.content.ComponentName
import androidx.annotation.DrawableRes

/** Visual grouping of results, inspired by KRunner/Spotlight categories. */
enum class ResultCategory {
    APPS, ACTIONS, CALCULATOR, CONVERSIONS, FILES, CONTACTS, WEB, SETTINGS, CLIPBOARD
}

/**
 * How a result renders its icon. Providers never hold platform Drawables so
 * the model stays cheap and cacheable; the UI resolves icons lazily.
 */
sealed interface ResultIcon {
    /** Installed app icon resolved from PackageManager. */
    data class AppIcon(val component: ComponentName) : ResultIcon

    /** Vector drawable from the app's own resources, tinted by the UI. */
    data class ResourceIcon(@DrawableRes val resId: Int) : ResultIcon

    /** Colored circle with a single letter (used for contacts). */
    data class LetterIcon(val letter: String, val hue: Float) : ResultIcon
}

/** What happened after executing a result's action. */
sealed interface ActionResult {
    /** Close the palette. */
    data object Dismiss : ActionResult

    /** Keep the palette open (e.g. copy actions show a toast instead). */
    data object Stay : ActionResult
}

/**
 * A single search result. [action] is a suspending lambda so providers can do
 * IO (launch intents, clipboard writes) without blocking the caller.
 */
data class SearchResult(
    val id: String,
    val title: String,
    val subtitle: String? = null,
    val icon: ResultIcon? = null,
    val score: Float = 0f,
    val category: ResultCategory,
    val copyText: String? = null,
    val recordable: Boolean = false,
    /** Payload stored in recents for one-tap replay (package/url/action). */
    val recordPayload: String? = null,
    val dismissAfterAction: Boolean = true,
    val action: suspend () -> ActionResult,
)

/** The query plus any explicit command the user typed. */
data class SearchQuery(
    val raw: String,
    val hint: CommandHint,
)

/** Explicit command prefixes parsed out of the raw query. */
sealed interface CommandHint {
    data object None : CommandHint
    data class Open(val term: String) : CommandHint
    data class Web(val term: String) : CommandHint
    data class Calc(val expression: String) : CommandHint
    data class Convert(val expression: String) : CommandHint
    data class Settings(val term: String) : CommandHint
    data class Files(val term: String) : CommandHint
}
