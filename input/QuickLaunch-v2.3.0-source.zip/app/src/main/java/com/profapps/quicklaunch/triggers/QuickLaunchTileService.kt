package com.profapps.quicklaunch.triggers

import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.TileService
import com.profapps.quicklaunch.MainActivity
import com.profapps.quicklaunch.overlay.OverlayController

/**
 * Quick Settings tile: tap toggles the palette. Kept deliberately stateless —
 * the tile is always "inactive" visually because the palette is momentary.
 */
class QuickLaunchTileService : TileService() {

    override fun onClick() {
        super.onClick()
        if (Settings.canDrawOverlays(this)) {
            OverlayController.show(this)
        } else {
            // Route the user to the app, which explains the permission.
            val intent = Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(MainActivity.EXTRA_MISSING_OVERLAY_PERMISSION, true)
            if (Build.VERSION.SDK_INT >= 34) {
                val pi = android.app.PendingIntent.getActivity(
                    this, 7, intent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE,
                )
                startActivityAndCollapse(pi)
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(intent)
            }
        }
    }
}
