package com.profapps.quicklaunch.providers

import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.profapps.quicklaunch.R
import com.profapps.quicklaunch.data.ProviderIds
import com.profapps.quicklaunch.search.ActionResult
import com.profapps.quicklaunch.search.CommandHint
import com.profapps.quicklaunch.search.ResultCategory
import com.profapps.quicklaunch.search.ResultIcon
import com.profapps.quicklaunch.search.SearchProvider
import com.profapps.quicklaunch.search.SearchQuery
import com.profapps.quicklaunch.search.SearchResult
import com.profapps.quicklaunch.search.ranking.FuzzyMatcher
import com.profapps.quicklaunch.util.UiBridge

/**
 * Safe shortcuts into documented Android Settings panels. These are plain
 * public intents — no protected settings are modified directly.
 */
class SettingsProvider(private val context: Context) : SearchProvider {

    private data class Route(
        val id: String,
        val titleRes: Int,
        val keywords: List<String>,
        val iconRes: Int,
        val action: String,
    )

    private val routes = listOf(
        Route("wifi", R.string.route_wifi, listOf("wireless", "internet", "network", "wlan"), R.drawable.ic_wifi, Settings.ACTION_WIFI_SETTINGS),
        Route("bluetooth", R.string.route_bluetooth, listOf("bt", "pairing"), R.drawable.ic_open, Settings.ACTION_BLUETOOTH_SETTINGS),
        Route("display", R.string.route_display, listOf("screen", "brightness", "resolution", "dark mode"), R.drawable.ic_open, Settings.ACTION_DISPLAY_SETTINGS),
        Route("apps", R.string.route_apps, listOf("applications", "default apps", "storage apps"), R.drawable.ic_open, Settings.ACTION_APPLICATION_SETTINGS),
        Route("sound", R.string.route_sound, listOf("volume", "ringtone", "audio", "do not disturb"), R.drawable.ic_open, Settings.ACTION_SOUND_SETTINGS),
        Route("battery", R.string.route_battery, listOf("power", "saver", "charging"), R.drawable.ic_bolt, Settings.ACTION_BATTERY_SAVER_SETTINGS),
        Route("datetime", R.string.route_datetime, listOf("clock", "timezone", "time zone", "date"), R.drawable.ic_open, Settings.ACTION_DATE_SETTINGS),
        Route("developer", R.string.route_developer, listOf("dev options", "adb", "debugging", "usb"), R.drawable.ic_open, Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
    )

    override val id = ProviderIds.SETTINGS
    override val displayName = "Settings shortcuts"

    override suspend fun search(query: SearchQuery): List<SearchResult> {
        val term: String = when (val hint = query.hint) {
            is CommandHint.Settings -> hint.term
            is CommandHint.None -> query.raw
            else -> return emptyList()
        }
        if (term.isBlank() || term.length > 40) return emptyList()
        val explicit = query.hint is CommandHint.Settings

        data class Hit(val score: Float, val route: Route)

        val hits = mutableListOf<Hit>()
        for (route in routes) {
            var best = FuzzyMatcher.match(term, context.getString(route.titleRes))?.score ?: 0f
            for (keyword in route.keywords) {
                val m = FuzzyMatcher.match(term, keyword) ?: continue
                if (m.score > best) best = m.score
            }
            if (best < MIN_SCORE) continue
            // Scale down so local app matches usually beat generic panels.
            val score = (best * (if (explicit) 1.05f else 0.78f)).coerceAtMost(1f)
            hits.add(Hit(score, route))
        }

        return hits
            .sortedByDescending { it.score }
            .take(4)
            .map { hit ->
                SearchResult(
                    id = "settings:${hit.route.id}",
                    title = context.getString(hit.route.titleRes),
                    subtitle = context.getString(R.string.settings_shortcut_subtitle),
                    icon = ResultIcon.ResourceIcon(hit.route.iconRes),
                    score = hit.score,
                    category = ResultCategory.SETTINGS,
                    recordable = true,
                    recordPayload = hit.route.action,
                    action = { open(hit.route) },
                )
            }
    }

    private suspend fun open(route: Route): ActionResult {
        val intent = Intent(route.action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            ActionResult.Dismiss
        } catch (e: Exception) {
            UiBridge.toast(context, context.getString(R.string.settings_route_failed))
            ActionResult.Stay
        }
    }

    private companion object {
        const val MIN_SCORE = 0.45f
    }
}
