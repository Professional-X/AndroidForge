package com.profapps.quicklaunch.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.profapps.quicklaunch.data.ThemeMode

// Original palette: calm indigo primary with a violet secondary. Deliberately
// restrained — no gradient-heavy "AI dashboard" look.
private val Indigo = Color(0xFF4F5BD5)
private val IndigoDarkContainer = Color(0xFF3742A6)
private val Violet = Color(0xFF9A5BD5)
private val Teal = Color(0xFF2E9E97)

private val LightColors = lightColorScheme(
    primary = Indigo,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E3FF),
    onPrimaryContainer = Color(0xFF101465),
    secondary = Violet,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEFDBFF),
    onSecondaryContainer = Color(0xFF34125C),
    tertiary = Teal,
    tertiaryContainer = Color(0xFFBCEDE8),
    onTertiaryContainer = Color(0xFF00201E),
    background = Color(0xFFFAFAFD),
    onBackground = Color(0xFF1B1B21),
    surface = Color(0xFFFCFCFE),
    onSurface = Color(0xFF1B1B21),
    surfaceVariant = Color(0xFFE3E1EC),
    onSurfaceVariant = Color(0xFF46464F),
    outlineVariant = Color(0xFFC7C5D0),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFBAC3FF),
    onPrimary = Color(0xFF182A78),
    primaryContainer = IndigoDarkContainer,
    onPrimaryContainer = Color(0xFFE0E3FF),
    secondary = Color(0xFFD9BAFF),
    onSecondary = Color(0xFF4B1A7E),
    secondaryContainer = Color(0xFF633497),
    onSecondaryContainer = Color(0xFFEFDBFF),
    tertiary = Color(0xFF9FD0CB),
    tertiaryContainer = Color(0xFF1F4E4A),
    onTertiaryContainer = Color(0xFFBCEDE8),
    background = Color(0xFF141318),
    onBackground = Color(0xFFE5E1E9),
    surface = Color(0xFF1B1A21),
    onSurface = Color(0xFFE5E1E9),
    surfaceVariant = Color(0xFF2B2A33),
    onSurfaceVariant = Color(0xFFC7C5D0),
    outlineVariant = Color(0xFF46464F),
)

@Composable
fun QuickLaunchTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit,
) {
    val dark = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        content = content,
    )
}
