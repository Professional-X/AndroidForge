package com.profapps.quicklaunch.providers.files

/**
 * Pure, device-free file-type logic shared by the file search provider and its
 * unit tests: extension-to-category mapping, filter keyword parsing, MIME
 * fallbacks and friendly size formatting. No Android framework calls here.
 */
object FileTypes {

    /** Coarse visual grouping for file results. */
    enum class Category { DOCS, IMAGES, VIDEOS, AUDIO, ARCHIVES, APK, OTHER }

    /** Lowercase extension (no dot) to category. */
    private val EXTENSION_CATEGORY: Map<String, Category> = buildMap {
        val docs = setOf(
            "pdf", "doc", "docx", "txt", "md", "rtf", "odt",
            "xls", "xlsx", "csv", "ppt", "pptx", "odp", "epub",
        )
        val images = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp", "svg")
        val videos = setOf("mp4", "mkv", "avi", "mov", "webm", "m4v", "3gp")
        val audio = setOf("mp3", "wav", "ogg", "flac", "m4a", "aac", "opus")
        val archives = setOf("zip", "rar", "7z", "tar", "gz")
        val apks = setOf("apk")
        docs.forEach { put(it, Category.DOCS) }
        images.forEach { put(it, Category.IMAGES) }
        videos.forEach { put(it, Category.VIDEOS) }
        audio.forEach { put(it, Category.AUDIO) }
        archives.forEach { put(it, Category.ARCHIVES) }
        apks.forEach { put(it, Category.APK) }
    }

    /** Fallback MIME types so files can be opened even when MediaStore lacks one. */
    private val EXTENSION_MIME: Map<String, String> = mapOf(
        "pdf" to "application/pdf",
        "doc" to "application/msword",
        "docx" to "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "xls" to "application/vnd.ms-excel",
        "xlsx" to "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "ppt" to "application/vnd.ms-powerpoint",
        "pptx" to "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "txt" to "text/plain",
        "md" to "text/plain",
        "csv" to "text/csv",
        "zip" to "application/zip",
        "apk" to "application/vnd.android.package-archive",
        "jpg" to "image/jpeg",
        "jpeg" to "image/jpeg",
        "png" to "image/png",
        "gif" to "image/gif",
        "webp" to "image/webp",
        "svg" to "image/svg+xml",
        "mp3" to "audio/mpeg",
        "m4a" to "audio/mp4",
        "wav" to "audio/wav",
        "ogg" to "audio/ogg",
        "flac" to "audio/flac",
        "mp4" to "video/mp4",
        "mkv" to "video/x-matroska",
        "avi" to "video/x-msvideo",
        "mov" to "video/quicktime",
        "webm" to "video/webm",
    )

    /** First-token filter keywords, e.g. "file pdf taxes" -> filter DOCS, term "taxes". */
    val FILTER_KEYWORDS: Map<String, Category> = mapOf(
        "doc" to Category.DOCS,
        "docs" to Category.DOCS,
        "document" to Category.DOCS,
        "documents" to Category.DOCS,
        "pdf" to Category.DOCS,
        "txt" to Category.DOCS,
        "sheet" to Category.DOCS,
        "image" to Category.IMAGES,
        "images" to Category.IMAGES,
        "photo" to Category.IMAGES,
        "photos" to Category.IMAGES,
        "pic" to Category.IMAGES,
        "pics" to Category.IMAGES,
        "video" to Category.VIDEOS,
        "videos" to Category.VIDEOS,
        "movie" to Category.VIDEOS,
        "movies" to Category.VIDEOS,
        "audio" to Category.AUDIO,
        "music" to Category.AUDIO,
        "song" to Category.AUDIO,
        "songs" to Category.AUDIO,
        "archive" to Category.ARCHIVES,
        "archives" to Category.ARCHIVES,
        "zip" to Category.ARCHIVES,
        "apk" to Category.APK,
    )

    /**
     * Splits a raw term into an optional leading filter and the remaining text.
     * Examples:
     *   "pdf taxes"    -> ("taxes", DOCS)
     *   "report 2024"  -> ("report 2024", null)
     *   ""             -> ("", null)
     */
    fun parseFilter(term: String): Pair<String, Category?> {
        val tokens = term.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return "" to null
        val first = tokens.first().lowercase().trimEnd('.', ':', ',')
        val filter = FILTER_KEYWORDS[first] ?: return term.trim() to null
        val rest = tokens.drop(1).joinToString(" ")
        return rest to filter
    }

    fun extensionOf(fileName: String): String {
        val dot = fileName.lastIndexOf('.')
        return if (dot >= 0 && dot < fileName.length - 1) {
            fileName.substring(dot + 1).lowercase()
        } else {
            ""
        }
    }

    fun categoryFor(fileName: String, mimeType: String?): Category {
        val byExt = EXTENSION_CATEGORY[extensionOf(fileName)]
        if (byExt != null) return byExt
        val mime = mimeType?.lowercase() ?: return Category.OTHER
        return when {
            mime.startsWith("image/") -> Category.IMAGES
            mime.startsWith("video/") -> Category.VIDEOS
            mime.startsWith("audio/") -> Category.AUDIO
            mime.contains("pdf") || mime.startsWith("text/") ||
                mime.contains("document") || mime.contains("presentation") ||
                mime.contains("spreadsheet") -> Category.DOCS
            mime.contains("zip") || mime.contains("compressed") ||
                mime.contains("tar") || mime.contains("rar") -> Category.ARCHIVES
            mime == "application/vnd.android.package-archive" -> Category.APK
            else -> Category.OTHER
        }
    }

    /** Best MIME for [ACTION_VIEW]: trust MediaStore, fall back to the extension map. */
    fun mimeFor(fileName: String, storedMime: String?): String {
        val stored = storedMime?.takeIf { it.isNotBlank() }
        if (stored != null && stored != "application/octet-stream") return stored
        return EXTENSION_MIME[extensionOf(fileName)] ?: "application/octet-stream"
    }

    /** "Invoice_2024 final.pdf" -> "Invoice_2024 final" for fuzzy matching. */
    fun stripExtension(fileName: String): String {
        val dot = fileName.lastIndexOf('.')
        return if (dot > 0) fileName.substring(0, dot) else fileName
    }

    /** Human-readable size: 0 B, 12 KB, 3.4 MB, 1.2 GB. */
    fun formatSize(bytes: Long): String {
        if (bytes < 0) return "0 B"
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return trimOneDecimal(kb) + " KB"
        val mb = kb / 1024.0
        if (mb < 1024) return trimOneDecimal(mb) + " MB"
        val gb = mb / 1024.0
        return trimOneDecimal(gb) + " GB"
    }

    private fun trimOneDecimal(value: Double): String {
        val rounded = kotlin.math.round(value * 10) / 10.0
        return if (rounded == rounded.toLong().toDouble()) {
            rounded.toLong().toString()
        } else {
            rounded.toString()
        }
    }
}
