package com.profapps.quicklaunch.search

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Orchestrates all providers for a query:
 *  - runs enabled providers in parallel on Dispatchers.Default,
 *  - applies a per-provider timeout so one slow provider never stalls the UI,
 *  - merges, de-duplicates and sorts results by score.
 *
 * The caller (palette controller) cancels the previous search before starting
 * a new one, so stale results can never overwrite fresher ones.
 */
class SearchEngine(
    private val providers: List<SearchProvider>,
    private val isEnabled: (String) -> Boolean = { true },
    private val defaultTimeoutMs: Long = 300,
) {

    suspend fun search(query: String): List<SearchResult> {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return emptyList()
        val searchQuery = SearchQuery(raw = trimmed, hint = CommandParser.parse(trimmed))

        return coroutineScope {
            val active = providers.filter { isEnabled(it.id) }
            val deferred = active.map { provider ->
                async {
                    try {
                        withTimeoutOrNull(defaultTimeoutMs) { provider.search(searchQuery) }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (t: Throwable) {
                        // A broken provider must never break search. We catch
                        // Throwable (not just Exception) because some OEM
                        // MediaStore / PackageManager builds throw Errors.
                        emptyList()
                    }
                }
            }
            deferred.awaitAll()
                .filterNotNull()
                .flatten()
                .filter { it.title.isNotBlank() }
                .distinctBy { it.id }
                .sortedWith(
                    compareByDescending<SearchResult> { it.score }
                        .thenBy { it.category.ordinal }
                        .thenBy { it.title }
                )
                .take(MAX_RESULTS)
        }
    }

    private companion object {
        const val MAX_RESULTS = 30
    }
}
