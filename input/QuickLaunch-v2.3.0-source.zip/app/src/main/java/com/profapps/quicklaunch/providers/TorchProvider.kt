package com.profapps.quicklaunch.providers

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import com.profapps.quicklaunch.R
import com.profapps.quicklaunch.data.ProviderIds
import com.profapps.quicklaunch.search.ActionResult
import com.profapps.quicklaunch.search.CommandHint
import com.profapps.quicklaunch.search.ResultCategory
import com.profapps.quicklaunch.search.ResultIcon
import com.profapps.quicklaunch.search.SearchProvider
import com.profapps.quicklaunch.search.SearchQuery
import com.profapps.quicklaunch.search.SearchResult
import com.profapps.quicklaunch.util.UiBridge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Flashlight switch as a first-class palette action: typing "flashlight",
 * "torch", "flashlight off" (or speaking it via voice search) offers a
 * one-tap toggle of the camera flash.
 *
 * Text matching lives in [TorchParser] (pure, unit-testable); the hardware
 * toggle lives in [Torch] and never throws past the result action — failures
 * surface as a toast, never as a crash.
 */
class TorchProvider(private val context: Context) : SearchProvider {

    override val id = ProviderIds.TORCH
    override val displayName = "Flashlight"

    private val torch = Torch()

    override suspend fun search(query: SearchQuery): List<SearchResult> =
        withContext(Dispatchers.Default) {
            // Explicit prefixes ("search torch", "file torch") mean the user is
            // looking for web results or files — stay out of the way.
            if (query.hint != CommandHint.None) return@withContext emptyList()
            val parsed = TorchParser.parse(query.raw) ?: return@withContext emptyList()
            buildList {
                if (parsed.includeOn) add(actionResult(on = true))
                if (parsed.includeOff) add(actionResult(on = false))
            }
        }

    private fun actionResult(on: Boolean): SearchResult =
        SearchResult(
            id = if (on) "torch:on" else "torch:off",
            title = context.getString(if (on) R.string.torch_action_on else R.string.torch_action_off),
            subtitle = context.getString(R.string.torch_subtitle),
            icon = ResultIcon.ResourceIcon(R.drawable.ic_bolt),
            score = 0.95f,
            category = ResultCategory.ACTIONS,
            recordable = false,
            action = {
                val result = runCatching { torch.toggle(context, on) }
                result.onSuccess { nowOn ->
                    UiBridge.toast(
                        context,
                        context.getString(if (nowOn) R.string.torch_on else R.string.torch_off),
                    )
                }
                result.onFailure {
                    UiBridge.toast(context, context.getString(R.string.torch_unavailable))
                }
                ActionResult.Stay
            },
        )

    /** Process-wide torch state; cheaply recreated if the process restarts. */
    class Torch {

        @Volatile
        var on: Boolean = false
            private set

        /** Returns the new state; fails when no controllable flash unit exists. */
        fun toggle(context: Context, target: Boolean): Boolean {
            val manager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
                ?: throw IllegalStateException("No camera service")
            val cameraId = manager.cameraIdList.firstOrNull { id ->
                runCatching {
                    manager.getCameraCharacteristics(id)
                        .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }.getOrDefault(false)
            } ?: throw IllegalStateException("No flash unit")
            manager.setTorchMode(cameraId, target)
            on = target
            return target
        }
    }
}

/** Pure query parser: decides which flashlight actions a query should offer. */
object TorchParser {

    data class Parsed(val includeOn: Boolean, val includeOff: Boolean)

    private const val MAX_QUERY_LENGTH = 40
    private const val MAX_TOKENS = 6

    fun parse(raw: String): Parsed? {
        val text = raw.trim().lowercase()
        if (text.isEmpty() || text.length > MAX_QUERY_LENGTH) return null
        val words = text.split(Regex("\\s+")).take(MAX_TOKENS)
        val hasTorchWord = words.any { it == "flashlight" || it == "torch" || it == "flash" }
        if (!hasTorchWord) return null
        val mentionsOff = words.any { it == "off" || it == "out" }
        val mentionsOn = words.any { it == "on" || it == "toggle" || it == "switch" }
        return when {
            mentionsOff && !mentionsOn -> Parsed(includeOn = false, includeOff = true)
            mentionsOn && !mentionsOff -> Parsed(includeOn = true, includeOff = false)
            else -> Parsed(includeOn = true, includeOff = true)
        }
    }
}
