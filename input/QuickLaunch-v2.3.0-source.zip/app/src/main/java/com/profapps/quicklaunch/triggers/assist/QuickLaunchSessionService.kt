package com.profapps.quicklaunch.triggers.assist

import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService

/** Creates a [QuickLaunchSession] for each assist gesture. */
class QuickLaunchSessionService : VoiceInteractionSessionService() {

    override fun onNewSession(args: Bundle?): VoiceInteractionSession = QuickLaunchSession(this)
}

/**
 * The system creates the session, then calls [onShow]; we immediately launch
 * the floating palette and hide the assist surface again.
 *
 * The permission check must happen HERE: OverlayController.show() is a
 * deliberate silent no-op without the overlay permission, which used to make
 * the assist gesture feel completely dead for users who had not granted it.
 * With the explicit check, we always fall back to the in-app palette so the
 * gesture always does something visible.
 */
class QuickLaunchSession(service: QuickLaunchSessionService) : VoiceInteractionSession(service) {

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val appContext = context.applicationContext
        val opened = runCatching {
            if (com.profapps.quicklaunch.overlay.OverlayController.isPermissionGranted(appContext)) {
                com.profapps.quicklaunch.overlay.OverlayController.show(appContext)
                true
            } else {
                false
            }
        }.getOrDefault(false)
        if (!opened) {
            // Overlay permission missing or the service start was refused:
            // fall back to the in-app palette, which needs no permission.
            runCatching {
                appContext.startActivity(
                    android.content.Intent(appContext, com.profapps.quicklaunch.MainActivity::class.java)
                        .putExtra(
                            com.profapps.quicklaunch.MainActivity.EXTRA_OPEN_OVERLAY,
                            true,
                        )
                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }
        }
        hide()
    }
}
