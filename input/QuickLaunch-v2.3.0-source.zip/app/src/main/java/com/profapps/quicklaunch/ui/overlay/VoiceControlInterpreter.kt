package com.profapps.quicklaunch.ui.overlay

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import com.profapps.quicklaunch.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import android.Manifest

/**
 * Captures voice input when the user triggers the assist gesture while the
 * palette is already open. Displays listening state, handles recognition
 * errors, and passes the transcript to the search controller as if the user
 * had typed it.
 *
 * This is a second-trigger-while-open pattern: first trigger opens the
 * palette (typing mode), second trigger starts listening (voice mode).
 */
class VoiceControlInterpreter(
    private val context: Context,
    private val onTranscript: (String) -> Unit,
    private val onListeningStateChange: (Boolean) -> Unit,
    private val onError: (String) -> Unit,
) : RecognitionListener {

    private var recognizer: SpeechRecognizer? = null
    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    fun canUseMic(): Boolean {
        val permission = Manifest.permission.RECORD_AUDIO
        return ContextCompat.checkSelfPermission(context, permission) ==
            PackageManager.PERMISSION_GRANTED
    }

    fun startListening() {
        if (!canUseMic()) {
            onError(context.getString(R.string.voice_mic_needed))
            return
        }

        runCatching {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(context)
                recognizer?.setRecognitionListener(this)
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
                )
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                // No explicit prompt text; the system handles it
                if (Build.VERSION.SDK_INT >= 33) {
                    putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, 1) // DEFAULT
                }
            }
            recognizer?.startListening(intent)
            _isListening.value = true
            onListeningStateChange(true)
        }.onFailure { e ->
            onError(context.getString(R.string.voice_unavailable))
            _isListening.value = false
            onListeningStateChange(false)
        }
    }

    fun stopListening() {
        recognizer?.stopListening()
        _isListening.value = false
        onListeningStateChange(false)
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
        // Recognition is still happening; don't close yet
    }

    override fun onError(error: Int) {
        _isListening.value = false
        onListeningStateChange(false)

        val message = when (error) {
            SpeechRecognizer.ERROR_AUDIO -> context.getString(R.string.voice_no_match)
            SpeechRecognizer.ERROR_NETWORK -> context.getString(R.string.voice_no_match)
            SpeechRecognizer.ERROR_NO_MATCH -> context.getString(R.string.voice_no_match)
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> context.getString(R.string.voice_no_match)
            else -> context.getString(R.string.voice_no_match)
        }
        onError(message)
    }

    override fun onResults(results: Bundle?) {
        _isListening.value = false
        onListeningStateChange(false)

        val transcripts = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val best = transcripts?.firstOrNull()?.trim()

        if (!best.isNullOrEmpty()) {
            onTranscript(best)
        } else {
            onError(context.getString(R.string.voice_no_match))
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    fun release() {
        recognizer?.destroy()
        recognizer = null
    }
}
