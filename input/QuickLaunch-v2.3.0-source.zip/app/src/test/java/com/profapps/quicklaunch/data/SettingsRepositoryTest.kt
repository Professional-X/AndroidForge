package com.profapps.quicklaunch.data

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class SettingsRepositoryTest {

    private fun newStore(testScope: CoroutineScope, file: File) =
        PreferenceDataStoreFactory.create(scope = testScope, produceFile = { file })

    @Test
    fun `defaults are sane`() = runTest {
        val file = File.createTempFile("ql-defaults", ".preferences_pb")
        val store = newStore(CoroutineScope(UnconfinedTestDispatcher(testScheduler) + Job()), file)
        val repo = SettingsRepository(store, CoroutineScope(UnconfinedTestDispatcher(testScheduler) + Job()))
        advanceUntilIdle()

        val settings = repo.settings.value
        assertTrue(settings.isProviderEnabled(ProviderIds.APPS))
        assertTrue(settings.isProviderEnabled(ProviderIds.WEB))
        assertEquals(ThemeMode.SYSTEM, settings.themeMode)
        assertEquals(0.94f, settings.panelOpacity, 0.001f)
        store.data.first()
        file.delete()
    }

    @Test
    fun `provider toggles persist and read back`() = runTest {
        val file = File.createTempFile("ql-providers", ".preferences_pb")
        val scope = CoroutineScope(UnconfinedTestDispatcher(testScheduler) + Job())
        val store = newStore(scope, file)
        val repo = SettingsRepository(store, scope)
        advanceUntilIdle()

        repo.setProviderEnabled(ProviderIds.CONTACTS, false)
        advanceUntilIdle()
        assertFalse(repo.settings.value.isProviderEnabled(ProviderIds.CONTACTS))
        assertTrue(repo.settings.value.isProviderEnabled(ProviderIds.APPS))

        repo.setProviderEnabled(ProviderIds.CONTACTS, true)
        advanceUntilIdle()
        assertTrue(repo.settings.value.isProviderEnabled(ProviderIds.CONTACTS))
        file.delete()
    }

    @Test
    fun `theme and opacity persist`() = runTest {
        val file = File.createTempFile("ql-theme", ".preferences_pb")
        val scope = CoroutineScope(UnconfinedTestDispatcher(testScheduler) + Job())
        val store = newStore(scope, file)
        val repo = SettingsRepository(store, scope)
        advanceUntilIdle()

        repo.setThemeMode(ThemeMode.DARK)
        repo.setPanelOpacity(0.7f)
        advanceUntilIdle()
        assertEquals(ThemeMode.DARK, repo.settings.value.themeMode)
        assertEquals(0.7f, repo.settings.value.panelOpacity, 0.001f)

        // Out-of-range values clamp instead of breaking the palette.
        repo.setPanelOpacity(5f)
        advanceUntilIdle()
        assertEquals(1f, repo.settings.value.panelOpacity, 0.001f)
        file.delete()
    }

    @Test
    fun `pinned apps update`() = runTest {
        val file = File.createTempFile("ql-pins", ".preferences_pb")
        val scope = CoroutineScope(UnconfinedTestDispatcher(testScheduler) + Job())
        val store = newStore(scope, file)
        val repo = SettingsRepository(store, scope)
        advanceUntilIdle()

        repo.setAppPinned("com.profapps.quicklaunch", true)
        advanceUntilIdle()
        assertTrue(repo.settings.value.pinnedApps.contains("com.profapps.quicklaunch"))

        repo.setAppPinned("com.profapps.quicklaunch", false)
        advanceUntilIdle()
        assertFalse(repo.settings.value.pinnedApps.contains("com.profapps.quicklaunch"))
        file.delete()
    }

    @Test
    fun `bubble trigger toggle persists and defaults off`() = runTest {
        val file = File.createTempFile("ql-bubble", ".preferences_pb")
        val scope = CoroutineScope(UnconfinedTestDispatcher(testScheduler) + Job())
        val store = newStore(scope, file)
        val repo = SettingsRepository(store, scope)
        advanceUntilIdle()

        assertFalse(repo.settings.value.bubbleTriggerEnabled)

        repo.setBubbleTriggerEnabled(true)
        advanceUntilIdle()
        assertTrue(repo.settings.value.bubbleTriggerEnabled)

        repo.setBubbleTriggerEnabled(false)
        advanceUntilIdle()
        assertFalse(repo.settings.value.bubbleTriggerEnabled)
        file.delete()
    }
}
