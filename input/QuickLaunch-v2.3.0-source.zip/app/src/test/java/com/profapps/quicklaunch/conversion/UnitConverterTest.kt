package com.profapps.quicklaunch.conversion

import com.profapps.quicklaunch.providers.conversion.UnitConverter
import com.profapps.quicklaunch.providers.conversion.UnitConverter.ConversionResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UnitConverterTest {

    private fun convertOrNull(input: String): ConversionResult.Success =
        UnitConverter.convert(input) as? ConversionResult.Success
            ?: error("expected success for $input")

    private fun value(input: String): Double = convertOrNull(input).rawOutput

    @Test
    fun `spec examples`() {
        assertEquals(6.2137119, value("10 km to miles"), 1e-4)
        assertEquals(11.023113, value("5 kg to lb"), 1e-4)
        assertEquals(212.0, value("100 c to f"), 1e-6)
    }

    @Test
    fun `no space and in keyword`() {
        assertEquals(11.023113, value("5kg in lb"), 1e-4)
        assertEquals(3.2808398, value("1 m in ft"), 1e-4)
    }

    @Test
    fun `temperature both directions`() {
        assertEquals(0.0, value("32 f to c"), 1e-6)
        assertEquals(373.15, value("100 c to k"), 1e-2)
        assertEquals(68.0, value("20 c to f"), 1e-6)
        assertEquals(-40.0, value("-40 c to f"), 1e-6) // the famous crossover
    }

    @Test
    fun `length conversions`() {
        assertEquals(1000.0, value("1 km to m"), 1e-9)
        assertEquals(1.609344, value("1 mi to km"), 1e-6)
        assertEquals(2.54, value("1 in to cm"), 1e-9)
    }

    @Test
    fun `mass conversions`() {
        assertEquals(0.45359237, value("1 lb to kg"), 1e-8)
        assertEquals(16.0, value("1 lb to oz"), 1e-6)
        assertEquals(6.35029318, value("1 st to kg"), 1e-8)
    }

    @Test
    fun `volume and time and data`() {
        assertEquals(3.785411784, value("1 gal to l"), 1e-6)
        assertEquals(90.0, value("1.5 h to min"), 1e-9)
        assertEquals(1024.0, value("1 kib to b"), 1e-6)
        assertEquals(1000.0, value("1 gb to mb"), 1e-6)
    }

    @Test
    fun `speed conversions`() {
        assertEquals(62.137119, value("100 kmh to mph"), 1e-4)
    }

    @Test
    fun `alias handling`() {
        assertEquals(11.023113, value("5 kilograms to pounds"), 1e-4)
        assertEquals(212.0, value("100 celsius to fahrenheit"), 1e-6)
    }

    @Test
    fun `case insensitive units`() {
        assertEquals(212.0, value("100 C to F"), 1e-6)
        assertEquals(11.023113, value("5 KG to LB"), 1e-4)
    }

    @Test
    fun `unknown unit reported not thrown`() {
        val result = UnitConverter.convert("10 zzz to km")
        assertTrue(result is ConversionResult.Failure)
    }

    @Test
    fun `cross dimension rejected`() {
        val result = UnitConverter.convert("10 km to kg")
        assertTrue(result is ConversionResult.Failure)
    }

    @Test
    fun `non conversion input returns null`() {
        assertNull(UnitConverter.convert("hello world"))
        assertNull(UnitConverter.convert("settings wifi"))
        assertNull(UnitConverter.convert("2+2"))
        assertNull(UnitConverter.convert("to be or not"))
    }

    @Test
    fun `looksLikeConversion gate`() {
        assertTrue(UnitConverter.looksLikeConversion("10 km to mi"))
        assertFalse(UnitConverter.looksLikeConversion("search cats"))
        assertFalse(UnitConverter.looksLikeConversion("10 km to zz"))
    }

    @Test
    fun `display strings include units`() {
        val success = convertOrNull("10 km to miles")
        assertTrue(success.inputDisplay.startsWith("10"))
        assertTrue(success.outputDisplay.contains("mile"))
    }
}
