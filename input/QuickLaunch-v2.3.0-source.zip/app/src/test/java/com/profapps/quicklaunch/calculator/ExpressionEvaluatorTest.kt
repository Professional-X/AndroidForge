package com.profapps.quicklaunch.calculator

import com.profapps.quicklaunch.providers.calculator.ExpressionEvaluator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExpressionEvaluatorTest {

    private fun eval(expression: String): Double =
        (ExpressionEvaluator.evaluate(expression) as ExpressionEvaluator.MathResult.Success).value

    private fun isFailure(expression: String): Boolean =
        ExpressionEvaluator.evaluate(expression) is ExpressionEvaluator.MathResult.Failure

    @Test
    fun `basic arithmetic from the spec`() {
        assertEquals(4.0, eval("2+2"), 1e-9)
        assertEquals(120.0, eval("15*8"), 1e-9)
        assertEquals(25.0, eval("100/4"), 1e-9)
        assertEquals(56.0, eval("(5+3)*7"), 1e-9)
        assertEquals(20.0, eval("25% of 80"), 1e-9)
    }

    @Test
    fun `operator precedence`() {
        assertEquals(14.0, eval("2+3*4"), 1e-9)
        assertEquals(20.0, eval("(2+3)*4"), 1e-9)
        assertEquals(2.0, eval("10-4*2"), 1e-9)
        assertEquals(1.5, eval("3/2"), 1e-9)
    }

    @Test
    fun `unicode operators are normalized`() {
        assertEquals(8.0, eval("2×4"), 1e-9)
        assertEquals(2.0, eval("8÷4"), 1e-9)
    }

    @Test
    fun `unary minus and plus`() {
        assertEquals(-5.0, eval("-5"), 1e-9)
        assertEquals(-7.0, eval("2-9"), 1e-9)
        assertEquals(5.0, eval("-(-5)"), 1e-9)
        assertEquals(-6.0, eval("-2*3"), 1e-9)
    }

    @Test
    fun `nested parentheses`() {
        assertEquals(30.0, eval("((2+3))*(6)"), 1e-9)
        assertEquals(11.0, eval("(2+(3*3))"), 1e-9)
    }

    @Test
    fun `modulo between numbers`() {
        assertEquals(1.0, eval("10 % 3"), 1e-9)
        assertEquals(0.0, eval("10 % 5"), 1e-9)
    }

    @Test
    fun `thousands separators are stripped`() {
        assertEquals(2000.0, eval("1,000*2"), 1e-9)
    }

    @Test
    fun `trailing equals sign tolerated`() {
        assertEquals(4.0, eval("2+2="), 1e-9)
    }

    @Test
    fun `division by zero fails safely`() {
        assertTrue(isFailure("5/0"))
        assertTrue(isFailure("5/(2-2)"))
    }

    @Test
    fun `malformed expressions fail`() {
        assertTrue(isFailure("2+"))
        assertTrue(isFailure("*3"))
        assertTrue(isFailure("(2+3"))
        assertTrue(isFailure("2++*3"))
        assertTrue(isFailure(""))
        assertTrue(isFailure("2 3"))
    }

    @Test
    fun `looksLikeMath gates correctly`() {
        assertTrue(ExpressionEvaluator.looksLikeMath("2+2"))
        assertTrue(ExpressionEvaluator.looksLikeMath("(5+3)*7"))
        assertTrue(ExpressionEvaluator.looksLikeMath("25% of 80".replace(" ", "")))
        assertFalse(ExpressionEvaluator.looksLikeMath("hello"))
        assertFalse(ExpressionEvaluator.looksLikeMath("10 km to miles"))
        assertFalse(ExpressionEvaluator.looksLikeMath("settings wifi"))
        assertFalse(ExpressionEvaluator.looksLikeMath("12345"))
    }

    @Test
    fun `formatNumber trims and groups`() {
        assertEquals("200", ExpressionEvaluator.formatNumber(200.0))
        assertEquals("1,200", ExpressionEvaluator.formatNumber(1200.0))
        assertEquals("0.5", ExpressionEvaluator.formatNumber(0.5))
        assertEquals("3.333333", ExpressionEvaluator.formatNumber(10.0 / 3.0))
    }
}
