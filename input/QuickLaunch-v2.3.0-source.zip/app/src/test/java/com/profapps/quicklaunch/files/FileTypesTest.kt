package com.profapps.quicklaunch.files

import com.profapps.quicklaunch.providers.files.FileTypes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FileTypesTest {

    @Test
    fun `parseFilter splits known keyword from remaining term`() {
        val (term, filter) = FileTypes.parseFilter("pdf taxes 2024")
        assertEquals("taxes 2024", term)
        assertEquals(FileTypes.Category.DOCS, filter)
    }

    @Test
    fun `parseFilter keeps unknown first token as term`() {
        val (term, filter) = FileTypes.parseFilter("report final")
        assertEquals("report final", term)
        assertNull(filter)
    }

    @Test
    fun `parseFilter handles all major categories`() {
        assertEquals(FileTypes.Category.IMAGES, FileTypes.parseFilter("photo beach").second)
        assertEquals(FileTypes.Category.VIDEOS, FileTypes.parseFilter("movie night").second)
        assertEquals(FileTypes.Category.AUDIO, FileTypes.parseFilter("music chill").second)
        assertEquals(FileTypes.Category.ARCHIVES, FileTypes.parseFilter("zip backup").second)
        assertEquals(FileTypes.Category.APK, FileTypes.parseFilter("apk launcher").second)
    }

    @Test
    fun `parseFilter ignores punctuation after keyword`() {
        assertEquals(FileTypes.Category.DOCS, FileTypes.parseFilter("pdf.").second)
        assertEquals("taxes", FileTypes.parseFilter("pdf. taxes").first)
    }

    @Test
    fun `parseFilter of blank term is empty`() {
        val (term, filter) = FileTypes.parseFilter("")
        assertEquals("", term)
        assertNull(filter)
    }

    @Test
    fun `categoryFor maps by extension`() {
        assertEquals(FileTypes.Category.DOCS, FileTypes.categoryFor("a.PDF", null))
        assertEquals(FileTypes.Category.IMAGES, FileTypes.categoryFor("photo.jpeg", null))
        assertEquals(FileTypes.Category.VIDEOS, FileTypes.categoryFor("clip.mkv", null))
        assertEquals(FileTypes.Category.AUDIO, FileTypes.categoryFor("song.mp3", null))
        assertEquals(FileTypes.Category.ARCHIVES, FileTypes.categoryFor("backup.zip", null))
        assertEquals(FileTypes.Category.APK, FileTypes.categoryFor("app.apk", null))
    }

    @Test
    fun `categoryFor falls back to mime when extension unknown`() {
        assertEquals(
            FileTypes.Category.IMAGES,
            FileTypes.categoryFor("render.xcf", "image/x-xcf"),
        )
        assertEquals(
            FileTypes.Category.DOCS,
            FileTypes.categoryFor("notes.weird", "application/pdf"),
        )
        assertEquals(FileTypes.Category.OTHER, FileTypes.categoryFor("blob", null))
        assertEquals(FileTypes.Category.OTHER, FileTypes.categoryFor("blob", "weird/mime"))
    }

    @Test
    fun `mimeFor trusts MediaStore and falls back to extension`() {
        assertEquals("image/jpeg", FileTypes.mimeFor("a.jpg", "image/jpeg"))
        assertEquals(
            "application/pdf",
            FileTypes.mimeFor("a.pdf", null),
        )
        assertEquals(
            "application/octet-stream",
            FileTypes.mimeFor("a.xyz123", null),
        )
        // octet-stream from MediaStore is treated as missing information.
        assertEquals("application/pdf", FileTypes.mimeFor("a.pdf", "application/octet-stream"))
    }

    @Test
    fun `stripExtension keeps dotfiles intact`() {
        assertEquals("invoice 2024", FileTypes.stripExtension("invoice 2024.pdf"))
        assertEquals("archive.tar", FileTypes.stripExtension("archive.tar.gz"))
        assertEquals(".gitignore", FileTypes.stripExtension(".gitignore"))
        assertEquals("README", FileTypes.stripExtension("README"))
    }

    @Test
    fun `formatSize produces friendly units`() {
        assertEquals("0 B", FileTypes.formatSize(0))
        assertEquals("512 B", FileTypes.formatSize(512))
        assertEquals("1 KB", FileTypes.formatSize(1024))
        assertEquals("1.5 KB", FileTypes.formatSize(1536))
        assertEquals("1 MB", FileTypes.formatSize(1024L * 1024))
        assertEquals("3.4 MB", FileTypes.formatSize((3.4 * 1024 * 1024).toLong()))
        assertEquals("2 GB", FileTypes.formatSize(2L * 1024 * 1024 * 1024))
        assertEquals("0 B", FileTypes.formatSize(-5))
    }

    @Test
    fun `extensionOf lowercases and ignores dotless names`() {
        assertEquals("pdf", FileTypes.extensionOf("Report.PDF"))
        assertEquals("", FileTypes.extensionOf("noext"))
        assertEquals("gz", FileTypes.extensionOf("x.tar.gz"))
    }
}
