# NAMMU AI - Android starter project

## Is project mein kya hai?
- Dark blue futuristic NAMMU AI screen
- Text chat starter
- Android speech recognition button (Hindi - India)
- Text-to-speech replies
- Experimental foreground wake-word service jo "Nammu" sunne par app launch karne ki koshish karta hai

## Important limitations
Ye **starter source project** hai, ready-built APK nahi. Isko build/test karna zaroori hai.
Wake-word detection Android SpeechRecognizer ko baar-baar listen karwata hai; ye dedicated offline hotword engine nahi hai. Phone, Google speech service, battery optimization, permissions aur Android restrictions ki wajah se background/locked-screen detection kabhi bhi ruk sakta hai. Isliye reliable always-on wake word ki guarantee nahi hai.
Chat replies abhi demo/rule-based hain. Real intelligent AI ke liye secure backend server aur AI API connect karni hogi. API key ko APK ke andar hardcode mat karein.

## APK kaise banayein
1. Computer par Android Studio install karein.
2. ZIP extract karein.
3. Android Studio mein extracted `NAMO_AI_Android_Project` folder open karein.
4. Gradle sync complete hone dein. JDK 17 select karein agar poocha jaye.
5. Android phone par Developer options aur USB debugging enable karke phone connect karein.
6. Run button dabakar phone par test karein.
7. APK banane ke liye: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
8. Android Studio build complete hone par APK path dikhayega (aam taur par `app/build/outputs/apk/debug/app-debug.apk`).

## Phone permissions
App ko microphone permission chahiye. Wake-word service start karne ke liye app ke andar button dabayein. Android notification/foreground service ko active rehne dein. Battery optimization ise band kar sakti hai.

## Agla development step
- Secure backend se AI chat connect karna
- App launching, alarm/reminder actions aur confirmation flows
- Dedicated on-device hotword engine (agar compatible model/license available ho)
- Error handling, privacy notice aur proper app icon
