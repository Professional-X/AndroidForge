package com.namo.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout messages;
    private EditText input;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private static final int REQ_AUDIO = 44;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(4, 12, 30));
        getWindow().setNavigationBarColor(Color.rgb(4, 12, 30));
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
        });
        buildUi();
        addMessage("NAMMU", "Namaste! Main NAMMU AI hoon. Aap mujhse bolkar ya type karke baat kar sakte hain.");
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 28, 20, 18);
        root.setBackgroundColor(Color.rgb(4, 12, 30));
        setContentView(root);

        TextView title = new TextView(this);
        title.setText("N A M M U   A I");
        title.setTextColor(Color.rgb(80, 210, 255));
        title.setTextSize(27); title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, 58));

        TextView sub = new TextView(this);
        sub.setText("YOUR PERSONAL AI ASSISTANT");
        sub.setTextColor(Color.LTGRAY); sub.setTextSize(11); sub.setGravity(Gravity.CENTER);
        root.addView(sub, new LinearLayout.LayoutParams(-1, 28));

        ScrollView scroll = new ScrollView(this);
        messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(0, 16, 0, 16); scroll.addView(messages);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        Button listen = button("🎙  TALK TO NAMMU");
        root.addView(listen, new LinearLayout.LayoutParams(-1, 52));
        listen.setOnClickListener(v -> startSpeech());

        input = new EditText(this);
        input.setSingleLine(true); input.setTextColor(Color.WHITE); input.setHintTextColor(Color.GRAY);
        input.setHint("Type a message...");
        input.setPadding(16, 8, 16, 8); input.setBackground(bg(Color.rgb(20, 32, 54), 24));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, 52); ip.topMargin = 10;
        root.addView(input, ip);

        Button send = button("SEND MESSAGE");
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 46); sp.topMargin = 8;
        root.addView(send, sp);
        send.setOnClickListener(v -> {
            String q = input.getText().toString().trim();
            if (!q.isEmpty()) { input.setText(""); respond(q); }
        });

        Button wake = button("ENABLE “NAMMU” WAKE WORD");
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1, 46); wp.topMargin = 8;
        root.addView(wake, wp);
        wake.setOnClickListener(v -> {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            } else startWakeService();
        });
    }

    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setBackground(bg(Color.rgb(0, 111, 180), 22)); return b;
    }

    private void addMessage(String who, String text) {
        TextView t = new TextView(this);
        t.setText(who + "\n" + text); t.setTextColor(Color.WHITE); t.setTextSize(15);
        t.setPadding(14, 12, 14, 12); t.setBackground(bg(Color.rgb(18, 34, 58), 18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = 12;
        messages.addView(t, p);
    }

    private void respond(String q) {
        addMessage("YOU", q);
        String lower = q.toLowerCase(Locale.ROOT);
        String a;
        if (lower.contains("hello") || lower.contains("hi") || lower.contains("namaste") || lower.contains("namo")) {
            a = "Namaste! Main NAMMU AI hoon. Aapki kya madad karun?";
        } else if (lower.contains("time") || lower.contains("samay") || lower.contains("kitne baje")) {
            a = "Aapke phone par current time dekhne ke liye status bar ya Clock app check karein.";
        } else if (lower.contains("open") || lower.contains("kholo")) {
            a = "Main is starter version mein app kholne ka command abhi support nahi karta. Is feature ko next development step mein add kiya ja sakta hai.";
        } else {
            a = "Maine aapka message suna: " + q + ". Abhi main starter assistant hoon. Full intelligent AI ke liye secure AI API/backend connect karna hoga.";
        }
        addMessage("NAMMU AI", a);
        if (tts != null) tts.speak(a, TextToSpeech.QUEUE_FLUSH, null, "nammu_reply");
    }

    private void startSpeech() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addMessage("NAMMU AI", "Speech recognition is not available on this phone. Install or enable a speech recognition service."); return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new android.speech.RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { addMessage("NAMMU AI", "Listening..."); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {}
            public void onError(int e) { addMessage("NAMMU AI", "Voice recognition ruk gaya. Dobara try karein."); }
            public void onResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty()) respond(r.get(0));
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int t, Bundle p) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "NAMO se baat karein");
        recognizer.startListening(i);
    }

    private void startWakeService() {
        Intent i = new Intent(this, WakeWordService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        addMessage("NAMMU AI", "Wake-word service start karne ki request bhej di. Screen lock/background mein Android ya phone battery settings ise rok sakti hain.");
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startWakeService();
        } else addMessage("NAMMU AI", "Voice features ke liye microphone permission zaroori hai.");
    }

    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
