package com.namo.ai;

import android.app.*;
import android.content.*;
import android.os.*;
import android.speech.*;
import java.util.*;

public class WakeWordService extends Service {
    private SpeechRecognizer recognizer;
    private boolean active = true;
    private static final String CHANNEL = "namo_wake_channel";

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification n = new Notification.Builder(this, CHANNEL)
            .setContentTitle("NAMMU AI wake word")
            .setContentText("Wake-word listening service is active")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build();
        startForeground(7, n);
        beginListening();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "NAMMU AI", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private void beginListening() {
        if (!active) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { stopSelf(); return; }
        try {
            if (recognizer != null) recognizer.destroy();
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle b) {}
                public void onBeginningOfSpeech() {}
                public void onRmsChanged(float r) {}
                public void onBufferReceived(byte[] b) {}
                public void onEndOfSpeech() {}
                public void onError(int e) { restartSoon(); }
                public void onResults(Bundle b) {
                    ArrayList<String> results = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (results != null) for (String s : results) {
                        String v = s.toLowerCase(Locale.ROOT);
                        if (v.contains("nammu") || v.contains("नम्मू")) {
                            Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
                            if (launch != null) {
                                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                                startActivity(launch);
                            }
                            break;
                        }
                    }
                    restartSoon();
                }
                public void onPartialResults(Bundle b) {}
                public void onEvent(int t, Bundle b) {}
            });
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            recognizer.startListening(i);
        } catch (Exception e) { restartSoon(); }
    }

    private void restartSoon() {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (recognizer != null) { recognizer.destroy(); recognizer = null; }
            beginListening();
        }, 1200);
    }

    @Override public int onStartCommand(Intent i, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        active = false;
        if (recognizer != null) recognizer.destroy();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
