package com.example.ui.screens

import android.app.PictureInPictureParams
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color as AndroidColor
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.TypedValue
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.Brightness6
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toAndroidRectF
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.graphics.toRect
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import com.example.data.model.AppSettings
import com.example.data.model.VideoItem
import com.example.ui.theme.LiquidSilver
import com.example.util.FormatUtils
import com.example.util.SubtitleSyncHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

private enum class HudOverlayType {
    BRIGHTNESS,
    VOLUME,
    SEEK,
    DOUBLE_TAP_LEFT,
    DOUBLE_TAP_RIGHT
}

private data class HudFeedback(
    val type: HudOverlayType,
    val label: String,
    val progress: Float? = null
)

private enum class ResizeOption(val label: String, val mode: Int) {
    FIT("Fit", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    FILL("Fill", AspectRatioFrameLayout.RESIZE_MODE_FILL),
    ZOOM("Zoom", AspectRatioFrameLayout.RESIZE_MODE_ZOOM)
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    video: VideoItem,
    settings: AppSettings,
    isInPictureInPictureMode: Boolean,
    onSaveProgress: (positionMs: Long, durationMs: Long) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findComponentActivity() }
    val lifecycleOwner = LocalLifecycleOwner.current
    val configuration = LocalConfiguration.current
    val coroutineScope = rememberCoroutineScope()
    val audioManager = remember(context) {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    val startPos = if (settings.autoResumePlayback) video.lastPositionMs else 0L

    val exoPlayer = remember(video.uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.parse(video.uri)))
            if (startPos > 0L) seekTo(startPos)
            setPlaybackSpeed(settings.defaultPlaybackSpeed)
            playWhenReady = true
            prepare()
        }
    }

    var isPlaying by remember { mutableStateOf(true) }
    var currentPositionMs by remember { mutableLongStateOf(startPos) }
    var durationMs by remember { mutableLongStateOf(video.durationMs.coerceAtLeast(0L)) }
    var playbackSpeed by remember { mutableFloatStateOf(settings.defaultPlaybackSpeed) }
    var videoSize by remember { mutableStateOf(VideoSize.UNKNOWN) }
    var playbackError by remember { mutableStateOf<String?>(null) }
    var currentTracks by remember { mutableStateOf(Tracks.EMPTY) }

    var showControls by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    val isCurrentlyLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    var resizeOption by remember { mutableStateOf(ResizeOption.FIT) }
    var showSpeedSheet by remember { mutableStateOf(false) }
    var showSubtitleSheet by remember { mutableStateOf(false) }

    // Subtitle selection & sync state
    var externalSubtitleUri by remember { mutableStateOf<Uri?>(null) }
    var externalSubtitleName by remember { mutableStateOf<String?>(null) }
    var subtitleOffsetMs by remember { mutableLongStateOf(0L) }
    var delayedEmbeddedCues by remember { mutableStateOf<List<String>>(emptyList()) }

    var hudFeedback by remember { mutableStateOf<HudFeedback?>(null) }
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubPreviewMs by remember { mutableLongStateOf(0L) }
    var lastInteractionTick by remember { mutableLongStateOf(System.currentTimeMillis()) }

    fun applyExternalSubtitleWithSync(subUri: Uri, fileName: String, offsetMs: Long) {
        coroutineScope.launch {
            val mimeType = inferSubtitleMimeType(fileName)
            val syncedUri = if (offsetMs != 0L && (fileName.endsWith(".srt", true) || fileName.endsWith(".vtt", true))) {
                withContext(Dispatchers.IO) {
                    SubtitleSyncHelper.createSyncedTempSrt(context, subUri, fileName, offsetMs)
                }
            } else null

            val effectiveUri = syncedUri ?: subUri
            val effectiveMime = if (syncedUri != null) MimeTypes.APPLICATION_SUBRIP else mimeType

            val resumeAt = exoPlayer.currentPosition
            val wasPlaying = exoPlayer.playWhenReady

            val subConfig = MediaItem.SubtitleConfiguration.Builder(effectiveUri)
                .setMimeType(effectiveMime)
                .setLanguage("en")
                .setLabel(fileName)
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()

            val updatedItem = MediaItem.Builder()
                .setUri(Uri.parse(video.uri))
                .setSubtitleConfigurations(listOf(subConfig))
                .build()

            exoPlayer.setMediaItem(updatedItem, resumeAt)
            exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .build()
            exoPlayer.playWhenReady = wasPlaying
            exoPlayer.prepare()
            playbackError = null
        }
    }

    val subtitlePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { subUri ->
        if (subUri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    subUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            val fileName = queryDisplayName(context, subUri) ?: "Subtitles.srt"
            externalSubtitleUri = subUri
            externalSubtitleName = fileName
            subtitleOffsetMs = 0L
            applyExternalSubtitleWithSync(subUri, fileName, 0L)
        }
    }

    // Listen to ExoPlayer playback, tracks, cues & errors
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                if (!playing) {
                    onSaveProgress(exoPlayer.currentPosition, exoPlayer.duration.coerceAtLeast(durationMs))
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    durationMs = exoPlayer.duration.coerceAtLeast(0L)
                    playbackError = null
                } else if (playbackState == Player.STATE_ENDED) {
                    isPlaying = false
                    showControls = true
                    onSaveProgress(0L, durationMs)
                }
            }

            override fun onVideoSizeChanged(size: VideoSize) {
                videoSize = size
            }

            override fun onTracksChanged(tracks: Tracks) {
                currentTracks = tracks
            }

            override fun onCues(cueGroup: CueGroup) {
                // Positive delay support for embedded subtitle tracks when no external SRT/VTT is active
                if (externalSubtitleUri == null && subtitleOffsetMs > 0L) {
                    val texts = cueGroup.cues.mapNotNull { it.text?.toString()?.takeIf { s -> s.isNotBlank() } }
                    val capturedDelay = subtitleOffsetMs
                    coroutineScope.launch {
                        delay(capturedDelay)
                        delayedEmbeddedCues = texts
                    }
                } else if (delayedEmbeddedCues.isNotEmpty()) {
                    delayedEmbeddedCues = emptyList()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                playbackError = when (error.errorCode) {
                    PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
                    PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ->
                        "This video codec is not supported by your device hardware decoder (${error.errorCodeName})."
                    PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ->
                        "Unsupported media container format (${video.formatExtension})."
                    PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
                        "Video file could not be found or storage permission expired."
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                        "Network connection failed while streaming video."
                    else -> error.message ?: "Unable to play this video format."
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            onSaveProgress(exoPlayer.currentPosition, exoPlayer.duration.coerceAtLeast(durationMs))
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    // Immersive fullscreen system bars & display cutout edge-to-edge
    DisposableEffect(activity) {
        val window = activity?.window
        val prevCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && window != null) {
            window.attributes.layoutInDisplayCutoutMode
        } else 0
        if (window != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                window.attributes = lp
            }
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            if (window != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val lp = window.attributes
                    lp.layoutInDisplayCutoutMode = prevCutoutMode
                    lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                    window.attributes = lp
                } else {
                    val lp = window.attributes
                    lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                    window.attributes = lp
                }
                val controller = WindowCompat.getInsetsController(window, window.decorView)
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Pause cleanly when backgrounded unless in Picture-in-Picture
    DisposableEffect(lifecycleOwner, isInPictureInPictureMode) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && !isInPictureInPictureMode) {
                onSaveProgress(exoPlayer.currentPosition, exoPlayer.duration.coerceAtLeast(durationMs))
                exoPlayer.pause()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Pre-Android 12 PiP on user leave hint
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && Build.VERSION.SDK_INT < Build.VERSION_CODES.S && activity != null) {
        DisposableEffect(activity, videoSize, isPlaying) {
            val onUserLeave = Runnable {
                if (isPlaying) {
                    val params = PictureInPictureParams.Builder()
                        .setAspectRatio(FormatUtils.safePipAspectRatio(videoSize.width, videoSize.height))
                        .build()
                    runCatching { activity.enterPictureInPictureMode(params) }
                }
            }
            activity.addOnUserLeaveHintListener(onUserLeave)
            onDispose { activity.removeOnUserLeaveHintListener(onUserLeave) }
        }
    }

    // Live position polling + periodic resume persistence
    LaunchedEffect(exoPlayer) {
        var tick = 0
        while (true) {
            if (!isScrubbing) {
                currentPositionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
                val d = exoPlayer.duration
                if (d > 0L) durationMs = d
            }
            tick++
            if (tick % 10 == 0 && exoPlayer.isPlaying) {
                onSaveProgress(exoPlayer.currentPosition, exoPlayer.duration.coerceAtLeast(durationMs))
            }
            delay(400L)
        }
    }

    // Auto-hide controls (3.5s while playing, or 2.5s for unlock pill when locked)
    LaunchedEffect(showControls, isPlaying, lastInteractionTick, isLocked, showSpeedSheet, showSubtitleSheet) {
        if (showControls && !showSpeedSheet && !showSubtitleSheet) {
            if (isLocked) {
                delay(2500L)
                showControls = false
            } else if (isPlaying) {
                delay(3500L)
                showControls = false
            }
        }
    }

    // Auto-clear HUD feedback
    LaunchedEffect(hudFeedback) {
        if (hudFeedback != null) {
            delay(1050L)
            hudFeedback = null
        }
    }

    BackHandler {
        if (isLocked) {
            showControls = true
            lastInteractionTick = System.currentTimeMillis()
        } else {
            onSaveProgress(exoPlayer.currentPosition, exoPlayer.duration.coerceAtLeast(durationMs))
            onBack()
        }
    }

    fun seekByDelta(deltaMs: Long) {
        val maxDur = durationMs.coerceAtLeast(exoPlayer.duration).coerceAtLeast(0L)
        val target = if (maxDur > 0L) {
            (exoPlayer.currentPosition + deltaMs).coerceIn(0L, maxDur)
        } else {
            (exoPlayer.currentPosition + deltaMs).coerceAtLeast(0L)
        }
        exoPlayer.seekTo(target)
        currentPositionMs = target
        onSaveProgress(target, maxDur)
        lastInteractionTick = System.currentTimeMillis()
    }

    fun triggerPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && activity != null) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(FormatUtils.safePipAspectRatio(videoSize.width, videoSize.height))
                .build()
            runCatching { activity.enterPictureInPictureMode(params) }
        }
    }

    fun toggleOrientation() {
        activity?.requestedOrientation = if (isCurrentlyLandscape) {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        lastInteractionTick = System.currentTimeMillis()
    }

    val pipModifier = Modifier.onGloballyPositioned { coords ->
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && activity != null) {
            val builder = PictureInPictureParams.Builder()
            val rect = coords.boundsInWindow().toAndroidRectF().toRect()
            if (!rect.isEmpty) {
                builder.setSourceRectHint(rect)
            }
            builder.setAspectRatio(FormatUtils.safePipAspectRatio(videoSize.width, videoSize.height))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                builder.setAutoEnterEnabled(isPlaying && playbackError == null)
            }
            runCatching { activity.setPictureInPictureParams(builder.build()) }
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("player_screen")
    ) {
        val totalWidthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val totalHeightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)

        // ExoPlayer Video Surface
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    keepScreenOn = true
                    setBackgroundColor(AndroidColor.BLACK)
                }
            },
            update = { view ->
                view.player = exoPlayer
                view.resizeMode = resizeOption.mode
                val hideNativeForDelayedEmbedded = externalSubtitleUri == null && subtitleOffsetMs > 0L
                view.subtitleView?.apply {
                    visibility = if (hideNativeForDelayedEmbedded) android.view.View.GONE else android.view.View.VISIBLE
                    val bgAlpha = (settings.subtitleBgOpacity * 255).roundToInt().coerceIn(0, 255)
                    val bgColor = AndroidColor.argb(bgAlpha, 11, 7, 20)
                    setStyle(
                        CaptionStyleCompat(
                            settings.subtitleColorHex.toInt(),
                            bgColor,
                            AndroidColor.TRANSPARENT,
                            CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW,
                            AndroidColor.BLACK,
                            null
                        )
                    )
                    setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, settings.subtitleTextSizeSp)
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .then(pipModifier)
        )

        // Delayed Embedded Subtitle Overlay (when user applies positive sync delay to embedded tracks)
        if (externalSubtitleUri == null && subtitleOffsetMs > 0L && delayedEmbeddedCues.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .systemBarsPadding()
                    .padding(horizontal = 24.dp, vertical = if (showControls) 96.dp else 28.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF0B0714).copy(alpha = settings.subtitleBgOpacity)
                ) {
                    Text(
                        text = delayedEmbeddedCues.joinToString("\n"),
                        color = Color(settings.subtitleColorHex),
                        fontSize = settings.subtitleTextSizeSp.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Gesture Layer: Single-Tap toggle, Double-Tap Seek L/R, Vertical Drag Brightness (L) / Volume (R), Horizontal Seek
        if (!isInPictureInPictureMode && playbackError == null) {
            var dragStartPosMs by remember { mutableLongStateOf(0L) }
            var dragAccumulatedX by remember { mutableFloatStateOf(0f) }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(isLocked, settings, durationMs) {
                        detectTapGestures(
                            onTap = {
                                showControls = !showControls
                                lastInteractionTick = System.currentTimeMillis()
                            },
                            onDoubleTap = { offset: Offset ->
                                if (isLocked || !settings.enableDoubleTapSeek) return@detectTapGestures
                                val jumpSec = 10
                                val isLeft = offset.x < totalWidthPx / 2f
                                val deltaMs = if (isLeft) -jumpSec * 1000L else jumpSec * 1000L
                                seekByDelta(deltaMs)
                                hudFeedback = HudFeedback(
                                    type = if (isLeft) HudOverlayType.DOUBLE_TAP_LEFT else HudOverlayType.DOUBLE_TAP_RIGHT,
                                    label = if (isLeft) "-${jumpSec}s" else "+${jumpSec}s"
                                )
                            }
                        )
                    }
                    .pointerInput(isLocked, settings.enableBrightnessGesture, settings.enableVolumeGesture) {
                        if (isLocked) return@pointerInput
                        var startBrightness = 0.5f
                        var startVolume = 0
                        var maxVolume = 15
                        var isLeftSide = true
                        var accumulatedY = 0f

                        detectVerticalDragGestures(
                            onDragStart = { offset ->
                                isLeftSide = offset.x < totalWidthPx / 2f
                                accumulatedY = 0f
                                if (isLeftSide && settings.enableBrightnessGesture) {
                                    val cur = activity?.window?.attributes?.screenBrightness ?: -1f
                                    startBrightness = if (cur < 0f) readSystemBrightness(context) else cur
                                } else if (!isLeftSide && settings.enableVolumeGesture) {
                                    maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                    startVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                }
                            },
                            onVerticalDrag = { change, dragAmount ->
                                change.consume()
                                accumulatedY -= dragAmount
                                val deltaRatio = accumulatedY / (totalHeightPx * 0.65f)

                                if (isLeftSide && settings.enableBrightnessGesture && activity != null) {
                                    val next = (startBrightness + deltaRatio).coerceIn(0.02f, 1.0f)
                                    val lp = activity.window.attributes
                                    lp.screenBrightness = next
                                    activity.window.attributes = lp
                                    hudFeedback = HudFeedback(
                                        type = HudOverlayType.BRIGHTNESS,
                                        label = "${(next * 100).roundToInt()}%",
                                        progress = next
                                    )
                                } else if (!isLeftSide && settings.enableVolumeGesture) {
                                    val nextVol = (startVolume + deltaRatio * maxVolume)
                                        .roundToInt()
                                        .coerceIn(0, maxVolume)
                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, nextVol, 0)
                                    val pct = nextVol.toFloat() / maxVolume.toFloat()
                                    hudFeedback = HudFeedback(
                                        type = HudOverlayType.VOLUME,
                                        label = "${(pct * 100).roundToInt()}%",
                                        progress = pct
                                    )
                                }
                            }
                        )
                    }
                    .pointerInput(isLocked, durationMs) {
                        if (isLocked) return@pointerInput
                        detectHorizontalDragGestures(
                            onDragStart = {
                                if (durationMs > 0L) {
                                    isScrubbing = true
                                    dragStartPosMs = exoPlayer.currentPosition
                                    dragAccumulatedX = 0f
                                }
                            },
                            onHorizontalDrag = { change, dragAmount ->
                                if (durationMs > 0L) {
                                    change.consume()
                                    dragAccumulatedX += dragAmount
                                    val deltaMs = ((dragAccumulatedX / totalWidthPx) * 90_000f).toLong()
                                    val target = (dragStartPosMs + deltaMs).coerceIn(0L, durationMs)
                                    scrubPreviewMs = target
                                    currentPositionMs = target
                                    val diffSec = (target - dragStartPosMs) / 1000L
                                    val sign = if (diffSec >= 0) "+" else "-"
                                    hudFeedback = HudFeedback(
                                        type = HudOverlayType.SEEK,
                                        label = "${FormatUtils.formatDuration(target)} ($sign${abs(diffSec)}s)"
                                    )
                                }
                            },
                            onDragEnd = {
                                if (isScrubbing) {
                                    exoPlayer.seekTo(scrubPreviewMs)
                                    onSaveProgress(scrubPreviewMs, durationMs)
                                    isScrubbing = false
                                }
                            },
                            onDragCancel = { isScrubbing = false }
                        )
                    }
            )
        }

        // Rich Gesture HUD Feedback (Brightness Bar / Volume Bar / Seek / Directional Double-Tap)
        hudFeedback?.let { feedback ->
            val hudAlignment = when (feedback.type) {
                HudOverlayType.DOUBLE_TAP_LEFT -> Alignment.CenterStart
                HudOverlayType.DOUBLE_TAP_RIGHT -> Alignment.CenterEnd
                else -> Alignment.Center
            }
            val hudPadding = when (feedback.type) {
                HudOverlayType.DOUBLE_TAP_LEFT -> Modifier.padding(start = 40.dp)
                HudOverlayType.DOUBLE_TAP_RIGHT -> Modifier.padding(end = 40.dp)
                else -> Modifier
            }

            AnimatedVisibility(
                visible = !isInPictureInPictureMode,
                enter = fadeIn(tween(120)) + scaleIn(initialScale = 0.92f, animationSpec = tween(120)),
                exit = fadeOut(tween(180)) + scaleOut(targetScale = 0.95f, animationSpec = tween(180)),
                modifier = Modifier
                    .align(hudAlignment)
                    .then(hudPadding)
            ) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color(0xD9130D21),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.7f))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            when (feedback.type) {
                                HudOverlayType.BRIGHTNESS ->
                                    Icon(Icons.Rounded.Brightness6, null, tint = LiquidSilver)
                                HudOverlayType.VOLUME ->
                                    Icon(
                                        if ((feedback.progress ?: 1f) <= 0.01f) {
                                            Icons.AutoMirrored.Rounded.VolumeOff
                                        } else {
                                            Icons.AutoMirrored.Rounded.VolumeUp
                                        },
                                        null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                HudOverlayType.DOUBLE_TAP_LEFT ->
                                    Icon(Icons.Rounded.FastRewind, null, tint = MaterialTheme.colorScheme.primary)
                                HudOverlayType.DOUBLE_TAP_RIGHT ->
                                    Icon(Icons.Rounded.FastForward, null, tint = MaterialTheme.colorScheme.primary)
                                HudOverlayType.SEEK ->
                                    Icon(Icons.Rounded.Speed, null, tint = MaterialTheme.colorScheme.primary)
                            }
                            Text(
                                text = feedback.label,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }

                        feedback.progress?.let { pct ->
                            LinearProgressIndicator(
                                progress = { pct.coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .width(120.dp)
                                    .height(5.dp)
                                    .clip(RoundedCornerShape(50)),
                                color = if (feedback.type == HudOverlayType.BRIGHTNESS) {
                                    LiquidSilver
                                } else {
                                    MaterialTheme.colorScheme.primary
                                },
                                trackColor = Color.White.copy(alpha = 0.2f)
                            )
                        }
                    }
                }
            }
        }

        // Screen Locked Overlay Pill
        if (isLocked && !isInPictureInPictureMode) {
            AnimatedVisibility(
                visible = showControls,
                enter = fadeIn(tween(180)),
                exit = fadeOut(tween(220)),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .systemBarsPadding()
                    .padding(bottom = 28.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xD91B1330),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("player_unlock_pill")
                        .clickable {
                            isLocked = false
                            showControls = true
                            lastInteractionTick = System.currentTimeMillis()
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Rounded.Lock, contentDescription = "Unlock screen", tint = MaterialTheme.colorScheme.primary)
                        Text(
                            text = "Screen Locked • Tap to Unlock",
                            color = Color.White,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }

        // Full Player Controls Overlay
        AnimatedVisibility(
            visible = showControls && !isLocked && !isInPictureInPictureMode && playbackError == null,
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(240)),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xD90B0714),
                                Color.Transparent,
                                Color.Transparent,
                                Color(0xE60B0714)
                            )
                        )
                    )
                    .systemBarsPadding()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                // Top Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            onSaveProgress(exoPlayer.currentPosition, exoPlayer.duration.coerceAtLeast(durationMs))
                            onBack()
                        },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("player_back_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = video.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val syncBadge = if (subtitleOffsetMs != 0L) {
                            val sec = subtitleOffsetMs / 1000f
                            String.format(Locale.US, " • Sync %+.2fs", sec)
                        } else ""
                        Text(
                            text = "${video.formatExtension} • ${formatSpeedLabel(playbackSpeed)}${externalSubtitleName?.let { " • $it" } ?: ""}$syncBadge",
                            style = MaterialTheme.typography.labelSmall,
                            color = LiquidSilver
                        )
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        IconButton(
                            onClick = { triggerPip() },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("player_pip_btn")
                        ) {
                            Icon(Icons.Rounded.PictureInPictureAlt, contentDescription = "Picture in Picture", tint = Color.White)
                        }
                    }

                    IconButton(
                        onClick = { showSubtitleSheet = true },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("player_subtitle_btn")
                    ) {
                        Icon(
                            Icons.Rounded.Subtitles,
                            contentDescription = "Subtitles and synchronization",
                            tint = if (externalSubtitleName != null || subtitleOffsetMs != 0L) {
                                MaterialTheme.colorScheme.primary
                            } else Color.White
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color(0x801B1330),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)),
                        modifier = Modifier
                            .padding(start = 4.dp)
                            .minimumInteractiveComponentSize()
                            .testTag("player_speed_btn")
                            .clickable { showSpeedSheet = true }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Rounded.Speed, contentDescription = "Playback speed", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                            Text(
                                text = formatSpeedLabel(playbackSpeed),
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White
                            )
                        }
                    }
                }

                // Center Play / Pause / Rewind 10s / Forward 10s Cluster
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(28.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            seekByDelta(-10_000L)
                            hudFeedback = HudFeedback(HudOverlayType.DOUBLE_TAP_LEFT, "-10s")
                        },
                        modifier = Modifier
                            .size(58.dp)
                            .testTag("player_rewind_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Replay10,
                            contentDescription = "Rewind 10 seconds",
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.92f),
                        border = BorderStroke(1.5.dp, LiquidSilver.copy(alpha = 0.7f)),
                        modifier = Modifier
                            .size(70.dp)
                            .testTag("player_play_pause_btn")
                            .clickable {
                                if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                                lastInteractionTick = System.currentTimeMillis()
                            }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(40.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            seekByDelta(10_000L)
                            hudFeedback = HudFeedback(HudOverlayType.DOUBLE_TAP_RIGHT, "+10s")
                        },
                        modifier = Modifier
                            .size(58.dp)
                            .testTag("player_forward_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Forward10,
                            contentDescription = "Forward 10 seconds",
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                // Bottom Timeline & Utility Bar
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = FormatUtils.formatDuration(currentPositionMs),
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White,
                            modifier = Modifier.testTag("player_current_time")
                        )
                        Slider(
                            value = if (durationMs > 0L) {
                                (currentPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                            } else 0f,
                            onValueChange = { frac ->
                                isScrubbing = true
                                currentPositionMs = (frac * durationMs).toLong()
                                lastInteractionTick = System.currentTimeMillis()
                            },
                            onValueChangeFinished = {
                                exoPlayer.seekTo(currentPositionMs)
                                onSaveProgress(currentPositionMs, durationMs)
                                isScrubbing = false
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = LiquidSilver,
                                activeTrackColor = MaterialTheme.colorScheme.primary,
                                inactiveTrackColor = Color.White.copy(alpha = 0.28f)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 10.dp)
                                .testTag("player_timeline_slider")
                        )
                        Text(
                            text = FormatUtils.formatDuration(durationMs),
                            style = MaterialTheme.typography.labelMedium,
                            color = LiquidSilver,
                            modifier = Modifier.testTag("player_total_duration")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(
                                onClick = {
                                    isLocked = true
                                    showControls = false
                                    lastInteractionTick = System.currentTimeMillis()
                                },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("player_lock_btn")
                            ) {
                                Icon(Icons.Rounded.LockOpen, contentDescription = "Lock screen controls", tint = Color.White)
                            }
                            IconButton(
                                onClick = { toggleOrientation() },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("player_rotate_btn")
                            ) {
                                Icon(
                                    Icons.Rounded.ScreenRotation,
                                    contentDescription = if (isCurrentlyLandscape) "Switch to portrait" else "Switch to landscape",
                                    tint = if (isCurrentlyLandscape) MaterialTheme.colorScheme.primary else Color.White
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(50),
                            color = Color(0x801B1330),
                            border = BorderStroke(1.dp, LiquidSilver.copy(alpha = 0.35f)),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("player_resize_btn")
                                .clickable {
                                    val all = ResizeOption.entries
                                    resizeOption = all[(resizeOption.ordinal + 1) % all.size]
                                    lastInteractionTick = System.currentTimeMillis()
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Rounded.AspectRatio, null, tint = LiquidSilver, modifier = Modifier.size(16.dp))
                                Text(resizeOption.label, style = MaterialTheme.typography.labelSmall, color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        // Playback Error Overlay
        playbackError?.let { errorMsg ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xEB0B0714))
                    .padding(24.dp)
                    .testTag("player_error_overlay"),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.6f))
                ) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ErrorOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(44.dp)
                        )
                        Text("Playback Error", style = MaterialTheme.typography.titleLarge)
                        Text(
                            text = errorMsg,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(onClick = onBack) {
                                Text("Back")
                            }
                            Button(onClick = {
                                playbackError = null
                                exoPlayer.prepare()
                                exoPlayer.play()
                            }) {
                                Text("Retry")
                            }
                        }
                        TextButton(onClick = {
                            runCatching {
                                val extIntent = Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(Uri.parse(video.uri), video.mimeType.ifBlank { "video/*" })
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(extIntent, "Open video with"))
                            }
                        }) {
                            Text("Open in Another Player")
                        }
                    }
                }
            }
        }
    }

    // Playback Speed Selector Dialog (0.5x, 1x, 1.25x, 1.5x, 2x + fine options)
    if (showSpeedSheet) {
        val speeds = listOf(0.5f, 1.0f, 1.25f, 1.5f, 2.0f)
        @kotlin.OptIn(ExperimentalLayoutApi::class)
        AlertDialog(
            onDismissRequest = { showSpeedSheet = false },
            title = { Text("Playback Speed") },
            text = {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    speeds.forEach { spd ->
                        val selected = abs(playbackSpeed - spd) < 0.01f
                        FilterChip(
                            selected = selected,
                            onClick = {
                                playbackSpeed = spd
                                exoPlayer.setPlaybackSpeed(spd)
                                showSpeedSheet = false
                                lastInteractionTick = System.currentTimeMillis()
                            },
                            label = { Text(formatSpeedLabel(spd)) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSpeedSheet = false }) { Text("Close") }
            }
        )
    }

    // Subtitles Selection & Synchronization Dialog
    if (showSubtitleSheet) {
        val textGroups = currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
        val subtitlesDisabled = exoPlayer.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)

        @kotlin.OptIn(ExperimentalLayoutApi::class)
        AlertDialog(
            onDismissRequest = { showSubtitleSheet = false },
            title = { Text("Subtitles & Sync") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = {
                            showSubtitleSheet = false
                            subtitlePicker.launch(arrayOf("*/*"))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.Subtitles, null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Load Subtitle (.srt / .vtt / .ass)")
                    }

                    if (externalSubtitleName != null) {
                        Text(
                            text = "External: $externalSubtitleName",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    if (textGroups.isEmpty()) {
                        Text(
                            text = "No embedded subtitle tracks in this video.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Text("Subtitle Tracks", style = MaterialTheme.typography.titleSmall)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = subtitlesDisabled,
                                onClick = {
                                    exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                        .buildUpon()
                                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                                        .build()
                                    showSubtitleSheet = false
                                },
                                label = { Text("Off") }
                            )
                            textGroups.forEachIndexed { index, group ->
                                val format = group.getTrackFormat(0)
                                val label = format.label ?: format.language?.uppercase() ?: "Track ${index + 1}"
                                FilterChip(
                                    selected = !subtitlesDisabled && group.isSelected,
                                    onClick = {
                                        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                            .buildUpon()
                                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                            .setOverrideForType(
                                                TrackSelectionOverride(group.mediaTrackGroup, 0)
                                            )
                                            .build()
                                        showSubtitleSheet = false
                                    },
                                    label = { Text(label) }
                                )
                            }
                        }
                    }

                    HorizontalDivider()

                    // Subtitle Timing Synchronization
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Subtitle Sync Offset", style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = String.format(Locale.US, "%+.2fs", subtitleOffsetMs / 1000f),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    val canShiftNegative = externalSubtitleUri != null &&
                        (externalSubtitleName?.endsWith(".srt", true) == true ||
                            externalSubtitleName?.endsWith(".vtt", true) == true)

                    fun applySyncDelta(deltaMs: Long) {
                        val next = (subtitleOffsetMs + deltaMs).coerceIn(-10_000L, 10_000L)
                        val clamped = if (!canShiftNegative) next.coerceAtLeast(0L) else next
                        subtitleOffsetMs = clamped
                        val extUri = externalSubtitleUri
                        val extName = externalSubtitleName
                        if (extUri != null && extName != null) {
                            applyExternalSubtitleWithSync(extUri, extName, clamped)
                        }
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = { applySyncDelta(-500L) },
                            enabled = canShiftNegative || subtitleOffsetMs >= 500L
                        ) { Text("-0.5s") }
                        OutlinedButton(
                            onClick = { applySyncDelta(-250L) },
                            enabled = canShiftNegative || subtitleOffsetMs >= 250L
                        ) { Text("-0.25s") }
                        TextButton(onClick = { applySyncDelta(-subtitleOffsetMs) }) {
                            Text("Reset")
                        }
                        OutlinedButton(onClick = { applySyncDelta(250L) }) {
                            Text("+0.25s")
                        }
                        OutlinedButton(onClick = { applySyncDelta(500L) }) {
                            Text("+0.5s")
                        }
                    }
                    if (!canShiftNegative) {
                        Text(
                            text = "Positive delay (+s) syncs embedded tracks live; load an .srt/.vtt file for both advance (-s) and delay (+s) sync.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSubtitleSheet = false }) { Text("Done") }
            }
        )
    }
}

private fun formatSpeedLabel(speed: Float): String {
    return when {
        abs(speed - 0.5f) < 0.01f -> "0.5x"
        abs(speed - 1.0f) < 0.01f -> "1x"
        abs(speed - 1.25f) < 0.01f -> "1.25x"
        abs(speed - 1.5f) < 0.01f -> "1.5x"
        abs(speed - 2.0f) < 0.01f -> "2x"
        else -> String.format(Locale.US, "%.2fx", speed)
    }
}

private fun readSystemBrightness(context: Context): Float {
    return runCatching {
        val raw = Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        (raw / 255f).coerceIn(0.05f, 1.0f)
    }.getOrDefault(0.5f)
}

private fun Context.findComponentActivity(): ComponentActivity? {
    var current: Context? = this
    while (current is ContextWrapper) {
        if (current is ComponentActivity) return current
        current = current.baseContext
    }
    return null
}

private fun queryDisplayName(context: Context, uri: Uri): String? {
    return runCatching {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) cursor.getString(idx) else null
            } else null
        }
    }.getOrNull()
}

private fun inferSubtitleMimeType(fileName: String): String {
    return when (fileName.substringAfterLast('.', "").lowercase()) {
        "vtt" -> MimeTypes.TEXT_VTT
        "ass", "ssa" -> MimeTypes.TEXT_SSA
        "ttml", "xml" -> MimeTypes.APPLICATION_TTML
        else -> MimeTypes.APPLICATION_SUBRIP
    }
}
