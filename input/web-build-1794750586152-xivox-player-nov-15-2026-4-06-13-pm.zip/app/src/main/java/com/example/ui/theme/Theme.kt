package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.data.model.ThemePreset

private fun obsidianPurpleScheme(accent: Color) = darkColorScheme(
    primary = accent,
    onPrimary = Color(0xFF140724),
    primaryContainer = DeepVioletContainer,
    onPrimaryContainer = SoftLavender,
    secondary = LiquidSilver,
    onSecondary = ObsidianVoid,
    secondaryContainer = VelvetCardHigh,
    onSecondaryContainer = ChromeSilver,
    tertiary = LuminousViolet,
    onTertiary = ObsidianVoid,
    background = ObsidianVoid,
    onBackground = LiquidSilver,
    surface = DeepPlumSurface,
    onSurface = LiquidSilver,
    surfaceVariant = VelvetCard,
    onSurfaceVariant = BrushedSilver,
    surfaceContainerLowest = ObsidianVoid,
    surfaceContainerLow = DeepPlumSurface,
    surfaceContainer = VelvetCard,
    surfaceContainerHigh = VelvetCardHigh,
    surfaceContainerHighest = VelvetCardHighest,
    outline = SlateBorder,
    outlineVariant = SilverHairline,
    error = RoseQuartzError,
    onError = Color.White,
    errorContainer = RoseErrorContainer,
    onErrorContainer = Color(0xFFFFD9E2)
)

private fun amoledMidnightScheme(accent: Color) = darkColorScheme(
    primary = accent,
    onPrimary = Color(0xFF0F041C),
    primaryContainer = DeepVioletContainer,
    onPrimaryContainer = SoftLavender,
    secondary = LiquidSilver,
    onSecondary = AmoledBlack,
    secondaryContainer = AmoledCard,
    onSecondaryContainer = ChromeSilver,
    tertiary = LuminousViolet,
    onTertiary = AmoledBlack,
    background = AmoledBlack,
    onBackground = LiquidSilver,
    surface = AmoledSurface,
    onSurface = LiquidSilver,
    surfaceVariant = AmoledCard,
    onSurfaceVariant = BrushedSilver,
    surfaceContainerLowest = AmoledBlack,
    surfaceContainerLow = AmoledSurface,
    surfaceContainer = AmoledCard,
    surfaceContainerHigh = VelvetCard,
    surfaceContainerHighest = VelvetCardHigh,
    outline = SlateBorder,
    outlineVariant = SilverHairline,
    error = RoseQuartzError,
    onError = Color.White,
    errorContainer = RoseErrorContainer,
    onErrorContainer = Color(0xFFFFD9E2)
)

private fun royalAmethystScheme(accent: Color) = darkColorScheme(
    primary = accent,
    onPrimary = Color(0xFF140724),
    primaryContainer = Color(0xFF5B21B6),
    onPrimaryContainer = SoftLavender,
    secondary = LiquidSilver,
    onSecondary = RoyalIndigo,
    secondaryContainer = RoyalCard,
    onSecondaryContainer = ChromeSilver,
    tertiary = LuminousViolet,
    onTertiary = RoyalIndigo,
    background = RoyalIndigo,
    onBackground = LiquidSilver,
    surface = RoyalSurface,
    onSurface = LiquidSilver,
    surfaceVariant = RoyalCard,
    onSurfaceVariant = BrushedSilver,
    surfaceContainerLowest = RoyalIndigo,
    surfaceContainerLow = RoyalSurface,
    surfaceContainer = RoyalCard,
    surfaceContainerHigh = VelvetCardHigh,
    surfaceContainerHighest = VelvetCardHighest,
    outline = Color(0xFF503E78),
    outlineVariant = SilverHairline,
    error = RoseQuartzError,
    onError = Color.White,
    errorContainer = RoseErrorContainer,
    onErrorContainer = Color(0xFFFFD9E2)
)

val XivoxShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun XivoxPlayerTheme(
    themePreset: ThemePreset = ThemePreset.OBSIDIAN_PURPLE,
    highContrastSilver: Boolean = false,
    content: @Composable () -> Unit
) {
    val accent = if (highContrastSilver) ChromeSilver else ElectricAmethyst
    val colorScheme = when (themePreset) {
        ThemePreset.OBSIDIAN_PURPLE -> obsidianPurpleScheme(accent)
        ThemePreset.AMOLED_MIDNIGHT -> amoledMidnightScheme(accent)
        ThemePreset.ROYAL_AMETHYST -> royalAmethystScheme(accent)
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = XivoxTypography,
        shapes = XivoxShapes,
        content = content
    )
}
