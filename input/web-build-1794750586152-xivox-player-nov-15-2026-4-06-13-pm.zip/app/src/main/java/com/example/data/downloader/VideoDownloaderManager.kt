package com.example.data.downloader

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import com.example.data.local.DownloadTaskDao
import com.example.data.local.DownloadTaskEntity
import com.example.data.model.DownloadStatus
import com.example.data.model.DownloadTask
import com.example.util.FormatUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

class VideoDownloaderManager(
    private val context: Context,
    private val dao: DownloadTaskDao
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val concurrencySemaphore = Semaphore(3)

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val activeCalls = ConcurrentHashMap<String, Call>()
    private val liveSpeeds = MutableStateFlow<Map<String, Long>>(emptyMap())

    val downloadsFlow: Flow<List<DownloadTask>> = combine(
        dao.observeAll(),
        liveSpeeds
    ) { entities, speeds ->
        entities.map { entity ->
            val status = runCatching { DownloadStatus.valueOf(entity.status) }
                .getOrDefault(DownloadStatus.FAILED)
            DownloadTask(
                id = entity.id,
                url = entity.url,
                fileName = entity.fileName,
                destinationFolderLabel = entity.destinationFolderLabel,
                destinationTreeUri = entity.destinationTreeUri,
                localStagingPath = entity.localStagingPath,
                finalUri = entity.finalUri,
                totalBytes = entity.totalBytes,
                downloadedBytes = entity.downloadedBytes,
                speedBytesPerSec = if (status == DownloadStatus.DOWNLOADING) speeds[entity.id] ?: 0L else 0L,
                status = status,
                errorMessage = entity.errorMessage,
                createdAtMs = entity.createdAtMs
            )
        }
    }

    private fun stagingDir(): File {
        return File(context.filesDir, "download_staging").apply { mkdirs() }
    }

    fun enqueueDownload(
        url: String,
        customFileName: String?,
        destinationTreeUri: String?,
        destinationLabel: String
    ): String {
        val cleanUrl = url.trim()
        val id = UUID.randomUUID().toString()
        val resolvedName = customFileName?.trim()?.takeIf { it.isNotBlank() }
            ?: FormatUtils.inferFileNameFromUrl(cleanUrl)
        val safeFileName = resolvedName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val stagingFile = File(stagingDir(), "$id.part")

        val entity = DownloadTaskEntity(
            id = id,
            url = cleanUrl,
            fileName = safeFileName,
            destinationFolderLabel = destinationLabel,
            destinationTreeUri = destinationTreeUri,
            localStagingPath = stagingFile.absolutePath,
            finalUri = null,
            totalBytes = 0L,
            downloadedBytes = 0L,
            status = DownloadStatus.QUEUED.name,
            errorMessage = null,
            createdAtMs = System.currentTimeMillis()
        )

        scope.launch {
            dao.upsert(entity)
            startDownloadJob(id)
        }
        return id
    }

    fun pauseDownload(id: String) {
        activeCalls.remove(id)?.cancel()
        activeJobs.remove(id)?.cancel()
        updateSpeed(id, 0L)
        scope.launch {
            val entity = dao.getById(id) ?: return@launch
            if (entity.status == DownloadStatus.DOWNLOADING.name || entity.status == DownloadStatus.QUEUED.name) {
                val staged = File(entity.localStagingPath)
                dao.upsert(
                    entity.copy(
                        downloadedBytes = if (staged.exists()) staged.length() else entity.downloadedBytes,
                        status = DownloadStatus.PAUSED.name,
                        errorMessage = null
                    )
                )
            }
        }
    }

    fun resumeDownload(id: String) {
        scope.launch {
            val entity = dao.getById(id) ?: return@launch
            if (entity.status == DownloadStatus.PAUSED.name || entity.status == DownloadStatus.FAILED.name) {
                dao.upsert(entity.copy(status = DownloadStatus.QUEUED.name, errorMessage = null))
                startDownloadJob(id)
            }
        }
    }

    fun cancelDownload(id: String) {
        activeCalls.remove(id)?.cancel()
        activeJobs.remove(id)?.cancel()
        updateSpeed(id, 0L)
        scope.launch {
            val entity = dao.getById(id) ?: return@launch
            runCatching { File(entity.localStagingPath).delete() }
            dao.upsert(
                entity.copy(
                    status = DownloadStatus.CANCELLED.name,
                    errorMessage = null
                )
            )
        }
    }

    fun removeTask(id: String) {
        activeCalls.remove(id)?.cancel()
        activeJobs.remove(id)?.cancel()
        updateSpeed(id, 0L)
        scope.launch {
            val entity = dao.getById(id)
            if (entity != null) {
                runCatching { File(entity.localStagingPath).delete() }
                dao.deleteById(id)
            }
        }
    }

    fun clearFinished() {
        scope.launch { dao.clearFinished() }
    }

    private fun startDownloadJob(id: String) {
        if (activeJobs[id]?.isActive == true) return
        val job = scope.launch {
            concurrencySemaphore.withPermit {
                executeDownload(id)
            }
        }
        activeJobs[id] = job
    }

    private suspend fun executeDownload(id: String) {
        val initial = dao.getById(id) ?: return
        val stagingFile = File(initial.localStagingPath)
        val existingBytes = if (stagingFile.exists()) stagingFile.length() else 0L

        dao.upsert(
            initial.copy(
                downloadedBytes = existingBytes,
                status = DownloadStatus.DOWNLOADING.name,
                errorMessage = null
            )
        )

        try {
            val requestBuilder = Request.Builder()
                .url(initial.url)
                .header("User-Agent", "XIVOXPlayer/1.0 (Android)")
            if (existingBytes > 0L) {
                requestBuilder.header("Range", "bytes=$existingBytes-")
            }

            val call = client.newCall(requestBuilder.build())
            activeCalls[id] = call

            call.execute().use { response ->
                if (response.code == 401 || response.code == 403) {
                    throw IllegalStateException("Access denied (HTTP ${response.code}). Login-protected or restricted content is not supported.")
                }
                if (response.code == 416 && existingBytes > 0L) {
                    // Range already satisfied -> finalize file
                    val savedUri = publishCompletedFile(initial, stagingFile)
                    dao.upsert(
                        initial.copy(
                            downloadedBytes = stagingFile.length(),
                            totalBytes = stagingFile.length(),
                            finalUri = savedUri.toString(),
                            status = DownloadStatus.COMPLETED.name,
                            errorMessage = null
                        )
                    )
                    updateSpeed(id, 0L)
                    return
                }
                if (!response.isSuccessful) {
                    throw IllegalStateException("Server returned HTTP ${response.code}")
                }

                val contentType = response.header("Content-Type").orEmpty()
                if (contentType.contains("text/html", ignoreCase = true)) {
                    throw IllegalStateException("URL returned a web page instead of a direct video file.")
                }

                val isPartial = response.code == 206
                val appendMode = isPartial && existingBytes > 0L
                val startOffset = if (appendMode) existingBytes else 0L

                val body = response.body ?: throw IllegalStateException("Empty response body")
                val bodyLength = body.contentLength()
                val totalBytes = when {
                    isPartial && bodyLength > 0L -> startOffset + bodyLength
                    bodyLength > 0L -> bodyLength
                    else -> initial.totalBytes
                }

                var updatedName = initial.fileName
                val disposition = response.header("Content-Disposition")
                if (!disposition.isNullOrBlank()) {
                    val match = Regex("filename=\"?([^\";]+)\"?").find(disposition)
                    val dispName = match?.groupValues?.getOrNull(1)?.trim()
                    if (!dispName.isNullOrBlank()) {
                        updatedName = dispName.replace(Regex("[^A-Za-z0-9._-]"), "_")
                    }
                }

                var downloaded = startOffset
                dao.upsert(
                    initial.copy(
                        fileName = updatedName,
                        totalBytes = totalBytes,
                        downloadedBytes = downloaded,
                        status = DownloadStatus.DOWNLOADING.name
                    )
                )

                val buffer = ByteArray(16 * 1024)
                var lastTickMs = System.currentTimeMillis()
                var bytesSinceTick = 0L

                body.byteStream().use { input ->
                    FileOutputStream(stagingFile, appendMode).use { output ->
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            downloaded += read
                            bytesSinceTick += read

                            val now = System.currentTimeMillis()
                            val elapsed = now - lastTickMs
                            if (elapsed >= 300L) {
                                val speed = (bytesSinceTick * 1000L) / elapsed.coerceAtLeast(1L)
                                updateSpeed(id, speed)
                                dao.upsert(
                                    initial.copy(
                                        fileName = updatedName,
                                        totalBytes = totalBytes,
                                        downloadedBytes = downloaded,
                                        status = DownloadStatus.DOWNLOADING.name
                                    )
                                )
                                lastTickMs = now
                                bytesSinceTick = 0L
                            }
                        }
                        output.flush()
                    }
                }

                updateSpeed(id, 0L)
                val finalSize = stagingFile.length()
                val completedEntity = initial.copy(
                    fileName = updatedName,
                    totalBytes = if (totalBytes > 0L) totalBytes else finalSize,
                    downloadedBytes = finalSize
                )
                val finalUri = publishCompletedFile(completedEntity, stagingFile)
                dao.upsert(
                    completedEntity.copy(
                        finalUri = finalUri.toString(),
                        status = DownloadStatus.COMPLETED.name,
                        errorMessage = null
                    )
                )
            }
        } catch (ce: CancellationException) {
            updateSpeed(id, 0L)
            throw ce
        } catch (ex: Exception) {
            updateSpeed(id, 0L)
            val current = dao.getById(id)
            if (current != null &&
                current.status != DownloadStatus.PAUSED.name &&
                current.status != DownloadStatus.CANCELLED.name
            ) {
                dao.upsert(
                    current.copy(
                        downloadedBytes = if (stagingFile.exists()) stagingFile.length() else current.downloadedBytes,
                        status = DownloadStatus.FAILED.name,
                        errorMessage = ex.message ?: "Download failed"
                    )
                )
            }
        } finally {
            activeCalls.remove(id)
            activeJobs.remove(id)
        }
    }

    private suspend fun publishCompletedFile(entity: DownloadTaskEntity, stagingFile: File): Uri =
        withContext(Dispatchers.IO) {
            val mimeType = inferMimeType(entity.fileName)

            // 1. If user picked a custom SAF folder via OpenDocumentTree, write there
            val treeUriStr = entity.destinationTreeUri
            if (!treeUriStr.isNullOrBlank()) {
                val treeUri = Uri.parse(treeUriStr)
                val folder = DocumentFile.fromTreeUri(context, treeUri)
                if (folder != null && folder.canWrite()) {
                    val created = folder.createFile(mimeType, entity.fileName)
                    if (created != null) {
                        context.contentResolver.openOutputStream(created.uri)?.use { out ->
                            FileInputStream(stagingFile).use { input ->
                                input.copyTo(out, 64 * 1024)
                            }
                        }
                        stagingFile.delete()
                        return@withContext created.uri
                    }
                }
            }

            // 2. Otherwise publish into MediaStore.Video.Media (API 29+) so it shows in Library
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, entity.fileName)
                    put(MediaStore.Video.Media.MIME_TYPE, mimeType)
                    put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/XIVOX Downloads")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val itemUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (itemUri != null) {
                    resolver.openOutputStream(itemUri)?.use { out ->
                        FileInputStream(stagingFile).use { input ->
                            input.copyTo(out, 64 * 1024)
                        }
                    }
                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    resolver.update(itemUri, values, null, null)
                    stagingFile.delete()
                    return@withContext itemUri
                }
            }

            // 3. Fallback to app external Movies directory
            val appMovies = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                ?.apply { mkdirs() } ?: context.filesDir
            val destFile = File(appMovies, entity.fileName)
            stagingFile.copyTo(destFile, overwrite = true)
            stagingFile.delete()
            Uri.fromFile(destFile)
        }

    private fun inferMimeType(fileName: String): String {
        return when (fileName.substringAfterLast('.', "").lowercase()) {
            "mkv" -> "video/x-matroska"
            "webm" -> "video/webm"
            "mov" -> "video/quicktime"
            "3gp" -> "video/3gpp"
            else -> "video/mp4"
        }
    }

    private fun updateSpeed(id: String, bytesPerSec: Long) {
        liveSpeeds.value = liveSpeeds.value.toMutableMap().apply {
            if (bytesPerSec <= 0L) remove(id) else put(id, bytesPerSec)
        }
    }
}
