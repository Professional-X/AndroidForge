package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
data object HomeRoute

@Serializable
data object VideosRoute

@Serializable
data object FoldersRoute

@Serializable
data class FolderDetailRoute(
    val folderId: String,
    val folderName: String
)

@Serializable
data object DownloaderRoute

@Serializable
data object DownloadsRoute

@Serializable
data object SettingsRoute

@Serializable
data object PrivateVaultRoute

@Serializable
data class PlayerRoute(
    val videoUri: String,
    val title: String,
    val folderName: String = "Local",
    val durationMs: Long = 0L,
    val sizeBytes: Long = 0L,
    val mimeType: String = "video/mp4",
    val startPositionMs: Long = 0L
)
