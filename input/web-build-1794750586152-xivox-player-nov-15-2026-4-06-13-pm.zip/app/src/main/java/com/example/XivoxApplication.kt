package com.example

import android.app.Application
import com.example.data.converter.AudioExtractorManager
import com.example.data.downloader.VideoDownloaderManager
import com.example.data.local.XivoxDatabase
import com.example.data.media.DeviceMediaRepository
import com.example.data.prefs.SettingsRepository

class XivoxApplication : Application() {

    lateinit var database: XivoxDatabase
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var mediaRepository: DeviceMediaRepository
        private set

    lateinit var downloaderManager: VideoDownloaderManager
        private set

    lateinit var audioExtractorManager: AudioExtractorManager
        private set

    override fun onCreate() {
        super.onCreate()
        database = XivoxDatabase.getInstance(this)
        settingsRepository = SettingsRepository(this)
        mediaRepository = DeviceMediaRepository(
            context = this,
            historyDao = database.playbackHistoryDao(),
            privateVideoDao = database.privateVideoDao()
        )
        downloaderManager = VideoDownloaderManager(
            context = this,
            dao = database.downloadTaskDao()
        )
        audioExtractorManager = AudioExtractorManager(this)
    }
}
