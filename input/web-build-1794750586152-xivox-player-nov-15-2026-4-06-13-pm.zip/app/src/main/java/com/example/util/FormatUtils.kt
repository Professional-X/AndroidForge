package com.example.util

import android.util.Rational
import java.util.Locale
import kotlin.math.log10
import kotlin.math.pow

object FormatUtils {

    fun formatDuration(durationMs: Long): String {
        if (durationMs <= 0L) return "00:00"
        val totalSeconds = durationMs / 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (log10(bytes.toDouble()) / log10(1024.0)).toInt().coerceIn(0, units.lastIndex)
        val value = bytes / 1024.0.pow(digitGroups.toDouble())
        return if (digitGroups == 0) {
            String.format(Locale.US, "%d %s", bytes, units[0])
        } else {
            String.format(Locale.US, "%.1f %s", value, units[digitGroups])
        }
    }

    fun formatSpeed(bytesPerSec: Long): String {
        if (bytesPerSec <= 0L) return "0 KB/s"
        return "${formatFileSize(bytesPerSec)}/s"
    }

    fun isValidHttpUrl(raw: String): Boolean {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return false
        return (trimmed.startsWith("https://", ignoreCase = true) ||
            trimmed.startsWith("http://", ignoreCase = true)) &&
            trimmed.length > 10 && !trimmed.contains(" ")
    }

    fun inferFileNameFromUrl(url: String, fallbackExt: String = "mp4"): String {
        val cleanUrl = url.substringBefore("?").substringBefore("#").trimEnd('/')
        val segment = cleanUrl.substringAfterLast('/', "").trim()
        val sanitized = segment.replace(Regex("[^A-Za-z0-9._-]"), "_")
        return when {
            sanitized.isBlank() -> "xivox_video_${System.currentTimeMillis()}.$fallbackExt"
            sanitized.contains('.') -> sanitized
            else -> "$sanitized.$fallbackExt"
        }
    }

    /**
     * Android PiP requires aspect ratios strictly within [1/2.39, 2.39].
     * Clamping prevents IllegalArgumentException crashes on ultra-wide or tall videos.
     */
    fun safePipAspectRatio(width: Int, height: Int): Rational {
        if (width <= 0 || height <= 0) return Rational(16, 9)
        val ratio = width.toFloat() / height.toFloat()
        val minRatio = 1f / 2.35f
        val maxRatio = 2.35f
        return when {
            ratio < minRatio -> Rational(100, 235)
            ratio > maxRatio -> Rational(235, 100)
            else -> Rational(width, height)
        }
    }

    fun sortVideos(
        videos: List<com.example.data.model.VideoItem>,
        field: com.example.data.model.SortField,
        order: com.example.data.model.SortOrder
    ): List<com.example.data.model.VideoItem> {
        val comparator = when (field) {
            com.example.data.model.SortField.NAME ->
                compareBy<com.example.data.model.VideoItem> { it.title.lowercase(Locale.ROOT) }
            com.example.data.model.SortField.SIZE ->
                compareBy<com.example.data.model.VideoItem> { it.sizeBytes }
            com.example.data.model.SortField.DATE ->
                compareBy<com.example.data.model.VideoItem> { it.dateAddedSec }
        }
        return if (order == com.example.data.model.SortOrder.ASCENDING) {
            videos.sortedWith(comparator)
        } else {
            videos.sortedWith(comparator.reversed())
        }
    }
}
