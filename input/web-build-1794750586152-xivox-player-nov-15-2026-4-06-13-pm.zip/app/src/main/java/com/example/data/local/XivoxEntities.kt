package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "playback_history")
data class PlaybackHistoryEntity(
    @PrimaryKey val uri: String,
    val title: String,
    val folderName: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val lastPositionMs: Long,
    val lastPlayedAtMs: Long,
    val isFavorite: Boolean = false
)

@Entity(tableName = "private_videos")
data class PrivateVideoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val displayName: String,
    val vaultFilePath: String,
    val originalUri: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val mimeType: String,
    val width: Int,
    val height: Int,
    val addedAtMs: Long
)

@Entity(tableName = "download_tasks")
data class DownloadTaskEntity(
    @PrimaryKey val id: String,
    val url: String,
    val fileName: String,
    val destinationFolderLabel: String,
    val destinationTreeUri: String?,
    val localStagingPath: String,
    val finalUri: String?,
    val totalBytes: Long,
    val downloadedBytes: Long,
    val status: String,
    val errorMessage: String?,
    val createdAtMs: Long
)
