package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricAmethyst
import com.example.ui.theme.LiquidSilver
import com.example.ui.theme.LuminousViolet

@Composable
fun XivoxLogoMark(
    modifier: Modifier = Modifier,
    size: Dp = 36.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Deep obsidian badge base
        drawRoundRect(
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFF28184D), Color(0xFF110A21)),
                start = Offset(0f, 0f),
                end = Offset(w, h)
            ),
            cornerRadius = CornerRadius(w * 0.26f, w * 0.26f)
        )

        // Metallic silver hairline border
        drawRoundRect(
            brush = Brush.linearGradient(
                colors = listOf(LiquidSilver.copy(alpha = 0.7f), ElectricAmethyst.copy(alpha = 0.75f))
            ),
            cornerRadius = CornerRadius(w * 0.26f, w * 0.26f),
            style = Stroke(width = w * 0.045f)
        )

        // Geometric X stroke (silver)
        val pad = w * 0.27f
        val strokeW = w * 0.11f
        drawLine(
            brush = Brush.linearGradient(listOf(LiquidSilver, Color(0xFF94A3B8))),
            start = Offset(pad, pad),
            end = Offset(w - pad, h - pad),
            strokeWidth = strokeW,
            cap = StrokeCap.Round
        )
        drawLine(
            brush = Brush.linearGradient(listOf(LuminousViolet, ElectricAmethyst)),
            start = Offset(w - pad, pad),
            end = Offset(pad, h - pad),
            strokeWidth = strokeW,
            cap = StrokeCap.Round
        )

        // Central luminous play prism
        val playPath = Path().apply {
            moveTo(w * 0.44f, h * 0.34f)
            lineTo(w * 0.69f, h * 0.50f)
            lineTo(w * 0.44f, h * 0.66f)
            close()
        }
        drawPath(
            path = playPath,
            color = Color.White.copy(alpha = 0.94f)
        )
        drawPath(
            path = playPath,
            color = ElectricAmethyst,
            style = Stroke(width = w * 0.03f, join = StrokeJoin.Round)
        )
    }
}

@Composable
fun XivoxBrandLockup(
    modifier: Modifier = Modifier,
    logoSize: Dp = 36.dp,
    showSubtitle: Boolean = false
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        XivoxLogoMark(size = logoSize)
        androidx.compose.foundation.layout.Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "XIVOX",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    ),
                    color = LiquidSilver
                )
                Text(
                    text = " PLAYER",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.5.sp
                    ),
                    color = MaterialTheme.colorScheme.primary
                )
            }
            if (showSubtitle) {
                Text(
                    text = "MEDIA3 ENGINE • DARK SILVER",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
