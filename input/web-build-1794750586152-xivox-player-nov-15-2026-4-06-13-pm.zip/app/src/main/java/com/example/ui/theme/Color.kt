package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Obsidian Purple + Liquid Silver Palette
val ObsidianVoid = Color(0xFF0B0714)
val DeepPlumSurface = Color(0xFF130D21)
val VelvetCard = Color(0xFF1B1330)
val VelvetCardHigh = Color(0xFF261B42)
val VelvetCardHighest = Color(0xFF322456)

// AMOLED Midnight Dark Variant
val AmoledBlack = Color(0xFF030206)
val AmoledSurface = Color(0xFF0D0817)
val AmoledCard = Color(0xFF160F26)

// Royal Amethyst Dark Variant
val RoyalIndigo = Color(0xFF120A26)
val RoyalSurface = Color(0xFF1B1136)
val RoyalCard = Color(0xFF251847)

// Accents — Electric Purple & Brushed Metallic Silver
val ElectricAmethyst = Color(0xFFA855F7)
val LuminousViolet = Color(0xFFC084FC)
val DeepVioletContainer = Color(0xFF4C1D95)
val SoftLavender = Color(0xFFE9D5FF)

val LiquidSilver = Color(0xFFE2E8F0)
val ChromeSilver = Color(0xFFCBD5E1)
val BrushedSilver = Color(0xFF94A3B8)
val SlateBorder = Color(0xFF3E325C)
val SilverHairline = Color(0x2EE2E8F0)

// Semantic Accents
val EmeraldGlow = Color(0xFF10B981)
val AmberGold = Color(0xFFF59E0B)
val RoseQuartzError = Color(0xFFF43F5E)
val RoseErrorContainer = Color(0xFF4C0519)
