package com.example.data.media

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.data.local.PlaybackHistoryDao
import com.example.data.local.PlaybackHistoryEntity
import com.example.data.local.PrivateVideoDao
import com.example.data.local.PrivateVideoEntity
import com.example.data.model.VideoFolder
import com.example.data.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class DeviceMediaRepository(
    private val context: Context,
    private val historyDao: PlaybackHistoryDao,
    private val privateVideoDao: PrivateVideoDao
) {

    fun hasVideoLibraryPermission(): Boolean {
        return when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                val full = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_MEDIA_VIDEO
                ) == PackageManager.PERMISSION_GRANTED
                val partial = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
                    ) == PackageManager.PERMISSION_GRANTED
                } else false
                full || partial
            }
            else -> {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
            }
        }
    }

    fun observeMediaStoreChanges(): Flow<Unit> = callbackFlow {
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                trySend(Unit)
            }
        }
        context.contentResolver.registerContentObserver(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            true,
            observer
        )
        trySend(Unit)
        awaitClose {
            context.contentResolver.unregisterContentObserver(observer)
        }
    }

    suspend fun queryDeviceVideos(): List<VideoItem> = withContext(Dispatchers.IO) {
        if (!hasVideoLibraryPermission()) return@withContext emptyList()

        val result = mutableListOf<VideoItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.BUCKET_ID,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )

        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        runCatching {
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                val widthCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val heightCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                val bucketIdCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_ID)
                val bucketNameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val displayName = cursor.getString(nameCol) ?: "video_$id.mp4"
                    val rawTitle = cursor.getString(titleCol)
                    val title = if (!rawTitle.isNullOrBlank()) rawTitle else displayName.substringBeforeLast('.')
                    val duration = cursor.getLong(durCol).coerceAtLeast(0L)
                    val size = cursor.getLong(sizeCol).coerceAtLeast(0L)
                    val dateAdded = cursor.getLong(dateCol).coerceAtLeast(0L)
                    val mime = cursor.getString(mimeCol) ?: "video/mp4"
                    val width = cursor.getInt(widthCol).coerceAtLeast(0)
                    val height = cursor.getInt(heightCol).coerceAtLeast(0)
                    val bucketId = cursor.getString(bucketIdCol) ?: "internal"
                    val bucketName = cursor.getString(bucketNameCol) ?: "Internal Storage"

                    result.add(
                        VideoItem(
                            id = id,
                            uri = contentUri.toString(),
                            title = title,
                            displayName = displayName,
                            folderName = bucketName,
                            folderId = bucketId,
                            durationMs = duration,
                            sizeBytes = size,
                            dateAddedSec = dateAdded,
                            mimeType = mime,
                            width = width,
                            height = height
                        )
                    )
                }
            }
        }
        result
    }

    fun groupIntoFolders(videos: List<VideoItem>): List<VideoFolder> {
        return videos.groupBy { it.folderId to it.folderName }
            .map { (key, list) ->
                VideoFolder(
                    id = key.first,
                    name = key.second,
                    videoCount = list.size,
                    totalSizeBytes = list.sumOf { it.sizeBytes },
                    latestTimestampSec = list.maxOfOrNull { it.dateAddedSec } ?: 0L,
                    thumbnailUri = list.firstOrNull()?.uri
                )
            }
            .sortedByDescending { it.latestTimestampSec }
    }

    suspend fun resolveVideoFromUri(uri: Uri): VideoItem = withContext(Dispatchers.IO) {
        var displayName = "External Video"
        var sizeBytes = 0L
        runCatching {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex >= 0) displayName = cursor.getString(nameIndex) ?: displayName
                    if (sizeIndex >= 0) sizeBytes = cursor.getLong(sizeIndex)
                }
            }
        }
        var durationMs = 0L
        var width = 0
        var height = 0
        val retriever = MediaMetadataRetriever()
        runCatching {
            retriever.setDataSource(context, uri)
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        }
        runCatching { retriever.release() }

        val mimeType = context.contentResolver.getType(uri) ?: "video/mp4"
        val title = displayName.substringBeforeLast('.').ifBlank { displayName }
        val existingHistory = historyDao.getByUri(uri.toString())

        VideoItem(
            id = uri.toString().hashCode().toLong(),
            uri = uri.toString(),
            title = title,
            displayName = displayName,
            folderName = "External",
            folderId = "external",
            durationMs = durationMs,
            sizeBytes = sizeBytes,
            dateAddedSec = System.currentTimeMillis() / 1000L,
            mimeType = mimeType,
            width = width,
            height = height,
            lastPositionMs = existingHistory?.lastPositionMs ?: 0L,
            lastPlayedAtMs = existingHistory?.lastPlayedAtMs ?: 0L,
            isFavorite = existingHistory?.isFavorite ?: false
        )
    }

    fun observeHistory(): Flow<Map<String, PlaybackHistoryEntity>> =
        historyDao.observeAll().map { list -> list.associateBy { it.uri } }

    fun observeRecentlyPlayed(): Flow<List<PlaybackHistoryEntity>> =
        historyDao.observeRecentlyPlayed()

    fun observeFavorites(): Flow<List<PlaybackHistoryEntity>> =
        historyDao.observeFavorites()

    suspend fun savePlaybackPosition(video: VideoItem, positionMs: Long, durationMs: Long) {
        val existing = historyDao.getByUri(video.uri)
        val effectiveDuration = if (durationMs > 0L) durationMs else video.durationMs
        val clampedPos = if (effectiveDuration > 0L && positionMs >= effectiveDuration - 1500L) {
            0L // Completed: reset resume position to start
        } else {
            positionMs.coerceAtLeast(0L)
        }
        historyDao.upsert(
            PlaybackHistoryEntity(
                uri = video.uri,
                title = video.title,
                folderName = video.folderName,
                durationMs = effectiveDuration,
                sizeBytes = video.sizeBytes,
                lastPositionMs = clampedPos,
                lastPlayedAtMs = System.currentTimeMillis(),
                isFavorite = existing?.isFavorite ?: video.isFavorite
            )
        )
    }

    suspend fun toggleFavorite(video: VideoItem) {
        val existing = historyDao.getByUri(video.uri)
        if (existing != null) {
            historyDao.setFavorite(video.uri, !existing.isFavorite)
        } else {
            historyDao.upsert(
                PlaybackHistoryEntity(
                    uri = video.uri,
                    title = video.title,
                    folderName = video.folderName,
                    durationMs = video.durationMs,
                    sizeBytes = video.sizeBytes,
                    lastPositionMs = video.lastPositionMs,
                    lastPlayedAtMs = video.lastPlayedAtMs,
                    isFavorite = true
                )
            )
        }
    }

    suspend fun clearHistory() = historyDao.clearHistory()

    fun observePrivateVideos(): Flow<List<VideoItem>> =
        privateVideoDao.observeAll().map { entities ->
            entities.map { entity ->
                val fileUri = Uri.fromFile(File(entity.vaultFilePath)).toString()
                VideoItem(
                    id = -entity.id,
                    uri = fileUri,
                    title = entity.title,
                    displayName = entity.displayName,
                    folderName = "Private Vault",
                    folderId = "private_vault",
                    durationMs = entity.durationMs,
                    sizeBytes = entity.sizeBytes,
                    dateAddedSec = entity.addedAtMs / 1000L,
                    mimeType = entity.mimeType,
                    width = entity.width,
                    height = entity.height,
                    isPrivate = true
                )
            }
        }

    suspend fun importToPrivateVault(sourceUri: Uri): Result<VideoItem> = withContext(Dispatchers.IO) {
        runCatching {
            val resolved = resolveVideoFromUri(sourceUri)
            val vaultDir = File(context.filesDir, "private_vault").apply { mkdirs() }
            val safeName = resolved.displayName.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val targetFile = File(vaultDir, "${System.currentTimeMillis()}_$safeName")

            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output, bufferSize = 64 * 1024)
                }
            } ?: throw IllegalStateException("Unable to read selected video")

            val entity = PrivateVideoEntity(
                title = resolved.title,
                displayName = resolved.displayName,
                vaultFilePath = targetFile.absolutePath,
                originalUri = sourceUri.toString(),
                durationMs = resolved.durationMs,
                sizeBytes = targetFile.length(),
                mimeType = resolved.mimeType,
                width = resolved.width,
                height = resolved.height,
                addedAtMs = System.currentTimeMillis()
            )
            val rowId = privateVideoDao.insert(entity)
            resolved.copy(
                id = -rowId,
                uri = Uri.fromFile(targetFile).toString(),
                sizeBytes = targetFile.length(),
                folderName = "Private Vault",
                folderId = "private_vault",
                isPrivate = true
            )
        }
    }

    suspend fun deleteFromPrivateVault(negativeId: Long) = withContext(Dispatchers.IO) {
        val id = kotlin.math.abs(negativeId)
        val entity = privateVideoDao.getById(id) ?: return@withContext
        runCatching { File(entity.vaultFilePath).delete() }
        privateVideoDao.deleteById(id)
    }

    fun buildShareIntent(uriString: String, title: String, mimeType: String = "video/*"): Intent {
        val parsed = Uri.parse(uriString)
        val shareUri = if (parsed.scheme == "file" && parsed.path != null) {
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                File(parsed.path!!)
            )
        } else {
            parsed
        }
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType.ifBlank { "video/*" }
            putExtra(Intent.EXTRA_STREAM, shareUri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(sendIntent, "Share \"$title\"").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
}
