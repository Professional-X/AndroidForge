package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaybackHistoryDao {
    @Query("SELECT * FROM playback_history ORDER BY lastPlayedAtMs DESC")
    fun observeAll(): Flow<List<PlaybackHistoryEntity>>

    @Query("SELECT * FROM playback_history WHERE lastPlayedAtMs > 0 ORDER BY lastPlayedAtMs DESC LIMIT 20")
    fun observeRecentlyPlayed(): Flow<List<PlaybackHistoryEntity>>

    @Query("SELECT * FROM playback_history WHERE isFavorite = 1 ORDER BY lastPlayedAtMs DESC, title ASC")
    fun observeFavorites(): Flow<List<PlaybackHistoryEntity>>

    @Query("SELECT * FROM playback_history WHERE uri = :uri LIMIT 1")
    suspend fun getByUri(uri: String): PlaybackHistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: PlaybackHistoryEntity)

    @Query("UPDATE playback_history SET lastPositionMs = :positionMs, lastPlayedAtMs = :playedAtMs WHERE uri = :uri")
    suspend fun updatePosition(uri: String, positionMs: Long, playedAtMs: Long)

    @Query("UPDATE playback_history SET isFavorite = :isFavorite WHERE uri = :uri")
    suspend fun setFavorite(uri: String, isFavorite: Boolean)

    @Query("DELETE FROM playback_history WHERE lastPositionMs >= 0")
    suspend fun clearHistory()
}

@Dao
interface PrivateVideoDao {
    @Query("SELECT * FROM private_videos ORDER BY addedAtMs DESC")
    fun observeAll(): Flow<List<PrivateVideoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: PrivateVideoEntity): Long

    @Query("DELETE FROM private_videos WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM private_videos WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): PrivateVideoEntity?
}

@Dao
interface DownloadTaskDao {
    @Query("SELECT * FROM download_tasks ORDER BY createdAtMs DESC")
    fun observeAll(): Flow<List<DownloadTaskEntity>>

    @Query("SELECT * FROM download_tasks WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): DownloadTaskEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: DownloadTaskEntity)

    @Query("DELETE FROM download_tasks WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM download_tasks WHERE status IN ('COMPLETED', 'CANCELLED', 'FAILED')")
    suspend fun clearFinished()
}
