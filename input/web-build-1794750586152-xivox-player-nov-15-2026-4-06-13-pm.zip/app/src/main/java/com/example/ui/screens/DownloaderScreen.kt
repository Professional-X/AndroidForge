package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AppSettings
import com.example.data.model.DownloadStatus
import com.example.data.model.DownloadTask
import com.example.util.FormatUtils

@Composable
fun DownloaderScreen(
    settings: AppSettings,
    downloads: List<DownloadTask>,
    onPickDownloadFolder: () -> Unit,
    onStartDownload: (url: String, fileName: String?) -> Boolean,
    onPauseDownload: (String) -> Unit,
    onResumeDownload: (String) -> Unit,
    onCancelDownload: (String) -> Unit,
    onPlayCompleted: (DownloadTask) -> Unit,
    onOpenDownloadsTab: () -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboard = LocalClipboardManager.current
    var urlInput by remember { mutableStateOf("") }
    var fileNameInput by remember { mutableStateOf("") }
    var urlError by remember { mutableStateOf<String?>(null) }

    val activeTasks = downloads.filter {
        it.status == DownloadStatus.DOWNLOADING ||
            it.status == DownloadStatus.QUEUED ||
            it.status == DownloadStatus.PAUSED
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("downloader_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Video Downloader",
                    style = MaterialTheme.typography.headlineMedium
                )
                Text(
                    text = "Direct HTTP/HTTPS streams with pause, resume & speed telemetry",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Compliance Notice
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VerifiedUser,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = stringResource(R.string.downloader_compliance_notice),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // URL Form Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = {
                            urlInput = it
                            urlError = null
                        },
                        label = { Text("Direct Video URL (.mp4, .mkv, .webm)") },
                        placeholder = { Text("https://example.com/media/video.mp4") },
                        leadingIcon = { Icon(Icons.Rounded.Link, contentDescription = null) },
                        trailingIcon = {
                            Row {
                                if (urlInput.isNotEmpty()) {
                                    IconButton(onClick = { urlInput = "" }) {
                                        Icon(Icons.Rounded.Close, contentDescription = "Clear URL")
                                    }
                                }
                                IconButton(
                                    onClick = {
                                        val clipText = clipboard.getText()?.text?.trim()
                                        if (!clipText.isNullOrBlank()) {
                                            urlInput = clipText
                                            urlError = null
                                        }
                                    }
                                ) {
                                    Icon(Icons.Rounded.ContentPaste, contentDescription = "Paste URL")
                                }
                            }
                        },
                        isError = urlError != null,
                        supportingText = urlError?.let { { Text(it) } },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("downloader_url_input")
                    )

                    OutlinedTextField(
                        value = fileNameInput,
                        onValueChange = { fileNameInput = it },
                        label = { Text("Custom File Name (Optional)") },
                        placeholder = { Text("Auto-detected from URL") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("downloader_filename_input")
                    )

                    // Destination Folder Picker
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.FolderOpen,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Save Location",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = settings.downloadFolderLabel,
                                    style = MaterialTheme.typography.titleSmall
                                )
                            }
                            OutlinedButton(
                                onClick = onPickDownloadFolder,
                                modifier = Modifier.testTag("select_download_folder_btn")
                            ) {
                                Text("Change")
                            }
                        }
                    }

                    Button(
                        onClick = {
                            if (!FormatUtils.isValidHttpUrl(urlInput)) {
                                urlError = "Please enter a valid http:// or https:// direct video URL"
                            } else {
                                val started = onStartDownload(
                                    urlInput.trim(),
                                    fileNameInput.trim().ifBlank { null }
                                )
                                if (started) {
                                    urlInput = ""
                                    fileNameInput = ""
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("start_download_btn"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Rounded.CloudDownload, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Start Download")
                    }
                }
            }
        }

        // Active Queue Preview
        if (activeTasks.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Active Queue (${activeTasks.size})",
                        style = MaterialTheme.typography.titleLarge
                    )
                    TextButton(onClick = onOpenDownloadsTab) {
                        Text("Manage All")
                    }
                }
            }

            items(activeTasks, key = { it.id }) { task ->
                DownloadTaskCard(
                    task = task,
                    onPause = { onPauseDownload(task.id) },
                    onResume = { onResumeDownload(task.id) },
                    onCancel = { onCancelDownload(task.id) },
                    onRemove = { onCancelDownload(task.id) },
                    onPlay = { onPlayCompleted(task) },
                    onShare = {}
                )
            }
        }
    }
}
