package com.example.data.converter

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodecList
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.example.data.model.AudioExtractionJob
import com.example.data.model.ExtractionStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileInputStream
import java.util.UUID

class AudioExtractorManager(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val _jobState = MutableStateFlow<AudioExtractionJob?>(null)
    val jobState: StateFlow<AudioExtractionJob?> = _jobState.asStateFlow()

    private var activeTransformer: Transformer? = null
    private var progressRunnable: Runnable? = null

    fun hasNativeMp3Encoder(): Boolean {
        return runCatching {
            val list = MediaCodecList(MediaCodecList.REGULAR_CODECS)
            list.codecInfos.any { info ->
                info.isEncoder && info.supportedTypes.any { it.equals(MimeTypes.AUDIO_MPEG, ignoreCase = true) }
            }
        }.getOrDefault(false)
    }

    @OptIn(UnstableApi::class)
    fun extractAudio(sourceUri: String, sourceTitle: String) {
        cancel()

        val jobId = UUID.randomUUID().toString()
        val safeTitle = sourceTitle.replace(Regex("[^A-Za-z0-9._-]"), "_").take(50)
        val tempOutFile = File(context.cacheDir, "${safeTitle}_${System.currentTimeMillis()}.m4a")
        val formatDesc = if (hasNativeMp3Encoder()) "MP3 / AAC (.m4a)" else "AAC Audio (.m4a)"

        _jobState.value = AudioExtractionJob(
            id = jobId,
            sourceTitle = sourceTitle,
            progress = 0f,
            status = ExtractionStatus.EXTRACTING,
            formatLabel = formatDesc
        )

        mainHandler.post {
            try {
                val inputItem = MediaItem.fromUri(Uri.parse(sourceUri))
                val editedItem = EditedMediaItem.Builder(inputItem)
                    .setRemoveVideo(true)
                    .build()

                val transformer = Transformer.Builder(context)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            stopProgressPolling()
                            val savedUri = publishAudioToMusicFolder(tempOutFile, "$safeTitle.m4a")
                            _jobState.value = _jobState.value?.copy(
                                progress = 1f,
                                status = ExtractionStatus.COMPLETED,
                                outputPath = tempOutFile.absolutePath,
                                outputUri = savedUri.toString(),
                                errorMessage = null
                            )
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: ExportResult,
                            exportException: ExportException
                        ) {
                            stopProgressPolling()
                            runCatching { tempOutFile.delete() }
                            _jobState.value = _jobState.value?.copy(
                                status = ExtractionStatus.FAILED,
                                errorMessage = exportException.message
                                    ?: "Audio track could not be extracted from this video format."
                            )
                        }
                    })
                    .build()

                activeTransformer = transformer
                transformer.start(editedItem, tempOutFile.absolutePath)
                startProgressPolling(transformer)
            } catch (ex: Exception) {
                stopProgressPolling()
                _jobState.value = _jobState.value?.copy(
                    status = ExtractionStatus.FAILED,
                    errorMessage = ex.message ?: "Unable to start audio extraction"
                )
            }
        }
    }

    @OptIn(UnstableApi::class)
    private fun startProgressPolling(transformer: Transformer) {
        val holder = ProgressHolder()
        val runnable = object : Runnable {
            override fun run() {
                val state = transformer.getProgress(holder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    _jobState.value = _jobState.value?.copy(
                        progress = (holder.progress / 100f).coerceIn(0f, 0.99f)
                    )
                }
                if (state != Transformer.PROGRESS_STATE_NOT_STARTED) {
                    mainHandler.postDelayed(this, 250L)
                }
            }
        }
        progressRunnable = runnable
        mainHandler.postDelayed(runnable, 250L)
    }

    private fun stopProgressPolling() {
        progressRunnable?.let { mainHandler.removeCallbacks(it) }
        progressRunnable = null
    }

    @OptIn(UnstableApi::class)
    fun cancel() {
        stopProgressPolling()
        mainHandler.post {
            runCatching { activeTransformer?.cancel() }
            activeTransformer = null
        }
        _jobState.value = null
    }

    fun dismiss() {
        _jobState.value = null
    }

    private fun publishAudioToMusicFolder(tempFile: File, displayName: String): Uri {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                put(MediaStore.Audio.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MUSIC}/XIVOX Audio")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                runCatching {
                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(tempFile).use { input ->
                            input.copyTo(out, 64 * 1024)
                        }
                    }
                    values.clear()
                    values.put(MediaStore.Audio.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                }.onSuccess {
                    return uri
                }
            }
        }
        val musicDir = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)?.apply { mkdirs() }
            ?: context.filesDir
        val outFile = File(musicDir, displayName)
        tempFile.copyTo(outFile, overwrite = true)
        return Uri.fromFile(outFile)
    }
}
