package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.VideoItem
import com.example.ui.components.VideoListCard

@Composable
fun PrivateVaultScreen(
    hasPin: Boolean,
    isUnlocked: Boolean,
    vaultError: String?,
    privateVideos: List<VideoItem>,
    onBack: () -> Unit,
    onCreatePin: (String) -> Unit,
    onUnlock: (String) -> Unit,
    onLock: () -> Unit,
    onClearError: () -> Unit,
    onImportToVault: () -> Unit,
    onPlayVideo: (VideoItem) -> Unit,
    onExtractAudio: (VideoItem) -> Unit,
    onShareVideo: (VideoItem) -> Unit,
    onDeleteFromVault: (VideoItem) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onLock()
        onBack()
    }

    if (!isUnlocked) {
        var pinInput by remember { mutableStateOf("") }
        var confirmPinInput by remember { mutableStateOf("") }
        var localError by remember { mutableStateOf<String?>(null) }

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
                .testTag("vault_lock_screen")
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
            }

            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(44.dp)
                        )
                        Text(
                            text = if (hasPin) "Private Vault Locked" else "Create Vault PIN",
                            style = MaterialTheme.typography.headlineMedium,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = if (hasPin) {
                                "Enter your 4–6 digit PIN to view secured videos stored privately inside XIVOX."
                            } else {
                                "Set a 4–6 digit PIN to isolate private videos from your public device gallery."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )

                        OutlinedTextField(
                            value = pinInput,
                            onValueChange = { value ->
                                if (value.length <= 6 && value.all { it.isDigit() }) {
                                    pinInput = value
                                    localError = null
                                    onClearError()
                                }
                            },
                            label = { Text(if (hasPin) "Enter PIN" else "New PIN (4–6 digits)") },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("vault_pin_input")
                        )

                        if (!hasPin) {
                            OutlinedTextField(
                                value = confirmPinInput,
                                onValueChange = { value ->
                                    if (value.length <= 6 && value.all { it.isDigit() }) {
                                        confirmPinInput = value
                                        localError = null
                                    }
                                },
                                label = { Text("Confirm PIN") },
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("vault_confirm_pin_input")
                            )
                        }

                        val displayedError = localError ?: vaultError
                        if (!displayedError.isNullOrBlank()) {
                            Text(
                                text = displayedError,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }

                        Button(
                            onClick = {
                                if (hasPin) {
                                    onUnlock(pinInput)
                                } else {
                                    when {
                                        pinInput.length < 4 -> localError = "PIN must be at least 4 digits"
                                        pinInput != confirmPinInput -> localError = "PINs do not match"
                                        else -> onCreatePin(pinInput)
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("vault_unlock_btn")
                        ) {
                            Icon(Icons.Rounded.LockOpen, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (hasPin) "Unlock Vault" else "Create & Open Vault")
                        }
                    }
                }
            }
        }
    } else {
        Scaffold(
            modifier = modifier.testTag("vault_unlocked_screen"),
            floatingActionButton = {
                FloatingActionButton(
                    onClick = onImportToVault,
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("vault_import_fab")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = "Import video to Private Vault")
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        onLock()
                        onBack()
                    }) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Private Vault", style = MaterialTheme.typography.titleLarge)
                        Text(
                            text = "${privateVideos.size} secured videos",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    OutlinedButton(
                        onClick = onLock,
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Icon(Icons.Rounded.Lock, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Lock")
                    }
                }

                if (privateVideos.isEmpty()) {
                    EmptyLibraryState(
                        title = "Private Vault is Empty",
                        subtitle = "Import videos from your device or choose 'Move to Private Vault' from any library video menu.",
                        primaryLabel = "Import Video",
                        onPrimary = onImportToVault
                    )
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(privateVideos, key = { it.uri }) { video ->
                            VideoListCard(
                                video = video,
                                onPlay = { onPlayVideo(video) },
                                onToggleFavorite = {},
                                onExtractAudio = { onExtractAudio(video) },
                                onShare = { onShareVideo(video) },
                                onRemoveFromVault = { onDeleteFromVault(video) }
                            )
                        }
                    }
                }
            }
        }
    }
}
