package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.model.AudioExtractionJob
import com.example.data.model.ExtractionStatus
import com.example.ui.theme.EmeraldGlow
import kotlin.math.roundToInt

@Composable
fun AudioExtractionDialog(
    job: AudioExtractionJob,
    onCancel: () -> Unit,
    onDismiss: () -> Unit,
    onShareAudio: (uri: String, title: String) -> Unit
) {
    AlertDialog(
        onDismissRequest = {
            if (job.status != ExtractionStatus.EXTRACTING) onDismiss()
        },
        icon = {
            Icon(
                imageVector = when (job.status) {
                    ExtractionStatus.COMPLETED -> Icons.Rounded.CheckCircle
                    ExtractionStatus.FAILED -> Icons.Rounded.ErrorOutline
                    else -> Icons.Rounded.AudioFile
                },
                contentDescription = null,
                tint = when (job.status) {
                    ExtractionStatus.COMPLETED -> EmeraldGlow
                    ExtractionStatus.FAILED -> MaterialTheme.colorScheme.error
                    else -> MaterialTheme.colorScheme.primary
                },
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text(
                text = when (job.status) {
                    ExtractionStatus.EXTRACTING -> "Extracting Audio"
                    ExtractionStatus.COMPLETED -> "Audio Extracted"
                    ExtractionStatus.FAILED -> "Extraction Failed"
                    ExtractionStatus.IDLE -> "Audio Extractor"
                }
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = job.sourceTitle,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Output: ${job.formatLabel} • Music/XIVOX Audio",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                when (job.status) {
                    ExtractionStatus.EXTRACTING -> {
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { job.progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Media3 Transformer active",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${(job.progress * 100).roundToInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    ExtractionStatus.COMPLETED -> {
                        Text(
                            text = "Saved cleanly to your Music/XIVOX Audio folder.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = EmeraldGlow
                        )
                    }
                    ExtractionStatus.FAILED -> {
                        Text(
                            text = job.errorMessage ?: "This video's audio codec is unsupported for extraction.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    ExtractionStatus.IDLE -> Unit
                }
            }
        },
        confirmButton = {
            when (job.status) {
                ExtractionStatus.EXTRACTING -> {
                    TextButton(onClick = onCancel) {
                        Text("Cancel")
                    }
                }
                ExtractionStatus.COMPLETED -> {
                    Row {
                        val outUri = job.outputUri
                        if (!outUri.isNullOrBlank()) {
                            OutlinedButton(
                                onClick = { onShareAudio(outUri, job.sourceTitle) }
                            ) {
                                Icon(Icons.Rounded.Share, null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Share")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Button(onClick = onDismiss) {
                            Text("Done")
                        }
                    }
                }
                else -> {
                    Button(onClick = onDismiss) {
                        Text("Close")
                    }
                }
            }
        }
    )
}
