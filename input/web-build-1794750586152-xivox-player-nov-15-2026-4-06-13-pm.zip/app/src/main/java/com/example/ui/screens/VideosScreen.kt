package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.SortField
import com.example.data.model.SortOrder
import com.example.data.model.VideoItem
import com.example.ui.LibraryUiState
import com.example.ui.components.VideoGridCard
import com.example.ui.components.VideoListCard

@Composable
fun VideosScreen(
    uiState: LibraryUiState,
    onSearchChange: (String) -> Unit,
    onSortFieldSelect: (SortField) -> Unit,
    onToggleSortOrder: () -> Unit,
    onToggleGridLayout: () -> Unit,
    onRefresh: () -> Unit,
    onRequestPermission: () -> Unit,
    onPickSafVideo: () -> Unit,
    onPlayVideo: (VideoItem) -> Unit,
    onToggleFavorite: (VideoItem) -> Unit,
    onExtractAudio: (VideoItem) -> Unit,
    onShareVideo: (VideoItem) -> Unit,
    onMoveToVault: (VideoItem) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("videos_screen")
    ) {
        // Header + Actions
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Video Library",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "${uiState.filteredVideos.size} items ready",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onPickSafVideo,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("videos_saf_pick_btn")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.FolderOpen,
                        contentDescription = "Open video via Storage Access Framework",
                        tint = MaterialTheme.colorScheme.secondary
                    )
                }
                IconButton(
                    onClick = onToggleGridLayout,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("videos_layout_toggle_btn")
                ) {
                    Icon(
                        imageVector = if (uiState.isGridLayout) Icons.Rounded.ViewList else Icons.Rounded.GridView,
                        contentDescription = "Toggle Grid or List view",
                        tint = MaterialTheme.colorScheme.secondary
                    )
                }
                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = "Rescan videos",
                        tint = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }

        // Search Bar
        OutlinedTextField(
            value = uiState.searchQuery,
            onValueChange = onSearchChange,
            placeholder = { Text("Search videos or folders...") },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
            trailingIcon = {
                if (uiState.searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Clear search")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("videos_search_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Sort Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SortField.entries.forEach { field ->
                val selected = uiState.sortField == field
                FilterChip(
                    selected = selected,
                    onClick = { onSortFieldSelect(field) },
                    label = { Text(field.label) },
                    trailingIcon = if (selected) {
                        {
                            Icon(
                                imageVector = if (uiState.sortOrder == SortOrder.ASCENDING) {
                                    Icons.Rounded.ArrowUpward
                                } else {
                                    Icons.Rounded.ArrowDownward
                                },
                                contentDescription = uiState.sortOrder.label,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    } else null,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                    ),
                    modifier = Modifier.testTag("sort_chip_${field.name.lowercase()}")
                )
            }
            Spacer(modifier = Modifier.weight(1f))
            IconButton(
                onClick = onToggleSortOrder,
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = if (uiState.sortOrder == SortOrder.ASCENDING) {
                        Icons.Rounded.ArrowUpward
                    } else {
                        Icons.Rounded.ArrowDownward
                    },
                    contentDescription = "Toggle sort direction",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        when {
            uiState.isLoading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            !uiState.hasPermission && uiState.filteredVideos.isEmpty() -> {
                EmptyLibraryState(
                    title = "Media Permission Required",
                    subtitle = "Grant video access so XIVOX can organize your local MP4, MKV, and WebM files, or open any video directly using Storage Access Framework.",
                    primaryLabel = "Grant Video Access",
                    onPrimary = onRequestPermission,
                    secondaryLabel = "Open via SAF",
                    onSecondary = onPickSafVideo
                )
            }
            uiState.filteredVideos.isEmpty() -> {
                EmptyLibraryState(
                    title = if (uiState.searchQuery.isNotBlank()) "No Matching Videos" else "No Videos Found on Device",
                    subtitle = if (uiState.searchQuery.isNotBlank()) {
                        "Try clearing your search filter or rescanning device storage."
                    } else {
                        "Add videos to your device, download one via URL, or open a video file via SAF."
                    },
                    primaryLabel = if (uiState.searchQuery.isNotBlank()) "Clear Search" else "Open Video (SAF)",
                    onPrimary = {
                        if (uiState.searchQuery.isNotBlank()) onSearchChange("") else onPickSafVideo()
                    },
                    secondaryLabel = "Rescan",
                    onSecondary = onRefresh
                )
            }
            uiState.isGridLayout -> {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 165.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(uiState.filteredVideos, key = { it.uri }) { video ->
                        VideoGridCard(
                            video = video,
                            onPlay = { onPlayVideo(video) },
                            onToggleFavorite = { onToggleFavorite(video) }
                        )
                    }
                }
            }
            else -> {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(uiState.filteredVideos, key = { it.uri }) { video ->
                        VideoListCard(
                            video = video,
                            onPlay = { onPlayVideo(video) },
                            onToggleFavorite = { onToggleFavorite(video) },
                            onExtractAudio = { onExtractAudio(video) },
                            onShare = { onShareVideo(video) },
                            onMoveToVault = { onMoveToVault(video) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyLibraryState(
    title: String,
    subtitle: String,
    primaryLabel: String,
    onPrimary: () -> Unit,
    secondaryLabel: String? = null,
    onSecondary: (() -> Unit)? = null
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_xivox_empty),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(148.dp)
                        .clip(RoundedCornerShape(14.dp))
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = onPrimary) {
                        Text(primaryLabel)
                    }
                    if (secondaryLabel != null && onSecondary != null) {
                        OutlinedButton(onClick = onSecondary) {
                            Text(secondaryLabel)
                        }
                    }
                }
            }
        }
    }
}
