package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PermMedia
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.VideoItem
import com.example.ui.LibraryUiState
import com.example.ui.components.VideoThumbnailBox
import com.example.ui.components.XivoxBrandLockup
import com.example.ui.theme.LiquidSilver
import com.example.util.FormatUtils

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    uiState: LibraryUiState,
    activeDownloadCount: Int,
    onRequestMediaPermission: () -> Unit,
    onPickSafVideo: () -> Unit,
    onOpenVideo: (VideoItem) -> Unit,
    onOpenVault: () -> Unit,
    onOpenDownloader: () -> Unit,
    onOpenVideos: () -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen"),
        contentAlignment = Alignment.TopCenter
    ) {
        val isCompact = maxWidth < 420.dp
        val isWide = maxWidth >= 600.dp
        val horizontalPadding = if (isCompact) 16.dp else 20.dp
        val heroHeight = if (isWide) 244.dp else 218.dp
        val cardWidth = when {
            maxWidth < 360.dp -> 208.dp
            maxWidth < 600.dp -> 228.dp
            else -> 256.dp
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 920.dp),
            contentPadding = PaddingValues(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Cinematic Hero Banner (preserving exact Dark Purple + Silver visual identity)
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = heroHeight)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_xivox_hero),
                        contentDescription = "XIVOX Player cinema banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.matchParentSize()
                    )
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Black.copy(alpha = 0.25f),
                                        MaterialTheme.colorScheme.background.copy(alpha = 0.70f),
                                        MaterialTheme.colorScheme.background
                                    )
                                )
                            )
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = heroHeight)
                            .padding(horizontal = horizontalPadding, vertical = 18.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        XivoxBrandLockup(logoSize = 42.dp, showSubtitle = true)

                        Spacer(modifier = Modifier.height(18.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = "Your cinema, refined.",
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                StatPill(
                                    label = "${uiState.videos.size} Videos",
                                    onClick = onOpenVideos
                                )
                                StatPill(
                                    label = "${uiState.folders.size} Folders",
                                    onClick = onOpenVideos
                                )
                                if (activeDownloadCount > 0) {
                                    StatPill(
                                        label = "$activeDownloadCount Active",
                                        highlighted = true,
                                        onClick = onOpenDownloader
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Quick Action Tiles — equal height & crisp touch targets
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = horizontalPadding)
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionTile(
                        icon = Icons.Rounded.FolderOpen,
                        title = "Open File",
                        subtitle = "SAF Picker",
                        onClick = onPickSafVideo,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .testTag("home_open_saf_btn")
                    )
                    QuickActionTile(
                        icon = Icons.Rounded.Lock,
                        title = "Vault",
                        subtitle = "Private PIN",
                        onClick = onOpenVault,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .testTag("home_vault_btn")
                    )
                    QuickActionTile(
                        icon = Icons.Rounded.CloudDownload,
                        title = "Download",
                        subtitle = "Direct URL",
                        onClick = onOpenDownloader,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .testTag("home_downloader_btn")
                    )
                }
            }

            // Media Permission Card with smooth animated visibility
            item {
                AnimatedVisibility(
                    visible = !uiState.hasPermission,
                    enter = fadeIn(tween(260)) + expandVertically(spring(stiffness = Spring.StiffnessMediumLow)),
                    exit = fadeOut(tween(200)) + shrinkVertically()
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = horizontalPadding),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.PermMedia,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Text(
                                    text = stringResource(R.string.permission_title),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = LiquidSilver
                                )
                            }
                            Text(
                                text = stringResource(R.string.permission_rationale),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = onRequestMediaPermission,
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("grant_permission_btn")
                                ) {
                                    Text("Grant Access")
                                }
                                OutlinedButton(
                                    onClick = onPickSafVideo,
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Text("Browse via SAF")
                                }
                            }
                        }
                    }
                }
            }

            // Recently Played / Continue Watching with prominent 16:9 thumbnails
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize(spring(stiffness = Spring.StiffnessMediumLow))
                ) {
                    SectionHeader(
                        icon = Icons.Rounded.History,
                        title = "Recently Played",
                        count = uiState.recentlyPlayed.size,
                        actionLabel = if (uiState.videos.isNotEmpty()) "All Videos" else null,
                        horizontalPadding = horizontalPadding,
                        onAction = onOpenVideos
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    if (uiState.recentlyPlayed.isEmpty()) {
                        EmptyShelfCard(
                            icon = Icons.Rounded.History,
                            title = "Nothing watched yet",
                            message = "Videos you watch will appear here with crisp thumbnails and automatic resume timestamps.",
                            actionLabel = if (uiState.videos.isNotEmpty()) "Browse Videos" else "Pick a Video",
                            horizontalPadding = horizontalPadding,
                            onAction = if (uiState.videos.isNotEmpty()) onOpenVideos else onPickSafVideo
                        )
                    } else {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = horizontalPadding),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(uiState.recentlyPlayed, key = { "recent_${it.uri}" }) { video ->
                                HomeFeaturedVideoCard(
                                    video = video,
                                    cardWidth = cardWidth,
                                    showFavoriteBadge = video.isFavorite,
                                    onClick = { onOpenVideo(video) }
                                )
                            }
                        }
                    }
                }
            }

            // Favorites Section (elevated dark-purple & silver treatment)
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize(spring(stiffness = Spring.StiffnessMediumLow))
                ) {
                    SectionHeader(
                        icon = Icons.Rounded.Favorite,
                        title = "Favorites",
                        count = uiState.favorites.size,
                        actionLabel = if (uiState.videos.isNotEmpty()) "Explore" else null,
                        horizontalPadding = horizontalPadding,
                        onAction = onOpenVideos
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    if (uiState.favorites.isEmpty()) {
                        EmptyShelfCard(
                            icon = Icons.Rounded.Favorite,
                            title = "Build your Favorites reel",
                            message = "Tap the heart icon on any video card to pin your go-to movies and clips right here.",
                            actionLabel = if (uiState.videos.isNotEmpty()) "Open Library" else "Open Video",
                            horizontalPadding = horizontalPadding,
                            accentHighlight = true,
                            onAction = if (uiState.videos.isNotEmpty()) onOpenVideos else onPickSafVideo
                        )
                    } else {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = horizontalPadding),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(uiState.favorites, key = { "fav_${it.uri}" }) { video ->
                                HomeFeaturedVideoCard(
                                    video = video,
                                    cardWidth = cardWidth,
                                    showFavoriteBadge = true,
                                    emphasizedBorder = true,
                                    onClick = { onOpenVideo(video) }
                                )
                            }
                        }
                    }
                }
            }

            // Quick Library Preview if permission granted and videos exist
            if (uiState.videos.isNotEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize(spring(stiffness = Spring.StiffnessMediumLow))
                    ) {
                        SectionHeader(
                            icon = Icons.Rounded.VideoLibrary,
                            title = "Latest on Device",
                            count = uiState.videos.size,
                            actionLabel = "See All",
                            horizontalPadding = horizontalPadding,
                            onAction = onOpenVideos
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = horizontalPadding),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(uiState.videos.take(10), key = { "latest_${it.uri}" }) { video ->
                                HomeFeaturedVideoCard(
                                    video = video,
                                    cardWidth = cardWidth,
                                    showFavoriteBadge = video.isFavorite,
                                    onClick = { onOpenVideo(video) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatPill(
    label: String,
    highlighted: Boolean = false,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "stat_pill_scale"
    )

    Surface(
        shape = RoundedCornerShape(50),
        color = if (highlighted) {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
        } else {
            MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.88f)
        },
        border = BorderStroke(
            1.dp,
            if (highlighted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
        ),
        modifier = Modifier
            .scale(scale)
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(),
                onClick = onClick
            )
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (highlighted) MaterialTheme.colorScheme.primary else LiquidSilver,
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp)
        )
    }
}

@Composable
private fun QuickActionTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "quick_tile_scale"
    )

    Card(
        modifier = modifier
            .scale(scale)
            .minimumInteractiveComponentSize()
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(),
                onClick = onClick
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SectionHeader(
    icon: ImageVector,
    title: String,
    count: Int,
    actionLabel: String?,
    horizontalPadding: Dp,
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = horizontalPadding),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (count > 0) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Text(
                        text = "$count",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }
        }
        if (actionLabel != null) {
            Text(
                text = actionLabel,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onAction)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }
    }
}

@Composable
private fun HomeFeaturedVideoCard(
    video: VideoItem,
    cardWidth: Dp,
    showFavoriteBadge: Boolean = false,
    emphasizedBorder: Boolean = false,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "featured_card_scale"
    )

    Card(
        modifier = Modifier
            .width(cardWidth)
            .scale(scale)
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(),
                onClick = onClick
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        border = BorderStroke(
            1.dp,
            if (emphasizedBorder) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.48f)
            } else {
                MaterialTheme.colorScheme.outlineVariant
            }
        )
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
            ) {
                VideoThumbnailBox(
                    uri = video.uri,
                    durationMs = video.durationMs,
                    formatBadge = video.resolutionLabel,
                    modifier = Modifier.fillMaxSize()
                )

                if (showFavoriteBadge) {
                    Surface(
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.65f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(7.dp)
                            .size(26.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Rounded.Favorite,
                                contentDescription = "Favorite",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }

                // Crisp obsidian-silver play emblem
                Surface(
                    shape = CircleShape,
                    color = Color(0xB3130D21),
                    border = BorderStroke(1.dp, LiquidSilver.copy(alpha = 0.65f)),
                    modifier = Modifier
                        .size(42.dp)
                        .align(Alignment.Center)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = "Play ${video.title}",
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                if (video.resumeFraction > 0.02f) {
                    LinearProgressIndicator(
                        progress = { video.resumeFraction },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height(4.dp),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = Color.Black.copy(alpha = 0.45f)
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 13.dp, vertical = 11.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = video.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (video.lastPositionMs > 0L) {
                        "Resume at ${FormatUtils.formatDuration(video.lastPositionMs)} • ${video.folderName}"
                    } else {
                        "${video.folderName} • ${FormatUtils.formatFileSize(video.sizeBytes)}"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun EmptyShelfCard(
    icon: ImageVector,
    title: String,
    message: String,
    actionLabel: String,
    horizontalPadding: Dp,
    accentHighlight: Boolean = false,
    onAction: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = horizontalPadding),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (accentHighlight) {
                MaterialTheme.colorScheme.surfaceContainer
            } else {
                MaterialTheme.colorScheme.surfaceContainerLow
            }
        ),
        border = BorderStroke(
            1.dp,
            if (accentHighlight) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
            } else {
                MaterialTheme.colorScheme.outlineVariant
            }
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                    modifier = Modifier.size(42.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = LiquidSilver
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = onAction,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                        contentColor = LiquidSilver
                    ),
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Text(actionLabel)
                }
            }
        }
    }
}
