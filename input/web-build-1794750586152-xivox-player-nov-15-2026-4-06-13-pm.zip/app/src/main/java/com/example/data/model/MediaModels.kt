package com.example.data.model

enum class ThemePreset(val label: String, val subtitle: String) {
    OBSIDIAN_PURPLE("Obsidian Purple", "Signature dark plum & liquid silver"),
    AMOLED_MIDNIGHT("AMOLED Midnight", "True black OLED depth with violet glow"),
    ROYAL_AMETHYST("Royal Amethyst", "Rich indigo-violet studio atmosphere")
}

enum class SortField(val label: String) {
    NAME("Name"),
    SIZE("Size"),
    DATE("Date")
}

enum class SortOrder(val label: String) {
    ASCENDING("Ascending"),
    DESCENDING("Descending")
}

enum class DownloadStatus(val label: String) {
    QUEUED("Queued"),
    DOWNLOADING("Downloading"),
    PAUSED("Paused"),
    COMPLETED("Completed"),
    FAILED("Failed"),
    CANCELLED("Cancelled")
}

enum class ExtractionStatus {
    IDLE,
    EXTRACTING,
    COMPLETED,
    FAILED
}

data class VideoItem(
    val id: Long,
    val uri: String,
    val title: String,
    val displayName: String,
    val folderName: String,
    val folderId: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateAddedSec: Long,
    val mimeType: String,
    val width: Int = 0,
    val height: Int = 0,
    val isPrivate: Boolean = false,
    val lastPositionMs: Long = 0L,
    val lastPlayedAtMs: Long = 0L,
    val isFavorite: Boolean = false
) {
    val formatExtension: String
        get() {
            val ext = displayName.substringAfterLast('.', "").uppercase()
            if (ext.isNotBlank() && ext.length <= 5) return ext
            return when {
                mimeType.contains("matroska", ignoreCase = true) || mimeType.contains("mkv", ignoreCase = true) -> "MKV"
                mimeType.contains("mp4", ignoreCase = true) -> "MP4"
                mimeType.contains("webm", ignoreCase = true) -> "WEBM"
                else -> "VIDEO"
            }
        }

    val resolutionLabel: String
        get() = when {
            height >= 2160 -> "4K"
            height >= 1440 -> "2K"
            height >= 1080 -> "1080p"
            height >= 720 -> "720p"
            height > 0 -> "${height}p"
            else -> formatExtension
        }

    val resumeFraction: Float
        get() = if (durationMs > 0 && lastPositionMs > 0) {
            (lastPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
        } else 0f
}

data class VideoFolder(
    val id: String,
    val name: String,
    val videoCount: Int,
    val totalSizeBytes: Long,
    val latestTimestampSec: Long,
    val thumbnailUri: String?
)

data class DownloadTask(
    val id: String,
    val url: String,
    val fileName: String,
    val destinationFolderLabel: String,
    val destinationTreeUri: String?,
    val localStagingPath: String,
    val finalUri: String?,
    val totalBytes: Long,
    val downloadedBytes: Long,
    val speedBytesPerSec: Long,
    val status: DownloadStatus,
    val errorMessage: String?,
    val createdAtMs: Long
) {
    val progress: Float
        get() = if (totalBytes > 0L) {
            (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
        } else 0f
}

data class AudioExtractionJob(
    val id: String,
    val sourceTitle: String,
    val outputPath: String? = null,
    val outputUri: String? = null,
    val progress: Float = 0f,
    val status: ExtractionStatus = ExtractionStatus.IDLE,
    val formatLabel: String = "AAC (.m4a)",
    val errorMessage: String? = null
)

data class AppSettings(
    val themePreset: ThemePreset = ThemePreset.OBSIDIAN_PURPLE,
    val highContrastSilver: Boolean = false,
    val defaultPlaybackSpeed: Float = 1.0f,
    val autoResumePlayback: Boolean = true,
    val enableBrightnessGesture: Boolean = true,
    val enableVolumeGesture: Boolean = true,
    val enableDoubleTapSeek: Boolean = true,
    val seekIncrementSec: Int = 10,
    val subtitleTextSizeSp: Float = 18f,
    val subtitleBgOpacity: Float = 0.55f,
    val subtitleColorHex: Long = 0xFFFFFFFF,
    val downloadFolderUri: String? = null,
    val downloadFolderLabel: String = "Movies / XIVOX Downloads",
    val hasVaultPin: Boolean = false
)
