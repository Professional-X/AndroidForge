package com.example.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.AppSettings
import com.example.data.model.ThemePreset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.MessageDigest

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "xivox_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME_PRESET = stringPreferencesKey("theme_preset")
        val HIGH_CONTRAST_SILVER = booleanPreferencesKey("high_contrast_silver")
        val DEFAULT_SPEED = floatPreferencesKey("default_speed")
        val AUTO_RESUME = booleanPreferencesKey("auto_resume")
        val BRIGHTNESS_GESTURE = booleanPreferencesKey("brightness_gesture")
        val VOLUME_GESTURE = booleanPreferencesKey("volume_gesture")
        val DOUBLE_TAP_SEEK = booleanPreferencesKey("double_tap_seek")
        val SEEK_INCREMENT_SEC = intPreferencesKey("seek_increment_sec")
        val SUBTITLE_TEXT_SIZE = floatPreferencesKey("subtitle_text_size")
        val SUBTITLE_BG_OPACITY = floatPreferencesKey("subtitle_bg_opacity")
        val SUBTITLE_COLOR_HEX = longPreferencesKey("subtitle_color_hex")
        val DOWNLOAD_FOLDER_URI = stringPreferencesKey("download_folder_uri")
        val DOWNLOAD_FOLDER_LABEL = stringPreferencesKey("download_folder_label")
        val PRIVATE_PIN_HASH = stringPreferencesKey("private_pin_hash")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        val presetName = prefs[Keys.THEME_PRESET] ?: ThemePreset.OBSIDIAN_PURPLE.name
        val preset = runCatching { ThemePreset.valueOf(presetName) }.getOrDefault(ThemePreset.OBSIDIAN_PURPLE)
        AppSettings(
            themePreset = preset,
            highContrastSilver = prefs[Keys.HIGH_CONTRAST_SILVER] ?: false,
            defaultPlaybackSpeed = (prefs[Keys.DEFAULT_SPEED] ?: 1.0f).coerceIn(0.25f, 2.0f),
            autoResumePlayback = prefs[Keys.AUTO_RESUME] ?: true,
            enableBrightnessGesture = prefs[Keys.BRIGHTNESS_GESTURE] ?: true,
            enableVolumeGesture = prefs[Keys.VOLUME_GESTURE] ?: true,
            enableDoubleTapSeek = prefs[Keys.DOUBLE_TAP_SEEK] ?: true,
            seekIncrementSec = prefs[Keys.SEEK_INCREMENT_SEC] ?: 10,
            subtitleTextSizeSp = prefs[Keys.SUBTITLE_TEXT_SIZE] ?: 18f,
            subtitleBgOpacity = prefs[Keys.SUBTITLE_BG_OPACITY] ?: 0.55f,
            subtitleColorHex = prefs[Keys.SUBTITLE_COLOR_HEX] ?: 0xFFFFFFFF,
            downloadFolderUri = prefs[Keys.DOWNLOAD_FOLDER_URI],
            downloadFolderLabel = prefs[Keys.DOWNLOAD_FOLDER_LABEL] ?: "Movies / XIVOX Downloads",
            hasVaultPin = !prefs[Keys.PRIVATE_PIN_HASH].isNullOrBlank()
        )
    }

    suspend fun setThemePreset(preset: ThemePreset) {
        context.dataStore.edit { it[Keys.THEME_PRESET] = preset.name }
    }

    suspend fun setHighContrastSilver(enabled: Boolean) {
        context.dataStore.edit { it[Keys.HIGH_CONTRAST_SILVER] = enabled }
    }

    suspend fun setDefaultPlaybackSpeed(speed: Float) {
        context.dataStore.edit { it[Keys.DEFAULT_SPEED] = speed.coerceIn(0.25f, 2.0f) }
    }

    suspend fun setAutoResume(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_RESUME] = enabled }
    }

    suspend fun setBrightnessGesture(enabled: Boolean) {
        context.dataStore.edit { it[Keys.BRIGHTNESS_GESTURE] = enabled }
    }

    suspend fun setVolumeGesture(enabled: Boolean) {
        context.dataStore.edit { it[Keys.VOLUME_GESTURE] = enabled }
    }

    suspend fun setDoubleTapSeek(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DOUBLE_TAP_SEEK] = enabled }
    }

    suspend fun setSeekIncrementSec(seconds: Int) {
        context.dataStore.edit { it[Keys.SEEK_INCREMENT_SEC] = seconds.coerceIn(5, 60) }
    }

    suspend fun setSubtitleTextSizeSp(sizeSp: Float) {
        context.dataStore.edit { it[Keys.SUBTITLE_TEXT_SIZE] = sizeSp.coerceIn(12f, 32f) }
    }

    suspend fun setSubtitleBgOpacity(opacity: Float) {
        context.dataStore.edit { it[Keys.SUBTITLE_BG_OPACITY] = opacity.coerceIn(0f, 1f) }
    }

    suspend fun setSubtitleColorHex(colorHex: Long) {
        context.dataStore.edit { it[Keys.SUBTITLE_COLOR_HEX] = colorHex }
    }

    suspend fun setDownloadFolder(uri: String?, label: String) {
        context.dataStore.edit { prefs ->
            if (uri == null) {
                prefs.remove(Keys.DOWNLOAD_FOLDER_URI)
            } else {
                prefs[Keys.DOWNLOAD_FOLDER_URI] = uri
            }
            prefs[Keys.DOWNLOAD_FOLDER_LABEL] = label
        }
    }

    suspend fun setVaultPin(pin: String) {
        val hash = sha256("xivox_salt_$pin")
        context.dataStore.edit { it[Keys.PRIVATE_PIN_HASH] = hash }
    }

    suspend fun verifyVaultPin(pin: String): Boolean {
        val stored = context.dataStore.data.first()[Keys.PRIVATE_PIN_HASH] ?: return false
        return stored == sha256("xivox_salt_$pin")
    }

    suspend fun clearVaultPin() {
        context.dataStore.edit { it.remove(Keys.PRIVATE_PIN_HASH) }
    }

    private fun sha256(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }
}
