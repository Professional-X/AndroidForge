package com.example.data.media

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object VideoThumbnailLoader {

    private val cache = object : LruCache<String, Bitmap>(48) {}

    fun clearCache() {
        cache.evictAll()
    }

    suspend fun loadThumbnail(context: Context, uriString: String): Bitmap? = withContext(Dispatchers.IO) {
        cache.get(uriString)?.let { return@withContext it }

        val uri = runCatching { Uri.parse(uriString) }.getOrNull() ?: return@withContext null

        val bitmap: Bitmap? = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && uri.scheme == "content") {
                runCatching {
                    context.contentResolver.loadThumbnail(uri, Size(480, 270), null)
                }.getOrNull()
            } else null
        }.getOrNull() ?: extractFrameFallback(context, uri)

        if (bitmap != null) {
            cache.put(uriString, bitmap)
        }
        bitmap
    }

    private fun extractFrameFallback(context: Context, uri: Uri): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            if (uri.scheme == "file" && uri.path != null) {
                retriever.setDataSource(uri.path)
            } else {
                retriever.setDataSource(context, uri)
            }
            retriever.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.frameAtTime
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }
}
