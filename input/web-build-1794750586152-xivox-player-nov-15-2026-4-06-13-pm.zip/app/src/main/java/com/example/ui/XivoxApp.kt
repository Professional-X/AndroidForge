package com.example.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.DownloadForOffline
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.DownloadForOffline
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.R
import com.example.data.model.DownloadStatus
import com.example.data.model.VideoItem
import com.example.ui.components.AudioExtractionDialog
import com.example.ui.navigation.DownloaderRoute
import com.example.ui.navigation.DownloadsRoute
import com.example.ui.navigation.FolderDetailRoute
import com.example.ui.navigation.FoldersRoute
import com.example.ui.navigation.HomeRoute
import com.example.ui.navigation.PlayerRoute
import com.example.ui.navigation.PrivateVaultRoute
import com.example.ui.navigation.SettingsRoute
import com.example.ui.navigation.VideosRoute
import com.example.ui.screens.DownloaderScreen
import com.example.ui.screens.DownloadsScreen
import com.example.ui.screens.FolderDetailScreen
import com.example.ui.screens.FoldersScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PlayerScreen
import com.example.ui.screens.PrivateVaultScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VideosScreen
import com.example.ui.theme.XivoxPlayerTheme

private data class TopLevelNavItem(
    val route: Any,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String
)

@Composable
fun XivoxApp(
    viewModel: XivoxViewModel,
    isInPictureInPictureMode: Boolean,
    incomingVideoUri: Uri?,
    onConsumeIncomingVideo: () -> Unit
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val libraryState by viewModel.libraryState.collectAsStateWithLifecycle()
    val downloads by viewModel.downloads.collectAsStateWithLifecycle()
    val privateVideos by viewModel.privateVideos.collectAsStateWithLifecycle()
    val isVaultUnlocked by viewModel.isVaultUnlocked.collectAsStateWithLifecycle()
    val vaultError by viewModel.vaultError.collectAsStateWithLifecycle()
    val extractionJob by viewModel.extractionJob.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()

    val activeDownloadCount = remember(downloads) {
        downloads.count {
            it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.QUEUED
        }
    }

    LaunchedEffect(statusMessage) {
        statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.consumeStatusMessage()
        }
    }

    fun navigateToPlayer(video: VideoItem) {
        val resumePos = if (video.lastPositionMs > 0L) {
            video.lastPositionMs
        } else {
            libraryState.recentlyPlayed.firstOrNull { it.uri == video.uri }?.lastPositionMs ?: 0L
        }
        navController.navigate(
            PlayerRoute(
                videoUri = video.uri,
                title = video.title,
                folderName = video.folderName,
                durationMs = video.durationMs,
                sizeBytes = video.sizeBytes,
                mimeType = video.mimeType,
                startPositionMs = resumePos
            )
        )
    }

    // Handle external ACTION_VIEW video URI
    LaunchedEffect(incomingVideoUri) {
        if (incomingVideoUri != null) {
            viewModel.addSafVideo(incomingVideoUri) { item ->
                navigateToPlayer(item)
            }
            onConsumeIncomingVideo()
        }
    }

    // Runtime media permission launcher
    val mediaPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.onPermissionUpdated()
    }

    fun requestMediaPermissions() {
        val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            )
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        mediaPermissionLauncher.launch(perms)
    }

    // SAF Open Video Picker
    val safVideoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            viewModel.addSafVideo(uri) { video ->
                navigateToPlayer(video)
            }
        }
    }

    // SAF Vault Import Picker
    val safVaultImportPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.importVideoToVault(uri)
        }
    }

    // SAF Download Folder Picker
    val safFolderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            val label = DocumentFile.fromTreeUri(context, treeUri)?.name ?: "Custom Folder"
            viewModel.setDownloadFolder(treeUri, label)
        }
    }

    val topLevelItems = remember {
        listOf(
            TopLevelNavItem(HomeRoute, R.string.nav_home, Icons.Rounded.Home, Icons.Outlined.Home, "nav_home"),
            TopLevelNavItem(VideosRoute, R.string.nav_videos, Icons.Rounded.VideoLibrary, Icons.Outlined.VideoLibrary, "nav_videos"),
            TopLevelNavItem(FoldersRoute, R.string.nav_folders, Icons.Rounded.Folder, Icons.Outlined.Folder, "nav_folders"),
            TopLevelNavItem(DownloaderRoute, R.string.nav_downloader, Icons.Rounded.CloudDownload, Icons.Outlined.CloudDownload, "nav_downloader"),
            TopLevelNavItem(DownloadsRoute, R.string.nav_downloads, Icons.Rounded.DownloadForOffline, Icons.Outlined.DownloadForOffline, "nav_downloads"),
            TopLevelNavItem(SettingsRoute, R.string.nav_settings, Icons.Rounded.Settings, Icons.Outlined.Settings, "nav_settings")
        )
    }

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = backStackEntry?.destination
    val isPlayerScreen = currentDest?.hasRoute<PlayerRoute>() == true
    val isPrivateVaultScreen = currentDest?.hasRoute<PrivateVaultRoute>() == true
    val showNavigationChrome = !isPlayerScreen && !isPrivateVaultScreen && !isInPictureInPictureMode

    fun navigateTopLevel(route: Any) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    XivoxPlayerTheme(
        themePreset = settings.themePreset,
        highContrastSilver = settings.highContrastSilver
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                contentWindowInsets = if (isPlayerScreen) WindowInsets(0) else WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (showNavigationChrome && !useRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            contentColor = MaterialTheme.colorScheme.onSurface
                        ) {
                            topLevelItems.forEach { item ->
                                val selected = when (item.route) {
                                    is HomeRoute -> currentDest?.hasRoute<HomeRoute>() == true
                                    is VideosRoute -> currentDest?.hasRoute<VideosRoute>() == true
                                    is FoldersRoute -> currentDest?.hasRoute<FoldersRoute>() == true ||
                                        currentDest?.hasRoute<FolderDetailRoute>() == true
                                    is DownloaderRoute -> currentDest?.hasRoute<DownloaderRoute>() == true
                                    is DownloadsRoute -> currentDest?.hasRoute<DownloadsRoute>() == true
                                    is SettingsRoute -> currentDest?.hasRoute<SettingsRoute>() == true
                                    else -> false
                                }
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateTopLevel(item.route) },
                                    icon = {
                                        val iconVector = if (selected) item.selectedIcon else item.unselectedIcon
                                        if (item.route is DownloadsRoute && activeDownloadCount > 0) {
                                            BadgedBox(badge = { Badge { Text("$activeDownloadCount") } }) {
                                                Icon(iconVector, contentDescription = stringResource(item.labelRes))
                                            }
                                        } else {
                                            Icon(iconVector, contentDescription = stringResource(item.labelRes))
                                        }
                                    },
                                    label = {
                                        Text(
                                            text = stringResource(item.labelRes),
                                            maxLines = 1,
                                            softWrap = false,
                                            overflow = TextOverflow.Clip,
                                            fontSize = 9.5.sp,
                                            letterSpacing = (-0.2).sp
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.testTag(item.tag)
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (showNavigationChrome && useRail) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            topLevelItems.forEach { item ->
                                val selected = when (item.route) {
                                    is HomeRoute -> currentDest?.hasRoute<HomeRoute>() == true
                                    is VideosRoute -> currentDest?.hasRoute<VideosRoute>() == true
                                    is FoldersRoute -> currentDest?.hasRoute<FoldersRoute>() == true ||
                                        currentDest?.hasRoute<FolderDetailRoute>() == true
                                    is DownloaderRoute -> currentDest?.hasRoute<DownloaderRoute>() == true
                                    is DownloadsRoute -> currentDest?.hasRoute<DownloadsRoute>() == true
                                    is SettingsRoute -> currentDest?.hasRoute<SettingsRoute>() == true
                                    else -> false
                                }
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateTopLevel(item.route) },
                                    icon = {
                                        val iconVector = if (selected) item.selectedIcon else item.unselectedIcon
                                        if (item.route is DownloadsRoute && activeDownloadCount > 0) {
                                            BadgedBox(badge = { Badge { Text("$activeDownloadCount") } }) {
                                                Icon(iconVector, contentDescription = stringResource(item.labelRes))
                                            }
                                        } else {
                                            Icon(iconVector, contentDescription = stringResource(item.labelRes))
                                        }
                                    },
                                    label = { Text(stringResource(item.labelRes), maxLines = 1) },
                                    modifier = Modifier.testTag(item.tag)
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                        NavHost(
                            navController = navController,
                            startDestination = HomeRoute,
                            enterTransition = {
                                fadeIn(animationSpec = tween(240, easing = FastOutSlowInEasing)) +
                                    slideInHorizontally(
                                        initialOffsetX = { it / 16 },
                                        animationSpec = tween(240, easing = FastOutSlowInEasing)
                                    )
                            },
                            exitTransition = {
                                fadeOut(animationSpec = tween(180, easing = FastOutSlowInEasing))
                            },
                            popEnterTransition = {
                                fadeIn(animationSpec = tween(240, easing = FastOutSlowInEasing)) +
                                    slideInHorizontally(
                                        initialOffsetX = { -it / 16 },
                                        animationSpec = tween(240, easing = FastOutSlowInEasing)
                                    )
                            },
                            popExitTransition = {
                                fadeOut(animationSpec = tween(180, easing = FastOutSlowInEasing)) +
                                    slideOutHorizontally(
                                        targetOffsetX = { it / 12 },
                                        animationSpec = tween(180, easing = FastOutSlowInEasing)
                                    )
                            }
                        ) {
                            composable<HomeRoute> {
                                HomeScreen(
                                    uiState = libraryState,
                                    activeDownloadCount = activeDownloadCount,
                                    onRequestMediaPermission = ::requestMediaPermissions,
                                    onPickSafVideo = { safVideoPicker.launch(arrayOf("video/*")) },
                                    onOpenVideo = ::navigateToPlayer,
                                    onOpenVault = { navController.navigate(PrivateVaultRoute) },
                                    onOpenDownloader = { navigateTopLevel(DownloaderRoute) },
                                    onOpenVideos = { navigateTopLevel(VideosRoute) }
                                )
                            }

                            composable<VideosRoute> {
                                VideosScreen(
                                    uiState = libraryState,
                                    onSearchChange = viewModel::setSearchQuery,
                                    onSortFieldSelect = viewModel::setSortField,
                                    onToggleSortOrder = viewModel::toggleSortOrder,
                                    onToggleGridLayout = viewModel::toggleGridLayout,
                                    onRefresh = viewModel::refreshLibrary,
                                    onRequestPermission = ::requestMediaPermissions,
                                    onPickSafVideo = { safVideoPicker.launch(arrayOf("video/*")) },
                                    onPlayVideo = ::navigateToPlayer,
                                    onToggleFavorite = viewModel::toggleFavorite,
                                    onExtractAudio = viewModel::extractAudio,
                                    onShareVideo = viewModel::shareVideo,
                                    onMoveToVault = { video ->
                                        viewModel.importVideoToVault(Uri.parse(video.uri))
                                    }
                                )
                            }

                            composable<FoldersRoute> {
                                FoldersScreen(
                                    uiState = libraryState,
                                    privateVideoCount = privateVideos.size,
                                    onOpenFolder = { folder ->
                                        navController.navigate(FolderDetailRoute(folder.id, folder.name))
                                    },
                                    onOpenPrivateVault = { navController.navigate(PrivateVaultRoute) },
                                    onRequestPermission = ::requestMediaPermissions,
                                    onPickSafVideo = { safVideoPicker.launch(arrayOf("video/*")) }
                                )
                            }

                            composable<FolderDetailRoute> { entry ->
                                val route = entry.toRoute<FolderDetailRoute>()
                                val folderVideos = remember(libraryState.videos, route.folderId) {
                                    libraryState.videos.filter { it.folderId == route.folderId }
                                }
                                FolderDetailScreen(
                                    folderName = route.folderName,
                                    videos = folderVideos,
                                    onBack = { navController.popBackStack() },
                                    onPlayVideo = ::navigateToPlayer,
                                    onToggleFavorite = viewModel::toggleFavorite,
                                    onExtractAudio = viewModel::extractAudio,
                                    onShareVideo = viewModel::shareVideo,
                                    onMoveToVault = { video ->
                                        viewModel.importVideoToVault(Uri.parse(video.uri))
                                    }
                                )
                            }

                            composable<DownloaderRoute> {
                                DownloaderScreen(
                                    settings = settings,
                                    downloads = downloads,
                                    onPickDownloadFolder = { safFolderPicker.launch(null) },
                                    onStartDownload = viewModel::startDownload,
                                    onPauseDownload = viewModel::pauseDownload,
                                    onResumeDownload = viewModel::resumeDownload,
                                    onCancelDownload = viewModel::cancelDownload,
                                    onPlayCompleted = { task ->
                                        val uri = task.finalUri ?: return@DownloaderScreen
                                        navigateToPlayer(
                                            VideoItem(
                                                id = task.id.hashCode().toLong(),
                                                uri = uri,
                                                title = task.fileName.substringBeforeLast('.'),
                                                displayName = task.fileName,
                                                folderName = task.destinationFolderLabel,
                                                folderId = "downloads",
                                                durationMs = 0L,
                                                sizeBytes = task.downloadedBytes,
                                                dateAddedSec = task.createdAtMs / 1000L,
                                                mimeType = "video/mp4"
                                            )
                                        )
                                    },
                                    onOpenDownloadsTab = { navigateTopLevel(DownloadsRoute) }
                                )
                            }

                            composable<DownloadsRoute> {
                                DownloadsScreen(
                                    downloads = downloads,
                                    onPause = viewModel::pauseDownload,
                                    onResume = viewModel::resumeDownload,
                                    onCancel = viewModel::cancelDownload,
                                    onRemove = viewModel::removeDownload,
                                    onClearFinished = viewModel::clearFinishedDownloads,
                                    onPlayCompleted = { task ->
                                        val uri = task.finalUri ?: return@DownloadsScreen
                                        navigateToPlayer(
                                            VideoItem(
                                                id = task.id.hashCode().toLong(),
                                                uri = uri,
                                                title = task.fileName.substringBeforeLast('.'),
                                                displayName = task.fileName,
                                                folderName = task.destinationFolderLabel,
                                                folderId = "downloads",
                                                durationMs = 0L,
                                                sizeBytes = task.downloadedBytes,
                                                dateAddedSec = task.createdAtMs / 1000L,
                                                mimeType = "video/mp4"
                                            )
                                        )
                                    },
                                    onShareCompleted = { task ->
                                        val uri = task.finalUri ?: return@DownloadsScreen
                                        viewModel.shareVideo(
                                            VideoItem(
                                                id = task.id.hashCode().toLong(),
                                                uri = uri,
                                                title = task.fileName,
                                                displayName = task.fileName,
                                                folderName = task.destinationFolderLabel,
                                                folderId = "downloads",
                                                durationMs = 0L,
                                                sizeBytes = task.downloadedBytes,
                                                dateAddedSec = task.createdAtMs / 1000L,
                                                mimeType = "video/mp4"
                                            )
                                        )
                                    },
                                    onGoToDownloader = { navigateTopLevel(DownloaderRoute) }
                                )
                            }

                            composable<SettingsRoute> {
                                SettingsScreen(
                                    settings = settings,
                                    onThemePresetChange = viewModel::setThemePreset,
                                    onHighContrastSilverChange = viewModel::setHighContrastSilver,
                                    onDefaultSpeedChange = viewModel::setDefaultSpeed,
                                    onAutoResumeChange = viewModel::setAutoResume,
                                    onBrightnessGestureChange = viewModel::setBrightnessGesture,
                                    onVolumeGestureChange = viewModel::setVolumeGesture,
                                    onDoubleTapSeekChange = viewModel::setDoubleTapSeek,
                                    onSeekIncrementChange = viewModel::setSeekIncrement,
                                    onSubtitleSizeChange = viewModel::setSubtitleTextSize,
                                    onSubtitleBgOpacityChange = viewModel::setSubtitleBgOpacity,
                                    onSubtitleColorChange = viewModel::setSubtitleColor,
                                    onPickDownloadFolder = { safFolderPicker.launch(null) },
                                    onResetDownloadFolder = {
                                        viewModel.setDownloadFolder(null, "Movies / XIVOX Downloads")
                                    },
                                    onClearThumbnailCache = viewModel::clearThumbnailCache,
                                    onClearPlaybackHistory = viewModel::clearPlaybackHistory,
                                    onResetVaultPin = viewModel::resetVaultPin
                                )
                            }

                            composable<PrivateVaultRoute> {
                                PrivateVaultScreen(
                                    hasPin = settings.hasVaultPin,
                                    isUnlocked = isVaultUnlocked,
                                    vaultError = vaultError,
                                    privateVideos = privateVideos,
                                    onBack = { navController.popBackStack() },
                                    onCreatePin = viewModel::createVaultPin,
                                    onUnlock = viewModel::unlockVault,
                                    onLock = viewModel::lockVault,
                                    onClearError = viewModel::clearVaultError,
                                    onImportToVault = { safVaultImportPicker.launch(arrayOf("video/*")) },
                                    onPlayVideo = ::navigateToPlayer,
                                    onExtractAudio = viewModel::extractAudio,
                                    onShareVideo = viewModel::shareVideo,
                                    onDeleteFromVault = viewModel::deleteFromVault
                                )
                            }

                            composable<PlayerRoute> { entry ->
                                val route = entry.toRoute<PlayerRoute>()
                                val video = VideoItem(
                                    id = route.videoUri.hashCode().toLong(),
                                    uri = route.videoUri,
                                    title = route.title,
                                    displayName = route.title,
                                    folderName = route.folderName,
                                    folderId = "player",
                                    durationMs = route.durationMs,
                                    sizeBytes = route.sizeBytes,
                                    dateAddedSec = 0L,
                                    mimeType = route.mimeType,
                                    lastPositionMs = route.startPositionMs
                                )
                                PlayerScreen(
                                    video = video,
                                    settings = settings,
                                    isInPictureInPictureMode = isInPictureInPictureMode,
                                    onSaveProgress = { pos, dur ->
                                        viewModel.savePlaybackProgress(video, pos, dur)
                                    },
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }
                    }
                }
            }

            // Global Audio Extraction Progress / Result Dialog
            extractionJob?.let { job ->
                AudioExtractionDialog(
                    job = job,
                    onCancel = viewModel::cancelExtraction,
                    onDismiss = viewModel::dismissExtraction,
                    onShareAudio = viewModel::shareAudio
                )
            }
        }
    }
}
