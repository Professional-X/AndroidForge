package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.model.AppSettings
import com.example.data.model.ThemePreset
import com.example.ui.components.XivoxBrandLockup
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onThemePresetChange: (ThemePreset) -> Unit,
    onHighContrastSilverChange: (Boolean) -> Unit,
    onDefaultSpeedChange: (Float) -> Unit,
    onAutoResumeChange: (Boolean) -> Unit,
    onBrightnessGestureChange: (Boolean) -> Unit,
    onVolumeGestureChange: (Boolean) -> Unit,
    onDoubleTapSeekChange: (Boolean) -> Unit,
    onSeekIncrementChange: (Int) -> Unit,
    onSubtitleSizeChange: (Float) -> Unit,
    onSubtitleBgOpacityChange: (Float) -> Unit,
    onSubtitleColorChange: (Long) -> Unit,
    onPickDownloadFolder: () -> Unit,
    onResetDownloadFolder: () -> Unit,
    onClearThumbnailCache: () -> Unit,
    onClearPlaybackHistory: () -> Unit,
    onResetVaultPin: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showPinDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Settings",
                style = MaterialTheme.typography.headlineMedium
            )
        }

        // Theme Settings
        item {
            SettingsSectionCard(
                icon = Icons.Rounded.Palette,
                title = "Theme & Appearance"
            ) {
                ThemePreset.entries.forEach { preset ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onThemePresetChange(preset) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = settings.themePreset == preset,
                            onClick = { onThemePresetChange(preset) }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(preset.label, style = MaterialTheme.typography.titleSmall)
                            Text(
                                preset.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                SettingsSwitchRow(
                    title = "Silver Chrome Accent",
                    subtitle = "Use metallic silver highlights instead of electric violet",
                    checked = settings.highContrastSilver,
                    onCheckedChange = onHighContrastSilverChange
                )
            }
        }

        // Default Playback Speed & Resume
        item {
            SettingsSectionCard(
                icon = Icons.Rounded.Speed,
                title = "Playback Defaults"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Default Speed", style = MaterialTheme.typography.titleSmall)
                    Text(
                        text = String.format(Locale.US, "%.2fx", settings.defaultPlaybackSpeed),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Slider(
                    value = settings.defaultPlaybackSpeed,
                    onValueChange = { raw ->
                        val snapped = (raw * 4f).roundToInt() / 4f
                        onDefaultSpeedChange(snapped.coerceIn(0.25f, 2.0f))
                    },
                    valueRange = 0.25f..2.0f,
                    steps = 6
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                SettingsSwitchRow(
                    title = "Auto-Resume Last Position",
                    subtitle = "Continue local videos right where you paused",
                    checked = settings.autoResumePlayback,
                    onCheckedChange = onAutoResumeChange
                )
            }
        }

        // Player Gesture Settings
        item {
            SettingsSectionCard(
                icon = Icons.Rounded.TouchApp,
                title = "Player Gestures"
            ) {
                SettingsSwitchRow(
                    title = "Brightness Swipe (Left Side)",
                    subtitle = "Vertical drag on left half adjusts screen brightness",
                    checked = settings.enableBrightnessGesture,
                    onCheckedChange = onBrightnessGestureChange
                )
                SettingsSwitchRow(
                    title = "Volume Swipe (Right Side)",
                    subtitle = "Vertical drag on right half adjusts media volume",
                    checked = settings.enableVolumeGesture,
                    onCheckedChange = onVolumeGestureChange
                )
                SettingsSwitchRow(
                    title = "Double-Tap Seek",
                    subtitle = "Double-tap left or right to jump backward or forward",
                    checked = settings.enableDoubleTapSeek,
                    onCheckedChange = onDoubleTapSeekChange
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Seek Jump Increment",
                    style = MaterialTheme.typography.titleSmall
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 6.dp)
                ) {
                    listOf(5, 10, 15, 30).forEach { sec ->
                        FilterChip(
                            selected = settings.seekIncrementSec == sec,
                            onClick = { onSeekIncrementChange(sec) },
                            label = { Text("${sec}s") }
                        )
                    }
                }
            }
        }

        // Subtitle Settings
        item {
            SettingsSectionCard(
                icon = Icons.Rounded.Subtitles,
                title = "Subtitle Styling"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Subtitle Text Size", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "${settings.subtitleTextSizeSp.roundToInt()} sp",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Slider(
                    value = settings.subtitleTextSizeSp,
                    onValueChange = onSubtitleSizeChange,
                    valueRange = 14f..28f
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Caption Background Opacity", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "${(settings.subtitleBgOpacity * 100).roundToInt()}%",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Slider(
                    value = settings.subtitleBgOpacity,
                    onValueChange = onSubtitleBgOpacityChange,
                    valueRange = 0f..0.9f
                )

                Text("Subtitle Text Color", style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    val palette = listOf(
                        0xFFFFFFFFL to "White",
                        0xFFE2E8F0L to "Silver",
                        0xFFFACC15L to "Gold",
                        0xFFC084FCL to "Violet"
                    )
                    palette.forEach { (hex, name) ->
                        val selected = settings.subtitleColorHex == hex
                        Surface(
                            shape = CircleShape,
                            color = Color(hex),
                            border = BorderStroke(
                                if (selected) 3.dp else 1.dp,
                                if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                            ),
                            modifier = Modifier
                                .size(34.dp)
                                .clickable { onSubtitleColorChange(hex) }
                        ) {}
                    }
                }
            }
        }

        // Storage & Vault Security
        item {
            SettingsSectionCard(
                icon = Icons.Rounded.FolderOpen,
                title = "Storage & Security"
            ) {
                Text("Download Destination", style = MaterialTheme.typography.titleSmall)
                Text(
                    text = settings.downloadFolderLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    OutlinedButton(onClick = onPickDownloadFolder) {
                        Text("Choose Folder (SAF)")
                    }
                    if (settings.downloadFolderUri != null) {
                        TextButton(onClick = onResetDownloadFolder) {
                            Text("Use Default")
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onClearThumbnailCache,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.DeleteSweep, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Clear Cache")
                    }
                    OutlinedButton(
                        onClick = onClearPlaybackHistory,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Clear History")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = { showPinDialog = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.Lock, null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (settings.hasVaultPin) "Change Private Vault PIN" else "Set Private Vault PIN")
                }
            }
        }

        // About XIVOX Player
        item {
            SettingsSectionCard(
                icon = Icons.Rounded.Info,
                title = "About XIVOX Player"
            ) {
                XivoxBrandLockup(logoSize = 38.dp, showSubtitle = true)
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Version 1.0.0 • Native Jetpack Compose & AndroidX Media3 ExoPlayer",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Supported containers & codecs: MP4, MKV, WebM, 3GP, H.264/AVC, H.265/HEVC, VP9, AV1, AAC, Opus, plus SRT/VTT/ASS subtitles, Picture-in-Picture, and Media3 Transformer audio extraction.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    if (showPinDialog) {
        var newPin by remember { mutableStateOf("") }
        var errorText by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text("Update Private Vault PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newPin,
                        onValueChange = {
                            if (it.length <= 6 && it.all { c -> c.isDigit() }) {
                                newPin = it
                                errorText = null
                            }
                        },
                        label = { Text("New 4–6 Digit PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true
                    )
                    if (errorText != null) {
                        Text(errorText!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (newPin.length < 4) {
                        errorText = "PIN must be at least 4 digits"
                    } else {
                        onResetVaultPin(newPin)
                        showPinDialog = false
                    }
                }) {
                    Text("Save PIN")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPinDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SettingsSectionCard(
    icon: ImageVector,
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 4.dp)
            ) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text(title, style = MaterialTheme.typography.titleMedium)
            }
            content()
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
