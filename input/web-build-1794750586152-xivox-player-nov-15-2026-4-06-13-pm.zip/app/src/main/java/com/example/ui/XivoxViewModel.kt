package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.XivoxApplication
import com.example.data.local.PlaybackHistoryEntity
import com.example.data.media.VideoThumbnailLoader
import com.example.data.model.AppSettings
import com.example.data.model.AudioExtractionJob
import com.example.data.model.DownloadStatus
import com.example.data.model.DownloadTask
import com.example.data.model.SortField
import com.example.data.model.SortOrder
import com.example.data.model.ThemePreset
import com.example.data.model.VideoFolder
import com.example.data.model.VideoItem
import com.example.util.FormatUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LibraryUiState(
    val isLoading: Boolean = true,
    val hasPermission: Boolean = false,
    val videos: List<VideoItem> = emptyList(),
    val filteredVideos: List<VideoItem> = emptyList(),
    val folders: List<VideoFolder> = emptyList(),
    val recentlyPlayed: List<VideoItem> = emptyList(),
    val favorites: List<VideoItem> = emptyList(),
    val searchQuery: String = "",
    val sortField: SortField = SortField.DATE,
    val sortOrder: SortOrder = SortOrder.DESCENDING,
    val isGridLayout: Boolean = false
)

class XivoxViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as XivoxApplication
    private val mediaRepo = app.mediaRepository
    private val settingsRepo = app.settingsRepository
    private val downloader = app.downloaderManager
    private val audioExtractor = app.audioExtractorManager

    private val rawDeviceVideos = MutableStateFlow<List<VideoItem>>(emptyList())
    private val safPickedVideos = MutableStateFlow<List<VideoItem>>(emptyList())
    private val hasPermissionState = MutableStateFlow(mediaRepo.hasVideoLibraryPermission())
    private val isLoadingLibrary = MutableStateFlow(true)
    private val searchQuery = MutableStateFlow("")
    private val sortField = MutableStateFlow(SortField.DATE)
    private val sortOrder = MutableStateFlow(SortOrder.DESCENDING)
    private val isGridLayout = MutableStateFlow(false)

    private val _isVaultUnlocked = MutableStateFlow(false)
    val isVaultUnlocked: StateFlow<Boolean> = _isVaultUnlocked

    private val _vaultError = MutableStateFlow<String?>(null)
    val vaultError: StateFlow<String?> = _vaultError

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage

    val settings: StateFlow<AppSettings> = settingsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    val downloads: StateFlow<List<DownloadTask>> = downloader.downloadsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val privateVideos: StateFlow<List<VideoItem>> = mediaRepo.observePrivateVideos()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val extractionJob: StateFlow<AudioExtractionJob?> = audioExtractor.jobState

    private data class QueryParams(
        val query: String,
        val field: SortField,
        val order: SortOrder,
        val isGrid: Boolean
    )

    private val queryParamsFlow = combine(
        searchQuery,
        sortField,
        sortOrder,
        isGridLayout
    ) { q, f, o, grid -> QueryParams(q, f, o, grid) }

    val libraryState: StateFlow<LibraryUiState> = combine(
        rawDeviceVideos,
        safPickedVideos,
        mediaRepo.observeHistory(),
        hasPermissionState,
        isLoadingLibrary,
        queryParamsFlow
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val deviceList = values[0] as List<VideoItem>
        @Suppress("UNCHECKED_CAST")
        val safList = values[1] as List<VideoItem>
        @Suppress("UNCHECKED_CAST")
        val historyMap = values[2] as Map<String, PlaybackHistoryEntity>
        val permitted = values[3] as Boolean
        val loading = values[4] as Boolean
        val params = values[5] as QueryParams

        val merged = (deviceList + safList)
            .distinctBy { it.uri }
            .map { video ->
                val history = historyMap[video.uri]
                if (history != null) {
                    video.copy(
                        lastPositionMs = history.lastPositionMs,
                        lastPlayedAtMs = history.lastPlayedAtMs,
                        isFavorite = history.isFavorite
                    )
                } else {
                    video
                }
            }

        val sorted = FormatUtils.sortVideos(merged, params.field, params.order)
        val filtered = if (params.query.isBlank()) {
            sorted
        } else {
            val q = params.query.trim().lowercase()
            sorted.filter {
                it.title.lowercase().contains(q) ||
                    it.folderName.lowercase().contains(q) ||
                    it.displayName.lowercase().contains(q)
            }
        }

        val folders = mediaRepo.groupIntoFolders(merged)
        val recent = historyMap.values
            .filter { it.lastPlayedAtMs > 0L }
            .sortedByDescending { it.lastPlayedAtMs }
            .mapNotNull { h ->
                merged.find { it.uri == h.uri } ?: VideoItem(
                    id = h.uri.hashCode().toLong(),
                    uri = h.uri,
                    title = h.title,
                    displayName = h.title,
                    folderName = h.folderName,
                    folderId = "history",
                    durationMs = h.durationMs,
                    sizeBytes = h.sizeBytes,
                    dateAddedSec = h.lastPlayedAtMs / 1000L,
                    mimeType = "video/mp4",
                    lastPositionMs = h.lastPositionMs,
                    lastPlayedAtMs = h.lastPlayedAtMs,
                    isFavorite = h.isFavorite
                )
            }

        val favs = historyMap.values
            .filter { it.isFavorite }
            .sortedByDescending { it.lastPlayedAtMs }
            .mapNotNull { h ->
                merged.find { it.uri == h.uri } ?: VideoItem(
                    id = h.uri.hashCode().toLong(),
                    uri = h.uri,
                    title = h.title,
                    displayName = h.title,
                    folderName = h.folderName,
                    folderId = "favorite",
                    durationMs = h.durationMs,
                    sizeBytes = h.sizeBytes,
                    dateAddedSec = h.lastPlayedAtMs / 1000L,
                    mimeType = "video/mp4",
                    lastPositionMs = h.lastPositionMs,
                    lastPlayedAtMs = h.lastPlayedAtMs,
                    isFavorite = true
                )
            }

        LibraryUiState(
            isLoading = loading,
            hasPermission = permitted,
            videos = sorted,
            filteredVideos = filtered,
            folders = folders,
            recentlyPlayed = recent,
            favorites = favs,
            searchQuery = params.query,
            sortField = params.field,
            sortOrder = params.order,
            isGridLayout = params.isGrid
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LibraryUiState())

    init {
        refreshLibrary()
        viewModelScope.launch {
            mediaRepo.observeMediaStoreChanges().collect {
                if (mediaRepo.hasVideoLibraryPermission()) {
                    rawDeviceVideos.value = mediaRepo.queryDeviceVideos()
                }
            }
        }
    }

    fun onPermissionUpdated() {
        hasPermissionState.value = mediaRepo.hasVideoLibraryPermission()
        refreshLibrary()
    }

    fun refreshLibrary() {
        viewModelScope.launch {
            isLoadingLibrary.value = true
            hasPermissionState.value = mediaRepo.hasVideoLibraryPermission()
            if (hasPermissionState.value) {
                rawDeviceVideos.value = mediaRepo.queryDeviceVideos()
            } else {
                rawDeviceVideos.value = emptyList()
            }
            isLoadingLibrary.value = false
        }
    }

    fun addSafVideo(uri: Uri, onResolved: (VideoItem) -> Unit = {}) {
        viewModelScope.launch {
            val item = mediaRepo.resolveVideoFromUri(uri)
            safPickedVideos.value = (safPickedVideos.value + item).distinctBy { it.uri }
            onResolved(item)
        }
    }

    fun setSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun setSortField(field: SortField) {
        if (sortField.value == field) {
            sortOrder.value = if (sortOrder.value == SortOrder.ASCENDING) {
                SortOrder.DESCENDING
            } else {
                SortOrder.ASCENDING
            }
        } else {
            sortField.value = field
            sortOrder.value = if (field == SortField.NAME) SortOrder.ASCENDING else SortOrder.DESCENDING
        }
    }

    fun toggleSortOrder() {
        sortOrder.value = if (sortOrder.value == SortOrder.ASCENDING) {
            SortOrder.DESCENDING
        } else {
            SortOrder.ASCENDING
        }
    }

    fun toggleGridLayout() {
        isGridLayout.value = !isGridLayout.value
    }

    fun toggleFavorite(video: VideoItem) {
        viewModelScope.launch {
            mediaRepo.toggleFavorite(video)
        }
    }

    fun savePlaybackProgress(video: VideoItem, positionMs: Long, durationMs: Long) {
        viewModelScope.launch {
            mediaRepo.savePlaybackPosition(video, positionMs, durationMs)
        }
    }

    fun shareVideo(video: VideoItem) {
        val intent = mediaRepo.buildShareIntent(video.uri, video.title, video.mimeType)
        app.startActivity(intent)
    }

    fun shareAudio(uriString: String, title: String) {
        val intent = mediaRepo.buildShareIntent(uriString, "$title (Audio)", "audio/*")
        app.startActivity(intent)
    }

    fun extractAudio(video: VideoItem) {
        audioExtractor.extractAudio(video.uri, video.title)
    }

    fun cancelExtraction() {
        audioExtractor.cancel()
    }

    fun dismissExtraction() {
        audioExtractor.dismiss()
    }

    // Downloader actions
    fun startDownload(url: String, customFileName: String?): Boolean {
        if (!FormatUtils.isValidHttpUrl(url)) {
            _statusMessage.value = "Enter a valid direct http:// or https:// media URL."
            return false
        }
        val currentSettings = settings.value
        downloader.enqueueDownload(
            url = url,
            customFileName = customFileName,
            destinationTreeUri = currentSettings.downloadFolderUri,
            destinationLabel = currentSettings.downloadFolderLabel
        )
        _statusMessage.value = "Added to download queue"
        return true
    }

    fun pauseDownload(id: String) = downloader.pauseDownload(id)
    fun resumeDownload(id: String) = downloader.resumeDownload(id)
    fun cancelDownload(id: String) = downloader.cancelDownload(id)
    fun removeDownload(id: String) = downloader.removeTask(id)
    fun clearFinishedDownloads() = downloader.clearFinished()

    fun activeDownloadCount(): Int = downloads.value.count {
        it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.QUEUED
    }

    // Private Vault actions
    fun createVaultPin(pin: String) {
        if (pin.length < 4) {
            _vaultError.value = "PIN must be 4 to 6 digits"
            return
        }
        viewModelScope.launch {
            settingsRepo.setVaultPin(pin)
            _vaultError.value = null
            _isVaultUnlocked.value = true
        }
    }

    fun unlockVault(pin: String) {
        viewModelScope.launch {
            if (settingsRepo.verifyVaultPin(pin)) {
                _vaultError.value = null
                _isVaultUnlocked.value = true
            } else {
                _vaultError.value = "Incorrect PIN. Try again."
            }
        }
    }

    fun lockVault() {
        _isVaultUnlocked.value = false
        _vaultError.value = null
    }

    fun clearVaultError() {
        _vaultError.value = null
    }

    fun importVideoToVault(uri: Uri) {
        viewModelScope.launch {
            val res = mediaRepo.importToPrivateVault(uri)
            _statusMessage.value = if (res.isSuccess) {
                "Secured in Private Vault"
            } else {
                res.exceptionOrNull()?.message ?: "Failed to move video to vault"
            }
        }
    }

    fun deleteFromVault(video: VideoItem) {
        viewModelScope.launch {
            mediaRepo.deleteFromPrivateVault(video.id)
            _statusMessage.value = "Removed from Private Vault"
        }
    }

    // Settings actions
    fun setThemePreset(preset: ThemePreset) = viewModelScope.launch { settingsRepo.setThemePreset(preset) }
    fun setHighContrastSilver(enabled: Boolean) = viewModelScope.launch { settingsRepo.setHighContrastSilver(enabled) }
    fun setDefaultSpeed(speed: Float) = viewModelScope.launch { settingsRepo.setDefaultPlaybackSpeed(speed) }
    fun setAutoResume(enabled: Boolean) = viewModelScope.launch { settingsRepo.setAutoResume(enabled) }
    fun setBrightnessGesture(enabled: Boolean) = viewModelScope.launch { settingsRepo.setBrightnessGesture(enabled) }
    fun setVolumeGesture(enabled: Boolean) = viewModelScope.launch { settingsRepo.setVolumeGesture(enabled) }
    fun setDoubleTapSeek(enabled: Boolean) = viewModelScope.launch { settingsRepo.setDoubleTapSeek(enabled) }
    fun setSeekIncrement(seconds: Int) = viewModelScope.launch { settingsRepo.setSeekIncrementSec(seconds) }
    fun setSubtitleTextSize(sp: Float) = viewModelScope.launch { settingsRepo.setSubtitleTextSizeSp(sp) }
    fun setSubtitleBgOpacity(opacity: Float) = viewModelScope.launch { settingsRepo.setSubtitleBgOpacity(opacity) }
    fun setSubtitleColor(colorHex: Long) = viewModelScope.launch { settingsRepo.setSubtitleColorHex(colorHex) }

    fun setDownloadFolder(uri: Uri?, label: String) {
        viewModelScope.launch {
            settingsRepo.setDownloadFolder(uri?.toString(), label)
            _statusMessage.value = "Download folder updated: $label"
        }
    }

    fun resetVaultPin(newPin: String) {
        viewModelScope.launch {
            if (newPin.length >= 4) {
                settingsRepo.setVaultPin(newPin)
                _statusMessage.value = "Vault PIN updated"
            }
        }
    }

    fun clearThumbnailCache() {
        VideoThumbnailLoader.clearCache()
        _statusMessage.value = "Thumbnail cache cleared"
    }

    fun clearPlaybackHistory() {
        viewModelScope.launch {
            mediaRepo.clearHistory()
            _statusMessage.value = "Playback history cleared"
        }
    }

    fun consumeStatusMessage() {
        _statusMessage.value = null
    }
}
