package com.example.util

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.Locale

data class SubtitleCueItem(
    val index: Int,
    val startMs: Long,
    val endMs: Long,
    val text: String
)

object SubtitleSyncHelper {

    fun parseSrt(raw: String): List<SubtitleCueItem> {
        val normalized = raw.replace("\r\n", "\n").replace("\r", "\n").trim()
        if (normalized.isEmpty()) return emptyList()

        val blocks = normalized.split(Regex("\n{2,}"))
        val cues = mutableListOf<SubtitleCueItem>()
        var fallbackIndex = 1

        for (block in blocks) {
            val lines = block.lines().map { it.trimEnd() }.filter { it.isNotEmpty() }
            if (lines.size < 2) continue

            val timeLineIndex = lines.indexOfFirst { it.contains("-->") }
            if (timeLineIndex == -1) continue

            val index = if (timeLineIndex > 0) {
                lines[0].trim().toIntOrNull() ?: fallbackIndex
            } else {
                fallbackIndex
            }

            val timeParts = lines[timeLineIndex].split("-->")
            if (timeParts.size < 2) continue

            val startMs = parseTimestampMs(timeParts[0].trim()) ?: continue
            val endMs = parseTimestampMs(timeParts[1].trim().substringBefore(" ")) ?: continue
            val text = lines.drop(timeLineIndex + 1).joinToString("\n").trim()
            if (text.isNotEmpty()) {
                cues.add(SubtitleCueItem(index, startMs, endMs, text))
                fallbackIndex++
            }
        }
        return cues
    }

    fun parseVtt(raw: String): List<SubtitleCueItem> {
        val cleaned = raw.replace("\r\n", "\n")
            .replace("\r", "\n")
            .removePrefix("\uFEFF")
            .replaceFirst(Regex("^WEBVTT[^\n]*\n+"), "")
        return parseSrt(cleaned)
    }

    fun shiftCues(cues: List<SubtitleCueItem>, offsetMs: Long): List<SubtitleCueItem> {
        if (offsetMs == 0L) return cues
        return cues.mapNotNull { cue ->
            val shiftedStart = (cue.startMs + offsetMs).coerceAtLeast(0L)
            val shiftedEnd = (cue.endMs + offsetMs).coerceAtLeast(0L)
            if (shiftedEnd <= shiftedStart) null
            else cue.copy(startMs = shiftedStart, endMs = shiftedEnd)
        }
    }

    fun formatAsSrt(cues: List<SubtitleCueItem>): String {
        val sb = StringBuilder()
        cues.forEachIndexed { idx, cue ->
            sb.append(idx + 1).append('\n')
            sb.append(formatSrtTimestamp(cue.startMs))
                .append(" --> ")
                .append(formatSrtTimestamp(cue.endMs))
                .append('\n')
            sb.append(cue.text).append("\n\n")
        }
        return sb.toString()
    }

    fun createSyncedTempSrt(
        context: Context,
        sourceUri: Uri,
        fileName: String,
        offsetMs: Long
    ): Uri? {
        return runCatching {
            val rawText = context.contentResolver.openInputStream(sourceUri)
                ?.bufferedReader(Charsets.UTF_8)
                ?.use { it.readText() }
                ?: return null

            val ext = fileName.substringAfterLast('.', "").lowercase(Locale.US)
            val cues = when (ext) {
                "vtt" -> parseVtt(rawText)
                "srt" -> parseSrt(rawText)
                else -> return null
            }
            if (cues.isEmpty()) return null

            val shifted = shiftCues(cues, offsetMs)
            val outFile = File(context.cacheDir, "xivox_synced_sub_${System.currentTimeMillis()}.srt")
            outFile.writeText(formatAsSrt(shifted), Charsets.UTF_8)
            Uri.fromFile(outFile)
        }.getOrNull()
    }

    fun parseTimestampMs(raw: String): Long? {
        // Supports HH:MM:SS,mmm or HH:MM:SS.mmm or MM:SS.mmm
        val normalized = raw.trim().replace(',', '.')
        val parts = normalized.split(':')
        return when (parts.size) {
            3 -> {
                val hours = parts[0].toLongOrNull() ?: return null
                val mins = parts[1].toLongOrNull() ?: return null
                val secParts = parts[2].split('.')
                val secs = secParts[0].toLongOrNull() ?: return null
                val ms = secParts.getOrNull(1)?.padEnd(3, '0')?.take(3)?.toLongOrNull() ?: 0L
                hours * 3_600_000L + mins * 60_000L + secs * 1_000L + ms
            }
            2 -> {
                val mins = parts[0].toLongOrNull() ?: return null
                val secParts = parts[1].split('.')
                val secs = secParts[0].toLongOrNull() ?: return null
                val ms = secParts.getOrNull(1)?.padEnd(3, '0')?.take(3)?.toLongOrNull() ?: 0L
                mins * 60_000L + secs * 1_000L + ms
            }
            else -> null
        }
    }

    fun formatSrtTimestamp(ms: Long): String {
        val safe = ms.coerceAtLeast(0L)
        val hours = safe / 3_600_000L
        val mins = (safe % 3_600_000L) / 60_000L
        val secs = (safe % 60_000L) / 1_000L
        val millis = safe % 1_000L
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, mins, secs, millis)
    }
}
