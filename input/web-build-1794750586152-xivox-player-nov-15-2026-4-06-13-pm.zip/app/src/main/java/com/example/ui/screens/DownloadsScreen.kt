package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.DownloadStatus
import com.example.data.model.DownloadTask
import com.example.ui.theme.AmberGold
import com.example.ui.theme.EmeraldGlow
import com.example.util.FormatUtils
import kotlin.math.roundToInt

private enum class DownloadsFilter(val label: String) {
    ALL("All"),
    ACTIVE("Active"),
    COMPLETED("Completed")
}

@Composable
fun DownloadsScreen(
    downloads: List<DownloadTask>,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onCancel: (String) -> Unit,
    onRemove: (String) -> Unit,
    onClearFinished: () -> Unit,
    onPlayCompleted: (DownloadTask) -> Unit,
    onShareCompleted: (DownloadTask) -> Unit,
    onGoToDownloader: () -> Unit,
    modifier: Modifier = Modifier
) {
    var filter by remember { mutableStateOf(DownloadsFilter.ALL) }

    val filtered = remember(downloads, filter) {
        when (filter) {
            DownloadsFilter.ALL -> downloads
            DownloadsFilter.ACTIVE -> downloads.filter {
                it.status == DownloadStatus.DOWNLOADING ||
                    it.status == DownloadStatus.QUEUED ||
                    it.status == DownloadStatus.PAUSED
            }
            DownloadsFilter.COMPLETED -> downloads.filter { it.status == DownloadStatus.COMPLETED }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("downloads_screen")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Downloads",
                    style = MaterialTheme.typography.headlineMedium
                )
                Text(
                    text = "${downloads.size} total tasks",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (downloads.any {
                    it.status == DownloadStatus.COMPLETED ||
                        it.status == DownloadStatus.CANCELLED ||
                        it.status == DownloadStatus.FAILED
                }
            ) {
                TextButton(onClick = onClearFinished) {
                    Text("Clear Finished")
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DownloadsFilter.entries.forEach { tab ->
                FilterChip(
                    selected = filter == tab,
                    onClick = { filter = tab },
                    label = { Text(tab.label) }
                )
            }
        }

        if (filtered.isEmpty()) {
            EmptyLibraryState(
                title = "No Downloads Yet",
                subtitle = "Queue direct video URLs in the Downloader tab to track live speeds, pause/resume progress, and save to your chosen folder.",
                primaryLabel = "Open Downloader",
                onPrimary = onGoToDownloader
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filtered, key = { it.id }) { task ->
                    DownloadTaskCard(
                        task = task,
                        onPause = { onPause(task.id) },
                        onResume = { onResume(task.id) },
                        onCancel = { onCancel(task.id) },
                        onRemove = { onRemove(task.id) },
                        onPlay = { onPlayCompleted(task) },
                        onShare = { onShareCompleted(task) }
                    )
                }
            }
        }
    }
}

@Composable
fun DownloadTaskCard(
    task: DownloadTask,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onRemove: () -> Unit,
    onPlay: () -> Unit,
    onShare: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("download_card_${task.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = task.fileName,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                StatusPill(task.status)
            }

            Text(
                text = "Folder: ${task.destinationFolderLabel}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (task.status == DownloadStatus.DOWNLOADING ||
                task.status == DownloadStatus.PAUSED ||
                task.status == DownloadStatus.QUEUED
            ) {
                if (task.totalBytes > 0L) {
                    LinearProgressIndicator(
                        progress = { task.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp),
                        color = MaterialTheme.colorScheme.primary
                    )
                } else if (task.status == DownloadStatus.DOWNLOADING) {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp),
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val sizeText = if (task.totalBytes > 0L) {
                        "${FormatUtils.formatFileSize(task.downloadedBytes)} / ${FormatUtils.formatFileSize(task.totalBytes)} (${(task.progress * 100).roundToInt()}%)"
                    } else {
                        "${FormatUtils.formatFileSize(task.downloadedBytes)} downloaded"
                    }
                    Text(
                        text = sizeText,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    if (task.status == DownloadStatus.DOWNLOADING) {
                        Text(
                            text = FormatUtils.formatSpeed(task.speedBytesPerSec),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            if (task.status == DownloadStatus.COMPLETED) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.DownloadDone,
                        contentDescription = null,
                        tint = EmeraldGlow,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Saved • ${FormatUtils.formatFileSize(task.downloadedBytes)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldGlow
                    )
                }
            }

            if (!task.errorMessage.isNullOrBlank()) {
                Text(
                    text = task.errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            // Actions row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                when (task.status) {
                    DownloadStatus.DOWNLOADING, DownloadStatus.QUEUED -> {
                        OutlinedButton(onClick = onPause) {
                            Icon(Icons.Rounded.Pause, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Pause")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(onClick = onCancel) {
                            Icon(
                                Icons.Rounded.Cancel,
                                contentDescription = "Cancel download",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                    DownloadStatus.PAUSED, DownloadStatus.FAILED -> {
                        Button(onClick = onResume) {
                            Icon(
                                if (task.status == DownloadStatus.PAUSED) Icons.Rounded.PlayArrow else Icons.Rounded.Refresh,
                                null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (task.status == DownloadStatus.PAUSED) "Resume" else "Retry")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(onClick = onCancel) {
                            Icon(
                                Icons.Rounded.DeleteOutline,
                                contentDescription = "Cancel and remove",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    DownloadStatus.COMPLETED -> {
                        OutlinedButton(onClick = onShare) {
                            Icon(Icons.Rounded.Share, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(onClick = onPlay) {
                            Icon(Icons.Rounded.PlayArrow, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Play")
                        }
                    }
                    DownloadStatus.CANCELLED -> {
                        IconButton(onClick = onRemove) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "Remove task")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusPill(status: DownloadStatus) {
    val (bg, fg) = when (status) {
        DownloadStatus.DOWNLOADING -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.primary
        DownloadStatus.COMPLETED -> EmeraldGlow.copy(alpha = 0.16f) to EmeraldGlow
        DownloadStatus.PAUSED -> AmberGold.copy(alpha = 0.16f) to AmberGold
        DownloadStatus.FAILED -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.error
        else -> MaterialTheme.colorScheme.surfaceContainerHigh to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(color = bg, shape = RoundedCornerShape(50)) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (status == DownloadStatus.COMPLETED) {
                Icon(Icons.Rounded.CheckCircle, null, tint = fg, modifier = Modifier.size(12.dp))
            }
            Text(
                text = status.label,
                style = MaterialTheme.typography.labelSmall,
                color = fg
            )
        }
    }
}
