package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.DownloadTaskEntity
import com.example.data.local.PlaybackHistoryEntity
import com.example.data.local.PrivateVideoEntity
import com.example.data.local.XivoxDatabase
import com.example.data.model.DownloadStatus
import com.example.data.model.ThemePreset
import com.example.data.prefs.SettingsRepository
import com.example.util.FormatUtils
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    private lateinit var context: Context
    private lateinit var db: XivoxDatabase

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, XivoxDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `app name matches XIVOX Player`() {
        assertEquals("XIVOX Player", context.getString(R.string.app_name))
    }

    @Test
    fun `safePipAspectRatio clamps extreme ratios within Android limits`() {
        val ultraWide = FormatUtils.safePipAspectRatio(4000, 500)
        assertTrue(ultraWide.toFloat() <= 2.39f)
        val ultraTall = FormatUtils.safePipAspectRatio(500, 4000)
        assertTrue(ultraTall.toFloat() >= 1f / 2.39f)
    }

    @Test
    fun `room persistence stores playback history favorites vault and downloads`() = runTest {
        val historyDao = db.playbackHistoryDao()
        historyDao.upsert(
            PlaybackHistoryEntity(
                uri = "content://media/external/video/media/42",
                title = "Demo MKV",
                folderName = "Movies",
                durationMs = 120_000L,
                sizeBytes = 50_000_000L,
                lastPositionMs = 45_000L,
                lastPlayedAtMs = 1000L,
                isFavorite = false
            )
        )
        historyDao.setFavorite("content://media/external/video/media/42", true)
        val favs = historyDao.observeFavorites().first()
        assertEquals(1, favs.size)
        assertEquals(45_000L, favs.first().lastPositionMs)

        val vaultDao = db.privateVideoDao()
        val insertedId = vaultDao.insert(
            PrivateVideoEntity(
                title = "Secret Clip",
                displayName = "secret.mp4",
                vaultFilePath = "/tmp/secret.mp4",
                originalUri = "content://video/1",
                durationMs = 15_000L,
                sizeBytes = 1024L,
                mimeType = "video/mp4",
                width = 1920,
                height = 1080,
                addedAtMs = 5000L
            )
        )
        assertEquals(1, vaultDao.observeAll().first().size)
        vaultDao.deleteById(insertedId)
        assertTrue(vaultDao.observeAll().first().isEmpty())

        val downloadDao = db.downloadTaskDao()
        downloadDao.upsert(
            DownloadTaskEntity(
                id = "dl_1",
                url = "https://example.com/clip.mp4",
                fileName = "clip.mp4",
                destinationFolderLabel = "Movies / XIVOX Downloads",
                destinationTreeUri = null,
                localStagingPath = "/tmp/dl_1.part",
                finalUri = null,
                totalBytes = 10_000L,
                downloadedBytes = 2_500L,
                status = DownloadStatus.PAUSED.name,
                errorMessage = null,
                createdAtMs = 100L
            )
        )
        val tasks = downloadDao.observeAll().first()
        assertEquals(1, tasks.size)
        assertEquals(DownloadStatus.PAUSED.name, tasks.first().status)
    }

    @Test
    fun `settings repository persists preferences and verifies hashed vault pin`() = runTest {
        val repo = SettingsRepository(context)
        repo.setThemePreset(ThemePreset.AMOLED_MIDNIGHT)
        repo.setDefaultPlaybackSpeed(1.5f)
        repo.setSubtitleTextSizeSp(22f)
        repo.setVaultPin("2580")

        val loaded = repo.settingsFlow.first()
        assertEquals(ThemePreset.AMOLED_MIDNIGHT, loaded.themePreset)
        assertEquals(1.5f, loaded.defaultPlaybackSpeed, 0.01f)
        assertEquals(22f, loaded.subtitleTextSizeSp, 0.01f)
        assertTrue(loaded.hasVaultPin)
        assertTrue(repo.verifyVaultPin("2580"))
        assertFalse(repo.verifyVaultPin("0000"))
        repo.clearVaultPin()
        assertFalse(repo.settingsFlow.first().hasVaultPin)
    }

    @Test
    fun `navigation across all 6 main sections and private vault works`() {
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("home_screen").assertIsDisplayed()
        composeRule.onNodeWithText("Downloader").assertIsDisplayed()
        composeRule.onNodeWithTag("nav_downloader").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_videos").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("videos_screen").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_folders").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("folders_screen").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_downloader").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("downloader_screen").assertIsDisplayed()

        // Validate invalid URL shows feedback instead of crashing
        composeRule.onNodeWithTag("downloader_url_input").performTextInput("not-a-url")
        composeRule.onNodeWithTag("downloader_screen")
            .performScrollToNode(androidx.compose.ui.test.hasTestTag("start_download_btn"))
        composeRule.onNodeWithTag("start_download_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("downloader_screen")
            .performScrollToNode(androidx.compose.ui.test.hasText("Please enter a valid http:// or https:// direct video URL"))
        composeRule.onNodeWithText("Please enter a valid http:// or https:// direct video URL").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_downloads").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("downloads_screen").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_settings").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("settings_screen")
            .performScrollToNode(androidx.compose.ui.test.hasText("About XIVOX Player"))
        composeRule.onNodeWithText("About XIVOX Player").assertIsDisplayed()
    }

    @Test
    fun `private vault pin creation unlocks vault`() {
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("home_vault_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("vault_lock_screen").assertIsDisplayed()

        composeRule.onNodeWithTag("vault_pin_input").performTextInput("1357")
        composeRule.onNodeWithTag("vault_confirm_pin_input").performTextInput("1357")
        composeRule.onNodeWithTag("vault_unlock_btn").performClick()

        composeRule.waitUntil(timeoutMillis = 5000L) {
            composeRule.onAllNodesWithTag("vault_unlocked_screen")
                .fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("vault_unlocked_screen").assertIsDisplayed()
    }
}
