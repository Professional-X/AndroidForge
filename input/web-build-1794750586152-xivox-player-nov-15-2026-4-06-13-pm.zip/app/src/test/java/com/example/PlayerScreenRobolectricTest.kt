package com.example

import android.content.Context
import android.net.Uri
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.PlaybackHistoryEntity
import com.example.data.local.XivoxDatabase
import com.example.data.media.DeviceMediaRepository
import com.example.data.model.AppSettings
import com.example.data.model.VideoItem
import com.example.ui.screens.PlayerScreen
import com.example.ui.theme.XivoxPlayerTheme
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PlayerScreenRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    private lateinit var context: Context
    private lateinit var db: XivoxDatabase

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, XivoxDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    private fun sampleVideo() = VideoItem(
        id = 101L,
        uri = "file:///tmp/xivox_nonexistent_test.mp4",
        title = "Cosmic Test Clip",
        displayName = "Cosmic_Test_Clip.mkv",
        folderName = "Movies",
        folderId = "movies_1",
        durationMs = 180_000L,
        sizeBytes = 25_000_000L,
        dateAddedSec = 10_000L,
        mimeType = "video/x-matroska",
        lastPositionMs = 35_000L
    )

    @Test
    fun `resolveVideoFromUri restores saved playback position and favorite status`() = runTest {
        val safUri = "content://com.android.providers.downloads.documents/document/777"
        db.playbackHistoryDao().upsert(
            PlaybackHistoryEntity(
                uri = safUri,
                title = "External Film",
                folderName = "External",
                durationMs = 240_000L,
                sizeBytes = 90_000_000L,
                lastPositionMs = 64_500L,
                lastPlayedAtMs = 9999L,
                isFavorite = true
            )
        )

        val repo = DeviceMediaRepository(
            context = context,
            historyDao = db.playbackHistoryDao(),
            privateVideoDao = db.privateVideoDao()
        )
        val resolved = repo.resolveVideoFromUri(Uri.parse(safUri))
        assertEquals(64_500L, resolved.lastPositionMs)
        assertTrue(resolved.isFavorite)
    }

    @Test
    fun `player screen shows controls speed options subtitle sync lock and back action`() {
        var backCalled = false
        var savedPos = -1L

        composeRule.setContent {
            XivoxPlayerTheme {
                PlayerScreen(
                    video = sampleVideo(),
                    settings = AppSettings(),
                    isInPictureInPictureMode = false,
                    onSaveProgress = { pos, _ -> savedPos = pos },
                    onBack = { backCalled = true }
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("player_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("player_play_pause_btn").assertIsDisplayed()
        composeRule.onNodeWithTag("player_rewind_btn").assertIsDisplayed()
        composeRule.onNodeWithTag("player_forward_btn").assertIsDisplayed()
        composeRule.onNodeWithTag("player_timeline_slider").assertIsDisplayed()
        composeRule.onNodeWithTag("player_current_time").assertIsDisplayed()
        composeRule.onNodeWithTag("player_total_duration").assertIsDisplayed()

        // Forward 10s updates position and saves progress
        composeRule.onNodeWithTag("player_forward_btn").performClick()
        composeRule.waitForIdle()
        assertTrue(savedPos >= 0L)

        // Speed selector dialog lists 0.5x, 1x, 1.25x, 1.5x, 2x
        composeRule.onNodeWithTag("player_speed_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Playback Speed").assertIsDisplayed()
        composeRule.onNodeWithText("0.5x").assertIsDisplayed()
        composeRule.onNodeWithText("1.25x").assertIsDisplayed()
        composeRule.onNodeWithText("1.5x").assertIsDisplayed()
        composeRule.onNodeWithText("2x").assertIsDisplayed()
        composeRule.onNodeWithText("1.5x").performClick()
        composeRule.waitForIdle()

        // Subtitles & sync dialog
        composeRule.onNodeWithTag("player_subtitle_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Subtitles & Sync").assertIsDisplayed()
        composeRule.onNodeWithText("+0.5s").performClick()
        composeRule.onNodeWithText("+0.50s").assertIsDisplayed()
        composeRule.onNodeWithText("Reset").performClick()
        composeRule.onNodeWithText("Done").performClick()
        composeRule.waitForIdle()

        // Lock controls hides main controls
        composeRule.onNodeWithTag("player_lock_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("player_play_pause_btn").assertDoesNotExist()
    }

    @Test
    fun `player back button saves progress and invokes onBack`() {
        var backCalled = false
        var savedPos = -1L

        composeRule.setContent {
            XivoxPlayerTheme {
                PlayerScreen(
                    video = sampleVideo(),
                    settings = AppSettings(),
                    isInPictureInPictureMode = false,
                    onSaveProgress = { pos, _ -> savedPos = pos },
                    onBack = { backCalled = true }
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("player_back_btn").performClick()
        composeRule.waitForIdle()
        assertTrue(backCalled)
        assertTrue(savedPos >= 0L)
    }
}
