package com.example

import com.example.util.SubtitleSyncHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class SubtitleSyncHelperTest {

    @Test
    fun `parseSrt parses cues accurately`() {
        val raw = """
            1
            00:00:01,500 --> 00:00:04,000
            Welcome to XIVOX Player

            2
            00:00:05,250 --> 00:00:08,750
            Line one
            Line two
        """.trimIndent()

        val cues = SubtitleSyncHelper.parseSrt(raw)
        assertEquals(2, cues.size)
        assertEquals(1500L, cues[0].startMs)
        assertEquals(4000L, cues[0].endMs)
        assertEquals("Welcome to XIVOX Player", cues[0].text)
        assertEquals(5250L, cues[1].startMs)
        assertEquals("Line one\nLine two", cues[1].text)
    }

    @Test
    fun `parseVtt strips header and parses mm_ss and hh_mm_ss timestamps`() {
        val raw = """
            WEBVTT

            00:02.500 --> 00:05.000
            Short timestamp cue

            00:01:10.125 --> 00:01:12.625 align:middle
            Full timestamp cue
        """.trimIndent()

        val cues = SubtitleSyncHelper.parseVtt(raw)
        assertEquals(2, cues.size)
        assertEquals(2500L, cues[0].startMs)
        assertEquals(5000L, cues[0].endMs)
        assertEquals("Short timestamp cue", cues[0].text)
        assertEquals(70125L, cues[1].startMs)
        assertEquals(72625L, cues[1].endMs)
        assertEquals("Full timestamp cue", cues[1].text)
    }

    @Test
    fun `shiftCues advances delays and clamps below zero safely`() {
        val cues = SubtitleSyncHelper.parseSrt(
            """
            1
            00:00:00,400 --> 00:00:01,000
            Too early

            2
            00:00:02,000 --> 00:00:05,000
            Second line
            """.trimIndent()
        )

        val delayed = SubtitleSyncHelper.shiftCues(cues, 1500L)
        assertEquals(2, delayed.size)
        assertEquals(1900L, delayed[0].startMs)
        assertEquals(3500L, delayed[1].startMs)

        val advanced = SubtitleSyncHelper.shiftCues(cues, -1200L)
        assertEquals(1, advanced.size)
        assertEquals(800L, advanced[0].startMs)
        assertEquals(3800L, advanced[0].endMs)
    }

    @Test
    fun `formatAsSrt round-trips timestamps cleanly`() {
        val ts = SubtitleSyncHelper.parseTimestampMs("01:02:03,045")
        assertNotNull(ts)
        assertEquals("01:02:03,045", SubtitleSyncHelper.formatSrtTimestamp(ts!!))
    }
}
