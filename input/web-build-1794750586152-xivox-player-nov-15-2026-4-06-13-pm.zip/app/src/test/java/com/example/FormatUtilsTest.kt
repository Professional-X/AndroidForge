package com.example

import com.example.data.model.SortField
import com.example.data.model.SortOrder
import com.example.data.model.VideoItem
import com.example.util.FormatUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FormatUtilsTest {

    @Test
    fun `formatDuration handles seconds minutes and hours`() {
        assertEquals("00:00", FormatUtils.formatDuration(0L))
        assertEquals("00:45", FormatUtils.formatDuration(45_000L))
        assertEquals("03:05", FormatUtils.formatDuration(185_000L))
        assertEquals("1:01:09", FormatUtils.formatDuration(3_669_000L))
    }

    @Test
    fun `formatFileSize formats bytes KB MB GB`() {
        assertEquals("0 B", FormatUtils.formatFileSize(0L))
        assertEquals("512 B", FormatUtils.formatFileSize(512L))
        assertEquals("1.5 KB", FormatUtils.formatFileSize(1536L))
        assertEquals("2.0 MB", FormatUtils.formatFileSize(2L * 1024L * 1024L))
        assertEquals("1.5 GB", FormatUtils.formatFileSize((1.5 * 1024 * 1024 * 1024).toLong()))
    }

    @Test
    fun `isValidHttpUrl accepts valid direct URLs and rejects invalid ones`() {
        assertTrue(FormatUtils.isValidHttpUrl("https://cdn.example.com/movie.mp4"))
        assertTrue(FormatUtils.isValidHttpUrl("http://192.168.1.10:8080/clip.mkv"))
        assertFalse(FormatUtils.isValidHttpUrl(""))
        assertFalse(FormatUtils.isValidHttpUrl("ftp://example.com/file.mp4"))
        assertFalse(FormatUtils.isValidHttpUrl("https://example.com/has space.mp4"))
    }

    @Test
    fun `inferFileNameFromUrl extracts sanitized filename`() {
        assertEquals(
            "sample_movie.mkv",
            FormatUtils.inferFileNameFromUrl("https://example.com/media/sample movie.mkv?token=123")
        )
        assertEquals(
            "clip.mp4",
            FormatUtils.inferFileNameFromUrl("https://example.com/clip")
        )
    }

    @Test
    fun `sortVideos sorts accurately by name size and date`() {
        val a = VideoItem(1, "u1", "Alpha", "a.mp4", "Movies", "1", 1000, 300, 100, "video/mp4")
        val b = VideoItem(2, "u2", "Beta", "b.mkv", "Movies", "1", 2000, 100, 300, "video/x-matroska")
        val c = VideoItem(3, "u3", "Gamma", "c.mp4", "Movies", "1", 3000, 200, 200, "video/mp4")

        assertEquals(
            listOf("Alpha", "Beta", "Gamma"),
            FormatUtils.sortVideos(listOf(c, a, b), SortField.NAME, SortOrder.ASCENDING).map { it.title }
        )
        assertEquals(
            listOf(300L, 200L, 100L),
            FormatUtils.sortVideos(listOf(a, b, c), SortField.SIZE, SortOrder.DESCENDING).map { it.sizeBytes }
        )
        assertEquals(
            listOf(300L, 200L, 100L),
            FormatUtils.sortVideos(listOf(a, b, c), SortField.DATE, SortOrder.DESCENDING).map { it.dateAddedSec }
        )
    }
}
