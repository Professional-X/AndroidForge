package com.pubgassistant;
import android.app.*; import android.os.*; import android.hardware.*; import android.view.*; import android.util.DisplayMetrics; import android.graphics.Color; import android.widget.*; import android.content.*;
public class MainActivity extends Activity {
 LinearLayout root; int gold=Color.rgb(214,178,76), bg=Color.rgb(12,15,10), panel=Color.rgb(25,30,20);
 TextView title(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setPadding(18,12,18,12);return t;}
 TextView value(String s){TextView t=title(s,15);t.setTextColor(Color.LTGRAY);return t;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setBackgroundColor(Color.rgb(62,72,42));return b;}
 public void onCreate(Bundle b){super.onCreate(b); showHome();}
 void base(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(18,12,18,12);root.setBackgroundColor(bg);setContentView(root);}
 void showHome(){base(); root.addView(title("🎯 PUBG СЕНСА",28));root.addView(value("Умный помощник настройки чувствительности"));root.addView(title("📱 МОЁ УСТРОЙСТВО",20)); 
  root.addView(value("Модель: "+Build.MANUFACTURER+" "+Build.MODEL)); DisplayMetrics m=getResources().getDisplayMetrics(); root.addView(value("Экран: "+m.widthPixels+" × "+m.heightPixels+" • DPI "+(int)m.densityDpi));
  root.addView(value("Android: "+Build.VERSION.RELEASE)); boolean gyro=((SensorManager)getSystemService(SENSOR_SERVICE)).getDefaultSensor(Sensor.TYPE_GYROSCOPE)!=null; root.addView(value("🌀 Гироскоп: "+(gyro?"ЕСТЬ ✓":"НЕТ")));
  Button p=btn("🎯 ПОДОБРАТЬ СЕНСУ");p.setOnClickListener(v->showSettings());root.addView(p); Button saved=btn("💾 СОХРАНЁННЫЕ ПРОФИЛИ");saved.setOnClickListener(v->showProfile());root.addView(saved);
 }
 void showSettings(){base();root.addView(title("🎯 ПОДБОР СЕНСЫ",26));root.addView(title("Режим",18));RadioGroup g=new RadioGroup(this);String[] modes={"🌀 С гироскопом","🎮 Без гироскопа"};for(String s:modes){RadioButton r=new RadioButton(this);r.setText(s);r.setTextColor(Color.WHITE);r.setTextSize(16);g.addView(r);}((RadioButton)g.getChildAt(0)).setChecked(true);root.addView(g);
  root.addView(title("Стиль игры",18));Spinner style=new Spinner(this);style.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"⚖️ Баланс","🛡️ Контроль","⚡ Агрессивный"}));root.addView(style);
  root.addView(title("Дистанция",18));Spinner dist=new Spinner(this);dist.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Смешанная","Ближняя","Средняя","Дальняя"}));root.addView(dist);
  Button make=btn("🔥 РАССЧИТАТЬ СЕНСУ");make.setOnClickListener(v->showSensitivity(g.getCheckedRadioButtonId()==g.getChildAt(0).getId()));root.addView(make);Button back=btn("← На главную");back.setOnClickListener(v->showHome());root.addView(back);
 }
 void showSensitivity(boolean gyro){base();root.addView(title("🔥 ГОТОВЫЙ ПРОФИЛЬ",26));root.addView(value("Устройство: "+Build.MANUFACTURER+" "+Build.MODEL));root.addView(value(gyro?"Режим: ГИРОСКОП":"Режим: БЕЗ ГИРОСКОПА"));
  String[] names={"TPP без прицела","FPP без прицела","Коллиматор / Red Dot","2x","3x","4x","6x","8x"};int[] vals=gyro?new int[]{300,300,320,300,250,220,110,75}:new int[]{120,110,55,45,35,25,15,10};
  LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);for(int i=0;i<names.length;i++){TextView t=value(names[i]+"  —  "+vals[i]);t.setTextSize(16);t.setPadding(12,8,12,8);box.addView(t);}root.addView(box);root.addView(title("💡 Это стартовый профиль. После теста в тренировочном режиме значения можно корректировать.",14));Button save=btn("💾 СОХРАНИТЬ ПРОФИЛЬ");save.setOnClickListener(v->Toast.makeText(this,"Профиль сохранён",Toast.LENGTH_SHORT).show());root.addView(save);Button back=btn("← Изменить параметры");back.setOnClickListener(v->showSettings());root.addView(back);
 }
 void showProfile(){base();root.addView(title("💾 ПРОФИЛИ",26));root.addView(value("Профиль устройства создаётся после расчёта сенсы."));Button back=btn("← На главную");back.setOnClickListener(v->showHome());root.addView(back);}
}