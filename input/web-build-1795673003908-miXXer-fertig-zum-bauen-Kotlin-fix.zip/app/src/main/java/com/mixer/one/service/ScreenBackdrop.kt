package com.mixer.one.service

import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.util.Log
import rikka.shizuku.Shizuku
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * A snapshot of the screen, used as the backdrop that the clear glass design refracts.
 *
 * An overlay window cannot read what is drawn behind it. With Shizuku the shell's `screencap`
 * can. The fast path is the raw frame (RGBA 8-bit or the 10-bit format many OLED phones use);
 * if that format is not understood, PNG output is used (slower, works everywhere). The overlay
 * is invisible while this runs, so it is not part of the snapshot.
 */
object ScreenBackdrop {

    private const val TAG = "ScreenBackdrop"
    private const val SCREENCAP = "/system/bin/screencap"
    private const val FORMAT_RGBA_8888 = 1
    private const val FORMAT_RGBX_8888 = 2
    private const val FORMAT_RGBA_1010102 = 43

    class Result(val bitmap: Bitmap, val inkDark: Boolean)

    /** Either a snapshot or the reason why there is none (shown to the user). */
    class Outcome(val result: Result?, val reason: String?)

    @Volatile
    private var preferPng = false

    /** Blocking (~100-800 ms): call from a background thread. */
    fun capture(): Outcome {
        return try {
            if (!Shizuku.pingBinder()) return Outcome(null, "Shizuku läuft nicht")
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                return Outcome(null, "Shizuku-Berechtigung fehlt")
            }
            val started = System.currentTimeMillis()
            var bitmap: Bitmap? = null
            var reason: String? = null

            if (!preferPng) {
                val raw = run(arrayOf(SCREENCAP))
                if (raw == null) {
                    reason = "screencap konnte nicht gestartet werden"
                } else {
                    val decoded = decodeRaw(raw)
                    if (decoded.first != null) bitmap = decoded.first
                    else {
                        reason = decoded.second
                        preferPng = true // do not try the raw format again
                    }
                }
            }
            if (bitmap == null) {
                val png = run(arrayOf(SCREENCAP, "-p"))
                bitmap = png?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
                if (bitmap == null) {
                    return Outcome(null, reason ?: "Schnappschuss nicht lesbar")
                }
            }
            Log.d(TAG, "snapshot ${bitmap.width}x${bitmap.height} in ${System.currentTimeMillis() - started} ms")
            Outcome(Result(bitmap, averageLuminance(bitmap) > 0.55f), null)
        } catch (t: Throwable) {
            Log.w(TAG, "Snapshot failed", t)
            Outcome(null, "Schnappschuss fehlgeschlagen (${t.javaClass.simpleName})")
        }
    }

    private fun run(command: Array<String>): ByteArray? = try {
        val newProcess = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        newProcess.isAccessible = true
        val process = newProcess.invoke(null, command, null, null) as Process
        val bytes = process.inputStream.readBytes()
        process.waitFor()
        bytes
    } catch (t: Throwable) {
        Log.w(TAG, "screencap run failed", t)
        null
    }

    /** @return bitmap, or null plus the reason */
    private fun decodeRaw(bytes: ByteArray): Pair<Bitmap?, String?> {
        if (bytes.size < 16) return null to "screencap lieferte keine Daten"
        val head = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val w = head.getInt(0)
        val h = head.getInt(4)
        val format = head.getInt(8)
        if (w <= 0 || h <= 0) return null to "Ungültiges Bildformat ($w x $h)"
        val pixelBytes = w * h * 4
        val header = bytes.size - pixelBytes
        if (header !in 12..64) return null to "Bildformat $format nicht unterstützt (Größe)"
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        return when (format) {
            FORMAT_RGBA_8888, FORMAT_RGBX_8888 -> {
                bitmap.copyPixelsFromBuffer(ByteBuffer.wrap(bytes, header, pixelBytes))
                bitmap to null
            }
            FORMAT_RGBA_1010102 -> {
                val pixels = IntArray(w * h)
                ByteBuffer.wrap(bytes, header, pixelBytes).order(ByteOrder.LITTLE_ENDIAN)
                    .asIntBuffer().get(pixels)
                for (i in pixels.indices) {
                    val v = pixels[i]
                    val r = v and 0x3FF
                    val g = (v shr 10) and 0x3FF
                    val b = (v shr 20) and 0x3FF
                    pixels[i] = (0xFF shl 24) or ((r shr 2) shl 16) or ((g shr 2) shl 8) or (b shr 2)
                }
                bitmap.setPixels(pixels, 0, w, 0, 0, w, h)
                bitmap to null
            }
            else -> {
                bitmap.recycle()
                null to "Bildformat $format nicht unterstützt"
            }
        }
    }

    /** Average luminance (0..1) of the area where the overlay appears (right side of the screen). */
    private fun averageLuminance(bitmap: Bitmap): Float {
        val w = bitmap.width
        val h = bitmap.height
        val landscape = w > h
        val x0 = if (landscape) (w * 0.55f).toInt() else (w * 0.35f).toInt()
        val y0 = if (landscape) (h * 0.05f).toInt() else (h * 0.20f).toInt()
        val y1 = if (landscape) (h * 0.95f).toInt() else (h * 0.75f).toInt()
        var sum = 0f
        var n = 0
        val steps = 24
        for (i in 0 until steps) {
            for (j in 0 until steps) {
                val x = x0 + (w - 1 - x0) * i / (steps - 1)
                val y = y0 + (y1 - y0) * j / (steps - 1)
                val c = bitmap.getPixel(x.coerceIn(0, w - 1), y.coerceIn(0, h - 1))
                sum += (0.2126f * Color.red(c) + 0.7152f * Color.green(c) + 0.0722f * Color.blue(c)) / 255f
                n++
            }
        }
        return sum / n
    }
}
