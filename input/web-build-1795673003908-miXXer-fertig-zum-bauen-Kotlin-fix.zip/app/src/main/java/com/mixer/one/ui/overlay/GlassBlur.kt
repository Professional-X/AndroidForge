package com.mixer.one.ui.overlay

import android.graphics.drawable.Drawable
import android.os.Build
import android.util.Log
import android.view.View
import android.view.WindowManager

/**
 * Real backdrop blur ("frosted glass") for single shapes of the overlay.
 *
 * Android has an internal way to blur only what is behind a given area of a window:
 * ViewRootImpl.createBackgroundBlurDrawable(). It is a hidden API (the app already runs with
 * HiddenApiBypass, see MixerApplication). Everything here is reflection inside try/catch: if
 * the device or Android version does not support it, [create] returns null and the glass design
 * simply falls back to the milk-glass look without blur.
 */
object GlassBlur {

    private const val TAG = "GlassBlur"

    /** @return a blur drawable for the window of [view], or null if not available. */
    fun create(view: View, radiusPx: Int): Drawable? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return null
        return try {
            val wm = view.context.getSystemService(WindowManager::class.java)
            if (wm == null || !wm.isCrossWindowBlurEnabled) {
                Log.d(TAG, "Cross-window blur is not enabled on this device")
                return null
            }
            val getRoot = View::class.java.getDeclaredMethod("getViewRootImpl")
            getRoot.isAccessible = true
            val root = getRoot.invoke(view) ?: return null
            val createDrawable = root.javaClass.getDeclaredMethod("createBackgroundBlurDrawable")
            createDrawable.isAccessible = true
            val drawable = createDrawable.invoke(root) as? Drawable ?: return null
            drawable.javaClass.getMethod("setBlurRadius", Int::class.javaPrimitiveType)
                .invoke(drawable, radiusPx)
            Log.d(TAG, "Backdrop blur available (${drawable.javaClass.name})")
            drawable
        } catch (t: Throwable) {
            Log.w(TAG, "Backdrop blur not available: ${t.javaClass.simpleName}")
            null
        }
    }

    /** Rounded corners of the blurred region (matches the glass shape). */
    fun setCornerRadius(drawable: Drawable, px: Float) {
        try {
            drawable.javaClass.getMethod("setCornerRadius", Float::class.javaPrimitiveType)
                .invoke(drawable, px)
        } catch (t: Throwable) {
            // blur still works, just without rounded corners
        }
    }
}
