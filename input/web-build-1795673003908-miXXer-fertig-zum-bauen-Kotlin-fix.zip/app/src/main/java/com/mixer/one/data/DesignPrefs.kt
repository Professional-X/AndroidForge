package com.mixer.one.data

import android.content.Context

/** The looks the volume overlay can have. */
enum class Design {
    /** Original Nothing look (dark, flat). */
    NORMAL,

    /** Light milk glass with dark ink. */
    MILK,

    /** Clear "liquid" glass: refracts what is behind it (needs Shizuku for a screen snapshot). */
    GLASS
}

/**
 * Which look the volume overlay uses. Plain SharedPreferences so the overlay service can read it
 * synchronously when it appears.
 */
object DesignPrefs {
    private const val FILE = "miXXer_design"
    private const val KEY_DESIGN = "design"
    private const val KEY_OLD_GLASS = "glass" // written by version 2.5/2.6

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun get(context: Context): Design {
        val p = prefs(context)
        p.getString(KEY_DESIGN, null)?.let { name ->
            return Design.values().firstOrNull { it.name == name } ?: Design.NORMAL
        }
        return if (p.getBoolean(KEY_OLD_GLASS, false)) Design.MILK else Design.NORMAL
    }

    fun set(context: Context, design: Design) {
        prefs(context).edit().putString(KEY_DESIGN, design.name).apply()
    }
}
