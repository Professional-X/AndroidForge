package com.mixer.one.service

import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.session.MediaSessionManager
import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Music that does not play on this phone but on another device (Spotify Connect, Cast, ...) is a
 * "remote" media session. The system's volume keys reach it; miXXer swallows the keys, so it has
 * to do the same:
 *
 *  - [adjust] sends the key press to the system exactly like a hardware key would, so a remote
 *    session (if there is one) gets it, otherwise the normal music stream.
 *  - [read] looks the remote session up (package, volume, maximum) with Shizuku, so the overlay can
 *    show its level and list the app in the mixer.
 *  - [setApproximately] moves a remote volume towards a target by sending single steps.
 */
object RemoteMedia {

    private const val TAG = "RemoteMedia"

    /** Fake session id of the remote entry in the mixer list. */
    const val SESSION_ID = -1000

    class Info(val packageName: String, val uid: Int, val current: Int, val max: Int) {
        val fraction: Float get() = if (max > 0) (current.toFloat() / max).coerceIn(0f, 1f) else 0f
    }

    @Volatile
    var latest: Info? = null
        private set
    private var latestAtMs = 0L
    private var refreshing = false
    private var lastRefreshMs = 0L
    private var setJob: Job? = null

    /** The remote info if it was read recently, else null. */
    fun fresh(maxAgeMs: Long = 4000L): Info? =
        if (SystemClock.uptimeMillis() - latestAtMs <= maxAgeMs) latest else null

    /** Like a hardware volume key: reaches a remote media session if one is playing. */
    fun adjust(context: Context, up: Boolean): Boolean = try {
        val manager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        val method = MediaSessionManager::class.java.getDeclaredMethod(
            "dispatchAdjustVolume",
            Int::class.javaPrimitiveType,
            Int::class.javaPrimitiveType,
            Int::class.javaPrimitiveType
        )
        method.isAccessible = true
        method.invoke(
            manager,
            AudioManager.USE_DEFAULT_STREAM_TYPE,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            0 // no system UI
        )
        true
    } catch (t: Throwable) {
        Log.w(TAG, "dispatchAdjustVolume not available: ${t.javaClass.simpleName}")
        false
    }

    /** Reads the playing remote session (blocking, ~100-300 ms). Needs Shizuku. */
    fun read(): Info? {
        return try {
            if (!Shizuku.pingBinder() ||
                Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED
            ) return null
            val text = runText(arrayOf("/system/bin/dumpsys", "media_session")) ?: return null
            val info = parse(text)
            latest = info
            latestAtMs = SystemClock.uptimeMillis()
            info
        } catch (t: Throwable) {
            Log.w(TAG, "read failed", t)
            null
        }
    }

    /**
     * Reads in the background (at most every 250 ms) and reports the result on the calling
     * thread's scope; [onResult] runs on the IO thread.
     */
    fun refreshAsync(scope: CoroutineScope, onResult: (Info?) -> Unit) {
        val now = SystemClock.uptimeMillis()
        if (refreshing || now - lastRefreshMs < 250L) return
        refreshing = true
        lastRefreshMs = now
        scope.launch(Dispatchers.IO) {
            try {
                onResult(read())
            } finally {
                refreshing = false
            }
        }
    }

    /**
     * Moves the remote volume towards [fraction] (0..1). There is no "set" for another app's
     * session, only steps up and down, so: learn the step size from the first step, then send as
     * many as needed and check the result.
     */
    fun setApproximately(context: Context, scope: CoroutineScope, fraction: Float) {
        setJob?.cancel()
        setJob = scope.launch(Dispatchers.IO) {
            var info = latest ?: read() ?: return@launch
            val target = (fraction.coerceIn(0f, 1f) * info.max).roundToInt()
            var step = 0
            var rounds = 0
            while (isActive && rounds++ < 8) {
                val diff = target - info.current
                if (abs(diff) <= max(1, step / 2)) break
                val before = info.current
                val count = if (step > 0) max(1, abs(diff) / step) else 1
                repeat(count) {
                    if (!adjust(context, diff > 0)) return@launch
                    delay(35)
                }
                delay(60)
                info = read() ?: return@launch
                val moved = abs(info.current - before)
                if (moved > 0) step = if (step == 0) moved else max(1, moved / count)
                else if (rounds > 3) break // no effect (fixed volume or nothing remote)
            }
        }
    }

    // ---- parsing of `dumpsys media_session` ----

    private val packageLine = Regex("""^\s*package=(\S+)""")
    private val uidLine = Regex("""ownerUid=(\d+)""")
    private val stateLine = Regex("""state=PlaybackState \{state=(\d+)""")
    private val volumeLine = Regex("""volumeType=(\w+)""")
    private val maxValue = Regex("""max=(\d+)""")
    private val currentValue = Regex("""current=(\d+)""")

    /** First session that plays and has a remote volume (volumeType 2 = REMOTE). */
    internal fun parse(text: String): Info? {
        var pendingUid = -1
        var pkg: String? = null
        var uid = -1
        var playing = false
        var found: Info? = null

        fun finish(max: Int, current: Int, remote: Boolean) {
            if (found == null && remote && playing && pkg != null && max > 0) {
                found = Info(pkg!!, uid, current, max)
            }
        }

        for (line in text.lineSequence()) {
            uidLine.find(line)?.let { pendingUid = it.groupValues[1].toInt() }
            packageLine.find(line)?.let {
                pkg = it.groupValues[1]
                uid = pendingUid
                playing = false
            }
            stateLine.find(line)?.let {
                val s = it.groupValues[1].toInt()
                playing = s == 3 || s == 6 // PLAYING or BUFFERING
            }
            val vt = volumeLine.find(line)
            if (vt != null) {
                val type = vt.groupValues[1]
                val remote = type == "2" || type.equals("REMOTE", ignoreCase = true)
                val max = maxValue.find(line)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                val current = currentValue.find(line)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                finish(max, current, remote)
            }
            if (found != null) break
        }
        return found
    }

    private fun runText(command: Array<String>): String? = try {
        val newProcess = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        newProcess.isAccessible = true
        val process = newProcess.invoke(null, command, null, null) as Process
        val out = process.inputStream.bufferedReader().use { it.readText() }
        process.waitFor()
        out
    } catch (t: Throwable) {
        Log.w(TAG, "shell failed", t)
        null
    }
}
