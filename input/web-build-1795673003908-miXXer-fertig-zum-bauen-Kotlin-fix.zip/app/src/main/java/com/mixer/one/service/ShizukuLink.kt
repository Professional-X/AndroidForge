package com.mixer.one.service

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import rikka.shizuku.Shizuku

/**
 * Takes the user to the right place in the Shizuku app so that miXXer can use it (needed for the
 * clear glass design, which takes a snapshot of the screen).
 *
 *  - Shizuku not installed: Play Store page.
 *  - Shizuku not running: the Shizuku app (start it there).
 *  - Shizuku running, miXXer not allowed yet: directly the Shizuku screen where apps get their
 *    permission ("Authorized applications"). If Android does not let us open that screen
 *    directly, Shizuku's own permission dialog is shown instead.
 */
object ShizukuLink {

    private const val TAG = "ShizukuLink"
    private const val PACKAGE = "moe.shizuku.privileged.api"
    private const val APPS_ACTIVITY = "moe.shizuku.manager.management.ApplicationManagementActivity"
    private const val REQUEST_CODE = 4712

    /** Shizuku runs and miXXer may use it. */
    fun isUsable(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        false
    }

    /** Opens what is needed and returns a short text that says what to do there. */
    fun connect(context: Context): String {
        val installed = context.packageManager.getLaunchIntentForPackage(PACKAGE) != null
        if (!installed) {
            openStore(context)
            return "Shizuku ist nicht installiert – Play Store geöffnet"
        }
        return try {
            when {
                !Shizuku.pingBinder() -> {
                    openMain(context)
                    "Shizuku läuft nicht – hier starten, danach miXXer unter „Autorisierte Apps“ erlauben"
                }
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED ->
                    "Shizuku ist schon verbunden"
                openApps(context) ->
                    "Hier miXXer in der Liste erlauben"
                else -> {
                    Shizuku.requestPermission(REQUEST_CODE)
                    "Bitte den Zugriff für miXXer erlauben"
                }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "connect failed", t)
            openMain(context)
            "Shizuku öffnen und miXXer erlauben"
        }
    }

    /** The "authorized applications" screen of the Shizuku app. False if it cannot be opened. */
    private fun openApps(context: Context): Boolean = try {
        context.startActivity(
            Intent().setClassName(PACKAGE, APPS_ACTIVITY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        true
    } catch (t: Throwable) {
        Log.w(TAG, "apps screen not reachable: ${t.javaClass.simpleName}")
        false
    }

    private fun openMain(context: Context) {
        try {
            context.packageManager.getLaunchIntentForPackage(PACKAGE)
                ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ?.let { context.startActivity(it) }
        } catch (t: Throwable) {
            Log.w(TAG, "could not open Shizuku", t)
        }
    }

    private fun openStore(context: Context) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$PACKAGE"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: ActivityNotFoundException) {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}
