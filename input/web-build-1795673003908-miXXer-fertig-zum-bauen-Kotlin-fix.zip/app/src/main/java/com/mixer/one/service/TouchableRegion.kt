package com.mixer.one.service

import android.graphics.Region
import android.util.Log
import android.view.View
import android.view.ViewTreeObserver
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Proxy

/**
 * Lets the overlay window be as wide as its widest state from the start (so it never has to be
 * resized, which makes the picture jump), while only the part that is actually drawn takes
 * touches. Everything else of the window passes touches through to the app below.
 *
 * This uses the same internal mechanism as Android's own system windows (touchable region via
 * ViewTreeObserver.OnComputeInternalInsetsListener, hidden API, reachable because the app runs
 * with HiddenApiBypass). Returns false if it is not available; the overlay then still works,
 * only the transparent part of the window absorbs touches.
 */
object TouchableRegion {

    private const val TAG = "TouchableRegion"
    private const val TOUCHABLE_INSETS_REGION = 3

    /** @param widthPx current width of the visible content, measured from the right edge */
    fun install(view: View, widthPx: () -> Int): Boolean {
        return try {
            val listenerClass =
                Class.forName("android.view.ViewTreeObserver\$OnComputeInternalInsetsListener")
            val infoClass = Class.forName("android.view.ViewTreeObserver\$InternalInsetsInfo")
            val setTouchableInsets = infoClass.getMethod("setTouchableInsets", Int::class.javaPrimitiveType)
            val regionField = infoClass.getField("touchableRegion")

            val handler = InvocationHandler { _, method, args ->
                when {
                    method.name == "onComputeInternalInsets" && args != null && args.isNotEmpty() -> {
                        val info = args[0]
                        setTouchableInsets.invoke(info, TOUCHABLE_INSETS_REGION)
                        val region = regionField.get(info) as Region
                        val w = view.width
                        val h = view.height
                        val left = (w - widthPx()).coerceIn(0, w)
                        region.set(left, 0, w, h)
                        null
                    }
                    method.returnType == Boolean::class.javaPrimitiveType -> false
                    method.returnType == Int::class.javaPrimitiveType -> 0
                    else -> null
                }
            }
            val proxy = Proxy.newProxyInstance(
                listenerClass.classLoader, arrayOf(listenerClass), handler
            )
            val add = ViewTreeObserver::class.java.getMethod(
                "addOnComputeInternalInsetsListener", listenerClass
            )
            add.invoke(view.viewTreeObserver, proxy)
            view.requestLayout()
            Log.d(TAG, "touchable region installed")
            true
        } catch (t: Throwable) {
            Log.w(TAG, "touchable region not available: ${t.javaClass.simpleName}")
            false
        }
    }
}
