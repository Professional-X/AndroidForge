package com.mixer.one.service

import android.content.Context
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Bundle // Added import
import android.os.ResultReceiver // Added import
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.runtime.Recomposer
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.AndroidUiDispatcher
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.compositionContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.mixer.one.data.AudioSession
import com.mixer.one.ui.overlay.StreamState
import com.mixer.one.ui.overlay.VolumeOverlay
import com.mixer.one.ui.theme.MixerTheme
import kotlinx.coroutines.*
import kotlin.math.roundToInt

/**
 * Self-contained Lifecycle Owner for ComposeView in Service context
 * Provides the "Heartbeat" Compose needs to run outside an Activity
 */
private class ComposeLifecycleOwner : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private val lifecycleRegistry: LifecycleRegistry = LifecycleRegistry(this)
    private val store: ViewModelStore = ViewModelStore()
    private val savedStateRegistryController: SavedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    fun performRestore(savedState: android.os.Bundle?) {
        savedStateRegistryController.performRestore(savedState)
    }

    fun handleLifecycleEvent(event: Lifecycle.Event) {
        lifecycleRegistry.handleLifecycleEvent(event)
    }

    fun destroy() {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
    }
}

/**
 * Manages the floating volume overlay using WindowManager
 * CRITICAL FIX: Self-contained lifecycle and proper window token management
 */
object OverlayManager {
    // ── Position of the Nothing-OS volume panel (reference: 1224 x 2720 screenshots) ──
    // Top edge of the first element and gap to the right screen edge, in reference px.
    // Tweak these two values to nudge the overlay after comparing with the original.
    private const val REF_WIDTH_PX = 1224f
    private const val REF_TOP_PX = 632f
    private const val REF_RIGHT_MARGIN_PX = 36f

    // Height of the fully expanded overlay in reference px (ringer bar + panel + mixer button
    // incl. gaps: 174 + 24 + 828 + 24 + 174). Used to make it fit on screen in landscape.
    private const val REF_EXPANDED_HEIGHT_PX = 1224f
    private const val EDGE_MARGIN_FRACTION = 0.04f // top/bottom margin as share of screen height

    private var windowManager: WindowManager? = null
    private var overlayContainer: FrameLayout? = null
    private var composeView: ComposeView? = null
    private var lifecycleOwner: ComposeLifecycleOwner? = null
    private var recomposer: Recomposer? = null
    private var audioManager: AudioManager? = null

    // Auto-hide timer
    private val managerScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var hideJob: Job? = null

    // State - persists across hide/show cycles
    private val currentVolume = mutableStateOf(0)
    private val maxVolume = mutableStateOf(30)
    private val isMuted = mutableStateOf(false)
    private val iconType = mutableStateOf("MUSIC")
    private val currentSessions = mutableStateOf<List<AudioSession>>(emptyList())
    
    // Phase 3.5: Smart Focus - the foreground app if detected
    private val focusedApp = mutableStateOf<AudioSession?>(null)

    // Nothing-OS panel: additional system streams + ringer mode
    private val alarmState = mutableStateOf(StreamState(0, 0, 1))
    private val ringState = mutableStateOf(StreamState(0, 0, 1))
    private val callState = mutableStateOf(StreamState(0, 0, 1))
    private val ringerMode = mutableIntStateOf(AudioManager.RINGER_MODE_NORMAL)

    // Callback for per-app volume changes (wired to Shizuku backend)
    private var onSessionVolumeChangeCallback: ((Int, Float) -> Unit)? = null
    
    // Phase 3: ResultReceiver for robust IPC volume control
    private var volumeReceiver: ResultReceiver? = null

    /**
     * Set the callback for per-app volume changes
     * This should be called by VolumeKeyService to wire up to AudioSessionManager
     */
    fun setSessionVolumeCallback(callback: (Int, Float) -> Unit) {
        Log.d("OverlayManager", "setSessionVolumeCallback: callback set")
        onSessionVolumeChangeCallback = callback
    }

    /**
     * Invoke the session volume callback
     * This method ensures the callback is always read fresh from the property
     */
    private fun invokeSessionVolumeCallback(sessionId: Int, volume: Float) {
        Log.d("OverlayManager", "invokeSessionVolumeCallback: sessionId=$sessionId, volume=$volume")
        val callback = onSessionVolumeChangeCallback
        if (callback != null) {
            Log.d("OverlayManager", "Callback exists, invoking...")
            callback.invoke(sessionId, volume)
        } else {
            Log.e("OverlayManager", "ERROR: onSessionVolumeChangeCallback is NULL!")
        }
    }

    /**
     * Show or update the overlay
     * CRITICAL: Context is passed in, not stored
     * Phase 3.5: Added focusedAppSession for Smart Focus feature
     * Phase 3: Added volumeReceiver for robust IPC volume control
     *
     * @param context Service context
     * @param volume Current global volume
     * @param newIconType Device icon type (MUSIC, BLUETOOTH, HEADPHONE)
     * @param sessions List of active audio sessions (Phase 3)
     * @param focusedAppSession The currently focused/foreground app (Phase 3.5 Smart Focus)
     * @param volumeReceiver ResultReceiver for per-app volume changes (Phase 3)
     */
    fun show(
        context: Context,
        volume: Int,
        newIconType: String = "MUSIC",
        sessions: List<AudioSession> = emptyList(),
        focusedAppSession: AudioSession? = null,
        volumeReceiver: ResultReceiver? = null
    ) {
        // Initialize managers if needed
        if (windowManager == null) {
            windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        }
        if (audioManager == null) {
            audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            maxVolume.value = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 30
        }

        // DEBUG: Log incoming state
        Log.d("OverlayManager", "show() called: volume=$volume, sessions=${sessions.size}, focused=${focusedAppSession?.appName}")

        // Update state
        currentVolume.value = volume
        isMuted.value = (volume == 0)
        iconType.value = newIconType
        currentSessions.value = sessions
        focusedApp.value = focusedAppSession
        refreshStreams()
        this.volumeReceiver = volumeReceiver // Update the receiver property
        
        // DEBUG: Verify state was set
        Log.d("OverlayManager", "State updated: currentSessions.value has ${currentSessions.value.size} items")

        if (overlayContainer == null) {
            createOverlay(context)
        }

        // Reset auto-hide timer
        scheduleHide()
    }

    /**
     * Create the overlay view with proper lifecycle
     * CRITICAL: Uses wrapper FrameLayout for proper view tree lifecycle propagation
     */
    private fun createOverlay(context: Context) {
        // Step 1: Create lifecycle owner FIRST
        val owner = ComposeLifecycleOwner()
        owner.performRestore(null)
        owner.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleOwner = owner

        // Step 2: Create wrapper FrameLayout - this holds the lifecycle for the view tree
        val container = FrameLayout(context)

        // Step 3: Set lifecycle owners on the CONTAINER (parent view)
        // This allows child views (ComposeView) to find the lifecycle via view tree traversal
        container.setViewTreeLifecycleOwner(owner)
        container.setViewTreeViewModelStoreOwner(owner)
        container.setViewTreeSavedStateRegistryOwner(owner)

        // Step 4: Create ComposeView as child
        val view = ComposeView(context)
        container.addView(view, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ))

        // Step 5: Create custom Recomposer for service context
        val coroutineContext = AndroidUiDispatcher.CurrentThread
        val newRecomposer = Recomposer(coroutineContext)
        view.compositionContext = newRecomposer
        recomposer = newRecomposer

        // Step 6: Start recomposer
        managerScope.launch(coroutineContext) {
            newRecomposer.runRecomposeAndApplyChanges()
        }

        // Step 7: Move lifecycle to STARTED state before setContent
        owner.handleLifecycleEvent(Lifecycle.Event.ON_START)
        owner.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        // Step 8: Set compose content
        val (refScale, topPx) = computeGeometry()
        view.setContent {
            MixerTheme {
                VolumeOverlay(
                    currentVolume = currentVolume.value,
                    maxVolume = maxVolume.value,
                    isMuted = isMuted.value,
                    iconType = iconType.value,
                    sessions = currentSessions.value,
                    focusedApp = focusedApp.value, // Phase 3.5: Smart Focus
                    refScale = refScale,
                    alarm = alarmState.value,
                    ring = ringState.value,
                    call = callState.value,
                    ringerMode = ringerMode.intValue,
                    onStreamVolumeChange = { stream, value -> setStreamVolume(stream, value) },
                    onRingerModeChange = { mode -> setRingerMode(mode) },
                    onVolumeChange = { newVolume ->
                        setVolume(newVolume)
                    },
                    onSessionVolumeChange = { sessionId, volume ->
                        // Phase 3: Use ResultReceiver to send data back to Service
                        Log.d("OverlayManager", "Sending volume change via ResultReceiver: id=$sessionId vol=$volume")
                        val bundle = Bundle().apply { putFloat("volume", volume) }
                        volumeReceiver?.send(sessionId, bundle)
                            ?: Log.w("OverlayManager", "ResultReceiver is null!")
                    },
                    onMuteToggle = {
                        toggleMute()
                    },
                    onInteraction = {
                        scheduleHide() // Reset timer on interaction
                    },
                    onTouchStart = {
                        cancelAutoHide() // Stop timer while user is touching
                    },
                    onTouchEnd = {
                        scheduleHide(2500L) // Start timer when touch ends
                    }
                )
            }
        }

        overlayContainer = container
        composeView = view

        // Step 9: Configure window params
        // Anchored top-right at the position of the original Nothing OS volume panel.
        // FLAG_NOT_FOCUSABLE: the overlay must never take input focus, otherwise the
        // keyboard / text field of the app underneath is interrupted. Touches still reach it.
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = (REF_RIGHT_MARGIN_PX * refScale).roundToInt()
            y = topPx
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        // Step 10: Add CONTAINER to window manager
        try {
            windowManager?.addView(container, params)
        } catch (e: Exception) {
            e.printStackTrace()
            // Cleanup on failure
            newRecomposer.cancel()
            recomposer = null
            lifecycleOwner?.destroy()
            lifecycleOwner = null
            overlayContainer = null
            composeView = null
        }
    }

    /**
     * Scale (pixels per reference pixel) and top offset (px) of the overlay.
     *
     * Portrait: width-based scale and the measured Nothing OS position (unchanged on the
     * Phone (4a)); the top offset is only pulled up if the expanded overlay would not fit.
     * Landscape: the overlay sits on the right short edge. The portrait position does not fit
     * into the screen height there, so it is scaled to the height and starts near the top.
     */
    private fun computeGeometry(): Pair<Float, Int> {
        val wm = windowManager ?: return 1f to REF_TOP_PX.roundToInt()
        val w: Int
        val h: Int
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.maximumWindowMetrics.bounds
            w = b.width()
            h = b.height()
        } else {
            val dm = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            w = dm.widthPixels
            h = dm.heightPixels
        }
        val margin = h * EDGE_MARGIN_FRACTION
        return if (w > h) {
            val scale = (h - 2 * margin) / REF_EXPANDED_HEIGHT_PX
            scale to margin.roundToInt()
        } else {
            val scale = w / REF_WIDTH_PX
            val maxTop = h - REF_EXPANDED_HEIGHT_PX * scale - margin
            scale to minOf(REF_TOP_PX * scale, maxTop).coerceAtLeast(0f).roundToInt()
        }
    }

    private fun readStream(stream: Int): StreamState {
        val am = audioManager ?: return StreamState(0, 0, 1)
        return StreamState(
            am.getStreamVolume(stream),
            am.getStreamMinVolume(stream),
            am.getStreamMaxVolume(stream)
        )
    }

    private fun refreshStreams() {
        alarmState.value = readStream(AudioManager.STREAM_ALARM)
        ringState.value = readStream(AudioManager.STREAM_RING)
        callState.value = readStream(AudioManager.STREAM_VOICE_CALL)
        ringerMode.intValue = audioManager?.ringerMode ?: AudioManager.RINGER_MODE_NORMAL
    }

    /** Set alarm / ring / call volume from the expanded panel (no system UI). */
    private fun setStreamVolume(stream: Int, value: Int) {
        try {
            audioManager?.setStreamVolume(stream, value, 0)
        } catch (e: SecurityException) {
            // e.g. ring volume 0 would toggle Do Not Disturb without policy access
            Log.w("OverlayManager", "setStreamVolume($stream, $value) refused", e)
        }
        refreshStreams()
    }

    private fun setRingerMode(mode: Int) {
        try {
            audioManager?.ringerMode = mode
        } catch (e: SecurityException) {
            Log.w("OverlayManager", "setRingerMode($mode) refused (needs DND access)", e)
        }
        refreshStreams()
    }

    /**
     * Hide and remove the overlay
     */
    fun hide() {
        hideJob?.cancel()

        overlayContainer?.let { container ->
            try {
                windowManager?.removeView(container)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Cleanup recomposer
        recomposer?.cancel()
        recomposer = null

        // Cleanup lifecycle
        lifecycleOwner?.destroy()
        lifecycleOwner = null
        overlayContainer = null
        composeView = null
    }

    /**
     * Update volume from overlay interaction
     */
    private fun setVolume(newVolume: Int) {
        currentVolume.value = newVolume
        audioManager?.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            newVolume,
            0 // No system UI
        )
    }

    /**
     * Smart mute toggle: 0 → 70%, any → 0
     */
    private fun toggleMute() {
        if (currentVolume.value == 0) {
            // Unmute: Restore to 70%
            val restoreVolume = (maxVolume.value * 0.7f).toInt()
            setVolume(restoreVolume)
        } else {
            // Mute: Set to 0
            setVolume(0)
        }
    }

    /**
     * Schedule auto-hide after delay
     * @param delayMs Delay in milliseconds before hiding (default 2500ms)
     */
    private fun scheduleHide(delayMs: Long = 2500L) {
        hideJob?.cancel()
        hideJob = managerScope.launch {
            delay(delayMs)
            hide()
        }
    }

    /**
     * Cancel auto-hide timer (when user is actively touching)
     */
    private fun cancelAutoHide() {
        hideJob?.cancel()
        hideJob = null
    }

    /**
     * Check if overlay is showing
     */
    fun isShowing(): Boolean = overlayContainer != null

    /**
     * Cleanup resources
     */
    fun cleanup() {
        hideJob?.cancel()
        managerScope.cancel()
        hide()
        windowManager = null
        audioManager = null
    }
}
