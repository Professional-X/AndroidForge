package com.example.assistivetouchgaming

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val overlayRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(13, 13, 18))
        }
        val title = TextView(this).apply {
            text = "ASSISTIVE TOUCH"
            textSize = 25f
            setTextColor(Color.rgb(255, 75, 85))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "GAMING • RED RING EDITION"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        val description = TextView(this).apply {
            text = "Nút nổi viền đỏ mô phỏng AssistiveTouch. Có thể di chuyển, chạm để mở bảng điều khiển và xem mẹo tối ưu trải nghiệm chơi game. Ứng dụng không điều khiển Free Fire."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 28)
        }
        val start = Button(this).apply {
            text = "BẬT NÚT NỔI"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                } else {
                    startActivityForResult(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")),
                        overlayRequest
                    )
                }
            }
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(description)
        root.addView(start)
        setContentView(root)
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == overlayRequest && Settings.canDrawOverlays(this)) {
            startService(Intent(this, OverlayService::class.java))
        }
    }
}
