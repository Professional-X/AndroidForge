package com.example.assistivetouchgaming

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var panel: View? = null
    private var ringThickness = 4

    override fun onCreate() {
        super.onCreate()
        startForegroundNotice()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showFloatingButton()
    }

    private fun startForegroundNotice() {
        val channelId = "assistive_touch_gaming"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                channelId, "AssistiveTouch Gaming", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }
        val notification = builder
            .setContentTitle("AssistiveTouch Gaming đang bật")
            .setContentText("Nút nổi viền đỏ đang hoạt động.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(11, notification)
    }

    private fun overlayParams(x: Int = 30, y: Int = 260): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        }
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }
    }

    private fun ringBackground(): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(95, 35, 35, 42))
            setStroke(ringThickness, Color.rgb(255, 55, 65))
        }
    }

    private fun showFloatingButton() {
        val button = TextView(this).apply {
            text = "●"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = ringBackground()
            setPadding(18, 18, 18, 18)
            elevation = 12f
        }
        val params = overlayParams()
        var downRawX = 0f
        var downRawY = 0f
        var initialX = 0
        var initialY = 0
        button.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    initialX = params.x
                    initialY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - downRawX).toInt()
                    params.y = initialY + (event.rawY - downRawY).toInt()
                    windowManager.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val distance = abs(event.rawX - downRawX) + abs(event.rawY - downRawY)
                    if (distance < 12f) togglePanel()
                    true
                }
                else -> true
            }
        }
        bubble = button
        windowManager.addView(button, params)
    }

    private fun textLine(value: String, size: Float = 14f): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(Color.WHITE)
            setPadding(6, 7, 6, 7)
        }
    }

    private fun togglePanel() {
        panel?.let {
            windowManager.removeView(it)
            panel = null
            return
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 14)
            background = GradientDrawable().apply {
                setColor(Color.rgb(22, 20, 27))
                setStroke(2, Color.rgb(255, 55, 65))
                cornerRadius = 24f
            }
            elevation = 16f
        }

        layout.addView(textLine("ASSISTIVE TOUCH", 18f))
        layout.addView(textLine("GAMING CONTROL • RED RING", 10f))
        layout.addView(textLine("Mẹo thao tác"))
        layout.addView(textLine("• Vuốt đều tay, tránh kéo giật đột ngột."))
        layout.addView(textLine("• Thử điều chỉnh độ nhạy trong cài đặt game."))
        layout.addView(textLine("• Giảm đồ họa nếu máy nóng hoặc FPS tụt."))

        layout.addView(textLine("Độ dày viền nút"))
        val thickness = SeekBar(this).apply {
            max = 8
            progress = ringThickness - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    ringThickness = progress + 1
                    bubble?.background = ringBackground()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        layout.addView(thickness)

        val close = Button(this).apply {
            text = "ĐÓNG BẢNG"
            setOnClickListener { togglePanel() }
        }
        val stop = Button(this).apply {
            text = "TẮT NÚT NỔI"
            setOnClickListener { stopSelf() }
        }
        layout.addView(close)
        layout.addView(stop)

        panel = layout
        windowManager.addView(layout, overlayParams(110, 300))
    }

    override fun onDestroy() {
        try {
            panel?.let { windowManager.removeView(it) }
            bubble?.let { windowManager.removeView(it) }
        } catch (_: Exception) { }
        panel = null
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
