# AssistiveTouch Gaming — Red Ring Edition

Ứng dụng Android mẫu mô phỏng nút nổi kiểu AssistiveTouch:
- Nút tròn trong mờ, viền đỏ.
- Kéo thả để di chuyển nút.
- Chạm nút để mở/đóng bảng hướng dẫn.
- Điều chỉnh độ dày viền đỏ.
- Tắt nút nổi từ bảng điều khiển.

## Giới hạn quan trọng
Đây là nút nổi giao diện, không phải công cụ tăng FPS hay thay đổi độ nhạy cảm ứng toàn hệ thống. Nó không thể làm tâm tự kéo nhẹ hơn, không tự động ngắm/bắn, không gửi thao tác xuyên qua nút xuống Free Fire, không đọc/sửa bộ nhớ hoặc APK game. Các mẹo trong bảng chỉ là hướng dẫn thủ công.

## Biên dịch APK
1. Cài Android Studio và JDK 17.
2. Mở thư mục dự án này bằng Android Studio.
3. Chờ Gradle Sync. Nếu được yêu cầu, cài Android SDK 35.
4. Chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug thường nằm tại `app/build/outputs/apk/debug/app-debug.apk`.
6. Cài app, mở app và cấp quyền **Hiển thị trên ứng dụng khác** để bật nút nổi.

## Cấu hình
- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.20
- Compile SDK: 35
- Min SDK: 23 (Android 6.0)
- Target SDK: 28

Ghi chú: gói ZIP này là mã nguồn dự án Android Studio, chưa phải APK đã biên dịch.
