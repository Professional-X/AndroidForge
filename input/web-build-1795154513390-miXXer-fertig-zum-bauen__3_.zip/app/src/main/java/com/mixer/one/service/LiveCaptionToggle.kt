package com.mixer.one.service

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.util.Log
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Switches the system's own automatic captions ("Live Caption") on or off.
 *
 * This does NOT implement captions itself. It flips the same system setting that the
 * original volume panel's captions button uses (Settings.Secure "odi_captions_enabled"),
 * so Nothing OS / Android does the actual work.
 *
 * Writing a secure setting needs the WRITE_SECURE_SETTINGS permission, which apps cannot get
 * on their own. Shizuku can grant it once (`pm grant`); from then on miXXer writes the setting
 * directly and Shizuku is not needed anymore for this button. Until then, Shizuku (running and
 * allowed for miXXer) does the write through the shell:
 * `settings put secure odi_captions_enabled <0|1>`.
 * Every failure is reported with a reason. The accessibility permission of miXXer is not
 * involved in this feature.
 */
object LiveCaptionToggle {

    private const val TAG = "LiveCaptionToggle"
    private const val KEY = "odi_captions_enabled"
    private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    private const val SHIZUKU_REQUEST_CODE = 4711

    /**
     * @param enabled new state if the setting was changed, otherwise null
     * @param message short text for the user (reason of a failure), or null
     */
    data class Result(val enabled: Boolean?, val message: String?)

    private data class Shell(val exit: Int, val out: String, val err: String)

    /** State as far as the app can read it (may be false if the app may not read the key). */
    fun isEnabled(context: Context): Boolean = try {
        Settings.Secure.getInt(context.contentResolver, KEY, 0) == 1
    } catch (e: Exception) {
        Log.w(TAG, "Could not read $KEY", e)
        false
    }

    /** Toggles automatic captions. Blocking: call from a background thread. */
    fun toggle(context: Context): Result {
        val tag = "miXXer ${versionName(context)}: "

        // 0. Permission already granted: write directly, no Shizuku needed
        if (context.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            return toggleDirect(context, tag)
        }

        // 1. Shizuku must be running and miXXer must be allowed to use it
        val shizukuProblem = ensureShizuku(context)
        if (shizukuProblem != null) return Result(null, tag + shizukuProblem)

        // Grant the permission once, so the next taps work without Shizuku
        runShell("pm grant ${context.packageName} ${Manifest.permission.WRITE_SECURE_SETTINGS}")

        // 2. Read the real current value from the shell
        val before = runShell("settings get secure $KEY")
            ?: return Result(null, tag + "Shizuku-Befehl konnte nicht gestartet werden")
        val current = before.out.trim() == "1"
        val target = if (current) 0 else 1

        // 3. Write it
        val put = runShell("settings put secure $KEY $target")
            ?: return Result(null, tag + "Shizuku-Befehl konnte nicht gestartet werden")
        if (put.exit != 0) {
            val reason = put.err.ifBlank { put.out }.trim().take(80)
            Log.w(TAG, "settings put failed: exit=${put.exit} $reason")
            return Result(null, tag + "Untertitel-Befehl fehlgeschlagen: $reason")
        }

        // 4. Verify
        val after = runShell("settings get secure $KEY")?.out?.trim()
        Log.d(TAG, "$KEY: $current -> $target, now=$after")
        return if (after == target.toString()) {
            Result(target == 1, null)
        } else {
            Result(null, tag + "Einstellung blieb unverändert (Wert: $after)")
        }
    }

    private fun toggleDirect(context: Context, tag: String): Result {
        return try {
            val resolver = context.contentResolver
            val current = Settings.Secure.getInt(resolver, KEY, 0) == 1
            val target = if (current) 0 else 1
            Settings.Secure.putInt(resolver, KEY, target)
            val now = Settings.Secure.getInt(resolver, KEY, -1)
            Log.d(TAG, "direct write: $KEY $current -> $target, now=$now")
            if (now == target) Result(target == 1, null)
            else Result(null, tag + "Einstellung blieb unverändert (Wert: $now)")
        } catch (e: Exception) {
            Log.w(TAG, "Direct write failed", e)
            Result(null, tag + "Schreiben fehlgeschlagen: ${e.javaClass.simpleName}")
        }
    }

    /**
     * @return a message if Shizuku cannot be used right now, otherwise null.
     * Opens the Shizuku app (to start it / allow miXXer) or shows Shizuku's own permission
     * dialog; it never sends the user to the accessibility settings.
     */
    private fun ensureShizuku(context: Context): String? = try {
        when {
            !Shizuku.pingBinder() ->
                "Shizuku läuft nicht – einmal in der Shizuku-App starten, danach geht es ohne"
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> null
            Shizuku.shouldShowRequestPermissionRationale() ->
                "Shizuku-Zugriff für miXXer fehlt – in der Shizuku-App unter Autorisierte Apps erlauben"
            else -> {
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
                "Bitte Shizuku-Zugriff erlauben und danach erneut tippen"
            }
        }
    } catch (e: Throwable) {
        Log.w(TAG, "Shizuku check failed", e)
        "Shizuku nicht erreichbar (${e.javaClass.simpleName})"
    }

    private fun openShizukuApp(context: Context) {
        try {
            context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
                ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ?.let { context.startActivity(it) }
        } catch (e: Exception) {
            Log.w(TAG, "Could not open Shizuku", e)
        }
    }

    private fun versionName(context: Context): String = try {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }

    /** Same mechanism as ShizukuRepository.executeShellCommand (Shizuku.newProcess via reflection). */
    private fun runShell(command: String): Shell? = try {
        val newProcess = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        newProcess.isAccessible = true
        val process = newProcess.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
        val out = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
        val err = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText() }
        val exit = process.waitFor()
        Log.d(TAG, "shell '$command' -> exit=$exit out='${out.trim()}' err='${err.trim()}'")
        Shell(exit, out, err)
    } catch (e: Throwable) {
        Log.w(TAG, "Shell command failed: $command", e)
        null
    }
}
