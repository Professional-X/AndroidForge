# Agri Knowledge Pool — Android starter project

An offline-first Android starter app for a personal agricultural knowledge library.

## Included in this first MVP
- Native Android UI built with Kotlin and Jetpack Compose
- Local Room database for articles, glossary terms, and bookmarks
- Add an article manually
- Add one glossary term/definition while creating an article
- Import text-based PDF files and TXT/Markdown files using Android's document picker
- Search articles by title, body, or category
- Tap underlined glossary terms in an article to open their definitions
- No login, cloud service, AI, or network permission required

## Current limitations
- This is the source project, not a compiled APK.
- DOCX import is not implemented in this starter; it is explicitly rejected.
- Scanned/image-only PDFs need OCR and are not extractable yet.
- The import error currently fails silently in the basic UI; production UX should show an error message.
- The first version only lets you add a glossary term through the article form. A dedicated glossary manager, edit/delete controls, category manager, and backup/export should be next.
- PDF extraction uses PDFBox-Android and works for PDFs with an embedded text layer.

## Build in Android Studio
1. Install Android Studio with Android SDK Platform 35 and JDK 17.
2. Open this folder as an existing Gradle project.
3. Allow Gradle to sync and download dependencies.
4. Connect an Android device with USB debugging enabled, or create an emulator.
5. Run the `app` configuration.

To build an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Main files
- `MainActivity.kt`: screens, article reader, import flow, term highlighting
- `data/Knowledge.kt`: Room entities, DAO, database

## Suggested next build steps
1. Add a dedicated glossary screen and full term CRUD.
2. Add DOCX import and visible import-error handling.
3. Add category/subcategory browsing and bookmarks screen.
4. Add backup/restore to a local JSON file.
5. Add a richer reader with headings, lists, and internal article links.
