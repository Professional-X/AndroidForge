package com.example.agriknowledge

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.room.Room
import com.example.agriknowledge.data.*
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : ComponentActivity() {
    private lateinit var db: KnowledgeDatabase
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        db = Room.databaseBuilder(applicationContext, KnowledgeDatabase::class.java, "agri-knowledge.db").build()
        setContent { MaterialTheme { AgriApp(db, ::readDocument) } }
    }

    private fun readDocument(uri: Uri, mime: String?): Pair<String, String> {
        val name = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else "Imported document"
        } ?: "Imported document"
        val text = contentResolver.openInputStream(uri)?.use { input ->
            when {
                mime == "application/pdf" || name.endsWith(".pdf", true) -> {
                    PDDocument.load(input).use { doc -> PDFTextStripper().getText(doc) }
                }
                mime == "text/plain" || name.endsWith(".txt", true) || name.endsWith(".md", true) ->
                    BufferedReader(InputStreamReader(input)).readText()
                else -> throw IllegalArgumentException("This first version supports text (.txt/.md) and text-based PDFs. DOCX support can be added next.")
            }
        } ?: ""
        return name.substringBeforeLast('.', name) to text
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AgriApp(db: KnowledgeDatabase, importReader: (Uri, String?) -> Pair<String, String>) {
    val dao = db.dao()
    val scope = rememberCoroutineScope()
    val articles by dao.articles().collectAsState(initial = emptyList())
    val terms by dao.terms().collectAsState(initial = emptyList())
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Article?>(null) }
    var termDialog by remember { mutableStateOf<Term?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }
    var newCategory by remember { mutableStateOf("General Agriculture") }
    var newBody by remember { mutableStateOf("") }
    var newTerm by remember { mutableStateOf("") }
    var newDefinition by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<Article>>(emptyList()) }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val mime = contentTypeFor(uri)
                val (title, body) = importReader(uri, mime)
                scope.launch { dao.saveArticle(Article(title = title, category = "Imported", body = body, sourceName = title)) }
            } catch (e: Exception) { /* User gets a visible message in the editor version. */ }
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Agri Knowledge Pool", fontWeight = FontWeight.Bold) }, actions = {
            IconButton(onClick = { showSearch = !showSearch }) { Icon(Icons.Default.Search, "Search") }
            IconButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, "Add knowledge") }
        })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
            if (showSearch) {
                OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Search topics and terms") }, singleLine = true)
                LaunchedEffect(query) { dao.searchArticles(query).collect { searchResults = it } }
            }
            if (selected != null) {
                val article = selected!!
                Text("‹ All topics", modifier = Modifier.clickable { selected = null }.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.primary)
                Text(article.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(article.category, style = MaterialTheme.typography.labelMedium)
                Row {
                    TextButton(onClick = { scope.launch { dao.bookmark(article.id, !article.isBookmarked) ; selected = dao.article(article.id) } }) { Icon(Icons.Default.Bookmark, null); Text(if (article.isBookmarked) "Saved" else "Save") }
                }
                LazyColumn { item { LinkedArticleText(article.body, terms) { termName -> scope.launch { termDialog = dao.term(termName) } } } }
            } else {
                Text("Your offline agricultural library", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
                Text("Topics: ${articles.size}   •   Glossary terms: ${terms.size}", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 12.dp)) {
                    Button(onClick = { showAdd = true }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("Write topic") }
                    OutlinedButton(onClick = { importLauncher.launch(arrayOf("text/plain", "text/markdown", "application/pdf")) }) { Text("Import PDF / text") }
                }
                if (articles.isEmpty()) {
                    Text("Start by importing a text-based PDF or text file, or write your first topic. Scanned PDFs need OCR and are not extracted in this version.", modifier = Modifier.padding(vertical = 20.dp))
                }
                val shown = if (showSearch && query.isNotBlank()) searchResults else articles
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(shown) { article ->
                        ElevatedCard(Modifier.fillMaxWidth().clickable { selected = article }) {
                            Column(Modifier.padding(16.dp)) {
                                Text(article.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Text(article.category, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                Text(article.body.take(130).replace('\n', ' ') + if (article.body.length > 130) "…" else "", maxLines = 2, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) AlertDialog(
        onDismissRequest = { showAdd = false },
        title = { Text("Add knowledge") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(newTitle, { newTitle = it }, label = { Text("Topic title") }, singleLine = true)
            OutlinedTextField(newCategory, { newCategory = it }, label = { Text("Category") }, singleLine = true)
            OutlinedTextField(newBody, { newBody = it }, label = { Text("Article text") }, minLines = 5)
            Divider()
            Text("Optional: add one glossary term", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(newTerm, { newTerm = it }, label = { Text("Term") }, singleLine = true)
            OutlinedTextField(newDefinition, { newDefinition = it }, label = { Text("Definition") }, minLines = 2)
        } },
        confirmButton = { TextButton(onClick = {
            if (newTitle.isNotBlank() && newBody.isNotBlank()) scope.launch {
                dao.saveArticle(Article(title = newTitle.trim(), category = newCategory.ifBlank { "General Agriculture" }, body = newBody.trim()))
                if (newTerm.isNotBlank() && newDefinition.isNotBlank()) dao.saveTerm(Term(newTerm.trim(), newDefinition.trim()))
                newTitle = ""; newCategory = "General Agriculture"; newBody = ""; newTerm = ""; newDefinition = ""; showAdd = false
            }
        }) { Text("Save") } },
        dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } }
    )
    if (termDialog != null) AlertDialog(onDismissRequest = { termDialog = null }, title = { Text(termDialog!!.name) }, text = { Text(termDialog!!.definition) }, confirmButton = { TextButton(onClick = { termDialog = null }) { Text("Close") } })
}

@Composable
private fun LinkedArticleText(body: String, terms: List<Term>, onTermClick: (String) -> Unit) {
    val annotated = remember(body, terms) {
        val builder = buildAnnotatedString { append(body) }
        terms.sortedByDescending { it.name.length }.forEach { term ->
            var start = 0
            while (start < body.length) {
                val index = body.indexOf(term.name, start, ignoreCase = true)
                if (index < 0) break
                val end = index + term.name.length
                builder.addStyle(SpanStyle(color = androidx.compose.ui.graphics.Color(0xFF176B45), textDecoration = TextDecoration.Underline, fontWeight = FontWeight.SemiBold), index, end)
                builder.addStringAnnotation("term", term.name, index, end)
                start = end
            }
        }
        builder.toAnnotatedString()
    }
    ClickableText(text = annotated, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), style = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface, lineHeight = MaterialTheme.typography.bodyLarge.lineHeight * 1.35f), onClick = { offset ->
        annotated.getStringAnnotations("term", offset, offset).firstOrNull()?.let { onTermClick(it.item) }
    })
}

private fun contentTypeFor(uri: Uri): String? = null
