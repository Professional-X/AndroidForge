package com.example.agriknowledge.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "articles")
data class Article(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String,
    val body: String,
    val sourceName: String = "Created in app",
    val isBookmarked: Boolean = false
)

@Entity(tableName = "terms")
data class Term(
    @PrimaryKey val name: String,
    val definition: String,
    val examples: String = "",
    val relatedTerms: String = ""
)

@Dao
interface KnowledgeDao {
    @Query("SELECT * FROM articles ORDER BY title COLLATE NOCASE") fun articles(): Flow<List<Article>>
    @Query("SELECT * FROM articles WHERE id = :id LIMIT 1") suspend fun article(id: Long): Article?
    @Query("SELECT * FROM articles WHERE title LIKE '%' || :q || '%' OR body LIKE '%' || :q || '%' OR category LIKE '%' || :q || '%' ORDER BY title") fun searchArticles(q: String): Flow<List<Article>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveArticle(article: Article): Long
    @Query("UPDATE articles SET isBookmarked = :saved WHERE id = :id") suspend fun bookmark(id: Long, saved: Boolean)
    @Query("SELECT * FROM terms ORDER BY name COLLATE NOCASE") fun terms(): Flow<List<Term>>
    @Query("SELECT * FROM terms WHERE name = :name COLLATE NOCASE LIMIT 1") suspend fun term(name: String): Term?
    @Query("SELECT * FROM terms WHERE name LIKE '%' || :q || '%' OR definition LIKE '%' || :q || '%' ORDER BY name") fun searchTerms(q: String): Flow<List<Term>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveTerm(term: Term)
}

@Database(entities = [Article::class, Term::class], version = 1, exportSchema = false)
abstract class KnowledgeDatabase : RoomDatabase() {
    abstract fun dao(): KnowledgeDao
}
