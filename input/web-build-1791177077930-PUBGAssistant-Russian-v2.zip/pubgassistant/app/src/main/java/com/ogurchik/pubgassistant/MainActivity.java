package com.ogurchik.pubgassistant;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.hardware.*;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
 int gold=Color.rgb(214,166,58), olive=Color.rgb(92,107,58), panel=Color.rgb(24,30,20), text=Color.rgb(242,238,218); LinearLayout root, results; Spinner style,distance; Switch gyro;
 TextView info;
 int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);} TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextColor(text);t.setTextSize(sp);t.setPadding(dp(8),dp(6),dp(8),dp(6));return t;}
 @Override public void onCreate(Bundle b){super.onCreate(b); build();}
 void build(){
  root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(12),dp(16),dp(18));root.setBackgroundResource(com.ogurchik.pubgassistant.R.drawable.bg);
  ScrollView sv=new ScrollView(this); sv.addView(root); setContentView(sv);
  TextView title=tv("PUBG SENSITIVITY",25);title.setTextColor(gold);title.setTypeface(null,1);root.addView(title);
  TextView sub=tv("ASSISTANT  •  v2.0",12);sub.setTextColor(olive);root.addView(sub);
  info=tv("",15);info.setBackgroundColor(panel);root.addView(info,new LinearLayout.LayoutParams(-1,dp(110)));
  root.addView(tv("\nПрофиль подбора",20));
  gyro=new Switch(this);gyro.setText("Использовать гироскоп");gyro.setTextColor(text);gyro.setTextSize(16);gyro.setChecked(hasGyro());root.addView(gyro);
  root.addView(tv("Стиль игры",14));style=spin(new String[]{"Спокойный","Сбалансированный","Агрессивный"});root.addView(style);
  root.addView(tv("Основная дистанция",14));distance=spin(new String[]{"Смешанная","Ближняя","Средняя","Дальняя"});root.addView(distance);
  Button go=button("🎯  ПОДОБРАТЬ СЕНСУ");root.addView(go);go.setOnClickListener(v->calculate());
  results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);results.setPadding(0,dp(12),0,0);root.addView(results);
  Button again=button("↻  ПЕРЕСЧИТАТЬ");root.addView(again);again.setOnClickListener(v->calculate());
  Button about=button("ℹ  О ПРИЛОЖЕНИИ");root.addView(about);about.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("PUBG Sensitivity Assistant").setMessage("Русский помощник для подбора сенситивити. Приложение определяет характеристики телефона и датчики, но не изменяет настройки PUBG автоматически.").setPositiveButton("ОК",null).show());
  detect();
 }
 Spinner spin(String[] a){Spinner s=new Spinner(this);ArrayAdapter<String>x=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a);s.setAdapter(x);return s;}
 Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setBackgroundColor(olive);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.setMargins(0,dp(8),0,0);b.setLayoutParams(p);return b;}
 boolean hasGyro(){SensorManager sm=(SensorManager)getSystemService(SENSOR_SERVICE);return sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)!=null;}
 void detect(){String model=Build.MANUFACTURER+" "+Build.MODEL;float hz=60;Display d=getWindowManager().getDefaultDisplay();try{hz=d.getRefreshRate();}catch(Exception ignored){} String g=hasGyro()?"ЕСТЬ 🌀":"НЕТ";info.setText("  📱 Устройство: "+model+"\n  🖥️ Экран: "+getResources().getDisplayMetrics().widthPixels+"×"+getResources().getDisplayMetrics().heightPixels+"  •  "+String.format(Locale.US,"%.0f Гц",hz)+"\n  🌀 Гироскоп: "+g+"\n  🤖 Android: "+Build.VERSION.RELEASE);}
 void calculate(){int base=gyro.isChecked()?300:100;String st=style.getSelectedItem().toString(),di=distance.getSelectedItem().toString();if(st.startsWith("Спокой"))base-=20;if(st.startsWith("Агрессив"))base+=25;if(di.equals("Ближняя"))base+=20;if(di.equals("Дальняя"))base-=25;int[] vals={Math.min(400,Math.max(50,base+20)),Math.min(400,Math.max(50,base+5)),Math.min(400,Math.max(50,base-25)),Math.min(400,Math.max(50,base-55)),Math.min(400,Math.max(50,base-130)),Math.min(400,Math.max(50,base-190))};String[] names={gyro.isChecked()?"Гироскоп":"ADS","Red Dot / Коллиматор","2x","3x","4x","6x / 8x"};results.removeAllViews();TextView h=tv("ГОТОВЫЙ ПРОФИЛЬ",19);h.setTextColor(gold);results.addView(h);for(int i=0;i<vals.length;i++){TextView r=tv("  "+names[i]+"  →  "+vals[i],16);r.setBackgroundColor(panel);results.addView(r,new LinearLayout.LayoutParams(-1,dp(44)));}}
}
