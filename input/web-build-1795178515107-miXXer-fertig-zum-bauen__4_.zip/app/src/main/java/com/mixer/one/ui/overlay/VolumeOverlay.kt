package com.mixer.one.ui.overlay

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Alarm
import androidx.compose.material.icons.outlined.Bluetooth
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.ClosedCaption
import androidx.compose.material.icons.outlined.ClosedCaptionDisabled
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.Equalizer
import androidx.compose.material.icons.outlined.Headphones
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.MusicOff
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Vibration
import androidx.compose.material.icons.outlined.VolumeOff
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.TextUnit
import androidx.core.graphics.drawable.toBitmap
import com.mixer.one.R
import com.mixer.one.data.AudioSession
import com.mixer.one.service.LiveCaptionToggle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

private const val TAG = "VolumeOverlay"

/**
 * Nothing-OS-style volume panel.
 *
 * All geometry below is expressed in "reference pixels" measured from native
 * Nothing Phone (4a) screenshots (1224 x 2720). [refScale] converts reference
 * pixels to real pixels, so the layout is exact on any density.
 */
private object G {
    const val UNIT = 174          // pill width, column width, circle diameter
    const val RIGHT_MARGIN = 36   // gap to the right screen edge (inside the window, so it can slide out)
    const val GAP = 24            // gap between stacked elements
    const val PANEL_W = 696       // expanded panel / ringer bar width (4 x UNIT)
    const val PANEL_RADIUS = 60   // corner radius of the expanded panel
    const val TRACK_H = 480       // dot track height
    const val DOT_COUNT = 16
    const val DOT_D = 12          // dot diameter
    const val DOT_PITCH = 30
    const val DOT_FIRST = 5.5f    // centre of first dot, from track top
    const val BAR_W = 36          // white level bar width
    const val ICON_BOX = 72       // vector icon box (glyph is ~60)
    const val BITMAP_ICON = 96    // original Nothing icon bitmaps (96 px crops)
    const val SEGMENT = 126       // selected ringer-mode circle
    const val MIXER_MAX_W = 432   // mixer panel max width (2.5 columns)
}

private object NOS {
    val Surface = Color(0xFF303030)
    val Light = Color(0xFFF1F1F1)
    val Icon = Color(0xFFBFBFBF)
    val IconDim = Color(0xFFA2A2A2)
    val Label = Color(0xFFE2E2E2)
    val Dot = Color(0xFF474747)
    val Focus = Color(0xFFD71920)
}

/**
 * Vertical metrics of the tall pill / panel, measured from the original Nothing OS panel.
 * Portrait: 1224 x 2720 screenshots. Landscape: 2720 x 1224 screenshot (shorter panel).
 * All values in reference px, from the top edge of the pill / panel.
 */
private data class Geo(val panelH: Int, val trackTop: Int, val iconCy: Int, val labelCy: Int) {
    companion object {
        val Portrait = Geo(panelH = 828, trackTop = 72, iconCy = 625, labelCy = 740)
        val Landscape = Geo(panelH = 762, trackTop = 48, iconCy = 599, labelCy = 702)
    }
}

private val LocalGeo = compositionLocalOf { Geo.Portrait }
private val LocalRef = compositionLocalOf { 1f }

@Composable
private fun rp(v: Number): Dp {
    val density = LocalDensity.current
    val s = LocalRef.current
    return with(density) { (v.toFloat() * s).toDp() }
}

@Composable
private fun rsp(v: Number): TextUnit {
    val density = LocalDensity.current
    val s = LocalRef.current
    return with(density) { (v.toFloat() * s).toSp() }
}

/** Value + range of one audio stream. */
data class StreamState(val value: Int, val min: Int, val max: Int) {
    val fraction: Float
        get() = if (max > min) ((value - min).toFloat() / (max - min)).coerceIn(0f, 1f) else 0f
}

@Composable
fun VolumeOverlay(
    currentVolume: Int,
    maxVolume: Int,
    isMuted: Boolean = false,
    iconType: String = "MUSIC",
    sessions: List<AudioSession> = emptyList(),
    focusedApp: AudioSession? = null,
    onVolumeChange: (Int) -> Unit = {},
    onSessionVolumeChange: (Int, Float) -> Unit = { _, _ -> },
    onMuteToggle: () -> Unit = {},
    onInteraction: () -> Unit = {},
    onTouchStart: () -> Unit = {},
    onTouchEnd: () -> Unit = {},
    refScale: Float = 1f,
    landscape: Boolean = false,
    visible: Boolean = true,
    onWindowWidth: (Int) -> Unit = {},
    onRequestHide: () -> Unit = {},
    alarm: StreamState = StreamState(0, 0, 1),
    notification: StreamState = StreamState(0, 0, 1),
    ring: StreamState = StreamState(0, 0, 1),
    ringerMode: Int = AudioManager.RINGER_MODE_NORMAL,
    onStreamVolumeChange: (Int, Int) -> Unit = { _, _ -> },
    onRingerModeChange: (Int) -> Unit = {}
) {
    CompositionLocalProvider(
        LocalRef provides refScale,
        LocalGeo provides (if (landscape) Geo.Landscape else Geo.Portrait)
    ) {
        val context = LocalContext.current
        val haptic = LocalHapticFeedback.current
        val captionScope = rememberCoroutineScope()
        var captionsOn by remember { mutableStateOf(LiveCaptionToggle.isEnabled(context)) }
        var expanded by remember { mutableStateOf(false) }
        var mixerOpen by remember { mutableStateOf(false) }

        // Tell the window how wide it has to be. Shrinking waits for the close animations.
        val targetWidthRef = G.RIGHT_MARGIN +
                (if (expanded) G.PANEL_W else G.UNIT) +
                (if (expanded && mixerOpen) mixerWidthRef(sessions.size) + G.GAP else 0)
        var appliedWidthRef by remember { mutableIntStateOf(G.RIGHT_MARGIN + G.UNIT) }
        LaunchedEffect(targetWidthRef) {
            if (targetWidthRef < appliedWidthRef) delay(350)
            appliedWidthRef = targetWidthRef
            onWindowWidth(targetWidthRef)
        }

        // Keep the captions button in sync with the real system setting
        // (e.g. when captions are switched off in the Settings app)
        DisposableEffect(Unit) {
            val resolver = context.contentResolver
            val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
                override fun onChange(selfChange: Boolean) {
                    LiveCaptionToggle.readEnabled(context)?.let { captionsOn = it }
                }
            }
            try {
                resolver.registerContentObserver(LiveCaptionToggle.settingUri(), false, observer)
            } catch (e: Exception) {
                Log.w(TAG, "Could not observe captions setting", e)
            }
            onDispose {
                try {
                    resolver.unregisterContentObserver(observer)
                } catch (e: Exception) {
                    Log.w(TAG, "Could not unregister captions observer", e)
                }
            }
        }
        val ordered = remember(sessions, focusedApp) {
            sessions.sortedByDescending { it.uid == focusedApp?.uid }
        }
        val progress by animateFloatAsState(
            targetValue = if (expanded) 1f else 0f,
            animationSpec = tween(300, easing = FastOutSlowInEasing),
            label = "expand"
        )

        val music = StreamState(currentVolume, 0, maxVolume)
        val mediaIcon: Any = when {
            iconType == "BLUETOOTH" -> Icons.Outlined.Bluetooth
            iconType == "HEADPHONE" -> Icons.Outlined.Headphones
            currentVolume == 0 -> R.drawable.nos_ic_note_off
            else -> R.drawable.nos_ic_note
        }
        val mediaTint = NOS.IconDim

        // Silent mode toggles Do Not Disturb, which Android only allows with DND access.
        // Without it, open the system page where it can be granted once.
        val requestRingerMode: (Int) -> Unit = { mode ->
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            // Entering OR leaving silent toggles Do Not Disturb, which needs DND access.
            val touchesSilent = mode == AudioManager.RINGER_MODE_SILENT ||
                    ringerMode == AudioManager.RINGER_MODE_SILENT
            if (touchesSilent && !nm.isNotificationPolicyAccessGranted) {
                Toast.makeText(
                    context,
                    "Bitte miXXer Zugriff auf „Nicht stören“ erlauben",
                    Toast.LENGTH_LONG
                ).show()
                try {
                    context.startActivity(
                        Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) {
                    Log.w(TAG, "Could not open DND access settings", e)
                }
            } else {
                onRingerModeChange(mode)
            }
        }

        fun streamSetter(stream: Int, state: StreamState): (Float) -> Unit = { f ->
            val v = state.min + (f * (state.max - state.min)).roundToInt()
            if (v != state.value) {
                onInteraction()
                onStreamVolumeChange(stream, v)
            }
        }
        val onMusicFraction: (Float) -> Unit = { f ->
            val v = (f * maxVolume).roundToInt().coerceIn(0, maxVolume)
            if (v != currentVolume) {
                onInteraction()
                onVolumeChange(v)
            }
        }

        // Slides in from / out to the right screen edge. The window ends at the screen edge,
        // so the content leaves the screen completely.
        val visibleState = remember { MutableTransitionState(false) }
        LaunchedEffect(visible) { visibleState.targetState = visible }

        AnimatedVisibility(
            visibleState = visibleState,
            enter = slideInHorizontally(
                animationSpec = tween(280, easing = FastOutSlowInEasing),
                initialOffsetX = { it }
            ) + fadeIn(tween(160)),
            exit = slideOutHorizontally(
                animationSpec = tween(240, easing = FastOutSlowInEasing),
                targetOffsetX = { it }
            ) + fadeOut(tween(200))
        ) {
        Row(
            modifier = Modifier
                .wrapContentSize()
                .padding(end = rp(G.RIGHT_MARGIN))
                .trackTouch(onTouchStart, onTouchEnd),
            verticalAlignment = Alignment.Top
        ) {
            LaunchedEffect(expanded) {
                if (expanded) captionsOn = LiveCaptionToggle.isEnabled(context)
            }
            // Mixer panel: opens to the LEFT of the system panel, top-aligned with it
            AnimatedVisibility(
                visible = expanded && mixerOpen,
                enter = fadeIn(tween(200)) + expandHorizontally(
                    expandFrom = Alignment.End,
                    animationSpec = tween(300, easing = FastOutSlowInEasing)
                ),
                exit = fadeOut(tween(150)) + shrinkHorizontally(
                    shrinkTowards = Alignment.End,
                    animationSpec = tween(250, easing = FastOutSlowInEasing)
                )
            ) {
                Row {
                    Column {
                        Spacer(Modifier.height(rp(G.UNIT + G.GAP)))
                        MixerPanel(
                            sessions = ordered,
                            focusedApp = focusedApp,
                            onSessionVolumeChange = { id, v ->
                                onInteraction()
                                onSessionVolumeChange(id, v)
                            },
                            onTouch = onInteraction
                        )
                    }
                    Spacer(Modifier.width(rp(G.GAP)))
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                TopBar(
                    progress = progress,
                    ringerMode = ringerMode,
                    onTouch = onInteraction,
                    onMode = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onInteraction()
                        requestRingerMode(it)
                    },
                    onCycle = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onInteraction()
                        requestRingerMode(
                            when (ringerMode) {
                                AudioManager.RINGER_MODE_NORMAL -> AudioManager.RINGER_MODE_VIBRATE
                                AudioManager.RINGER_MODE_VIBRATE -> AudioManager.RINGER_MODE_SILENT
                                else -> AudioManager.RINGER_MODE_NORMAL
                            }
                        )
                    }
                )
                Spacer(Modifier.height(rp(G.GAP)))

                AnimatedContent(
                    targetState = expanded,
                    transitionSpec = {
                        (fadeIn(tween(120)) togetherWith fadeOut(tween(100)))
                            .using(SizeTransform(clip = false) { _, _ -> snap() })
                    },
                    contentAlignment = Alignment.TopEnd,
                    label = "body"
                ) { isExpanded ->
                    if (!isExpanded) {
                        MediaPill(
                            music = music,
                            mediaIcon = mediaIcon,
                            mediaTint = mediaTint,
                            onFraction = onMusicFraction,
                            onTouch = onInteraction,
                            onMuteToggle = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onInteraction()
                                onMuteToggle()
                            },
                            onExpand = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                expanded = true
                                onInteraction()
                            }
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.End) {
                            SystemPanel(
                                alarm = alarm,
                                notification = notification,
                                ring = ring,
                                ringerMode = ringerMode,
                                music = music,
                                mediaIcon = mediaIcon,
                                mediaTint = mediaTint,
                                onAlarm = streamSetter(AudioManager.STREAM_ALARM, alarm),
                                onNotification = streamSetter(AudioManager.STREAM_NOTIFICATION, notification),
                                onRing = streamSetter(AudioManager.STREAM_RING, ring),
                                onMusic = onMusicFraction,
                                onMuteToggle = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    onInteraction()
                                    onMuteToggle()
                                },
                                onTouch = onInteraction,
                                onMore = {
                                    onInteraction()
                                    try {
                                        context.startActivity(
                                            Intent(Settings.ACTION_SOUND_SETTINGS)
                                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        )
                                    } catch (e: Exception) {
                                        Log.w(TAG, "Could not open sound settings", e)
                                    }
                                }
                            )
                        }
                    }
                }
                if (expanded) {
                    Spacer(Modifier.height(rp(G.GAP)))
                    // Right: the original Nothing OS live-caption button (stays where it was).
                    // Left of it: the miXXer mixer button.
                    Row(horizontalArrangement = Arrangement.spacedBy(rp(G.GAP))) {
                        MixerButton(
                            active = mixerOpen,
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                mixerOpen = !mixerOpen
                                onInteraction()
                            }
                        )
                        CaptionButton(
                            active = captionsOn,
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onInteraction()
                                captionScope.launch {
                                    // Toggles Nothing OS's own "automatic captions" setting
                                    val result = withContext(Dispatchers.IO) { LiveCaptionToggle.toggle(context) }
                                    result.enabled?.let { captionsOn = it }
                                    result.message?.let {
                                        Toast.makeText(context, it, Toast.LENGTH_LONG).show()
                                    }
                                    // Captions just activated: get the volume panel out of the way
                                    if (result.enabled == true) {
                                        delay(150)
                                        onRequestHide()
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
        }
    }
}

// ───────────────────────── Top bar (ringer mode) ─────────────────────────

private fun ringerIcon(mode: Int): Int = when (mode) {
    AudioManager.RINGER_MODE_SILENT -> R.drawable.nos_ic_ringer_silent
    AudioManager.RINGER_MODE_VIBRATE -> R.drawable.nos_ic_ringer_vibrate
    else -> R.drawable.nos_ic_ringer_normal
}

@Composable
private fun TopBar(
    progress: Float,
    ringerMode: Int,
    onTouch: () -> Unit,
    onMode: (Int) -> Unit,
    onCycle: () -> Unit
) {
    val width = rp(G.UNIT) + (rp(G.PANEL_W) - rp(G.UNIT)) * progress
    Box(
        modifier = Modifier
            .size(width, rp(G.UNIT))
            .clip(RoundedCornerShape(50))
            .background(NOS.Surface)
    ) {
        // Collapsed: single circle button showing the current mode
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .size(rp(G.UNIT), rp(G.UNIT))
                .alpha(1f - progress)
                .then(if (progress < 0.5f) Modifier.tap(onCycle) else Modifier),
            contentAlignment = Alignment.Center
        ) {
            NIcon(ringerIcon(ringerMode), NOS.Light)
        }

        // Expanded: laid out at full width and clipped by the growing pill
        if (progress > 0.02f) {
            RingerSelector(
                ringerMode = ringerMode,
                enabled = progress > 0.5f,
                onSelect = onMode,
                onTouch = onTouch,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .requiredSize(rp(G.PANEL_W), rp(G.UNIT))
                    .alpha(progress)
            )
        }
    }
}

private val RINGER_MODES = intArrayOf(
    AudioManager.RINGER_MODE_SILENT,   // left
    AudioManager.RINGER_MODE_VIBRATE,  // middle
    AudioManager.RINGER_MODE_NORMAL    // right
)

/** Segment centres, in reference px from the left edge of the 696 px bar. */
private val SEGMENT_CENTERS = floatArrayOf(87f, 348f, 609f)

/**
 * Three-way ringer selector with a sliding indicator.
 *
 * - Tap: the indicator glides to the tapped segment.
 * - Hold / drag: the indicator follows the finger inside the bar.
 * - Finger leaves the bar: the indicator glides to the nearest segment.
 * - Release: the nearest segment is selected.
 */
@Composable
private fun RingerSelector(
    ringerMode: Int,
    enabled: Boolean,
    onSelect: (Int) -> Unit,
    onTouch: () -> Unit,
    modifier: Modifier = Modifier
) {
    val s = LocalRef.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val currentMode by rememberUpdatedState(ringerMode)
    val currentEnabled by rememberUpdatedState(enabled)
    val currentOnSelect by rememberUpdatedState(onSelect)
    val currentOnTouch by rememberUpdatedState(onTouch)

    fun centerOf(mode: Int): Float =
        SEGMENT_CENTERS[RINGER_MODES.indexOf(mode).coerceAtLeast(0)] * s

    val indicator = remember { Animatable(centerOf(ringerMode)) }
    var touching by remember { mutableStateOf(false) }
    var generation by remember { mutableIntStateOf(0) }
    val glide = spring<Float>(
        dampingRatio = Spring.DampingRatioNoBouncy,
        stiffness = Spring.StiffnessMedium
    )
    val follow = spring<Float>(
        dampingRatio = Spring.DampingRatioNoBouncy,
        stiffness = Spring.StiffnessHigh
    )

    // Follow the real mode (also when it changes from outside, e.g. the hardware switch)
    LaunchedEffect(ringerMode, touching) {
        if (!touching) indicator.animateTo(centerOf(ringerMode), glide)
    }

    Box(
        modifier = modifier.pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown()
                if (!currentEnabled) return@awaitEachGesture
                val myGeneration = ++generation
                touching = true
                currentOnTouch()
                val minX = SEGMENT_CENTERS.first() * s
                val maxX = SEGMENT_CENTERS.last() * s
                var lastIndex = RINGER_MODES.indexOf(currentMode).coerceAtLeast(0)

                fun nearestIndex(x: Float): Int =
                    SEGMENT_CENTERS.indices.minByOrNull { abs(SEGMENT_CENTERS[it] * s - x) } ?: 0

                fun track(pos: Offset) {
                    val inside = pos.x >= 0f && pos.x <= size.width &&
                            pos.y >= 0f && pos.y <= size.height
                    val index = nearestIndex(pos.x)
                    if (index != lastIndex) {
                        lastIndex = index
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                    // Inside the bar: follow the finger. Outside: go to the nearest segment.
                    val target = if (inside) pos.x.coerceIn(minX, maxX) else SEGMENT_CENTERS[index] * s
                    scope.launch { indicator.animateTo(target, follow) }
                }

                track(down.position)
                down.consume()
                do {
                    val event = awaitPointerEvent()
                    val change = event.changes.firstOrNull() ?: break
                    track(change.position)
                    change.consume()
                } while (event.changes.any { it.pressed })

                val mode = RINGER_MODES[lastIndex]
                scope.launch {
                    indicator.animateTo(SEGMENT_CENTERS[lastIndex] * s, glide)
                    if (mode != currentMode) currentOnSelect(mode)
                    // If the mode did not change (e.g. silent needs DND access first),
                    // the effect above glides the indicator back to the real mode.
                    if (myGeneration == generation) touching = false
                }
            }
        }
    ) {
        // Sliding indicator
        Box(
            modifier = Modifier
                .offset {
                    IntOffset(
                        (indicator.value - G.SEGMENT / 2f * s).roundToInt(),
                        ((G.UNIT - G.SEGMENT) / 2f * s).roundToInt()
                    )
                }
                .size(rp(G.SEGMENT))
                .background(NOS.Light, CircleShape)
        )
        // Icons: dark while the indicator is behind them, light otherwise
        RINGER_MODES.forEachIndexed { i, mode ->
            val cx = SEGMENT_CENTERS[i] * s
            val t = (1f - abs(indicator.value - cx) / (G.SEGMENT * 0.6f * s)).coerceIn(0f, 1f)
            Box(
                modifier = Modifier
                    .offset {
                        IntOffset(
                            (cx - G.BITMAP_ICON / 2f * s).roundToInt(),
                            ((G.UNIT - G.BITMAP_ICON) / 2f * s).roundToInt()
                        )
                    }
                    .size(rp(G.BITMAP_ICON))
            ) {
                NIcon(ringerIcon(mode), lerp(NOS.Light, NOS.Surface, t))
            }
        }
    }
}

// ───────────────────────── Collapsed media pill ─────────────────────────

@Composable
private fun MediaPill(
    music: StreamState,
    mediaIcon: Any,
    mediaTint: Color,
    onFraction: (Float) -> Unit,
    onTouch: () -> Unit,
    onMuteToggle: () -> Unit,
    onExpand: () -> Unit
) {
    val geo = LocalGeo.current
    Box(
        modifier = Modifier
            .size(rp(G.UNIT), rp(geo.panelH))
            .background(NOS.Surface, RoundedCornerShape(50))
    ) {
        DotSlider(music.fraction, onFraction, onTouch, Modifier.offset(y = rp(geo.trackTop)))
        IconSlot(geo.iconCy, G.UNIT, Modifier.tap(onMuteToggle)) { NIcon(mediaIcon, mediaTint) }
        IconSlot(geo.labelCy, G.UNIT, Modifier.tap(onExpand)) {
            NIcon(R.drawable.nos_ic_chevron, NOS.Label)
        }
    }
}

// ───────────────────────── Expanded system panel ─────────────────────────

@Composable
private fun SystemPanel(
    alarm: StreamState,
    notification: StreamState,
    ring: StreamState,
    ringerMode: Int,
    music: StreamState,
    mediaIcon: Any,
    mediaTint: Color,
    onAlarm: (Float) -> Unit,
    onNotification: (Float) -> Unit,
    onRing: (Float) -> Unit,
    onMusic: (Float) -> Unit,
    onMuteToggle: () -> Unit,
    onTouch: () -> Unit,
    onMore: () -> Unit
) {
    val geo = LocalGeo.current
    Box(
        modifier = Modifier
            .size(rp(G.PANEL_W), rp(geo.panelH))
            .background(NOS.Surface, RoundedCornerShape(rp(G.PANEL_RADIUS)))
    ) {
        // Like the original: in vibrate and silent mode the notification and ring columns
        // are empty and show the matching mode icon.
        val audible = ringerMode == AudioManager.RINGER_MODE_NORMAL
        val notificationShown = if (audible) notification else notification.copy(value = notification.min)
        val ringShown = if (audible) ring else ring.copy(value = ring.min)
        val bellIcon = when (ringerMode) {
            AudioManager.RINGER_MODE_SILENT -> R.drawable.nos_ic_bell_off
            AudioManager.RINGER_MODE_VIBRATE -> R.drawable.nos_ic_bell_vibrate
            else -> R.drawable.nos_ic_bell
        }
        val phoneIcon = when (ringerMode) {
            AudioManager.RINGER_MODE_SILENT -> R.drawable.nos_ic_phone_off
            AudioManager.RINGER_MODE_VIBRATE -> R.drawable.nos_ic_phone_vibrate
            else -> R.drawable.nos_ic_phone
        }
        Row {
            StreamColumn(alarm, R.drawable.nos_ic_alarm, NOS.Icon, onAlarm, onTouch)
            StreamColumn(notificationShown, bellIcon, NOS.Icon, onNotification, onTouch)
            StreamColumn(ringShown, phoneIcon, NOS.Icon, onRing, onTouch)
            StreamColumn(music, mediaIcon, mediaTint, onMusic, onTouch, onMuteToggle)
        }
        Box(
            modifier = Modifier
                .offset(y = rp(geo.labelCy - 36))
                .size(rp(G.PANEL_W), rp(72))
                .tap(onMore),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "MEHR",
                color = NOS.Label,
                fontSize = rsp(48),
                fontFamily = FontFamily.Default,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun StreamColumn(
    state: StreamState,
    icon: Any,
    iconTint: Color,
    onFraction: (Float) -> Unit,
    onTouch: () -> Unit,
    onIconClick: (() -> Unit)? = null
) {
    val geo = LocalGeo.current
    Box(Modifier.size(rp(G.UNIT), rp(geo.panelH))) {
        DotSlider(state.fraction, onFraction, onTouch, Modifier.offset(y = rp(geo.trackTop)))
        IconSlot(
            geo.iconCy, G.UNIT,
            if (onIconClick != null) Modifier.tap(onIconClick) else Modifier
        ) { NIcon(icon, iconTint) }
    }
}

// ───────────────────────── Mixer (per-app volumes) ─────────────────────────

@Composable
private fun MixerButton(active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(rp(G.UNIT))
            .background(if (active) NOS.Light else NOS.Surface, CircleShape)
            .tap(onClick),
        contentAlignment = Alignment.Center
    ) {
        NIcon(Icons.Outlined.Equalizer, if (active) NOS.Surface else NOS.Label)
    }
}

/** Nothing OS "automatic captions" (live caption) button; toggles the system feature. */
@Composable
private fun CaptionButton(active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(rp(G.UNIT))
            .background(if (active) NOS.Light else NOS.Surface, CircleShape)
            .tap(onClick),
        contentAlignment = Alignment.Center
    ) {
        NIcon(
            if (active) Icons.Outlined.ClosedCaption else R.drawable.nos_ic_caption_off,
            if (active) NOS.Surface else NOS.Label
        )
    }
}

/** Width of the mixer panel in reference px: empty state 2 columns, 3+ apps scroll. */
private fun mixerWidthRef(count: Int): Int = when {
    count == 0 -> 2 * G.UNIT // the empty-state hint needs room
    count >= 3 -> G.MIXER_MAX_W
    else -> count * G.UNIT
}

@Composable
private fun MixerPanel(
    sessions: List<AudioSession>,
    focusedApp: AudioSession?,
    onSessionVolumeChange: (Int, Float) -> Unit,
    onTouch: () -> Unit
) {
    val geo = LocalGeo.current
    val width = mixerWidthRef(sessions.size)
    val shape = RoundedCornerShape(rp(G.PANEL_RADIUS))
    Box(
        modifier = Modifier
            .size(rp(width), rp(geo.panelH))
            .background(NOS.Surface, shape)
    ) {
        if (sessions.isEmpty()) {
            // Empty state: same panel, same label, short hint where the sliders would be
            Box(
                modifier = Modifier
                    .offset(y = rp(geo.trackTop))
                    .size(rp(width), rp(G.TRACK_H))
                    .padding(horizontal = rp(24)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Keine App spielt gerade Audio ab",
                    color = NOS.Icon,
                    fontSize = rsp(40),
                    fontFamily = FontFamily.Default,
                    textAlign = TextAlign.Center
                )
            }
        }
        Row(
            modifier = Modifier
                .fillMaxSize()
                .clip(shape)
                .horizontalScroll(rememberScrollState())
        ) {
            sessions.forEach { session ->
                key(session.sessionId) {
                    AppColumn(
                        session = session,
                        isFocused = focusedApp?.uid == session.uid,
                        onVolumeChange = { v -> onSessionVolumeChange(session.sessionId, v) },
                        onTouch = onTouch
                    )
                }
            }
        }
        Box(
            modifier = Modifier
                .offset(y = rp(geo.labelCy - 36))
                .size(rp(width), rp(72)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "APPS",
                color = NOS.Label,
                fontSize = rsp(48),
                fontFamily = FontFamily.Default,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun AppColumn(
    session: AudioSession,
    isFocused: Boolean,
    onVolumeChange: (Float) -> Unit,
    onTouch: () -> Unit
) {
    val geo = LocalGeo.current
    var local by remember(session.sessionId) { mutableFloatStateOf(session.volume) }

    // Debounce: only push to the Shizuku backend after 80 ms without movement
    LaunchedEffect(local) {
        delay(80L)
        Log.d(TAG, "App volume: ${session.appName} = $local")
        onVolumeChange(local)
    }

    val icon = remember(session.packageName) {
        session.appIcon?.toBitmap(144, 144)?.asImageBitmap()
    }

    Box(Modifier.size(rp(G.UNIT), rp(geo.panelH))) {
        DotSlider(local, { local = it }, onTouch, Modifier.offset(y = rp(geo.trackTop)))
        IconSlot(geo.iconCy, G.UNIT, Modifier) {
            if (icon != null) {
                Image(
                    bitmap = icon,
                    contentDescription = session.appName,
                    modifier = Modifier
                        .size(rp(66))
                        .clip(RoundedCornerShape(rp(18)))
                )
            } else {
                NIcon(Icons.Outlined.MusicNote, NOS.Icon)
            }
        }
        if (isFocused) {
            IconSlot(geo.iconCy + 62, G.UNIT, Modifier) {
                Box(
                    Modifier
                        .size(rp(12))
                        .background(NOS.Focus, CircleShape)
                )
            }
        }
    }
}

// ───────────────────────── Building blocks ─────────────────────────

/**
 * Vertical dot track with a white level bar growing from the bottom.
 *
 * While the finger is down the bar follows it continuously; the callback still
 * receives the raw fraction and the caller decides on discrete volume steps.
 * After release (or when the value changes from outside) the bar glides to the
 * real value instead of jumping.
 */
@Composable
private fun DotSlider(
    fraction: Float,
    onFraction: (Float) -> Unit,
    onTouch: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val s = LocalRef.current
    val scope = rememberCoroutineScope()
    val currentOnFraction by rememberUpdatedState(onFraction)
    val currentOnTouch by rememberUpdatedState(onTouch)
    var lastStep by remember { mutableIntStateOf(-1) }

    var dragging by remember { mutableStateOf(false) }
    var dragLevel by remember { mutableFloatStateOf(0f) }
    val level = remember { Animatable(fraction) }
    LaunchedEffect(fraction, dragging) {
        // Spring (not tween): when the target moves again while still animating, e.g. while a
        // volume key is held and the value steps every ~150 ms, the velocity is carried over,
        // so the bar glides continuously instead of restarting at every step.
        if (!dragging) {
            level.animateTo(
                targetValue = fraction,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = Spring.StiffnessMediumLow,
                    visibilityThreshold = 0.0005f
                )
            )
        }
    }

    val emit: (Float) -> Unit = { f ->
        val step = (f * G.DOT_COUNT).roundToInt()
        if (step != lastStep) {
            lastStep = step
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        }
        currentOnTouch()
        currentOnFraction(f)
    }
    val finishDrag: () -> Unit = {
        scope.launch {
            level.snapTo(dragLevel)
            dragging = false
        }
    }

    Canvas(
        modifier = modifier
            .size(rp(G.UNIT), rp(G.TRACK_H))
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    emit(1f - (offset.y / size.height.toFloat()).coerceIn(0f, 1f))
                }
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { offset ->
                        val f = 1f - (offset.y / size.height.toFloat()).coerceIn(0f, 1f)
                        dragLevel = f
                        dragging = true
                        emit(f)
                    },
                    onDragEnd = { finishDrag() },
                    onDragCancel = { finishDrag() },
                    onVerticalDrag = { change, _ ->
                        change.consume()
                        val f = 1f - (change.position.y / size.height.toFloat()).coerceIn(0f, 1f)
                        dragLevel = f
                        emit(f)
                    }
                )
            }
    ) {
        val radius = G.DOT_D / 2f * s
        for (k in 0 until G.DOT_COUNT) {
            drawCircle(
                color = NOS.Dot,
                radius = radius,
                center = Offset(size.width / 2f, (G.DOT_FIRST + k * G.DOT_PITCH) * s)
            )
        }
        val shown = if (dragging) dragLevel else level.value
        if (shown > 0.002f) {
            val w = G.BAR_W * s
            val h = (shown * G.TRACK_H).coerceAtLeast(G.BAR_W.toFloat()) * s
            drawRoundRect(
                color = NOS.Light,
                topLeft = Offset((size.width - w) / 2f, size.height - h),
                size = Size(w, h),
                cornerRadius = CornerRadius(w / 2f, w / 2f)
            )
        }
    }
}

/** Centres [content] vertically on [centerY] (reference px from panel top). */
@Composable
private fun IconSlot(
    centerY: Int,
    width: Int,
    modifier: Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .offset(y = rp(centerY - G.ICON_BOX / 2))
            .size(rp(width), rp(G.ICON_BOX))
            .then(modifier),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

/** [icon] is either a Material [ImageVector] or a drawable resource id (original Nothing icon). */
@Composable
private fun NIcon(icon: Any, tint: Color) {
    when (icon) {
        is ImageVector -> Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(rp(G.ICON_BOX))
        )
        is Int -> Icon(
            painter = painterResource(icon),
            contentDescription = null,
            tint = tint,
            modifier = Modifier.requiredSize(rp(G.BITMAP_ICON))
        )
    }
}

@Composable
private fun Modifier.tap(onClick: () -> Unit): Modifier = this.clickable(
    interactionSource = remember { MutableInteractionSource() },
    indication = null,
    onClick = onClick
)

/** Reports touch start/end on the whole overlay (pauses the auto-hide timer). */
private fun Modifier.trackTouch(onStart: () -> Unit, onEnd: () -> Unit): Modifier =
    pointerInput(Unit) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            onStart()
            do {
                val event = awaitPointerEvent(PointerEventPass.Initial)
            } while (event.changes.any { it.pressed })
            onEnd()
        }
    }
