package com.mixer.one.service

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.util.Log
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.concurrent.thread

/**
 * Switches the system's own automatic captions ("Live Caption") on or off.
 *
 * This does NOT implement captions itself. It flips the same system setting that the
 * original volume panel's captions button uses (Settings.Secure "odi_captions_enabled"),
 * so Nothing OS / Android does the actual work.
 *
 * Writing a secure setting needs the WRITE_SECURE_SETTINGS permission, which apps cannot get
 * on their own. Shizuku grants it once (`pm grant`); from then on miXXer writes the setting
 * directly and Shizuku is not needed anymore for this button. Until then, Shizuku (running and
 * allowed for miXXer) does the write through ONE shell command (read, flip, write).
 * Every failure is reported with a reason.
 */
object LiveCaptionToggle {

    private const val TAG = "LiveCaptionToggle"
    private const val KEY = "odi_captions_enabled"
    private const val SHIZUKU_REQUEST_CODE = 4711

    /**
     * @param enabled new state if the setting was changed, otherwise null
     * @param message short text for the user (reason of a failure), or null
     */
    data class Result(val enabled: Boolean?, val message: String?)

    private data class Shell(val exit: Int, val out: String, val err: String)

    /** Uri to observe, so the button can follow changes made elsewhere (e.g. in Settings). */
    fun settingUri(): Uri = Settings.Secure.getUriFor(KEY)

    /** Current state, or null if the app is not allowed to read it. */
    fun readEnabled(context: Context): Boolean? = try {
        Settings.Secure.getString(context.contentResolver, KEY) == "1"
    } catch (e: Exception) {
        Log.w(TAG, "Could not read $KEY", e)
        null
    }

    fun isEnabled(context: Context): Boolean = readEnabled(context) ?: false

    /** Toggles automatic captions. Blocking: call from a background thread. */
    fun toggle(context: Context): Result {
        val tag = "miXXer ${versionName(context)}: "

        // Fast path: permission already granted, write directly (no Shizuku, no process)
        if (context.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            return toggleDirect(context, tag)
        }

        // Shizuku must be running and miXXer must be allowed to use it
        val shizukuProblem = ensureShizuku()
        if (shizukuProblem != null) return Result(null, tag + shizukuProblem)

        // One single shell call: read the real value, flip it, write it, print the new value
        val script = "v=\$(settings get secure $KEY); " +
                "if [ \"\$v\" = \"1\" ]; then n=0; else n=1; fi; " +
                "settings put secure $KEY \$n && echo \$n"
        val result = runShell(script)
            ?: return Result(null, tag + "Shizuku-Befehl konnte nicht gestartet werden")
        val value = result.out.trim()
        if (result.exit != 0 || (value != "0" && value != "1")) {
            val reason = result.err.ifBlank { result.out }.trim().take(80)
            Log.w(TAG, "toggle failed: exit=${result.exit} $reason")
            return Result(null, tag + "Untertitel-Befehl fehlgeschlagen: $reason")
        }

        // Grant the permission for next time, in the background (does not delay this result)
        thread(isDaemon = true) {
            runShell("pm grant ${context.packageName} ${Manifest.permission.WRITE_SECURE_SETTINGS}")
        }
        return Result(value == "1", null)
    }

    private fun toggleDirect(context: Context, tag: String): Result {
        return try {
            val resolver = context.contentResolver
            val target = if (readEnabled(context) == true) 0 else 1
            Settings.Secure.putInt(resolver, KEY, target)
            val now = readEnabled(context)
            Log.d(TAG, "direct write: -> $target, now=$now")
            if (now == null || now == (target == 1)) Result(target == 1, null)
            else Result(null, tag + "Einstellung blieb unverändert")
        } catch (e: Exception) {
            Log.w(TAG, "Direct write failed", e)
            Result(null, tag + "Schreiben fehlgeschlagen: ${e.javaClass.simpleName}")
        }
    }

    /**
     * @return a message if Shizuku cannot be used right now, otherwise null.
     * Shows Shizuku's own permission dialog if needed; never opens other apps or settings.
     */
    private fun ensureShizuku(): String? = try {
        when {
            !Shizuku.pingBinder() ->
                "Shizuku läuft nicht – einmal in der Shizuku-App starten, danach geht es ohne"
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> null
            Shizuku.shouldShowRequestPermissionRationale() ->
                "Shizuku-Zugriff für miXXer fehlt – in der Shizuku-App unter Autorisierte Apps erlauben"
            else -> {
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
                "Bitte Shizuku-Zugriff erlauben und danach erneut tippen"
            }
        }
    } catch (e: Throwable) {
        Log.w(TAG, "Shizuku check failed", e)
        "Shizuku nicht erreichbar (${e.javaClass.simpleName})"
    }

    private fun versionName(context: Context): String = try {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }

    /** Same mechanism as ShizukuRepository.executeShellCommand (Shizuku.newProcess via reflection). */
    private fun runShell(command: String): Shell? = try {
        val newProcess = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        newProcess.isAccessible = true
        val process = newProcess.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
        val out = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
        val err = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText() }
        val exit = process.waitFor()
        Log.d(TAG, "shell -> exit=$exit out='${out.trim()}' err='${err.trim()}'")
        Shell(exit, out, err)
    } catch (e: Throwable) {
        Log.w(TAG, "Shell command failed", e)
        null
    }
}
