# Quick Launch v2.4.0

**This is it: the real Google Assistant replacement.** Smart voice commands that understand intent and execute directly, not just search for what you said.

## The big change: Voice commands execute, not search

**v2.3 mistake:** You'd say "open WhatsApp" and it would just type that into the search bar.  
**v2.4 fixed:** You say "open WhatsApp" and it opens WhatsApp directly.

Same with everything else:

- **"open [app]"** → launches the app directly (no search)
- **"call [contact]"** → dials the contact immediately
- **"text [contact]"** / **"message [contact]"** → opens SMS
- **"play [song]"** → plays in your default music app (Spotify, Apple Music, etc.)
- **"search [query]"** → opens a web search
- **"what is [question]"** / **"who is"** / **"how do I"** → searches AND speaks the answer back (TTS)

This is command interpretation, not transcription-into-search. Your voice becomes an API.

## New features

### Smart command interpreter
`VoiceCommandInterpreter.kt` parses natural language and executes it:
- Pattern matching for "open X", "call Y", "play Z" formats
- Fallback to web search for anything unrecognized
- Automatically speaks answers to factual questions (using Android TextToSpeech)
- Integrates with contacts, app index, and system intents

### Default music app setting
New setting in **Settings → Voice control → Default music app**. Choose from installed music apps (Spotify, Apple Music, YouTube Music, Amazon Music, Deezer, or system default). When you say "play [song]", it launches there and passes the song query to the app.

### Voice feedback (TTS)
Question patterns like "what is the date" or "how do I reset my phone" now:
1. Recognize they're questions
2. Search Google for the answer
3. Read the answer aloud while opening the browser for more context

No need to read a screen — just listen while you keep doing what you were doing.

### Visual improvements
- While listening, the palette shows "Listening…" with a pulsing progress bar
- Mic button turns blue when actively recording
- Keyboard disabled during voice input (no accidental typing)
- Feedback toast shows the command that was executed (e.g., "Opening WhatsApp", "Calling Mom")

## Fixed & improved

- Voice commands no longer fall through to search as a last resort — they execute their intent directly
- Contact matching is case-insensitive and forgiving
- App launching is resilient — if one intent fails, it tries alternatives
- Music app detection tries Spotify → Apple Music → Google → Amazon → Deezer → system default
- TTS initializes safely with fallback if voice output isn't available
- CoroutineScope passed to VoiceCommandInterpreter for safe async execution

## Upgrading

This is a continuation of v2.3; no app uninstall needed. Existing voice settings carry over.

On first voice command, you may see a one-time prompt to allow microphone and/or system permissions (varies by device/Android version). Accept them, then try again.

## Testing

Tested voice commands:
- ✅ "open gmail" → launches Gmail
- ✅ "call mom" → dials contact
- ✅ "text alex" → opens SMS to Alex
- ✅ "play love me do" → plays in Spotify (if set as default)
- ✅ "what's the weather" → searches and speaks (with TTS)
- ✅ "search android development" → opens web search
- ✅ Fallback to web search for unrecognized patterns
- ✅ App not found → shows error toast
- ✅ Contact not found → shows error toast
- ✅ TTS unavailable → still searches/opens, just doesn't speak

---

## Changes

- New: `com.profapps.quicklaunch.voice.VoiceCommandInterpreter` (smart command parsing)
- Updated: `VoiceControlInterpreter` (now interprets, not just transcribes)
- Updated: `PaletteController` (creates and owns the command interpreter)
- Updated: `OverlayPanel` (feedback toast for executed commands)
- Updated: Settings strings for default music app UI
- New strings: voice command response messages
- Version bumped: `2.3.0` (versionCode 8) → **`2.4.0`** (versionCode 9)

---

**Full Changelog**: v2.3.0...v2.4.0
