package com.profapps.quicklaunch.ui.overlay

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.profapps.quicklaunch.data.AppEntry
import com.profapps.quicklaunch.data.RecentEntry
import com.profapps.quicklaunch.data.RecentsRepository
import com.profapps.quicklaunch.data.SettingsRepository
import com.profapps.quicklaunch.providers.AppIndex
import com.profapps.quicklaunch.search.SearchEngine
import com.profapps.quicklaunch.search.SearchResult
import com.profapps.quicklaunch.util.UiBridge
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * State holder for the command palette, shared by the overlay window and the
 * in-app "try it" mode. Owns debounced search, selection state, empty-state
 * content (recents, pinned apps, clipboard) and result execution.
 */
class PaletteController(
    private val context: Context,
    private val engine: SearchEngine,
    private val recents: RecentsRepository,
    private val settings: SettingsRepository,
    private val appIndex: AppIndex,
    private val scope: CoroutineScope,
    private val onDismiss: () -> Unit,
) {

    val query = MutableStateFlow("")
    val results = MutableStateFlow<List<SearchResult>>(emptyList())
    val selection = MutableStateFlow(0)
    val searching = MutableStateFlow(false)
    val panelVisible = MutableStateFlow(true)

    val recentsList = MutableStateFlow<List<RecentEntry>>(emptyList())
    val pinnedApps = MutableStateFlow<List<AppEntry>>(emptyList())
    val clipboardText = MutableStateFlow<String?>(null)

    private var searchJob: Job? = null
    private var bootstrapJob: Job? = null

    private val voiceControl = VoiceControlInterpreter(
        context = context,
        commandInterpreter = com.profapps.quicklaunch.voice.VoiceCommandInterpreter(
            context = context,
            appIndex = appIndex,
        ),
        scope = scope,
        onCommandExecuted = { feedback ->
            UiBridge.toast(context, feedback)
        },
        onListeningStateChange = { /* UI responds to voiceControl.isListening directly */ },
        onError = { error -> UiBridge.toast(context, error) },
    )
    val voiceIsListening: StateFlow<Boolean> = voiceControl.isListening
    val voiceCanSpeak: Boolean get() = voiceControl.canUseMic()

    /** Called when the palette window becomes visible. */
    fun onPaletteShown() {
        bootstrapJob?.cancel()
        bootstrapJob = scope.launch {
            // Android 10+ only allows clipboard reads from a focused window;
            // failure is expected and simply means no suggestion is shown.
            clipboardText.value = runCatching {
                UiBridge.readClipboardText(context)?.take(120)
            }.getOrNull()
            runCatching { refreshEmptyState() }
        }
    }

    private suspend fun refreshEmptyState() {
        val s = settings.settings.value
        recentsList.value = if (s.recentsEnabled) {
            // Only the most recent couple of actions — a long recents list
            // pushed pinned apps and the sample chips off-screen for no
            // real benefit; the freshest 1-2 are what people actually reach
            // for again.
            runCatching { recents.recents.first().take(MAX_EMPTY_STATE_RECENTS) }
                .getOrDefault(emptyList())
        } else {
            emptyList()
        }
        val pinnedPackages = s.pinnedApps
        pinnedApps.value = if (pinnedPackages.isEmpty()) {
            emptyList()
        } else {
            runCatching {
                appIndex.getApps().filter { it.packageName in pinnedPackages }.take(8)
            }.getOrDefault(emptyList())
        }
    }

    fun onQueryChange(newQuery: String) {
        query.value = newQuery
        searchJob?.cancel()
        if (newQuery.isBlank()) {
            searching.value = false
            results.value = emptyList()
            selection.value = 0
            return
        }
        searching.value = true
        searchJob = scope.launch {
            delay(SEARCH_DEBOUNCE_MS) // tiny debounce; keeps keystrokes snappy
            val found = try {
                engine.search(newQuery)
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                // Search must never take the palette down — show an empty
                // result list instead of crashing.
                emptyList()
            }
            if (!isActive) return@launch
            results.value = found
            selection.value = 0
            searching.value = false
        }
    }

    fun moveSelection(delta: Int) {
        val size = results.value.size
        if (size == 0) return
        val next = (selection.value + delta).coerceIn(0, size - 1)
        selection.value = next
    }

    fun activateSelected() {
        val current = results.value.getOrNull(selection.value) ?: return
        activate(current)
    }

    fun activate(result: SearchResult) {
        scope.launch {
            if (result.recordable && settings.settings.value.recentsEnabled) {
                runCatching {
                    recents.record(
                        RecentEntry(
                            id = result.id,
                            title = result.title,
                            subtitle = result.subtitle,
                            packageName = null,
                            kind = kindFor(result),
                            timestamp = System.currentTimeMillis(),
                            payload = result.recordPayload ?: "",
                        ),
                    )
                }
            }
            val outcome = runCatching { result.action() }.getOrDefault(
                com.profapps.quicklaunch.search.ActionResult.Dismiss,
            )
            if (result.dismissAfterAction && outcome ==
                com.profapps.quicklaunch.search.ActionResult.Dismiss
            ) {
                onDismiss()
            }
        }
    }

    private fun kindFor(result: SearchResult): String = when (result.category) {
        com.profapps.quicklaunch.search.ResultCategory.APPS -> RecentEntry.KIND_APP
        com.profapps.quicklaunch.search.ResultCategory.WEB -> RecentEntry.KIND_WEB
        com.profapps.quicklaunch.search.ResultCategory.SETTINGS -> RecentEntry.KIND_SETTINGS
        com.profapps.quicklaunch.search.ResultCategory.CONTACTS -> RecentEntry.KIND_CONTACT
        com.profapps.quicklaunch.search.ResultCategory.FILES -> RecentEntry.KIND_FILE
        else -> RecentEntry.KIND_OTHER
    }

    /** Re-executes a recent entry directly (one tap, no retyping). */
    fun replay(entry: RecentEntry) {
        scope.launch {
            runCatching {
                val launched: Boolean = when (entry.kind) {
                    RecentEntry.KIND_APP -> entry.payload.isNotEmpty() && launchApp(entry.payload)
                    RecentEntry.KIND_WEB -> entry.payload.isNotEmpty() && launchUrl(entry.payload)
                    RecentEntry.KIND_SETTINGS -> entry.payload.isNotEmpty() && launchAction(entry.payload)
                    RecentEntry.KIND_CONTACT -> entry.payload.startsWith("tel:") &&
                        launchUrl(entry.payload.replace(" ", ""))
                    RecentEntry.KIND_FILE -> entry.payload.isNotEmpty() && launchUrl(entry.payload)
                    else -> false
                }
                if (launched) {
                    if (settings.settings.value.recentsEnabled) recents.record(entry)
                    onDismiss()
                }
            }
        }
    }

    fun searchClipboard() {
        clipboardText.value?.let { text -> onQueryChange(text) }
    }

    fun copyToClipboard(text: String) {
        UiBridge.copy(context, text)
        UiBridge.toast(context, context.getString(com.profapps.quicklaunch.R.string.copied))
    }

    fun togglePinned(app: AppEntry) {
        scope.launch {
            runCatching {
                val pinnedNow = app.packageName in settings.settings.value.pinnedApps
                settings.setAppPinned(app.packageName, !pinnedNow)
                refreshEmptyState()
                val messageRes = if (pinnedNow) {
                    com.profapps.quicklaunch.R.string.unpinned_toast
                } else {
                    com.profapps.quicklaunch.R.string.pinned_toast
                }
                UiBridge.toast(context, context.getString(messageRes, app.label))
            }
        }
    }

    /** Long-press on an app result toggles its pinned state. */
    fun togglePinnedFromResult(result: SearchResult) {
        val icon = result.icon as? com.profapps.quicklaunch.search.ResultIcon.AppIcon ?: return
        scope.launch {
            runCatching {
                val pkg = icon.component.packageName
                val pinnedNow = pkg in settings.settings.value.pinnedApps
                settings.setAppPinned(pkg, !pinnedNow)
                refreshEmptyState()
                val messageRes = if (pinnedNow) {
                    com.profapps.quicklaunch.R.string.unpinned_toast
                } else {
                    com.profapps.quicklaunch.R.string.pinned_toast
                }
                UiBridge.toast(context, context.getString(messageRes, result.title))
            }
        }
    }

    /** Opens a pinned app from the empty state. */
    fun launchPinnedApp(app: AppEntry) {
        scope.launch {
            runCatching {
                val ok = runCatching {
                    context.startActivity(
                        Intent(Intent.ACTION_MAIN)
                            .addCategory(Intent.CATEGORY_LAUNCHER)
                            .setClassName(app.packageName, app.component.className)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                }.isSuccess
                if (ok) {
                    if (settings.settings.value.recentsEnabled) {
                        recents.record(
                            RecentEntry(
                                id = app.id,
                                title = app.label,
                                subtitle = app.packageName,
                                packageName = app.packageName,
                                kind = RecentEntry.KIND_APP,
                                timestamp = System.currentTimeMillis(),
                                payload = app.packageName,
                            ),
                        )
                    }
                    onDismiss()
                }
            }
        }
    }

    fun clearRecents() {
        scope.launch {
            runCatching {
                recents.clear()
                refreshEmptyState()
            }
        }
    }

    /** Start voice input: second tap of assist gesture while palette is already open. */
    fun startVoiceInput() {
        if (voiceCanSpeak) {
            voiceControl.startListening()
        }
    }

    /** Stop voice input and cleanup. */
    fun stopVoiceInput() {
        voiceControl.stopListening()
    }

    /** Release resources when the palette is destroyed. */
    fun onDestroy() {
        voiceControl.release()
    }

    private suspend fun launchApp(packageName: String): Boolean {
        val entry = appIndex.findByPackage(packageName) ?: return false
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(entry.packageName, entry.component.className)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { context.startActivity(intent) }.isSuccess
    }

    private fun launchUrl(url: String): Boolean = runCatching {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }.isSuccess

    private fun launchAction(action: String): Boolean = runCatching {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }.isSuccess

    companion object {
        const val SEARCH_DEBOUNCE_MS = 40L
        const val MAX_EMPTY_STATE_RECENTS = 2
    }
}
