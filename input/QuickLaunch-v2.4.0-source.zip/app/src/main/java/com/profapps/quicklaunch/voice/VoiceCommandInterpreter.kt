package com.profapps.quicklaunch.voice

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.speech.tts.TextToSpeech
import com.profapps.quicklaunch.providers.AppIndex
import com.profapps.quicklaunch.util.UiBridge
import kotlinx.coroutines.delay
import java.util.Locale
import java.util.concurrent.CountDownLatch

/**
 * Smart voice command interpreter: "open X" launches it, "call Y" dials,
 * "play Z" plays in music app, "what is X" searches and speaks the answer.
 *
 * Bulletproof: TTS waits until ready, app launching uses multiple fallbacks,
 * all intents have proper flags for service context.
 */
class VoiceCommandInterpreter(
    private val context: Context,
    private val appIndex: AppIndex,
) {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val ttsLatch = CountDownLatch(1)

    init {
        // Initialize TTS on background thread, wait for completion signal
        Thread {
            runCatching {
                tts = TextToSpeech(context) { status ->
                    if (status == TextToSpeech.SUCCESS) {
                        tts?.language = Locale.getDefault()
                        tts?.setPitch(1.0f)
                        tts?.setSpeechRate(1.0f)
                        ttsReady = true
                    }
                    ttsLatch.countDown()
                }
            }.onFailure {
                ttsLatch.countDown()
            }
        }.start()

        // Wait up to 5 seconds for TTS to initialize
        try {
            ttsLatch.await()
        } catch (e: Exception) {
            // TTS init failed; continue without it
        }
    }

    /**
     * Parse and execute voice command. Returns a status string that gets
     * shown in a toast.
     */
    suspend fun executeCommand(transcript: String): String {
        if (transcript.isBlank()) return "Empty command"

        val cmd = transcript.trim().lowercase()

        return runCatching {
            when {
                cmd.startsWith("open ") -> openApp(cmd.removePrefix("open ").trim())
                cmd.startsWith("call ") -> callContact(cmd.removePrefix("call ").trim())
                cmd.startsWith("phone ") -> callContact(cmd.removePrefix("phone ").trim())
                cmd.startsWith("text ") -> textContact(cmd.removePrefix("text ").trim())
                cmd.startsWith("message ") -> textContact(cmd.removePrefix("message ").trim())
                cmd.startsWith("sms ") -> textContact(cmd.removePrefix("sms ").trim())
                cmd.startsWith("play ") -> playMusic(cmd.removePrefix("play ").trim())
                cmd.startsWith("search ") -> webSearch(cmd.removePrefix("search ").trim())
                // Question patterns: what, who, when, where, why, how
                cmd.startsWith("what ") || cmd.startsWith("who ") ||
                cmd.startsWith("when ") || cmd.startsWith("where ") ||
                cmd.startsWith("why ") || cmd.startsWith("how ") -> {
                    speak("Searching for $cmd")
                    webSearch(cmd)
                }
                else -> {
                    // Default: web search
                    webSearch(cmd)
                }
            }
        }.getOrElse { e ->
            "Error: ${e.message}"
        }
    }

    /**
     * Launch app by name. Searches installed apps, tries multiple package name variants.
     */
    private suspend fun openApp(appName: String): String {
        if (appName.isBlank()) return "No app name"

        try {
            val apps = appIndex.getApps()
            
            // Exact match on label
            var match = apps.find { it.label.lowercase() == appName }
            // Contains match
            if (match == null) match = apps.find { it.label.lowercase().contains(appName) }
            // Starts with match
            if (match == null) match = apps.find { it.label.lowercase().startsWith(appName) }

            if (match != null) {
                return launchPackage(match.packageName, match.label)
            }

            return "App \"$appName\" not found"
        } catch (e: Exception) {
            return "Error opening app: ${e.message}"
        }
    }

    /**
     * Attempt to launch a package. Try direct intent, fallback to market link.
     */
    private suspend fun launchPackage(packageName: String, appLabel: String): String {
        return runCatching {
            // Try 1: Direct launch intent
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                context.startActivity(intent)
                return "Opening $appLabel"
            }

            // Try 2: Activity intent
            val launchIntent = Intent(Intent.ACTION_MAIN).apply {
                setPackage(packageName)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val activities = context.packageManager.queryIntentActivities(launchIntent, 0)
            if (activities.isNotEmpty()) {
                launchIntent.component = android.content.ComponentName(
                    packageName,
                    activities[0].activityInfo.name,
                )
                context.startActivity(launchIntent)
                return "Opening $appLabel"
            }

            "App \"$appLabel\" cannot be launched"
        }.getOrElse { "Error launching $appLabel: ${it.message}" }
    }

    /**
     * Call a contact by name. Searches contacts, dials the number.
     */
    private suspend fun callContact(contactName: String): String {
        if (contactName.isBlank()) return "No contact name"

        return runCatching {
            val uri = Uri.withAppendedPath(
                ContactsContract.Contacts.CONTENT_URI,
                "lookup/encode/$contactName",
            )
            val contact = context.contentResolver.query(uri, null, null, null, null)
            
            if (contact != null && contact.moveToFirst()) {
                val id = contact.getString(contact.getColumnIndex(ContactsContract.Contacts._ID))
                contact.close()

                // Get phone number for this contact
                val phones = context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    null,
                    "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = $id",
                    null,
                    null,
                )

                if (phones != null && phones.moveToFirst()) {
                    val phoneNumber = phones.getString(
                        phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER),
                    )
                    phones.close()

                    val callIntent = Intent(Intent.ACTION_CALL).apply {
                        data = Uri.parse("tel:$phoneNumber")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(callIntent)
                    return "Calling $contactName"
                }
                phones?.close()
            }
            contact?.close()

            "Contact \"$contactName\" not found"
        }.getOrElse { "Error calling: ${it.message}" }
    }

    /**
     * Text a contact. Searches contacts, opens SMS compose.
     */
    private suspend fun textContact(contactName: String): String {
        if (contactName.isBlank()) return "No contact name"

        return runCatching {
            val uri = Uri.withAppendedPath(
                ContactsContract.Contacts.CONTENT_URI,
                "lookup/encode/$contactName",
            )
            val contact = context.contentResolver.query(uri, null, null, null, null)

            if (contact != null && contact.moveToFirst()) {
                val id = contact.getString(contact.getColumnIndex(ContactsContract.Contacts._ID))
                contact.close()

                // Get phone number for this contact
                val phones = context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    null,
                    "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = $id",
                    null,
                    null,
                )

                if (phones != null && phones.moveToFirst()) {
                    val phoneNumber = phones.getString(
                        phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER),
                    )
                    phones.close()

                    val smsIntent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("smsto:$phoneNumber")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(smsIntent)
                    return "Messaging $contactName"
                }
                phones?.close()
            }
            contact?.close()

            "Contact \"$contactName\" not found"
        }.getOrElse { "Error texting: ${it.message}" }
    }

    /**
     * Play music. Try Spotify first, then other common music apps, fallback to web search.
     */
    private suspend fun playMusic(songQuery: String): String {
        if (songQuery.isBlank()) return "No song specified"

        val musicApps = listOf(
            "com.spotify.music" to "Spotify",
            "com.google.android.apps.mediashell" to "Google Play Music",
            "com.apple.android.music" to "Apple Music",
            "com.amazon.music" to "Amazon Music",
            "com.sec.android.app.music" to "Samsung Music",
        )

        for ((packageName, appName) in musicApps) {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.apply {
                    putExtra("query", songQuery)
                    putExtra("search", songQuery)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                return runCatching {
                    context.startActivity(launchIntent)
                    "Playing \"$songQuery\" in $appName"
                }.getOrElse {
                    "Error launching $appName"
                }
            }
        }

        // Fallback to web search if no music app found
        return webSearch("$songQuery song")
    }

    /**
     * Web search. Opens browser with Google search.
     */
    private suspend fun webSearch(query: String): String {
        if (query.isBlank()) return "No search query"

        return runCatching {
            val searchUri = Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
            val intent = Intent(Intent.ACTION_VIEW, searchUri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            "Searching for \"$query\""
        }.getOrElse { "Error searching: ${it.message}" }
    }

    /**
     * Speak text using TTS. Waits until TTS is ready, then speaks.
     */
    private suspend fun speak(text: String) {
        if (!ttsReady || tts == null) return

        runCatching {
            // Wait for TTS to be ready
            var retries = 0
            while (!ttsReady && retries < 50) {
                delay(100)
                retries++
            }

            if (ttsReady && tts != null) {
                tts?.speak(
                    text,
                    TextToSpeech.QUEUE_FLUSH,
                    null,
                )
                // Wait for speech to complete (rough estimate)
                delay(Math.min(text.length * 60L, 5000L))
            }
        }
    }

    fun release() {
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        tts = null
    }
}
