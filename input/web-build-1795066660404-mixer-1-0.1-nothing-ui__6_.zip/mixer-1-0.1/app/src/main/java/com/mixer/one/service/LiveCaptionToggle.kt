package com.mixer.one.service

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import rikka.shizuku.Shizuku

/**
 * Switches the system's own automatic captions ("Live Caption") on or off.
 *
 * This does NOT implement captions itself. It flips the same system setting that the
 * original volume panel's captions button uses (Settings.Secure "odi_captions_enabled"),
 * so Nothing OS / Android does the actual work.
 *
 * Writing a secure setting needs privileges an app does not have. With Shizuku running,
 * the write is done by the shell (`settings put secure ...`). Without Shizuku, the system
 * accessibility settings are opened instead, where the feature can be switched manually.
 */
object LiveCaptionToggle {

    private const val TAG = "LiveCaptionToggle"
    private const val KEY = "odi_captions_enabled"

    /** Current state of the system setting (readable without special permissions). */
    fun isEnabled(context: Context): Boolean = try {
        Settings.Secure.getInt(context.contentResolver, KEY, 0) == 1
    } catch (e: Exception) {
        Log.w(TAG, "Could not read $KEY", e)
        false
    }

    /**
     * Toggles automatic captions. Blocking: call from a background thread.
     * @return true if the system setting was changed.
     */
    fun toggle(context: Context): Boolean {
        val newValue = if (isEnabled(context)) 0 else 1
        if (writeViaShizuku(newValue)) {
            val ok = isEnabled(context) == (newValue == 1)
            Log.d(TAG, "Set $KEY=$newValue via Shizuku, verified=$ok")
            if (ok) return true
        }
        openAccessibilitySettings(context)
        return false
    }

    private fun writeViaShizuku(value: Int): Boolean {
        return try {
            if (!Shizuku.pingBinder()) return false
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return false
            // Shizuku.newProcess is not public API in 13.x, hence reflection.
            val newProcess = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            newProcess.isAccessible = true
            val process = newProcess.invoke(
                null,
                arrayOf("settings", "put", "secure", KEY, value.toString()),
                null,
                null
            ) as Process
            process.waitFor() == 0
        } catch (e: Throwable) {
            Log.w(TAG, "Shizuku write failed", e)
            false
        }
    }

    private fun openAccessibilitySettings(context: Context) {
        try {
            context.startActivity(
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                Toast.makeText(
                    context,
                    "Automatische Untertitel hier in den Bedienungshilfen aktivieren (Shizuku nicht verbunden)",
                    Toast.LENGTH_LONG
                ).show()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not open accessibility settings", e)
        }
    }
}
