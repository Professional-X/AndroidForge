package com.sensassistant

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt
import kotlin.math.sqrt

// ---------- Данные о телефоне ----------
data class PhoneInfo(
    val brand: String, val model: String,
    val hasGyro: Boolean, val maxHz: Int, val diagonalInch: Double
)

// Сюда можно добавлять модели, где игра ограничивает FPS ниже частоты экрана:
// ключ = Build.MODEL, значение = максимум FPS в игре.
val knownFpsLimits: Map<String, Int> = mapOf(
    // "SM-A525F" to 60,
)

@Suppress("DEPRECATION")
fun readPhone(ctx: Context): PhoneInfo {
    val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null
    val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    val hz = wm.defaultDisplay.supportedModes.maxOf { it.refreshRate }.roundToInt()
    val dm = ctx.resources.displayMetrics
    val w = dm.widthPixels / dm.xdpi
    val h = dm.heightPixels / dm.ydpi
    return PhoneInfo(
        Build.MANUFACTURER.replaceFirstChar { it.uppercase() }, Build.MODEL,
        gyro, hz, sqrt((w * w + h * h).toDouble())
    )
}

fun fpsFor(p: PhoneInfo): Int {
    val byScreen = when { p.maxHz >= 120 -> 120; p.maxHz >= 90 -> 90; else -> 60 }
    return knownFpsLimits[p.model]?.coerceAtMost(byScreen) ?: byScreen
}

// ---------- Расчёт сенсы ----------
enum class Style(val label: String, val k: Double) {
    AGGRESSIVE("Агрессивный", 1.15), NORMAL("Обычный", 1.0)
}
enum class Range(val label: String, val k: Double) {
    CLOSE("Ближний бой", 1.1), LONG("Дальний бой", 0.9)
}

val scopes = listOf("Камера (без прицела)", "Красная точка / голо", "2x", "3x", "4x", "6x", "8x")
val baseNoGyro = listOf(100, 90, 55, 40, 32, 22, 17)
val baseGyro = listOf(240, 200, 120, 90, 70, 48, 38)

fun calcSens(p: PhoneInfo, gyro: Boolean, s: Style, r: Range): List<Pair<String, Int>> {
    val screen = (6.5 / p.diagonalInch).coerceIn(0.8, 1.2) // меньше экран -> выше сенса
    val hz = when { fpsFor(p) >= 120 -> 0.95; fpsFor(p) >= 90 -> 0.98; else -> 1.0 }
    val k = screen * hz * s.k * r.k
    val base = if (gyro) baseGyro else baseNoGyro
    return scopes.indices.map { scopes[it] to (base[it] * k).roundToInt().coerceIn(1, 300) }
}

// ---------- Интерфейс ----------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val phone = readPhone(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen(phone) }
            }
        }
    }
}

@Composable
fun Screen(p: PhoneInfo) {
    var style by remember { mutableStateOf(Style.NORMAL) }
    var range by remember { mutableStateOf(Range.CLOSE) }
    var useGyro by remember { mutableStateOf(p.hasGyro) }
    val fps = fpsFor(p)

    Column(
        Modifier.systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Sens Assistant", style = MaterialTheme.typography.headlineMedium)
        Text("Неофициальное приложение, не связано с Krafton", style = MaterialTheme.typography.bodySmall)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("${p.brand} ${p.model}", style = MaterialTheme.typography.titleMedium)
                Text("Гироскоп: ${if (p.hasGyro) "есть" else "нет"}")
                Text("Экран: до ${p.maxHz} Гц, ${"%.1f".format(p.diagonalInch)}\"")
                Text("Рекомендуемый FPS: $fps", fontWeight = FontWeight.Bold)
                Text("Если в игре нет такого FPS, выберите максимальный доступный.",
                    style = MaterialTheme.typography.bodySmall)
            }
        }

        Text("Стиль игры")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Style.values().forEach {
                FilterChip(style == it, { style = it }, { Text(it.label) })
            }
        }
        Text("Дистанция")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Range.values().forEach {
                FilterChip(range == it, { range = it }, { Text(it.label) })
            }
        }
        if (p.hasGyro) {
            Text("Режим")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(useGyro, { useGyro = true }, { Text("С гироскопом") })
                FilterChip(!useGyro, { useGyro = false }, { Text("Без гироскопа") })
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (useGyro && p.hasGyro) "Сенса гироскопа" else "Сенса камеры",
                    style = MaterialTheme.typography.titleMedium)
                calcSens(p, useGyro && p.hasGyro, style, range).forEach { (name, v) ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(name)
                        Text("$v%", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Text("Это стартовые значения. Подстройте их под себя в тренировочном режиме.",
            style = MaterialTheme.typography.bodySmall)
    }
}
