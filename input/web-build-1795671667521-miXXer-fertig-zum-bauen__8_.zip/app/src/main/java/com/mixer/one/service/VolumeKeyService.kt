package com.mixer.one.service

import android.os.SystemClock
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.util.Log
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.mixer.one.audio.AudioSessionManager
import com.mixer.one.data.AudioSession
import com.mixer.one.data.toParcelable
import com.mixer.one.shizuku.ShizukuRepository
import kotlinx.coroutines.*
import kotlin.math.roundToInt

/**
 * AccessibilityService that detects volume key presses
 * with proper hold-to-repeat behavior and accurate volume mapping
 * PLUS: Dynamic icon detection based on audio device connections
 */
class VolumeKeyService : AccessibilityService() {

    companion object {
        private const val TAG = "VolumeKeyService"
    }

    private var audioManager: AudioManager? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // Hold-to-repeat job
    private var repeatJob: Job? = null
    private val HOLD_START_MS = 300L       // pause before repeating starts
    private val ACCELERATION_MS = 750L     // time until the fastest repeat rate is reached
    private val REPEAT_SLOW_MS = 150f
    private val REPEAT_FAST_MS = 30f

    // Volume step configuration
    private var maxVolume = 30
    private val volumeStep = 1 // Change by 1 step per press

    // Current icon type
    private var currentIconType = "MUSIC"

    // Phase 3.5: Smart Focus - track foreground app package
    private var foregroundPackage: String? = null

    // Phase 3: Audio session management
    private var shizukuRepository: ShizukuRepository? = null
    private var audioSessionManager: AudioSessionManager? = null

    // Audio device callback for dynamic icon updates
    private val audioDeviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
            super.onAudioDevicesAdded(addedDevices)

            // AGGRESSIVE Z-ORDER STRATEGY: "Double Tap" to force our overlay on top
            serviceScope.launch {
                // Step 1: Wait for System UI to appear
                delay(300) // 300ms delay

                // Step 2: Update icon type and show overlay (first tap)
                updateIconType()
                val currentVol = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0
                showOverlay(currentVol)

                // Step 3: Wait a bit
                delay(150) // 150ms delay

                // Step 4: FORCE REFRESH - hide & immediately re-show (second tap)
                // This forces WindowManager to re-evaluate the stack
                forceRefreshOverlay(currentVol)
            }
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
            super.onAudioDevicesRemoved(removedDevices)

            // Update icon to reflect device disconnection
            serviceScope.launch {
                delay(300) // Consistency delay
                updateIconType()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        // Get real max volume from system
        maxVolume = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 30

        // Register audio device callback
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            audioManager?.registerAudioDeviceCallback(audioDeviceCallback, null)
        }

        // Initial icon type detection
        updateIconType()

        // Phase 3: Initialize audio session management
        try {
            shizukuRepository = ShizukuRepository(this)
            audioSessionManager = AudioSessionManager(this, shizukuRepository!!)
            audioSessionManager?.startPolling()
            Log.d(TAG, "AudioSessionManager initialized and polling started")
            
            // Set up per-app volume callback
            ensureCallbackRegistered()
            Log.d(TAG, "Per-app volume callback registered in onServiceConnected")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize AudioSessionManager", e)
            // Continue without per-app volume (graceful fallback)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Phase 3.5: Track foreground app for Smart Focus
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString()
            // Another app, the recents screen or the shade came up: slide the overlay out
            if (!packageName.isNullOrBlank() && packageName != this.packageName && !isKeyboardEvent(event)) {
                OverlayManager.onForegroundWindowChanged()
            }
            if (!packageName.isNullOrBlank() && 
                !packageName.startsWith("com.android.systemui") &&
                !packageName.startsWith("com.nothing.systemui")) {
                foregroundPackage = packageName
                Log.d(TAG, "Foreground app: $foregroundPackage")
            }
        }
    }

    /** A keyboard (re)positioning itself is not an app change. */
    private fun isKeyboardEvent(event: AccessibilityEvent): Boolean {
        val className = event.className?.toString().orEmpty()
        if (className.contains("SoftInputWindow") || className.contains("InputMethod")) return true
        val ime = try {
            android.provider.Settings.Secure.getString(
                contentResolver, android.provider.Settings.Secure.DEFAULT_INPUT_METHOD
            )?.substringBefore('/')
        } catch (e: Exception) {
            null
        }
        return ime != null && event.packageName?.toString() == ime
    }

    override fun onInterrupt() {
        // Required override
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                return when (event.action) {
                    KeyEvent.ACTION_DOWN -> {
                        // The system's own key repeat is ignored; hold-to-repeat is done below
                        if (event.repeatCount == 0) handleVolumeKeyDown(isUp = true)
                        true // Consume event
                    }
                    KeyEvent.ACTION_UP -> {
                        handleVolumeKeyUp()
                        true
                    }
                    else -> false
                }
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                return when (event.action) {
                    KeyEvent.ACTION_DOWN -> {
                        if (event.repeatCount == 0) handleVolumeKeyDown(isUp = false)
                        true // Consume event
                    }
                    KeyEvent.ACTION_UP -> {
                        handleVolumeKeyUp()
                        true
                    }
                    else -> false
                }
            }
        }

        return false // Let other keys pass through
    }

    /**
     * Handle volume key down with hold-to-repeat logic
     */
    private fun handleVolumeKeyDown(isUp: Boolean) {
        // Cancel any existing repeat job
        repeatJob?.cancel()

        // Change volume once immediately
        changeVolume(isUp)

        // Holding the key: after a short pause the steps come faster and faster. The speed
        // ramps from one step per 150 ms up to one per 30 ms within 0.75 s.
        repeatJob = serviceScope.launch {
            delay(HOLD_START_MS) // tap vs. hold
            val startedAt = SystemClock.uptimeMillis()
            while (isActive) {
                changeVolume(isUp)
                val progress =
                    ((SystemClock.uptimeMillis() - startedAt) / ACCELERATION_MS.toFloat()).coerceIn(0f, 1f)
                val eased = progress * progress * (3f - 2f * progress) // smoothstep
                delay((REPEAT_SLOW_MS + (REPEAT_FAST_MS - REPEAT_SLOW_MS) * eased).toLong())
            }
        }
    }

    /**
     * Handle volume key up - stop repeating
     */
    private fun handleVolumeKeyUp() {
        repeatJob?.cancel()
        repeatJob = null
    }

    /**
     * Change volume by one step
     * Uses real max volume and proper mapping
     */
    private fun changeVolume(isUp: Boolean) {
        // Nothing plays on this phone. The music may come from another device (Spotify Connect,
        // Cast ...): a system volume key would reach that session, so send it like one. If there
        // is no remote session the system adjusts the normal music stream instead.
        if (audioManager?.isMusicActive != true && RemoteMedia.adjust(this, isUp)) {
            RemoteMedia.refreshAsync(serviceScope) { info ->
                // the real level of the remote session arrives a moment later
                if (info != null) serviceScope.launch { showOverlay(currentLocalVolume()) }
            }
            showOverlay(currentLocalVolume())
            return
        }

        val currentVolume = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0

        val newVolume = if (isUp) {
            (currentVolume + volumeStep).coerceAtMost(maxVolume)
        } else {
            (currentVolume - volumeStep).coerceAtLeast(0)
        }

        // CRITICAL: Set volume using real system values
        audioManager?.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            newVolume,
            0 // No flags = no system UI
        )

        // Show/update custom overlay
        showOverlay(newVolume)
    }

    /**
     * Show or update the overlay with current sessions
     * Phase 3.5: Now includes focused app detection for Smart Focus
     */
    private fun currentLocalVolume(): Int = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0

    /** Entry for the mixer list that stands for the music playing on another device. */
    private fun remoteSession(info: RemoteMedia.Info): AudioSession {
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(info.packageName, 0)).toString()
        } catch (e: Exception) {
            info.packageName
        }
        return AudioSession(
            sessionId = RemoteMedia.SESSION_ID,
            uid = info.uid,
            packageName = info.packageName,
            appName = label,
            appIcon = null,
            streamType = AudioManager.STREAM_MUSIC,
            volume = info.fraction,
            lastSeenTimestamp = System.currentTimeMillis()
        )
    }

    private fun showOverlay(localVolume: Int) {
        // Music on another device: show ITS level and list its app in the mixer
        val remote = RemoteMedia.fresh()
        val volume = if (remote != null) (remote.fraction * maxVolume).roundToInt() else localVolume
        // IMPORTANT: Ensure callback is always set (safety net for app updates)
        // This is needed because onServiceConnected() may not run after an APK update
        ensureCallbackRegistered()
        
        // Get current sessions from AudioSessionManager
        val sessions = (audioSessionManager?.getCurrentSessions() ?: emptyList()) +
                listOfNotNull(remote?.let { remoteSession(it) })
        
        // DEBUG: Log session count
        Log.d(TAG, "showOverlay: volume=$volume, sessions=${sessions.size}, foreground=$foregroundPackage")
        sessions.forEachIndexed { index, session ->
            Log.d(TAG, "  Session[$index]: ${session.appName} (uid=${session.uid}, pkg=${session.packageName})")
        }
        
        // Phase 3.5: Get focused app based on foreground package
        val focusedApp = audioSessionManager?.getFocusedApp(foregroundPackage)
            ?: audioSessionManager?.getMostRecentSession() // Fallback to most recent
        Log.d(TAG, "  Focused app: ${focusedApp?.appName ?: "none"}")

        val intent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_SHOW_OVERLAY
            putExtra(OverlayService.EXTRA_VOLUME, volume)
            putExtra(OverlayService.EXTRA_MAX_VOLUME, maxVolume)
            putExtra(OverlayService.EXTRA_ICON_TYPE, currentIconType)

            // Phase 3: Pass sessions as parcelable list
            if (sessions.isNotEmpty()) {
                val parcelableSessions = ArrayList(sessions.map { it.toParcelable() })
                putParcelableArrayListExtra(OverlayService.EXTRA_SESSIONS, parcelableSessions)
                Log.d(TAG, "  Passing ${parcelableSessions.size} parcelable sessions to overlay")
            } else {
                Log.w(TAG, "  WARNING: No sessions to pass to overlay!")
            }
            
            // Phase 3.5: Pass focused app for Smart Focus
            focusedApp?.let {
                putExtra(OverlayService.EXTRA_FOCUSED_APP, it.toParcelable())
            }

            // Phase 3: Create ResultReceiver for robust per-app volume control
            val volumeReceiver = object : android.os.ResultReceiver(android.os.Handler(android.os.Looper.getMainLooper())) {
                override fun onReceiveResult(resultCode: Int, resultData: android.os.Bundle?) {
                    val sessionId = resultCode // We use resultCode as sessionId
                    val newVolume = resultData?.getFloat("volume") ?: return
                    Log.d(TAG, "VolumeReceiver: sessionId=$sessionId, volume=$newVolume")
                    
                    serviceScope.launch {
                        applySessionVolume(sessionId, newVolume)
                    }
                }
            }
            putExtra(OverlayService.EXTRA_VOLUME_RECEIVER, volumeReceiver)
        }
        
        // Start the overlay service
        startService(intent)
    }

    /**
     * Force refresh overlay by hiding and immediately re-showing
     * This forces WindowManager to re-evaluate Z-order stack
     */
    private fun forceRefreshOverlay(volume: Int) {
        val intent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_FORCE_REFRESH
            putExtra(OverlayService.EXTRA_VOLUME, volume)
            putExtra(OverlayService.EXTRA_MAX_VOLUME, maxVolume)
            putExtra(OverlayService.EXTRA_ICON_TYPE, currentIconType)
        }
        startService(intent)
    }

    /**
     * Detect connected audio devices and update icon type
     */
    private fun updateIconType() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val devices = audioManager?.getDevices(AudioManager.GET_DEVICES_OUTPUTS) ?: return

            // Priority: Bluetooth > Wired > Default
            currentIconType = when {
                devices.any { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                             it.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                             it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO } -> "BLUETOOTH"

                devices.any { it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                             it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                             it.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
                             it.type == AudioDeviceInfo.TYPE_USB_DEVICE } -> "HEADPHONE"

                else -> "MUSIC"
            }
        } else {
            // Fallback for older Android versions
            currentIconType = "MUSIC"
        }
    }

    /**
     * Ensure the per-app volume callback is registered
     * Called from both onServiceConnected() and showOverlay() for redundancy
     */
    /** Per-app volume; the remote (other device) entry has no player here, it is stepped. */
    private fun applySessionVolume(sessionId: Int, volume: Float) {
        if (sessionId == RemoteMedia.SESSION_ID) {
            RemoteMedia.setApproximately(this, serviceScope, volume)
        } else {
            audioSessionManager?.setSessionVolume(sessionId, volume)
        }
    }

    private fun ensureCallbackRegistered() {
        OverlayManager.setSessionVolumeCallback { sessionId, newVolume ->
            Log.d(TAG, "Per-app volume callback invoked: sessionId=$sessionId, volume=$newVolume")
            serviceScope.launch {
                applySessionVolume(sessionId, newVolume)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        repeatJob?.cancel()
        serviceScope.cancel()

        // Unregister audio device callback
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            audioManager?.unregisterAudioDeviceCallback(audioDeviceCallback)
        }

        // Phase 3: Cleanup audio session management
        audioSessionManager?.cleanup()
        shizukuRepository?.cleanup()
        Log.d(TAG, "VolumeKeyService destroyed, cleaned up audio session management")
    }
}
