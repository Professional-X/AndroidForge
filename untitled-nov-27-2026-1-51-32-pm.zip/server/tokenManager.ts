import crypto from 'node:crypto';

export type TokenValidationErrorCode =
  | 'TOKEN_MISSING'
  | 'TOKEN_INVALID'
  | 'TOKEN_EXPIRED'
  | 'TOKEN_REVOKED'
  | 'TOKEN_REPLAYED';

export interface CoreTokenSession {
  sessionId: string;
  token: string;
  issuedAtMs: number;
  expiresAtMs: number;
  refreshAfterMs: number;
  issuedAtIso: string;
  expiresAtIso: string;
  rotationCount: number;
  scope: 'core-session' | 'relay-agent';
  clientLabel?: string;
}

export interface TokenVerifyResult {
  valid: boolean;
  errorCode?: TokenValidationErrorCode;
  session?: CoreTokenSession;
  shouldRotate?: boolean;
}

export interface TokenManagerOptions {
  ttlMs?: number;
  renewThresholdRatio?: number;
  maxActiveSessions?: number;
  signingSecret?: Buffer;
  now?: () => number;
}

const SENSITIVE_KEY_RE =
  /^(pass(word)?|pwd|secret|.*token|cookie|set-cookie|authorization|__requestverificationtoken.*|sesinfo|tokinfo|psk|api_?key)$/i;

/**
 * Redact passwords, tokens, session cookies, and authorization headers from strings.
 */
export function redactSecrets(input: string, extraSecrets: string[] = []): string {
  let out = String(input ?? '');

  for (const s of extraSecrets) {
    if (s && s.length >= 3) {
      out = out.split(s).join('[REDACTED]');
    }
  }

  // Redact common header / query / XML / form credential patterns
  out = out
    .replace(/(bearer\s+)[a-z0-9._\-+/=]+/gi, '$1[REDACTED]')
    .replace(/((?:pass(?:word)?|pwd|token|cookie|x_hw_token|sesinfo|tokinfo)\s*[:=]\s*)([^\s&;,"'<>\n]+)/gi, '$1[REDACTED]')
    .replace(/(<(?:Password|WifiWpaPreSharedKey|SesInfo|TokInfo)>)([\s\S]*?)(<\/(?:Password|WifiWpaPreSharedKey|SesInfo|TokInfo)>)/gi, '$1[REDACTED]$3');

  return out.slice(0, 600);
}

/**
 * Recursively sanitize diagnostic objects so secrets never escape into responses or logs.
 */
export function sanitizeRecord(value: unknown, extraSecrets: string[] = []): unknown {
  if (typeof value === 'string') {
    return redactSecrets(value, extraSecrets);
  }
  if (Array.isArray(value)) {
    return value.map((item) => sanitizeRecord(item, extraSecrets));
  }
  if (value && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value)) {
      if (SENSITIVE_KEY_RE.test(k)) {
        out[k] = '[REDACTED]';
      } else {
        out[k] = sanitizeRecord(v, extraSecrets);
      }
    }
    return out;
  }
  return value;
}

export class AutomaticTokenManager {
  private readonly signingSecret: Buffer;
  private readonly ttlMs: number;
  private readonly renewThresholdRatio: number;
  private readonly maxActiveSessions: number;
  private readonly now: () => number;

  private readonly sessions = new Map<string, CoreTokenSession & { tokenHash: string }>();
  private readonly revokedTokenHashes = new Map<string, number>();

  constructor(options: TokenManagerOptions = {}) {
    this.signingSecret = options.signingSecret ?? crypto.randomBytes(32);
    this.ttlMs = Math.max(10_000, options.ttlMs ?? 15 * 60 * 1000);
    this.renewThresholdRatio = Math.min(0.9, Math.max(0.2, options.renewThresholdRatio ?? 0.65));
    this.maxActiveSessions = Math.max(8, options.maxActiveSessions ?? 256);
    this.now = options.now ?? (() => Date.now());
  }

  private signPayload(sessionId: string, nonce: string, issuedAtMs: number, expiresAtMs: number): string {
    const payload = `${sessionId}.${nonce}.${issuedAtMs}.${expiresAtMs}`;
    return crypto.createHmac('sha256', this.signingSecret).update(payload).digest('base64url');
  }

  private hashToken(token: string): string {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  private constantTimeEqualStrings(a: string, b: string): boolean {
    const bufA = Buffer.from(a, 'utf8');
    const bufB = Buffer.from(b, 'utf8');
    if (bufA.length !== bufB.length) return false;
    return crypto.timingSafeEqual(bufA, bufB);
  }

  public purgeExpired(): void {
    const current = this.now();
    for (const [sid, rec] of this.sessions.entries()) {
      if (rec.expiresAtMs <= current) {
        this.revokedTokenHashes.set(rec.tokenHash, current + this.ttlMs);
        this.sessions.delete(sid);
      }
    }
    for (const [hash, deleteAfterMs] of this.revokedTokenHashes.entries()) {
      if (deleteAfterMs <= current) {
        this.revokedTokenHashes.delete(hash);
      }
    }
  }

  public issueSession(params: {
    scope?: 'core-session' | 'relay-agent';
    clientLabel?: string;
    customTtlMs?: number;
    sessionId?: string;
    rotationCount?: number;
  } = {}): CoreTokenSession {
    this.purgeExpired();

    if (this.sessions.size >= this.maxActiveSessions) {
      // Evict oldest session cleanly to bound memory
      const oldestKey = this.sessions.keys().next().value;
      if (oldestKey) {
        const oldRec = this.sessions.get(oldestKey);
        if (oldRec) {
          this.revokedTokenHashes.set(oldRec.tokenHash, this.now() + this.ttlMs);
        }
        this.sessions.delete(oldestKey);
      }
    }

    const issuedAtMs = this.now();
    const effectiveTtl = Math.max(10_000, params.customTtlMs ?? this.ttlMs);
    const expiresAtMs = issuedAtMs + effectiveTtl;
    const refreshAfterMs = issuedAtMs + Math.floor(effectiveTtl * this.renewThresholdRatio);
    const sessionId = params.sessionId ?? `core_${crypto.randomBytes(12).toString('base64url')}`;
    const nonce = crypto.randomBytes(24).toString('base64url');
    const sig = this.signPayload(sessionId, nonce, issuedAtMs, expiresAtMs);
    const token = `awt1.${sessionId}.${nonce}.${issuedAtMs}.${expiresAtMs}.${sig}`;
    const tokenHash = this.hashToken(token);

    const record: CoreTokenSession & { tokenHash: string } = {
      sessionId,
      token,
      tokenHash,
      issuedAtMs,
      expiresAtMs,
      refreshAfterMs,
      issuedAtIso: new Date(issuedAtMs).toISOString(),
      expiresAtIso: new Date(expiresAtMs).toISOString(),
      rotationCount: params.rotationCount ?? 0,
      scope: params.scope ?? 'core-session',
      clientLabel: params.clientLabel?.slice(0, 64),
    };

    this.sessions.set(sessionId, record);
    return {
      sessionId: record.sessionId,
      token: record.token,
      issuedAtMs: record.issuedAtMs,
      expiresAtMs: record.expiresAtMs,
      refreshAfterMs: record.refreshAfterMs,
      issuedAtIso: record.issuedAtIso,
      expiresAtIso: record.expiresAtIso,
      rotationCount: record.rotationCount,
      scope: record.scope,
      clientLabel: record.clientLabel,
    };
  }

  public verifyToken(rawToken: string | undefined | null, requiredScope?: 'core-session' | 'relay-agent'): TokenVerifyResult {
    this.purgeExpired();

    if (!rawToken || typeof rawToken !== 'string' || !rawToken.trim()) {
      return { valid: false, errorCode: 'TOKEN_MISSING' };
    }

    const token = rawToken.trim();
    const tokenHash = this.hashToken(token);

    if (this.revokedTokenHashes.has(tokenHash)) {
      return { valid: false, errorCode: 'TOKEN_REPLAYED' };
    }

    const parts = token.split('.');
    if (parts.length !== 6 || parts[0] !== 'awt1') {
      return { valid: false, errorCode: 'TOKEN_INVALID' };
    }

    const [, sessionId, nonce, issuedStr, expiresStr, sig] = parts;
    const issuedAtMs = Number(issuedStr);
    const expiresAtMs = Number(expiresStr);
    if (!sessionId || !nonce || !Number.isFinite(issuedAtMs) || !Number.isFinite(expiresAtMs)) {
      return { valid: false, errorCode: 'TOKEN_INVALID' };
    }

    const expectedSig = this.signPayload(sessionId, nonce, issuedAtMs, expiresAtMs);
    if (!this.constantTimeEqualStrings(sig, expectedSig)) {
      return { valid: false, errorCode: 'TOKEN_INVALID' };
    }

    const current = this.now();
    if (expiresAtMs <= current) {
      return { valid: false, errorCode: 'TOKEN_EXPIRED' };
    }

    const stored = this.sessions.get(sessionId);
    if (!stored) {
      return { valid: false, errorCode: 'TOKEN_REVOKED' };
    }

    if (!this.constantTimeEqualStrings(stored.tokenHash, tokenHash)) {
      return { valid: false, errorCode: 'TOKEN_REPLAYED' };
    }

    if (requiredScope && stored.scope !== requiredScope) {
      return { valid: false, errorCode: 'TOKEN_INVALID' };
    }

    return {
      valid: true,
      shouldRotate: current >= stored.refreshAfterMs,
      session: {
        sessionId: stored.sessionId,
        token: stored.token,
        issuedAtMs: stored.issuedAtMs,
        expiresAtMs: stored.expiresAtMs,
        refreshAfterMs: stored.refreshAfterMs,
        issuedAtIso: stored.issuedAtIso,
        expiresAtIso: stored.expiresAtIso,
        rotationCount: stored.rotationCount,
        scope: stored.scope,
        clientLabel: stored.clientLabel,
      },
    };
  }

  public renewToken(rawToken: string | undefined | null): { ok: true; session: CoreTokenSession } | { ok: false; errorCode: TokenValidationErrorCode } {
    const check = this.verifyToken(rawToken);
    if (!check.valid || !check.session) {
      return { ok: false, errorCode: check.errorCode ?? 'TOKEN_INVALID' };
    }

    const oldRec = this.sessions.get(check.session.sessionId);
    if (oldRec) {
      // Tombstone the previous token immediately so it can never be replayed
      this.revokedTokenHashes.set(oldRec.tokenHash, this.now() + this.ttlMs);
    }

    const rotated = this.issueSession({
      sessionId: check.session.sessionId,
      scope: check.session.scope,
      clientLabel: check.session.clientLabel,
      rotationCount: check.session.rotationCount + 1,
    });

    return { ok: true, session: rotated };
  }

  public revokeToken(rawToken: string | undefined | null): boolean {
    if (!rawToken || typeof rawToken !== 'string') return false;
    const token = rawToken.trim();
    const parts = token.split('.');
    const tokenHash = this.hashToken(token);
    this.revokedTokenHashes.set(tokenHash, this.now() + this.ttlMs);

    if (parts.length === 6 && parts[1]) {
      const stored = this.sessions.get(parts[1]);
      if (stored && this.constantTimeEqualStrings(stored.tokenHash, tokenHash)) {
        this.sessions.delete(parts[1]);
        return true;
      }
    }
    return false;
  }

  public getPublicStats(): { activeSessions: number; revokedTombstones: number; ttlMs: number } {
    this.purgeExpired();
    return {
      activeSessions: this.sessions.size,
      revokedTombstones: this.revokedTokenHashes.size,
      ttlMs: this.ttlMs,
    };
  }
}
