import express, { type Request, type Response, type Router } from 'express';
import { AdvancedWifiCoreEngine } from './coreEngine.ts';
import { type TokenValidationErrorCode } from './tokenManager.ts';

function extractBearerToken(req: Request): string | undefined {
  const auth = req.header('authorization');
  if (auth && auth.toLowerCase().startsWith('bearer ')) {
    return auth.slice(7).trim();
  }
  const headerToken = req.header('x-core-token');
  if (headerToken) return headerToken.trim();
  return undefined;
}

function mapTokenErrorStatus(code?: TokenValidationErrorCode): number {
  if (code === 'TOKEN_MISSING') return 401;
  return 401;
}

export function createCoreApiRouter(core: AdvancedWifiCoreEngine): Router {
  const router = express.Router();

  // Public Core status & topology snapshot (strictly secret-free)
  router.get('/status', (req: Request, res: Response) => {
    const requestHost = req.header('x-forwarded-host') || req.header('host') || '';
    res.json(core.getSafeStatusSnapshot(requestHost));
  });

  // Issue a short-lived temporary Core session token
  router.post('/tokens/issue', (req: Request, res: Response) => {
    const label = typeof req.body?.clientLabel === 'string' ? req.body.clientLabel : 'web-client';
    const session = core.tokenManager.issueSession({
      scope: 'core-session',
      clientLabel: label,
    });
    res.status(201).json({
      ok: true,
      sessionId: session.sessionId,
      token: session.token,
      issuedAtIso: session.issuedAtIso,
      expiresAtIso: session.expiresAtIso,
      expiresAtMs: session.expiresAtMs,
      refreshAfterMs: session.refreshAfterMs,
      rotationCount: session.rotationCount,
    });
  });

  // Verify token validity and whether rotation is advised
  router.post('/tokens/verify', (req: Request, res: Response) => {
    const token = extractBearerToken(req) || (typeof req.body?.token === 'string' ? req.body.token : undefined);
    const check = core.tokenManager.verifyToken(token, 'core-session');
    if (!check.valid || !check.session) {
      res.status(mapTokenErrorStatus(check.errorCode)).json({
        ok: false,
        error: check.errorCode ?? 'TOKEN_INVALID',
      });
      return;
    }
    res.json({
      ok: true,
      shouldRotate: Boolean(check.shouldRotate),
      sessionId: check.session.sessionId,
      expiresAtIso: check.session.expiresAtIso,
      expiresAtMs: check.session.expiresAtMs,
      refreshAfterMs: check.session.refreshAfterMs,
      rotationCount: check.session.rotationCount,
    });
  });

  // Rotate token cleanly before expiration (old token is immediately revoked & anti-replay blacklisted)
  router.post('/tokens/refresh', (req: Request, res: Response) => {
    const token = extractBearerToken(req) || (typeof req.body?.token === 'string' ? req.body.token : undefined);
    const renewed = core.tokenManager.renewToken(token);
    if (renewed.ok === false) {
      res.status(401).json({
        ok: false,
        error: renewed.errorCode,
      });
      return;
    }
    res.json({
      ok: true,
      sessionId: renewed.session.sessionId,
      token: renewed.session.token,
      issuedAtIso: renewed.session.issuedAtIso,
      expiresAtIso: renewed.session.expiresAtIso,
      expiresAtMs: renewed.session.expiresAtMs,
      refreshAfterMs: renewed.session.refreshAfterMs,
      rotationCount: renewed.session.rotationCount,
    });
  });

  // Revoke Core session token and purge isolated upstream router cookies
  router.post('/tokens/revoke', (req: Request, res: Response) => {
    const token = extractBearerToken(req) || (typeof req.body?.token === 'string' ? req.body.token : undefined);
    const check = core.tokenManager.verifyToken(token);
    if (check.session?.sessionId) {
      core.clearSession(check.session.sessionId);
    }
    const revoked = core.tokenManager.revokeToken(token);
    res.json({ ok: true, revoked });
  });

  // Method 4: Core LAN Router Probe & Request Bridge (when server runs locally on user's LAN)
  router.post('/router/request', async (req: Request, res: Response) => {
    const token = extractBearerToken(req);
    const check = core.tokenManager.verifyToken(token, 'core-session');
    if (!check.valid || !check.session) {
      res.status(401).json({
        ok: false,
        error: check.errorCode ?? 'TOKEN_INVALID',
      });
      return;
    }

    const url = typeof req.body?.url === 'string' ? req.body.url : '';
    const rawMethod = typeof req.body?.method === 'string' ? req.body.method.toUpperCase() : 'GET';
    const method: 'GET' | 'POST' | 'PUT' =
      rawMethod === 'POST' || rawMethod === 'PUT' ? rawMethod : 'GET';
    const headers =
      req.body?.headers && typeof req.body.headers === 'object'
        ? (req.body.headers as Record<string, string>)
        : {};
    const body = typeof req.body?.body === 'string' ? req.body.body : undefined;
    const timeoutMs = typeof req.body?.timeoutMs === 'number' ? req.body.timeoutMs : 6000;
    const requestHost = req.header('x-forwarded-host') || req.header('host') || '';

    const result = await core.executeLocalLanRequest({
      sessionId: check.session.sessionId,
      requestHost,
      request: { url, method, headers, body, timeoutMs },
    });

    // Optional seamless token rotation hint header (client calls /tokens/refresh)
    if (check.shouldRotate) {
      res.setHeader('X-Core-Token-Refresh-Recommended', '1');
    }

    if (!result.ok) {
      res.status(result.error === 'INVALID_ROUTER_ADDRESS' ? 400 : 502).json(result);
      return;
    }
    res.json(result);
  });

  // Method 5: Secure Cloud Relay (authentic outbound-initiated LAN agent broker)
  router.get('/relay/status', (req: Request, res: Response) => {
    const token = extractBearerToken(req);
    const check = core.tokenManager.verifyToken(token, 'core-session');
    if (!check.valid) {
      res.status(401).json({ ok: false, error: check.errorCode ?? 'TOKEN_INVALID' });
      return;
    }
    const agents = core.listRelayAgents();
    res.json({
      ok: true,
      onlineCount: agents.filter((a) => a.online).length,
      agents: agents.map((a) => ({
        agentId: a.agentId,
        label: a.label,
        lanGatewayHint: a.lanGatewayHint ?? null,
        online: a.online,
        registeredAtIso: a.registeredAtIso,
      })),
    });
  });

  router.post('/relay/register', (req: Request, res: Response) => {
    const token = extractBearerToken(req);
    const check = core.tokenManager.verifyToken(token, 'core-session');
    if (!check.valid) {
      res.status(401).json({ ok: false, error: check.errorCode ?? 'TOKEN_INVALID' });
      return;
    }
    const label = typeof req.body?.label === 'string' ? req.body.label : 'Home LAN Relay';
    const lanGatewayHint = typeof req.body?.lanGatewayHint === 'string' ? req.body.lanGatewayHint : undefined;
    const registered = core.registerRelayAgent({ label, lanGatewayHint });
    res.status(201).json({
      ok: true,
      ...registered,
    });
  });

  router.post('/relay/poll', (req: Request, res: Response) => {
    const token = extractBearerToken(req);
    const check = core.tokenManager.verifyToken(token, 'relay-agent');
    if (!check.valid || !check.session) {
      res.status(401).json({ ok: false, error: check.errorCode ?? 'TOKEN_INVALID' });
      return;
    }
    const agentId = typeof req.body?.agentId === 'string' ? req.body.agentId : '';
    const cmd = core.pollRelayCommand(agentId);
    res.json({
      ok: true,
      command: cmd,
    });
  });

  router.post('/relay/respond', (req: Request, res: Response) => {
    const token = extractBearerToken(req);
    const check = core.tokenManager.verifyToken(token, 'relay-agent');
    if (!check.valid) {
      res.status(401).json({ ok: false, error: check.errorCode ?? 'TOKEN_INVALID' });
      return;
    }
    const agentId = typeof req.body?.agentId === 'string' ? req.body.agentId : '';
    const commandId = typeof req.body?.commandId === 'string' ? req.body.commandId : '';
    const status = typeof req.body?.status === 'number' ? req.body.status : 502;
    const ok = Boolean(req.body?.ok);
    const body = typeof req.body?.body === 'string' ? req.body.body : '';
    const headers =
      req.body?.headers && typeof req.body.headers === 'object'
        ? (req.body.headers as Record<string, string>)
        : {};
    const error = typeof req.body?.error === 'string' ? req.body.error : undefined;

    const accepted = core.completeRelayCommand(agentId, commandId, {
      ok,
      status,
      headers,
      body,
      error,
    });
    res.json({ ok: accepted });
  });

  router.post('/relay/request', async (req: Request, res: Response) => {
    const token = extractBearerToken(req);
    const check = core.tokenManager.verifyToken(token, 'core-session');
    if (!check.valid || !check.session) {
      res.status(401).json({
        ok: false,
        error: check.errorCode ?? 'TOKEN_INVALID',
      });
      return;
    }

    const url = typeof req.body?.url === 'string' ? req.body.url : '';
    const rawMethod = typeof req.body?.method === 'string' ? req.body.method.toUpperCase() : 'GET';
    const method: 'GET' | 'POST' | 'PUT' =
      rawMethod === 'POST' || rawMethod === 'PUT' ? rawMethod : 'GET';
    const headers =
      req.body?.headers && typeof req.body.headers === 'object'
        ? (req.body.headers as Record<string, string>)
        : {};
    const body = typeof req.body?.body === 'string' ? req.body.body : undefined;
    const timeoutMs = typeof req.body?.timeoutMs === 'number' ? req.body.timeoutMs : 6000;

    const result = await core.executeViaRelay({
      sessionId: check.session.sessionId,
      request: { url, method, headers, body, timeoutMs },
    });

    if (!result.ok) {
      res.status(result.error === 'INVALID_ROUTER_ADDRESS' ? 400 : 503).json(result);
      return;
    }
    res.json(result);
  });

  return router;
}
