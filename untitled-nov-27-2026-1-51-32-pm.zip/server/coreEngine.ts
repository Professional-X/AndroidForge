import crypto from 'node:crypto';
import os from 'node:os';
import {
  AutomaticTokenManager,
  redactSecrets,
  sanitizeRecord,
} from './tokenManager.ts';

export type ServerLanTopology = 'local-lan' | 'cloud-hosted';

export interface CoreUpstreamHttpRequest {
  url: string;
  method: 'GET' | 'POST' | 'PUT';
  headers?: Record<string, string>;
  body?: string;
  timeoutMs?: number;
}

export interface CoreUpstreamHttpResponse {
  ok: boolean;
  status: number;
  headers: Record<string, string>;
  body: string;
  latencyMs: number;
  error?: string;
}

export interface RelayAgentInfo {
  agentId: string;
  label: string;
  lanGatewayHint?: string;
  registeredAtIso: string;
  lastSeenMs: number;
  online: boolean;
}

interface PendingRelayCommand {
  commandId: string;
  sessionId: string;
  request: CoreUpstreamHttpRequest;
  createdAtMs: number;
  resolve: (res: CoreUpstreamHttpResponse) => void;
  timer: ReturnType<typeof setTimeout>;
}

const KNOWN_ROUTER_HOSTNAMES = new Set([
  'tplinkwifi.net',
  'tplinklogin.net',
  'mwlogin.net',
  'router.asus.com',
  'www.routerlogin.net',
  'routerlogin.net',
  'tendawifi.com',
  'dlinkrouter.local',
  'fritz.box',
  'myrouter.local',
  'huawei.local',
]);

export function isPrivateLanIpv4(ip: string): boolean {
  const parts = ip.split('.');
  if (parts.length !== 4) return false;
  const nums = parts.map((p) => (/^\d{1,3}$/.test(p) ? Number(p) : -1));
  if (nums.some((n) => n < 0 || n > 255)) return false;

  const [a, b] = nums;
  if (a === 10) return true;
  if (a === 172 && b >= 16 && b <= 31) return true;
  if (a === 192 && b === 168) return true;
  return false;
}

export function validateLanTargetUrl(
  rawUrl: string,
  options: { allowLoopbackForTests?: boolean } = {}
): { valid: boolean; normalizedUrl: string; hostname: string; reason?: string } {
  const trimmed = String(rawUrl ?? '').trim();
  if (!trimmed) {
    return { valid: false, normalizedUrl: '', hostname: '', reason: 'empty_url' };
  }

  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    return { valid: false, normalizedUrl: '', hostname: '', reason: 'malformed_url' };
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    return { valid: false, normalizedUrl: '', hostname: '', reason: 'invalid_scheme' };
  }

  if (parsed.username || parsed.password) {
    return { valid: false, normalizedUrl: '', hostname: '', reason: 'embedded_credentials' };
  }

  const host = parsed.hostname.toLowerCase();

  // Always block cloud metadata (169.254.x.x), 0.0.0.0, and IPv6 link-local
  if (
    host.startsWith('169.254.') ||
    host === '0.0.0.0' ||
    host.startsWith('fe80:') ||
    host.startsWith('[fe80:')
  ) {
    return { valid: false, normalizedUrl: '', hostname: host, reason: 'blocked_internal_target' };
  }

  const isLoopback =
    host === 'localhost' || host.startsWith('127.') || host === '::1' || host === '[::1]';
  if (isLoopback && !options.allowLoopbackForTests) {
    return { valid: false, normalizedUrl: '', hostname: host, reason: 'blocked_loopback' };
  }

  const isAllowed =
    (isLoopback && Boolean(options.allowLoopbackForTests)) ||
    isPrivateLanIpv4(host) ||
    KNOWN_ROUTER_HOSTNAMES.has(host) ||
    host.endsWith('.local');

  if (!isAllowed) {
    return { valid: false, normalizedUrl: '', hostname: host, reason: 'non_lan_target' };
  }

  return {
    valid: true,
    normalizedUrl: parsed.toString(),
    hostname: host,
  };
}

export function detectServerLanTopology(
  requestHost?: string,
  env: Record<string, string | undefined> = process.env
): {
  topology: ServerLanTopology;
  hostHeader: string;
  localInterfaces: string[];
  reason: string;
} {
  const host = String(requestHost ?? '').toLowerCase().split(':')[0].trim();

  // Collect server network interfaces (RFC1918 only, no external details)
  const localInterfaces: string[] = [];
  try {
    const nets = os.networkInterfaces();
    for (const entries of Object.values(nets)) {
      for (const info of entries ?? []) {
        if (info.family === 'IPv4' && !info.internal && isPrivateLanIpv4(info.address)) {
          localInterfaces.push(info.address);
        }
      }
    }
  } catch {
    // Ignore interface scan failures in restricted sandboxes
  }

  const isCloudEnv = Boolean(
    env.K_SERVICE ||
      env.CLOUD_RUN_JOB ||
      env.K_REVISION ||
      host.endsWith('.run.app') ||
      host.includes('ais-dev-') ||
      host.includes('ais-pre-')
  );

  if (isCloudEnv) {
    return {
      topology: 'cloud-hosted',
      hostHeader: host || 'cloud-run',
      localInterfaces,
      reason: 'Server is running in an isolated cloud environment outside the user home Wi-Fi LAN.',
    };
  }

  if (
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host === '' ||
    isPrivateLanIpv4(host) ||
    host.endsWith('.local')
  ) {
    return {
      topology: 'local-lan',
      hostHeader: host || 'localhost',
      localInterfaces,
      reason: 'Server is executing locally or on a private RFC1918 LAN host.',
    };
  }

  return {
    topology: 'cloud-hosted',
    hostHeader: host,
    localInterfaces,
    reason: 'Server origin is public and isolated from private home LAN subnets.',
  };
}

function mergeSetCookieHeaders(
  jar: Map<string, string>,
  headers: Headers
): void {
  const rawSetCookies =
    typeof (headers as unknown as { getSetCookie?: () => string[] }).getSetCookie === 'function'
      ? (headers as unknown as { getSetCookie: () => string[] }).getSetCookie()
      : headers.get('set-cookie')
      ? [headers.get('set-cookie') as string]
      : [];

  for (const cookieStr of rawSetCookies) {
    const firstPair = cookieStr.split(';')[0]?.trim();
    if (!firstPair) continue;
    const eqIdx = firstPair.indexOf('=');
    if (eqIdx <= 0) continue;
    const name = firstPair.slice(0, eqIdx).trim();
    const value = firstPair.slice(eqIdx + 1).trim();
    if (!value || value.toLowerCase() === 'deleted') {
      jar.delete(name);
    } else {
      jar.set(name, value);
    }
  }
}

export class AdvancedWifiCoreEngine {
  public readonly tokenManager: AutomaticTokenManager;
  private readonly cookieJars = new Map<string, Map<string, string>>();
  private readonly relayAgents = new Map<
    string,
    {
      agentId: string;
      label: string;
      lanGatewayHint?: string;
      registeredAtIso: string;
      lastSeenMs: number;
      queue: PendingRelayCommand[];
      pendingResponses: Map<string, PendingRelayCommand>;
    }
  >();
  private readonly allowLoopbackForTests: boolean;

  constructor(options: { tokenManager?: AutomaticTokenManager; allowLoopbackForTests?: boolean } = {}) {
    this.tokenManager = options.tokenManager ?? new AutomaticTokenManager();
    this.allowLoopbackForTests = Boolean(options.allowLoopbackForTests);
  }

  public clearSession(sessionId: string): void {
    this.cookieJars.delete(sessionId);
  }

  private getSessionCookieHeader(sessionId: string, extraCookie?: string): string | undefined {
    const jar = this.cookieJars.get(sessionId);
    const merged = new Map<string, string>(jar ? jar.entries() : []);
    if (extraCookie) {
      for (const part of extraCookie.split(';')) {
        const trimmed = part.trim();
        const eq = trimmed.indexOf('=');
        if (eq > 0) {
          merged.set(trimmed.slice(0, eq).trim(), trimmed.slice(eq + 1).trim());
        }
      }
    }
    if (merged.size === 0) return undefined;
    return Array.from(merged.entries())
      .map(([k, v]) => `${k}=${v}`)
      .join('; ');
  }

  public async executeLocalLanRequest(params: {
    sessionId: string;
    requestHost?: string;
    request: CoreUpstreamHttpRequest;
  }): Promise<CoreUpstreamHttpResponse> {
    const startMs = Date.now();
    const topo = detectServerLanTopology(params.requestHost);
    if (topo.topology !== 'local-lan' && !this.allowLoopbackForTests) {
      return {
        ok: false,
        status: 502,
        headers: {},
        body: '',
        latencyMs: Date.now() - startMs,
        error: 'CLOUD_ISOLATED_FROM_LAN',
      };
    }

    const targetCheck = validateLanTargetUrl(params.request.url, {
      allowLoopbackForTests: this.allowLoopbackForTests,
    });
    if (!targetCheck.valid) {
      return {
        ok: false,
        status: 400,
        headers: {},
        body: '',
        latencyMs: Date.now() - startMs,
        error: 'INVALID_ROUTER_ADDRESS',
      };
    }

    const timeoutMs = Math.min(20_000, Math.max(800, params.request.timeoutMs ?? 6000));
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const cleanHeaders: Record<string, string> = {};
      for (const [k, v] of Object.entries(params.request.headers ?? {})) {
        const lower = k.toLowerCase();
        if (lower === 'host' || lower === 'content-length' || lower === 'cookie') continue;
        cleanHeaders[k] = v;
      }

      const cookieHeader = this.getSessionCookieHeader(
        params.sessionId,
        params.request.headers?.Cookie ?? params.request.headers?.cookie
      );
      if (cookieHeader) {
        cleanHeaders['Cookie'] = cookieHeader;
      }

      const method = params.request.method || 'GET';
      const upstream = await fetch(targetCheck.normalizedUrl, {
        method,
        headers: cleanHeaders,
        body: method !== 'GET' && params.request.body !== undefined ? params.request.body : undefined,
        redirect: 'follow',
        signal: controller.signal,
      });

      let jar = this.cookieJars.get(params.sessionId);
      if (!jar) {
        jar = new Map<string, string>();
        this.cookieJars.set(params.sessionId, jar);
      }
      mergeSetCookieHeaders(jar, upstream.headers);

      const safeHeaders: Record<string, string> = {};
      upstream.headers.forEach((v, k) => {
        if (k.toLowerCase() === 'set-cookie') return; // Never leak raw router Set-Cookie to browser storage
        safeHeaders[k.toLowerCase()] = v;
      });

      const body = await upstream.text();
      return {
        ok: true,
        status: upstream.status,
        headers: safeHeaders,
        body,
        latencyMs: Date.now() - startMs,
      };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      return {
        ok: false,
        status: 502,
        headers: {},
        body: '',
        latencyMs: Date.now() - startMs,
        error: msg.toLowerCase().includes('abort') ? 'ROUTER_OFFLINE' : 'ROUTER_OFFLINE',
      };
    } finally {
      clearTimeout(timer);
    }
  }

  public registerRelayAgent(params: {
    label?: string;
    lanGatewayHint?: string;
  }): { agentId: string; relayToken: string; expiresAtIso: string; registeredAtIso: string } {
    const agentId = `relay_${crypto.randomBytes(6).toString('hex')}`;
    const issued = this.tokenManager.issueSession({
      scope: 'relay-agent',
      clientLabel: params.label?.trim().slice(0, 48) || 'LAN Relay Agent',
      customTtlMs: 24 * 60 * 60 * 1000,
    });

    const registeredAtIso = new Date().toISOString();
    this.relayAgents.set(agentId, {
      agentId,
      label: params.label?.trim().slice(0, 48) || 'LAN Relay Agent',
      lanGatewayHint: params.lanGatewayHint?.trim().slice(0, 64),
      registeredAtIso,
      lastSeenMs: Date.now(),
      queue: [],
      pendingResponses: new Map(),
    });

    return {
      agentId,
      relayToken: issued.token,
      expiresAtIso: issued.expiresAtIso,
      registeredAtIso,
    };
  }

  public listRelayAgents(): RelayAgentInfo[] {
    const now = Date.now();
    const out: RelayAgentInfo[] = [];
    for (const agent of this.relayAgents.values()) {
      const online = now - agent.lastSeenMs < 45_000;
      out.push({
        agentId: agent.agentId,
        label: agent.label,
        lanGatewayHint: agent.lanGatewayHint,
        registeredAtIso: agent.registeredAtIso,
        lastSeenMs: agent.lastSeenMs,
        online,
      });
    }
    return out;
  }

  public pollRelayCommand(agentId: string): {
    commandId: string;
    request: CoreUpstreamHttpRequest;
  } | null {
    const agent = this.relayAgents.get(agentId);
    if (!agent) return null;
    agent.lastSeenMs = Date.now();
    const next = agent.queue.shift();
    if (!next) return null;
    agent.pendingResponses.set(next.commandId, next);
    return {
      commandId: next.commandId,
      request: next.request,
    };
  }

  public completeRelayCommand(
    agentId: string,
    commandId: string,
    response: Omit<CoreUpstreamHttpResponse, 'latencyMs'>
  ): boolean {
    const agent = this.relayAgents.get(agentId);
    if (!agent) return false;
    agent.lastSeenMs = Date.now();
    const pending = agent.pendingResponses.get(commandId);
    if (!pending) return false;
    clearTimeout(pending.timer);
    agent.pendingResponses.delete(commandId);
    pending.resolve({
      ...response,
      latencyMs: Date.now() - pending.createdAtMs,
    });
    return true;
  }

  public async executeViaRelay(params: {
    sessionId: string;
    request: CoreUpstreamHttpRequest;
  }): Promise<CoreUpstreamHttpResponse> {
    const startMs = Date.now();
    const targetCheck = validateLanTargetUrl(params.request.url, {
      allowLoopbackForTests: this.allowLoopbackForTests,
    });
    if (!targetCheck.valid) {
      return {
        ok: false,
        status: 400,
        headers: {},
        body: '',
        latencyMs: Date.now() - startMs,
        error: 'INVALID_ROUTER_ADDRESS',
      };
    }

    const now = Date.now();
    const activeAgent = Array.from(this.relayAgents.values()).find(
      (a) => now - a.lastSeenMs < 45_000
    );

    if (!activeAgent) {
      return {
        ok: false,
        status: 503,
        headers: {},
        body: '',
        latencyMs: Date.now() - startMs,
        error: 'RELAY_AGENT_OFFLINE',
      };
    }

    const commandId = `cmd_${crypto.randomBytes(8).toString('hex')}`;
    const timeoutMs = Math.min(15_000, Math.max(1500, params.request.timeoutMs ?? 6000));

    return await new Promise<CoreUpstreamHttpResponse>((resolve) => {
      const timer = setTimeout(() => {
        activeAgent.pendingResponses.delete(commandId);
        activeAgent.queue = activeAgent.queue.filter((c) => c.commandId !== commandId);
        resolve({
          ok: false,
          status: 504,
          headers: {},
          body: '',
          latencyMs: Date.now() - startMs,
          error: 'RELAY_AGENT_OFFLINE',
        });
      }, timeoutMs);

      activeAgent.queue.push({
        commandId,
        sessionId: params.sessionId,
        request: {
          ...params.request,
          url: targetCheck.normalizedUrl,
        },
        createdAtMs: startMs,
        resolve,
        timer,
      });
    });
  }

  public getSafeStatusSnapshot(requestHost?: string) {
    const topo = detectServerLanTopology(requestHost);
    return sanitizeRecord({
      ok: true,
      coreName: 'Advanced Wi-Fi Core',
      topology: topo.topology,
      topologyReason: topo.reason,
      localInterfaces: topo.localInterfaces,
      tokenStats: this.tokenManager.getPublicStats(),
      relayAgentsOnline: this.listRelayAgents().filter((a) => a.online).length,
      relayAgentsTotal: this.relayAgents.size,
    });
  }

  public redactForLog(input: string): string {
    return redactSecrets(input);
  }
}
