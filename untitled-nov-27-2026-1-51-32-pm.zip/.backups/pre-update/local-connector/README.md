# Advanced Wi-Fi Local Connector Companion

Because modern web browsers enforce CORS, HTTPS-to-HTTP Mixed Content protection, and Private Network Access rules, a web application hosted over HTTPS cannot directly open raw authenticated HTTP sessions to a local home router (`http://192.168.1.1`).

The Local Connector Companion is an optional, zero-dependency Node.js bridge that runs exclusively on your computer inside your local Wi-Fi network.

## Security Guarantees
- Listens **only** on `127.0.0.1:4890` (localhost only).
- Enforces strict RFC1918 private LAN validation (`192.168.0.0/16`, `10.0.0.0/8`, `172.16.0.0/12`, or known router local hostnames).
- Blocks loopback, cloud metadata (`169.254.169.254`), and public internet targets.
- Stores router cookies strictly in RAM during your active session and never logs passwords.

## Usage
Requires Node.js 18+:

```bash
node local-connector/server.mjs
```

Once running, return to **Router Connection** in Advanced Wi-Fi and select **Local Connector Companion**.
