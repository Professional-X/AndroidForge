#!/usr/bin/env node
/**
 * Advanced Wi-Fi — Optional Local Connector Companion
 * Runs strictly on 127.0.0.1:4890 inside the user's local machine to bridge
 * browser CORS / HTTPS->HTTP Mixed Content boundaries when talking to a local LAN router.
 *
 * Security invariants:
 * - Binds exclusively to 127.0.0.1 (never 0.0.0.0)
 * - Validates every target router URL against RFC1918 private LAN ranges only
 * - Blocks loopback, 169.254.x.x metadata, and public internet URLs
 * - Holds router session cookies strictly in memory (never writes to disk or logs secrets)
 */

import http from 'node:http';
import { URL } from 'node:url';

const PORT = 4890;
const HOST = '127.0.0.1';

const KNOWN_ROUTER_HOSTS = new Set([
  'tplinkwifi.net',
  'tplinklogin.net',
  'mwlogin.net',
  'router.asus.com',
  'www.routerlogin.net',
  'routerlogin.net',
  'tendawifi.com',
  'dlinkrouter.local',
  'fritz.box'
]);

const sessionCookieJar = new Map();

function isPrivateLanIpv4(ip) {
  const parts = ip.split('.');
  if (parts.length !== 4) return false;
  const nums = parts.map((p) => (/^\d{1,3}$/.test(p) ? Number(p) : -1));
  if (nums.some((n) => n < 0 || n > 255)) return false;
  const [a, b] = nums;
  return a === 10 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
}

function validateLanTarget(targetUrl) {
  let parsed;
  try {
    parsed = new URL(targetUrl);
  } catch {
    return null;
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return null;
  const host = parsed.hostname.toLowerCase();
  if (
    host === 'localhost' ||
    host.startsWith('127.') ||
    host.startsWith('169.254.') ||
    host === '0.0.0.0' ||
    host === '::1'
  ) {
    return null;
  }
  if (!isPrivateLanIpv4(host) && !KNOWN_ROUTER_HOSTS.has(host) && !host.endsWith('.local')) {
    return null;
  }
  return parsed;
}

function setCorsHeaders(req, res) {
  const origin = req.headers.origin;
  if (origin) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Connector-Session');
  res.setHeader('Access-Control-Allow-Private-Network', 'true');
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;
    req.on('data', (chunk) => {
      total += chunk.length;
      if (total > 1024 * 1024) {
        reject(new Error('Payload too large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        const text = Buffer.concat(chunks).toString('utf8');
        resolve(text ? JSON.parse(text) : {});
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  setCorsHeaders(req, res);

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true, service: 'advanced-wifi-local-connector', version: '1.0.0' }));
    return;
  }

  if (req.method === 'POST' && req.url === '/session/clear') {
    const sessionId = String(req.headers['x-connector-session'] || 'default');
    sessionCookieJar.delete(sessionId);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ cleared: true }));
    return;
  }

  if (req.method === 'POST' && req.url === '/proxy') {
    try {
      const body = await readJsonBody(req);
      const targetUrl = validateLanTarget(body.url);
      if (!targetUrl) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'INVALID_ROUTER_ADDRESS' }));
        return;
      }

      const method = ['GET', 'POST', 'PUT'].includes(String(body.method || 'GET').toUpperCase())
        ? String(body.method || 'GET').toUpperCase()
        : 'GET';

      const sessionId = String(req.headers['x-connector-session'] || 'default');
      const outgoingHeaders = { ...(body.headers || {}) };
      const existingCookies = sessionCookieJar.get(sessionId);
      if (existingCookies && !outgoingHeaders.Cookie) {
        outgoingHeaders.Cookie = existingCookies;
      }

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), Number(body.timeoutMs || 8000));

      const upstream = await fetch(targetUrl.toString(), {
        method,
        headers: outgoingHeaders,
        body: method !== 'GET' && typeof body.body === 'string' ? body.body : undefined,
        signal: controller.signal
      });
      clearTimeout(timeout);

      const setCookies = upstream.headers.getSetCookie ? upstream.headers.getSetCookie() : [];
      if (setCookies.length > 0) {
        const cookiePairs = setCookies.map((c) => c.split(';')[0]).join('; ');
        sessionCookieJar.set(sessionId, cookiePairs);
      }

      const responseHeaders = {};
      upstream.headers.forEach((value, key) => {
        if (!['set-cookie', 'content-encoding', 'transfer-encoding'].includes(key.toLowerCase())) {
          responseHeaders[key] = value;
        }
      });

      const responseText = await upstream.text();
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(
        JSON.stringify({
          status: upstream.status,
          headers: responseHeaders,
          body: responseText
        })
      );
    } catch (err) {
      res.writeHead(502, { 'Content-Type': 'application/json' });
      res.end(
        JSON.stringify({
          error: 'ROUTER_OFFLINE',
          message: err instanceof Error ? err.message : 'Upstream connection failed'
        })
      );
    }
    return;
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Not Found' }));
});

server.listen(PORT, HOST, () => {
  console.log(`Advanced Wi-Fi Local Connector listening on http://${HOST}:${PORT}`);
});
