import { detectBestAdapter, getAdapterById } from '../router-adapters/registry';
import {
  ConnectedDevice,
  HttpRequestOptions,
  HttpResponse,
  RouterAdapter,
  RouterAdapterId,
  RouterConnectionContext,
  RouterCredentials,
  RouterError,
  RouterInfo,
  TransportRequestFn,
  WifiSettings,
  WifiUpdateInput
} from '../router-adapters/types';
import { sanitizeDiagnosticText, validateRouterAddress } from '../utils/networkSecurity';

export type TransportMode = 'connector' | 'direct';

export const CONNECTOR_BASE_URL = 'http://127.0.0.1:4890';

export interface ActiveRouterSession {
  adapter: RouterAdapter;
  context: RouterConnectionContext;
  transportMode: TransportMode;
  routerInfo: RouterInfo;
  wifiSettings: WifiSettings;
  devices: ConnectedDevice[];
  blockedMacs: string[];
  guestWifiEnabled: boolean | null;
  internetBlocked: boolean | null;
  lastUpdatedIso: string;
}

export async function checkLocalConnectorHealth(): Promise<boolean> {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 1800);
    const res = await fetch(`${CONNECTOR_BASE_URL}/health`, { signal: controller.signal });
    clearTimeout(timer);
    if (!res.ok) return false;
    const data = (await res.json()) as { ok?: boolean };
    return Boolean(data?.ok);
  } catch {
    return false;
  }
}

export function createTransport(
  baseUrl: string,
  mode: TransportMode,
  sessionId: string
): TransportRequestFn {
  return async (req: HttpRequestOptions): Promise<HttpResponse> => {
    const targetUrl = new URL(req.path, baseUrl).toString();
    const timeoutMs = req.timeoutMs ?? 8000;

    if (mode === 'connector') {
      let proxyRes: Response;
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), timeoutMs + 1000);
        proxyRes = await fetch(`${CONNECTOR_BASE_URL}/proxy`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Connector-Session': sessionId
          },
          body: JSON.stringify({
            url: targetUrl,
            method: req.method,
            headers: req.headers || {},
            body: req.body,
            timeoutMs
          }),
          signal: controller.signal
        });
        clearTimeout(timer);
      } catch {
        throw new RouterError(
          'BROWSER_BLOCKED_CORS_OR_MIXED_CONTENT',
          'Local Connector is not reachable on 127.0.0.1:4890'
        );
      }

      const payload = (await proxyRes.json()) as {
        status?: number;
        headers?: Record<string, string>;
        body?: string;
        error?: string;
      };

      if (payload.error === 'INVALID_ROUTER_ADDRESS') {
        throw new RouterError('INVALID_ROUTER_ADDRESS');
      }
      if (payload.error === 'ROUTER_OFFLINE' || !proxyRes.ok) {
        throw new RouterError('ROUTER_OFFLINE');
      }

      return {
        status: payload.status ?? 200,
        headers: payload.headers ?? {},
        body: payload.body ?? ''
      };
    }

    // Direct Browser Request mode
    if (typeof window !== 'undefined' && window.location.protocol === 'https:' && baseUrl.startsWith('http://')) {
      throw new RouterError(
        'BROWSER_BLOCKED_CORS_OR_MIXED_CONTENT',
        'HTTPS page cannot issue direct HTTP requests to local LAN IP'
      );
    }

    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      const res = await fetch(targetUrl, {
        method: req.method,
        headers: req.headers,
        body: req.method !== 'GET' ? req.body : undefined,
        credentials: 'include',
        signal: controller.signal
      });
      clearTimeout(timer);
      const headers: Record<string, string> = {};
      res.headers.forEach((v, k) => {
        headers[k.toLowerCase()] = v;
      });
      return {
        status: res.status,
        headers,
        body: await res.text()
      };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.toLowerCase().includes('abort') || msg.toLowerCase().includes('timeout')) {
        throw new RouterError('ROUTER_OFFLINE');
      }
      throw new RouterError('BROWSER_BLOCKED_CORS_OR_MIXED_CONTENT', sanitizeDiagnosticText(msg));
    }
  };
}

export async function connectToRouter(params: {
  rawAddress: string;
  preferredAdapterId: RouterAdapterId | 'auto';
  credentials: RouterCredentials;
  transportMode: TransportMode;
}): Promise<ActiveRouterSession> {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    throw new RouterError('INTERNET_OFFLINE');
  }

  const validated = validateRouterAddress(params.rawAddress);
  if (!validated.valid) {
    throw new RouterError('INVALID_ROUTER_ADDRESS', validated.reason);
  }

  const sessionId = `aw_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const transport = createTransport(validated.normalizedUrl, params.transportMode, sessionId);

  let adapter: RouterAdapter;
  if (params.preferredAdapterId === 'auto') {
    const rootRes = await transport({ method: 'GET', path: '/' });
    const huaweiProbe = await transport({ method: 'GET', path: '/api/webserver/SesTokInfo' }).catch(() => null);
    const detected = detectBestAdapter({
      rootStatus: rootRes.status,
      rootHeaders: rootRes.headers,
      rootBody: rootRes.body,
      extraProbeBody: huaweiProbe?.body
    });
    adapter = detected.adapter;
  } else {
    adapter = getAdapterById(params.preferredAdapterId);
  }

  const context: RouterConnectionContext = {
    baseUrl: validated.normalizedUrl,
    adapterId: adapter.id,
    transport,
    sessionState: { sessionId }
  };

  await adapter.connect(context);
  await adapter.authenticate(context, params.credentials);

  const [routerInfo, wifiSettings, deviceResult, guestWifiEnabled, internetBlocked] = await Promise.all([
    adapter.getRouterInfo(context),
    adapter.capabilities.readWifiSettings
      ? adapter.getWifiSettings(context)
      : Promise.resolve({ band24: null, band5: null }),
    adapter.capabilities.listDevices
      ? adapter.getConnectedDevices(context)
      : Promise.resolve({ connected: [], blockedMacs: [] }),
    adapter.capabilities.guestWifi && adapter.getGuestWifiEnabled
      ? adapter.getGuestWifiEnabled(context).catch(() => null)
      : Promise.resolve(null),
    adapter.capabilities.blockAllInternet && adapter.getInternetAccessPaused
      ? adapter.getInternetAccessPaused(context).catch(() => null)
      : Promise.resolve(null)
  ]);

  return {
    adapter,
    context,
    transportMode: params.transportMode,
    routerInfo,
    wifiSettings,
    devices: deviceResult.connected,
    blockedMacs: deviceResult.blockedMacs,
    guestWifiEnabled,
    internetBlocked,
    lastUpdatedIso: new Date().toISOString()
  };
}

export async function refreshRouterSession(session: ActiveRouterSession): Promise<ActiveRouterSession> {
  const [routerInfo, wifiSettings, deviceResult, guestWifiEnabled, internetBlocked] = await Promise.all([
    session.adapter.getRouterInfo(session.context),
    session.adapter.capabilities.readWifiSettings
      ? session.adapter.getWifiSettings(session.context)
      : Promise.resolve(session.wifiSettings),
    session.adapter.capabilities.listDevices
      ? session.adapter.getConnectedDevices(session.context)
      : Promise.resolve({ connected: session.devices, blockedMacs: session.blockedMacs }),
    session.adapter.capabilities.guestWifi && session.adapter.getGuestWifiEnabled
      ? session.adapter.getGuestWifiEnabled(session.context).catch(() => session.guestWifiEnabled)
      : Promise.resolve(session.guestWifiEnabled),
    session.adapter.capabilities.blockAllInternet && session.adapter.getInternetAccessPaused
      ? session.adapter.getInternetAccessPaused(session.context).catch(() => session.internetBlocked)
      : Promise.resolve(session.internetBlocked)
  ]);

  return {
    ...session,
    routerInfo,
    wifiSettings,
    devices: deviceResult.connected,
    blockedMacs: deviceResult.blockedMacs,
    guestWifiEnabled,
    internetBlocked,
    lastUpdatedIso: new Date().toISOString()
  };
}

export async function applyRouterWifiUpdate(
  session: ActiveRouterSession,
  update: WifiUpdateInput
): Promise<ActiveRouterSession> {
  if (!session.adapter.capabilities.writeWifiSettings) {
    throw new RouterError('UNSUPPORTED_MODEL');
  }
  await session.adapter.updateWifiSettings(session.context, update);
  const wifiSettings = await session.adapter.getWifiSettings(session.context).catch(() => session.wifiSettings);
  return {
    ...session,
    wifiSettings,
    lastUpdatedIso: new Date().toISOString()
  };
}

export async function blockRouterDevice(
  session: ActiveRouterSession,
  macAddress: string
): Promise<ActiveRouterSession> {
  if (!session.adapter.capabilities.blockMacDevice) {
    throw new RouterError('UNSUPPORTED_MODEL');
  }
  await session.adapter.blockDevice(session.context, macAddress);
  const deviceResult = await session.adapter.getConnectedDevices(session.context);
  return {
    ...session,
    devices: deviceResult.connected,
    blockedMacs: deviceResult.blockedMacs,
    lastUpdatedIso: new Date().toISOString()
  };
}

export async function unblockRouterDevice(
  session: ActiveRouterSession,
  macAddress: string
): Promise<ActiveRouterSession> {
  if (!session.adapter.capabilities.unblockMacDevice) {
    throw new RouterError('UNSUPPORTED_MODEL');
  }
  await session.adapter.unblockDevice(session.context, macAddress);
  const deviceResult = await session.adapter.getConnectedDevices(session.context);
  return {
    ...session,
    devices: deviceResult.connected,
    blockedMacs: deviceResult.blockedMacs,
    lastUpdatedIso: new Date().toISOString()
  };
}

export async function rebootConnectedRouter(session: ActiveRouterSession): Promise<void> {
  if (!session.adapter.capabilities.rebootRouter || !session.adapter.rebootRouter) {
    throw new RouterError('UNSUPPORTED_MODEL');
  }
  await session.adapter.rebootRouter(session.context);
}

export async function toggleGuestWifi(
  session: ActiveRouterSession,
  enabled: boolean
): Promise<ActiveRouterSession> {
  if (!session.adapter.capabilities.guestWifi || !session.adapter.setGuestWifiEnabled) {
    throw new RouterError('UNSUPPORTED_MODEL');
  }
  await session.adapter.setGuestWifiEnabled(session.context, enabled);
  return {
    ...session,
    guestWifiEnabled: enabled,
    lastUpdatedIso: new Date().toISOString()
  };
}

export async function toggleInternetAccess(
  session: ActiveRouterSession,
  blocked: boolean
): Promise<ActiveRouterSession> {
  if (!session.adapter.capabilities.blockAllInternet || !session.adapter.setInternetAccessPaused) {
    throw new RouterError('UNSUPPORTED_MODEL');
  }
  await session.adapter.setInternetAccessPaused(session.context, blocked);
  return {
    ...session,
    internetBlocked: blocked,
    routerInfo: {
      ...session.routerInfo,
      wanConnected: !blocked
    },
    lastUpdatedIso: new Date().toISOString()
  };
}

export async function disconnectRouterSession(session: ActiveRouterSession): Promise<void> {
  await session.adapter.disconnect(session.context).catch(() => undefined);
  if (session.transportMode === 'connector' && session.context.sessionState.sessionId) {
    await fetch(`${CONNECTOR_BASE_URL}/session/clear`, {
      method: 'POST',
      headers: { 'X-Connector-Session': session.context.sessionState.sessionId }
    }).catch(() => undefined);
  }
}
