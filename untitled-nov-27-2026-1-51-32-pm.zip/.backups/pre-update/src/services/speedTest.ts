export type SpeedTestPhase = 'idle' | 'ping' | 'download' | 'upload' | 'done' | 'error';

export interface SpeedTestMeasurement {
  id: string;
  serverName: string;
  downloadMbps: number;
  uploadMbps: number;
  pingMs: number;
  jitterMs: number;
  packetLossPct: number;
  measuredAtIso: string;
}

export interface SpeedTestProgress {
  phase: SpeedTestPhase;
  liveMbps: number;
  pingMs: number | null;
  jitterMs: number | null;
  packetLossPct: number | null;
  downloadMbps: number | null;
  uploadMbps: number | null;
}

export function computeMbps(bytes: number, elapsedMs: number): number {
  if (bytes <= 0 || elapsedMs <= 0) return 0;
  const bits = bytes * 8;
  const seconds = elapsedMs / 1000;
  return Number((bits / seconds / 1_000_000).toFixed(2));
}

export function computeLatencyStats(
  samplesMs: number[],
  totalProbes: number
): { pingMs: number; jitterMs: number; packetLossPct: number } {
  const failed = Math.max(0, totalProbes - samplesMs.length);
  const packetLossPct = totalProbes > 0 ? Number(((failed / totalProbes) * 100).toFixed(1)) : 0;

  if (samplesMs.length === 0) {
    return { pingMs: 0, jitterMs: 0, packetLossPct: 100 };
  }

  const sorted = [...samplesMs].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  const pingMs = Number(
    (sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid]).toFixed(1)
  );

  let diffSum = 0;
  for (let i = 1; i < samplesMs.length; i++) {
    diffSum += Math.abs(samplesMs[i] - samplesMs[i - 1]);
  }
  const jitterMs = samplesMs.length > 1 ? Number((diffSum / (samplesMs.length - 1)).toFixed(1)) : 0;

  return { pingMs, jitterMs, packetLossPct };
}

const CLOUDFLARE_DOWN = 'https://speed.cloudflare.com/__down';
const CLOUDFLARE_UP = 'https://speed.cloudflare.com/__up';

export async function runLiveSpeedTest(
  onProgress: (progress: SpeedTestProgress) => void,
  signal?: AbortSignal
): Promise<SpeedTestMeasurement> {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    throw new Error('INTERNET_OFFLINE');
  }

  // Phase 1: Ping, Jitter & Packet Loss (6 real sequential probes)
  onProgress({
    phase: 'ping',
    liveMbps: 0,
    pingMs: null,
    jitterMs: null,
    packetLossPct: null,
    downloadMbps: null,
    uploadMbps: null
  });

  const totalProbes = 6;
  const rttSamples: number[] = [];

  for (let i = 0; i < totalProbes; i++) {
    if (signal?.aborted) throw new Error('ABORTED');
    const probeController = new AbortController();
    const timer = setTimeout(() => probeController.abort(), 3500);
    if (signal) {
      signal.addEventListener('abort', () => probeController.abort(), { once: true });
    }
    const start = performance.now();
    try {
      const res = await fetch(`${CLOUDFLARE_DOWN}?bytes=0&cb=${Date.now()}_${i}`, {
        cache: 'no-store',
        signal: probeController.signal
      });
      await res.arrayBuffer();
      const elapsed = performance.now() - start;
      if (res.ok) rttSamples.push(elapsed);
    } catch {
      // Counted as packet loss if probe times out or drops
    } finally {
      clearTimeout(timer);
    }
  }

  if (rttSamples.length === 0) {
    throw new Error('SERVER_UNREACHABLE');
  }

  const { pingMs, jitterMs, packetLossPct } = computeLatencyStats(rttSamples, totalProbes);

  // Phase 2: Real Download Measurement (progressive payloads: 1MB + 4MB + 8MB)
  onProgress({
    phase: 'download',
    liveMbps: 0,
    pingMs,
    jitterMs,
    packetLossPct,
    downloadMbps: null,
    uploadMbps: null
  });

  const downSizes = [1_000_000, 4_000_000, 8_000_000];
  let totalDownBytes = 0;
  const downStart = performance.now();

  for (const bytes of downSizes) {
    if (signal?.aborted) throw new Error('ABORTED');
    const res = await fetch(`${CLOUDFLARE_DOWN}?bytes=${bytes}&cb=${Date.now()}`, {
      cache: 'no-store',
      signal
    });
    if (!res.ok) throw new Error('SERVER_UNREACHABLE');

    if (res.body) {
      const reader = res.body.getReader();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value) {
          totalDownBytes += value.byteLength;
          const liveMbps = computeMbps(totalDownBytes, performance.now() - downStart);
          onProgress({
            phase: 'download',
            liveMbps,
            pingMs,
            jitterMs,
            packetLossPct,
            downloadMbps: liveMbps,
            uploadMbps: null
          });
        }
      }
    } else {
      const buf = await res.arrayBuffer();
      totalDownBytes += buf.byteLength;
    }

    // Cap download phase at ~4.5 seconds so slower links stay responsive
    if (performance.now() - downStart > 4500) break;
  }

  const downloadMbps = computeMbps(totalDownBytes, performance.now() - downStart);

  // Phase 3: Real Upload Measurement (progressive payloads: 512KB + 2MB)
  onProgress({
    phase: 'upload',
    liveMbps: 0,
    pingMs,
    jitterMs,
    packetLossPct,
    downloadMbps,
    uploadMbps: null
  });

  const upSizes = [512_000, 2_000_000];
  let totalUpBytes = 0;
  const upStart = performance.now();

  for (const size of upSizes) {
    if (signal?.aborted) throw new Error('ABORTED');
    const payload = new Uint8Array(size);
    const res = await fetch(`${CLOUDFLARE_UP}?cb=${Date.now()}`, {
      method: 'POST',
      body: payload,
      cache: 'no-store',
      signal
    });
    if (!res.ok) throw new Error('SERVER_UNREACHABLE');
    totalUpBytes += size;
    const liveUp = computeMbps(totalUpBytes, performance.now() - upStart);
    onProgress({
      phase: 'upload',
      liveMbps: liveUp,
      pingMs,
      jitterMs,
      packetLossPct,
      downloadMbps,
      uploadMbps: liveUp
    });
    if (performance.now() - upStart > 4500) break;
  }

  const uploadMbps = computeMbps(totalUpBytes, performance.now() - upStart);

  onProgress({
    phase: 'done',
    liveMbps: downloadMbps,
    pingMs,
    jitterMs,
    packetLossPct,
    downloadMbps,
    uploadMbps
  });

  return {
    id: `st_${Date.now()}`,
    serverName: 'Cloudflare Edge',
    downloadMbps,
    uploadMbps,
    pingMs,
    jitterMs,
    packetLossPct,
    measuredAtIso: new Date().toISOString()
  };
}
