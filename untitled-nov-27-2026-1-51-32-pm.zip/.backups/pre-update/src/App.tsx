/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { AppProvider, useApp } from './context/AppContext';
import { I18nProvider, useI18n } from './i18n';
import { Account } from './pages/Account';
import { ActivityLog } from './pages/ActivityLog';
import { Dashboard } from './pages/Dashboard';
import { Devices } from './pages/Devices';
import { Diagnostics } from './pages/Diagnostics';
import { Login } from './pages/Login';
import { RouterConnection } from './pages/RouterConnection';
import { SpeedTest } from './pages/SpeedTest';
import { WiFiSettings } from './pages/WiFiSettings';

const MainShell: React.FC = () => {
  const { page } = useApp();
  const { t } = useI18n();
  const [mobileOpen, setMobileOpen] = useState(false);

  const renderPage = () => {
    switch (page) {
      case 'dashboard':
        return <Dashboard />;
      case 'wifi-settings':
        return <WiFiSettings />;
      case 'speed-test':
        return <SpeedTest />;
      case 'diagnostics':
        return <Diagnostics />;
      case 'devices':
        return <Devices />;
      case 'activity-log':
        return <ActivityLog />;
      case 'router-connection':
        return <RouterConnection />;
      case 'account':
        return <Account />;
      case 'login':
        return <Login />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen flex bg-[#F4F7FB] dark:bg-[#0B1522] text-[#102B49] dark:text-[#EAF1F8]">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:start-3 focus:z-50 focus:px-4 focus:py-2 focus:rounded-xl focus:bg-[#174C78] focus:text-white focus:text-sm"
      >
        {t('app.skipToContent')}
      </a>

      <Sidebar mobileOpen={mobileOpen} onCloseMobile={() => setMobileOpen(false)} />

      <div className="flex-1 flex flex-col min-w-0">
        <Header onOpenMobileMenu={() => setMobileOpen(true)} />
        <main id="main-content" className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
          {renderPage()}
        </main>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <I18nProvider>
        <AppProvider>
          <MainShell />
        </AppProvider>
      </I18nProvider>
    </ErrorBoundary>
  );
}
