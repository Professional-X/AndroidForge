import React, { useRef, useState } from 'react';
import { Play, RotateCcw } from 'lucide-react';
import { SpeedGauge } from '../components/SpeedGauge';
import { useApp } from '../context/AppContext';
import { useI18n } from '../i18n';
import { runLiveSpeedTest, SpeedTestProgress } from '../services/speedTest';

export const SpeedTest: React.FC = () => {
  const { speedHistory, recordSpeedTest } = useApp();
  const { t, language } = useI18n();

  const [progress, setProgress] = useState<SpeedTestProgress>({
    phase: 'idle',
    liveMbps: 0,
    pingMs: null,
    jitterMs: null,
    packetLossPct: null,
    downloadMbps: null,
    uploadMbps: null
  });
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const running = progress.phase === 'ping' || progress.phase === 'download' || progress.phase === 'upload';

  const startTest = async () => {
    if (running) return;
    setErrorMsg(null);
    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const result = await runLiveSpeedTest((p) => setProgress(p), controller.signal);
      await recordSpeedTest(result);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'SERVER_UNREACHABLE';
      if (msg === 'ABORTED') return;
      setProgress((prev) => ({ ...prev, phase: 'error' }));
      setErrorMsg(msg === 'INTERNET_OFFLINE' ? t('speed.errorOffline') : t('speed.errorServer'));
    }
  };

  const phaseText =
    progress.phase === 'ping'
      ? t('speed.phasePing')
      : progress.phase === 'download'
      ? t('speed.phaseDownload')
      : progress.phase === 'upload'
      ? t('speed.phaseUpload')
      : progress.phase === 'done'
      ? t('speed.phaseDone')
      : t('speed.phaseIdle');

  const chartPoints = [...speedHistory].slice(0, 10).reverse();
  const maxChartMbps = Math.max(20, ...chartPoints.map((p) => Math.max(p.downloadMbps, p.uploadMbps)));
  const localeStr = language === 'ar' ? 'ar-EG' : language === 'fr' ? 'fr-FR' : 'en-US';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#102B49] dark:text-[#EAF1F8] tracking-tight">
            {t('speed.title')}
          </h1>
          <p className="text-sm text-[#526A84] dark:text-[#93ACC6] mt-1">{t('speed.description')}</p>
        </div>

        <button
          type="button"
          onClick={() => void startTest()}
          disabled={running}
          className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-sm font-semibold transition-colors disabled:opacity-60 whitespace-nowrap shrink-0"
        >
          {progress.phase === 'done' ? <RotateCcw className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          <span>
            {running ? t('speed.testing') : progress.phase === 'done' ? t('speed.retest') : t('speed.startTest')}
          </span>
        </button>
      </div>

      {errorMsg && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 text-sm text-red-800 dark:text-red-200">
          {errorMsg}
        </div>
      )}

      {/* Gauge + Live Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 flex flex-col items-center justify-center">
          <SpeedGauge
            valueMbps={progress.liveMbps}
            maxScaleMbps={Math.max(100, Math.ceil((progress.liveMbps || 100) / 50) * 50)}
            label={progress.phase === 'upload' ? t('speed.upload') : t('speed.download')}
            phaseLabel={phaseText}
            active={running}
          />
          <div className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-2 text-center">
            {t('speed.serverLabel')}: {t('speed.serverCloudflare')}
          </div>
        </div>

        <div className="lg:col-span-2 grid grid-cols-2 sm:grid-cols-3 gap-4 content-start">
          <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5">
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('speed.download')}</div>
            <div className="text-2xl font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] mt-1">
              {progress.downloadMbps !== null ? progress.downloadMbps.toFixed(2) : '—'}
            </div>
            <div className="text-xs text-[#3989C9] mt-0.5">{t('speed.mbps')}</div>
          </div>

          <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5">
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('speed.upload')}</div>
            <div className="text-2xl font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] mt-1">
              {progress.uploadMbps !== null ? progress.uploadMbps.toFixed(2) : '—'}
            </div>
            <div className="text-xs text-[#3989C9] mt-0.5">{t('speed.mbps')}</div>
          </div>

          <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5">
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('speed.ping')}</div>
            <div className="text-2xl font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] mt-1">
              {progress.pingMs !== null ? progress.pingMs.toFixed(1) : '—'}
            </div>
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-0.5">{t('speed.ms')}</div>
          </div>

          <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5">
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('speed.jitter')}</div>
            <div className="text-2xl font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] mt-1">
              {progress.jitterMs !== null ? progress.jitterMs.toFixed(1) : '—'}
            </div>
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-0.5">{t('speed.ms')}</div>
          </div>

          <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 col-span-2 sm:col-span-2">
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('speed.packetLoss')}</div>
            <div className="text-2xl font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] mt-1">
              {progress.packetLossPct !== null ? `${progress.packetLossPct.toFixed(1)}%` : '—'}
            </div>
            <p className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-2 leading-relaxed">
              {t('speed.disclaimer')}
            </p>
          </div>
        </div>
      </div>

      {/* Trend Chart + History Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
              {t('speed.trendTitle')}
            </h2>
            <div className="flex items-center gap-4 text-xs text-[#526A84] dark:text-[#93ACC6]">
              <span className="inline-flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-[#174C78] dark:bg-[#6BB3EB] inline-block" aria-hidden="true" />
                {t('speed.download')}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-[#3989C9] inline-block" aria-hidden="true" />
                {t('speed.upload')}
              </span>
            </div>
          </div>

          {chartPoints.length === 0 ? (
            <p className="text-sm text-[#526A84] dark:text-[#93ACC6] py-8 text-center">
              {t('speed.noHistory')}
            </p>
          ) : (
            <svg viewBox="0 0 460 180" className="w-full h-44" role="img" aria-label={t('speed.trendTitle')}>
              {[0.25, 0.5, 0.75, 1].map((frac) => (
                <line
                  key={frac}
                  x1="36"
                  x2="444"
                  y1={150 - frac * 120}
                  y2={150 - frac * 120}
                  stroke="currentColor"
                  strokeDasharray="3 3"
                  className="text-[#DCE5F0] dark:text-[#1F354F]"
                />
              ))}
              {chartPoints.length > 1 && (
                <>
                  <polyline
                    fill="none"
                    stroke="#174C78"
                    strokeWidth="2.5"
                    points={chartPoints
                      .map((p, i) => {
                        const x = 36 + (i / (chartPoints.length - 1)) * 408;
                        const y = 150 - (p.downloadMbps / maxChartMbps) * 120;
                        return `${x},${y}`;
                      })
                      .join(' ')}
                  />
                  <polyline
                    fill="none"
                    stroke="#3989C9"
                    strokeWidth="2.5"
                    points={chartPoints
                      .map((p, i) => {
                        const x = 36 + (i / (chartPoints.length - 1)) * 408;
                        const y = 150 - (p.uploadMbps / maxChartMbps) * 120;
                        return `${x},${y}`;
                      })
                      .join(' ')}
                  />
                </>
              )}
              {chartPoints.map((p, i) => {
                const x = chartPoints.length === 1 ? 240 : 36 + (i / (chartPoints.length - 1)) * 408;
                const yd = 150 - (p.downloadMbps / maxChartMbps) * 120;
                const yu = 150 - (p.uploadMbps / maxChartMbps) * 120;
                return (
                  <g key={p.id}>
                    <circle cx={x} cy={yd} r="4" fill="#174C78" />
                    <circle cx={x} cy={yu} r="4" fill="#3989C9" />
                  </g>
                );
              })}
            </svg>
          )}
        </div>

        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-[#DCE5F0] dark:border-[#1F354F]">
            <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
              {t('speed.historyTitle')}
            </h2>
          </div>
          {speedHistory.length === 0 ? (
            <p className="text-sm text-[#526A84] dark:text-[#93ACC6] p-6">{t('speed.noHistory')}</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-[#F4F7FB] dark:bg-[#0B1522] text-xs text-[#526A84] dark:text-[#93ACC6]">
                  <tr>
                    <th className="px-4 py-2.5 text-start font-medium">{t('activity.date')}</th>
                    <th className="px-4 py-2.5 text-end font-medium">{t('speed.download')}</th>
                    <th className="px-4 py-2.5 text-end font-medium">{t('speed.upload')}</th>
                    <th className="px-4 py-2.5 text-end font-medium">{t('speed.ping')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#DCE5F0] dark:divide-[#1F354F] font-mono-tabular text-xs">
                  {speedHistory.slice(0, 8).map((row) => (
                    <tr key={row.id}>
                      <td className="px-4 py-2.5 text-[#526A84] dark:text-[#93ACC6]">
                        {new Intl.DateTimeFormat(localeStr, {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        }).format(new Date(row.measuredAtIso))}
                      </td>
                      <td className="px-4 py-2.5 text-end font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                        {row.downloadMbps.toFixed(1)} {t('speed.mbps')}
                      </td>
                      <td className="px-4 py-2.5 text-end text-[#102B49] dark:text-[#EAF1F8]">
                        {row.uploadMbps.toFixed(1)} {t('speed.mbps')}
                      </td>
                      <td className="px-4 py-2.5 text-end text-[#526A84] dark:text-[#93ACC6]">
                        {row.pingMs.toFixed(1)} {t('speed.ms')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
