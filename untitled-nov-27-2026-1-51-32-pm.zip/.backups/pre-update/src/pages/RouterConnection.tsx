import React, { useEffect, useState } from 'react';
import { Check, Copy, Download, Eye, EyeOff, RefreshCw, Router, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useI18n } from '../i18n';
import { ROUTER_ADAPTERS } from '../router-adapters/registry';
import { RouterAdapterId } from '../router-adapters/types';
import { checkLocalConnectorHealth, TransportMode } from '../services/routerConnection';
import {
  clearSavedRouterCredentials,
  hasSavedRouterCredentials,
  loadEncryptedRouterCredentials,
  saveEncryptedRouterCredentials
} from '../utils/cryptoStore';
import { validateRouterAddress } from '../utils/networkSecurity';

export const RouterConnection: React.FC = () => {
  const {
    routerSession,
    routerConnecting,
    routerError,
    clearRouterError,
    connectRouter,
    disconnectRouter,
    setPage
  } = useApp();
  const { t } = useI18n();

  const [transportMode, setTransportMode] = useState<TransportMode>('connector');
  const [connectorHealthy, setConnectorHealthy] = useState<boolean | null>(null);
  const [routerAddress, setRouterAddress] = useState('192.168.1.1');
  const [adapterId, setAdapterId] = useState<RouterAdapterId | 'auto'>('auto');
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [saveCreds, setSaveCreds] = useState(false);
  const [hasSaved, setHasSaved] = useState(false);
  const [noticeKey, setNoticeKey] = useState<string | null>(null);
  const [copiedCmd, setCopiedCmd] = useState(false);

  const onlineNow = typeof navigator !== 'undefined' ? navigator.onLine : true;

  const refreshConnector = async () => {
    const ok = await checkLocalConnectorHealth();
    setConnectorHealthy(ok);
  };

  useEffect(() => {
    void hasSavedRouterCredentials().then(setHasSaved);
  }, []);

  const handleLoadSaved = async () => {
    const saved = await loadEncryptedRouterCredentials();
    if (saved) {
      setRouterAddress(saved.routerUrl);
      setAdapterId((saved.adapterId as RouterAdapterId | 'auto') || 'auto');
      setUsername(saved.username);
      setPassword(saved.password);
      setSaveCreds(true);
    }
  };

  const handleDeleteSaved = async () => {
    await clearSavedRouterCredentials();
    setHasSaved(false);
    setPassword('');
    setNoticeKey('router.deletedSavedNotice');
  };

  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    setNoticeKey(null);
    clearRouterError();

    const validated = validateRouterAddress(routerAddress);
    if (!validated.valid) {
      setNoticeKey('router.errors.INVALID_ROUTER_ADDRESS');
      return;
    }

    const ok = await connectRouter({
      rawAddress: routerAddress,
      preferredAdapterId: adapterId,
      credentials: { username, password },
      transportMode
    });

    if (ok) {
      if (saveCreds) {
        await saveEncryptedRouterCredentials({
          routerUrl: validated.normalizedUrl,
          adapterId,
          username,
          password,
          savedAt: new Date().toISOString()
        });
        setHasSaved(true);
      }
      setPage('dashboard');
    }
  };

  const handleDownloadConnector = () => {
    const content = `// Run with Node.js 18+: node server.mjs\n// Full version is in local-connector/server.mjs in this repository.\n`;
    const blob = new Blob([content], { type: 'text/javascript;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'local-connector-info.js';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopyCmd = async () => {
    try {
      await navigator.clipboard.writeText(t('router.connectorCommand'));
      setCopiedCmd(true);
      setTimeout(() => setCopiedCmd(false), 1800);
    } catch {
      // Ignore clipboard failure
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-[#102B49] dark:text-[#EAF1F8] tracking-tight">
          {t('router.title')}
        </h1>
        <p className="text-sm text-[#526A84] dark:text-[#93ACC6] mt-1">
          {t('router.description')}
        </p>
      </div>

      {/* LAN & Connector Status Strip */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-1.5">
          <div className="text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
            {t('router.lanStatus')}
          </div>
          <div className={`text-sm font-semibold ${onlineNow ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
            {onlineNow ? t('router.lanOnline') : t('router.lanOffline')}
          </div>
        </div>

        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 flex items-center justify-between gap-4">
          <div className="space-y-1.5 min-w-0">
            <div className="text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
              {t('router.connectorStatus')}
            </div>
            <div className={`text-sm font-semibold ${connectorHealthy ? 'text-emerald-700 dark:text-emerald-400' : 'text-amber-700 dark:text-amber-400'}`}>
              {connectorHealthy ? t('router.connectorRunning') : t('router.connectorStopped')}
            </div>
          </div>
          <button
            type="button"
            onClick={() => void refreshConnector()}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] text-xs font-medium text-[#102B49] dark:text-[#EAF1F8] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44] whitespace-nowrap shrink-0"
          >
            <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{t('router.checkConnector')}</span>
          </button>
        </div>
      </div>

      {/* Main Connection Form + Local Connector Instructions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <form
          onSubmit={(e) => void handleConnect(e)}
          className="lg:col-span-2 bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-5"
        >
          {routerSession && (
            <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
              <div className="text-sm text-emerald-900 dark:text-emerald-200 font-medium">
                {t('dashboard.connectedTo')}: {routerSession.routerInfo.vendor} {routerSession.routerInfo.model} ({routerSession.routerInfo.gatewayIp})
              </div>
              <button
                type="button"
                onClick={() => void disconnectRouter()}
                className="px-3.5 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-medium whitespace-nowrap"
              >
                {t('router.disconnectButton')}
              </button>
            </div>
          )}

          {(routerError || noticeKey) && (
            <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800/60 text-sm text-red-800 dark:text-red-200">
              {routerError ? t(`router.errors.${routerError}`) : noticeKey ? t(noticeKey) : ''}
            </div>
          )}

          {hasSaved && (
            <div className="p-4 rounded-xl bg-[#F4F7FB] dark:bg-[#0B1522] border border-[#DCE5F0] dark:border-[#1F354F] flex flex-wrap items-center justify-between gap-3">
              <span className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('router.savedNotice')}</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => void handleLoadSaved()}
                  className="px-3 py-1.5 rounded-lg bg-[#174C78] hover:bg-[#102B49] text-white text-xs font-medium whitespace-nowrap"
                >
                  {t('router.useSavedButton')}
                </button>
                <button
                  type="button"
                  onClick={() => void handleDeleteSaved()}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-red-300 dark:border-red-800 text-red-700 dark:text-red-300 text-xs font-medium hover:bg-red-50 dark:hover:bg-red-950/40 whitespace-nowrap"
                >
                  <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{t('router.deleteSavedButton')}</span>
                </button>
              </div>
            </div>
          )}

          {/* Transport Mode */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
              {t('router.connectionMode')}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setTransportMode('connector')}
                className={`p-3.5 rounded-xl border text-start text-xs font-medium ${
                  transportMode === 'connector'
                    ? 'border-[#174C78] dark:border-[#3989C9] bg-[#EAF3FB] dark:bg-[#172B42] text-[#102B49] dark:text-white'
                    : 'border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-[#526A84] dark:text-[#93ACC6]'
                }`}
              >
                {t('router.modeConnector')}
              </button>
              <button
                type="button"
                onClick={() => setTransportMode('direct')}
                className={`p-3.5 rounded-xl border text-start text-xs font-medium ${
                  transportMode === 'direct'
                    ? 'border-[#174C78] dark:border-[#3989C9] bg-[#EAF3FB] dark:bg-[#172B42] text-[#102B49] dark:text-white'
                    : 'border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-[#526A84] dark:text-[#93ACC6]'
                }`}
              >
                {t('router.modeDirect')}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label htmlFor="router-ip" className="block text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
                {t('router.routerIpLabel')}
              </label>
              <input
                id="router-ip"
                type="text"
                value={routerAddress}
                onChange={(e) => setRouterAddress(e.target.value)}
                placeholder="192.168.1.1"
                required
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] focus:outline-none focus:ring-2 focus:ring-[#3989C9]"
              />
              <p className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('router.routerIpHint')}</p>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="router-adapter" className="block text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
                {t('router.adapterLabel')}
              </label>
              <select
                id="router-adapter"
                value={adapterId}
                onChange={(e) => setAdapterId(e.target.value as RouterAdapterId | 'auto')}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm text-[#102B49] dark:text-[#EAF1F8] focus:outline-none focus:ring-2 focus:ring-[#3989C9]"
              >
                <option value="auto">{t('router.autoDetect')}</option>
                {ROUTER_ADAPTERS.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.vendor} ({a.id})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label htmlFor="router-user" className="block text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
                {t('router.usernameLabel')}
              </label>
              <input
                id="router-user"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder={t('router.usernamePlaceholder')}
                autoComplete="username"
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm text-[#102B49] dark:text-[#EAF1F8] focus:outline-none focus:ring-2 focus:ring-[#3989C9]"
              />
            </div>

            <div className="space-y-1.5">
              <label htmlFor="router-pass" className="block text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
                {t('router.passwordLabel')}
              </label>
              <div className="relative">
                <input
                  id="router-pass"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={t('router.passwordPlaceholder')}
                  autoComplete="current-password"
                  className="w-full pe-10 ps-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm text-[#102B49] dark:text-[#EAF1F8] focus:outline-none focus:ring-2 focus:ring-[#3989C9]"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? t('wifi.hidePassword') : t('wifi.showPassword')}
                  className="absolute inset-y-0 end-0 px-3 flex items-center text-[#526A84] hover:text-[#102B49] dark:hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#F4F7FB] dark:bg-[#0B1522] border border-[#DCE5F0] dark:border-[#1F354F] space-y-1.5">
            <label className="flex items-center gap-2.5 cursor-pointer text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
              <input
                type="checkbox"
                checked={saveCreds}
                onChange={(e) => setSaveCreds(e.target.checked)}
                className="w-4 h-4 rounded border-[#DCE5F0] text-[#174C78] focus:ring-[#3989C9]"
              />
              <span>{t('router.saveCredentialsLabel')}</span>
            </label>
            <p className="text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed">
              {t('router.saveCredentialsNote')}
            </p>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={routerConnecting}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-sm font-medium transition-colors disabled:opacity-60 whitespace-nowrap"
            >
              <Router className="w-4 h-4" aria-hidden="true" />
              <span>{routerConnecting ? t('app.loading') : t('router.connectButton')}</span>
            </button>
          </div>
        </form>

        {/* Local Connector Instructions Panel */}
        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-4">
          <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
            {t('router.connectorInstructionsTitle')}
          </h2>
          <p className="text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed">
            {t('router.connectorInstructionsBody')}
          </p>

          <div className="p-3 rounded-xl bg-[#0B1522] text-[#EAF1F8] font-mono-tabular text-xs flex items-center justify-between gap-2">
            <code className="truncate">{t('router.connectorCommand')}</code>
            <button
              type="button"
              onClick={() => void handleCopyCmd()}
              aria-label={t('app.copy')}
              className="p-1.5 rounded-lg hover:bg-white/10 text-white shrink-0"
            >
              {copiedCmd ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          <button
            type="button"
            onClick={handleDownloadConnector}
            className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] text-xs font-medium text-[#102B49] dark:text-[#EAF1F8] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44] transition-colors whitespace-nowrap"
          >
            <Download className="w-4 h-4" aria-hidden="true" />
            <span>{t('router.downloadConnector')}</span>
          </button>
        </div>
      </div>

      {/* Router Adapters Registry Table */}
      <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-[#DCE5F0] dark:border-[#1F354F]">
          <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
            {t('router.supportedAdaptersTitle')}
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-start text-sm">
            <thead className="bg-[#F4F7FB] dark:bg-[#0B1522] text-xs text-[#526A84] dark:text-[#93ACC6]">
              <tr>
                <th className="px-5 py-3 text-start font-medium">{t('router.adapterLabel')}</th>
                <th className="px-5 py-3 text-start font-medium">{t('router.modelsLabel')}</th>
                <th className="px-5 py-3 text-start font-medium">{t('router.authLabel')}</th>
                <th className="px-5 py-3 text-start font-medium">{t('router.capabilitiesLabel')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#DCE5F0] dark:divide-[#1F354F]">
              {ROUTER_ADAPTERS.map((adapter) => (
                <tr key={adapter.id} className="hover:bg-[#F4F7FB]/60 dark:hover:bg-[#172B42]/50">
                  <td className="px-5 py-3.5 font-medium text-[#102B49] dark:text-[#EAF1F8] whitespace-nowrap">
                    {adapter.vendor}
                  </td>
                  <td className="px-5 py-3.5 text-xs text-[#526A84] dark:text-[#93ACC6]">
                    {adapter.supportedModels.join(' · ')}
                  </td>
                  <td className="px-5 py-3.5 text-xs text-[#526A84] dark:text-[#93ACC6]">
                    {adapter.authMethod}
                  </td>
                  <td className="px-5 py-3.5 text-xs font-mono-tabular text-[#102B49] dark:text-[#EAF1F8]">
                    {adapter.capabilities.writeWifiSettings
                      ? `${t('app.supported')} (Wi-Fi · MAC ACL)`
                      : t('app.unsupported')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
