import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { User } from 'firebase/auth';
import { LanguageCode, useI18n } from '../i18n';
import { RouterAdapterId, RouterCredentials, RouterError, RouterErrorCode, WifiUpdateInput } from '../router-adapters/types';
import { analyzeNetworkDiagnostics, DiagnosticsReport } from '../services/diagnostics';
import {
  ActivityActionType,
  ActivityLogRecord,
  createActivityLog,
  DeviceAliasRecord,
  ensureUserProfile,
  fetchActivityLogs,
  fetchDeviceAliases,
  fetchSpeedTests,
  persistSpeedTest,
  signInWithGoogle,
  signOutGoogle,
  subscribeAuthState,
  ThemeMode,
  updateUserPreferences,
  upsertDeviceAlias,
  UserProfileData
} from '../services/firebaseService';
import {
  ActiveRouterSession,
  applyRouterWifiUpdate,
  blockRouterDevice,
  connectToRouter,
  disconnectRouterSession,
  rebootConnectedRouter,
  refreshRouterSession,
  toggleGuestWifi,
  toggleInternetAccess,
  TransportMode,
  unblockRouterDevice
} from '../services/routerConnection';
import { SpeedTestMeasurement } from '../services/speedTest';
import { normalizeMac } from '../utils/networkSecurity';

export type PageId =
  | 'dashboard'
  | 'wifi-settings'
  | 'speed-test'
  | 'diagnostics'
  | 'devices'
  | 'activity-log'
  | 'router-connection'
  | 'account'
  | 'login';

const THEME_STORAGE_KEY = 'aw_ui_theme';

interface AppContextValue {
  page: PageId;
  setPage: (p: PageId) => void;
  theme: ThemeMode;
  toggleTheme: () => void;
  setTheme: (t: ThemeMode) => void;
  changeLanguage: (lang: LanguageCode) => void;

  user: User | null;
  authReady: boolean;
  userProfile: UserProfileData | null;
  signInGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  updateSessionTimeout: (minutes: number) => Promise<void>;

  routerSession: ActiveRouterSession | null;
  routerConnecting: boolean;
  routerError: RouterErrorCode | null;
  clearRouterError: () => void;
  connectRouter: (params: {
    rawAddress: string;
    preferredAdapterId: RouterAdapterId | 'auto';
    credentials: RouterCredentials;
    transportMode: TransportMode;
  }) => Promise<boolean>;
  refreshRouter: () => Promise<void>;
  updateWifi: (update: WifiUpdateInput) => Promise<void>;
  blockDevice: (mac: string) => Promise<void>;
  unblockDevice: (mac: string) => Promise<void>;
  rebootRouter: () => Promise<void>;
  setGuestWifi: (enabled: boolean) => Promise<void>;
  setInternetBlocked: (blocked: boolean) => Promise<void>;
  disconnectRouter: () => Promise<void>;
  autoRefresh: boolean;
  setAutoRefresh: (v: boolean) => void;

  speedHistory: SpeedTestMeasurement[];
  latestSpeed: SpeedTestMeasurement | null;
  recordSpeedTest: (m: SpeedTestMeasurement) => Promise<void>;

  diagnosticsReport: DiagnosticsReport;
  runDiagnosticsCheck: () => Promise<void>;

  activityLogs: ActivityLogRecord[];
  logEvent: (
    actionType: ActivityActionType,
    target: string,
    status: 'success' | 'failure' | 'info',
    details: string
  ) => Promise<void>;

  deviceAliases: Record<string, DeviceAliasRecord>;
  seenMacs: Set<string>;
  saveDeviceAlias: (mac: string, customName: string, trustStatus: 'known' | 'unknown') => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { language, setLanguage } = useI18n();
  const [page, setPage] = useState<PageId>('dashboard');
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    try {
      const saved = localStorage.getItem(THEME_STORAGE_KEY);
      if (saved === 'dark' || saved === 'light') return saved;
    } catch {
      // Ignore storage errors
    }
    return 'light';
  });

  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfileData | null>(null);

  const [routerSession, setRouterSession] = useState<ActiveRouterSession | null>(null);
  const [routerConnecting, setRouterConnecting] = useState(false);
  const [routerError, setRouterError] = useState<RouterErrorCode | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(false);

  const [speedHistory, setSpeedHistory] = useState<SpeedTestMeasurement[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLogRecord[]>([]);
  const [deviceAliases, setDeviceAliases] = useState<Record<string, DeviceAliasRecord>>({});
  const [seenMacs, setSeenMacs] = useState<Set<string>>(() => new Set());

  // Sync theme class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem(THEME_STORAGE_KEY, theme);
    } catch {
      // Ignore storage errors
    }
  }, [theme]);

  // Subscribe to Firebase Auth
  useEffect(() => {
    const unsub = subscribeAuthState(async (nextUser) => {
      setUser(nextUser);
      if (nextUser) {
        try {
          const profile = await ensureUserProfile(nextUser, { language, theme });
          setUserProfile(profile);
          if (profile.language && profile.language !== language) {
            setLanguage(profile.language);
          }
          if (profile.theme && profile.theme !== theme) {
            setThemeState(profile.theme);
          }

          const [logs, tests, aliases] = await Promise.all([
            fetchActivityLogs(nextUser.uid),
            fetchSpeedTests(nextUser.uid),
            fetchDeviceAliases(nextUser.uid)
          ]);
          setActivityLogs(logs);
          setSpeedHistory(
            tests.map((t) => ({
              id: t.id,
              serverName: t.serverName,
              downloadMbps: t.downloadMbps,
              uploadMbps: t.uploadMbps,
              pingMs: t.pingMs,
              jitterMs: t.jitterMs,
              packetLossPct: t.packetLossPct,
              measuredAtIso: t.createdAtIso
            }))
          );
          setDeviceAliases(aliases);
        } catch (err) {
          console.error('Failed loading user data:', err instanceof Error ? err.message : String(err));
        }
      } else {
        setUserProfile(null);
      }
      setAuthReady(true);
    });
    return () => unsub();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Session idle timeout enforcement when user is signed in
  useEffect(() => {
    if (!user || !userProfile?.sessionTimeoutMinutes) return;
    const timeoutMs = userProfile.sessionTimeoutMinutes * 60 * 1000;
    let timer = setTimeout(() => {
      void signOutGoogle();
    }, timeoutMs);

    const resetTimer = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        void signOutGoogle();
      }, timeoutMs);
    };

    window.addEventListener('pointerdown', resetTimer);
    window.addEventListener('keydown', resetTimer);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('pointerdown', resetTimer);
      window.removeEventListener('keydown', resetTimer);
    };
  }, [user, userProfile?.sessionTimeoutMinutes]);

  const setTheme = useCallback(
    (next: ThemeMode) => {
      setThemeState(next);
      if (user) {
        void updateUserPreferences(user.uid, { theme: next }).catch(() => undefined);
      }
    },
    [user]
  );

  const toggleTheme = useCallback(() => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  }, [theme, setTheme]);

  const changeLanguage = useCallback(
    (lang: LanguageCode) => {
      setLanguage(lang);
      if (user) {
        void updateUserPreferences(user.uid, { language: lang }).catch(() => undefined);
      }
    },
    [setLanguage, user]
  );

  const logEvent = useCallback(
    async (
      actionType: ActivityActionType,
      target: string,
      status: 'success' | 'failure' | 'info',
      details: string
    ) => {
      const localRecord: ActivityLogRecord = {
        id: `local_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        userId: user?.uid || 'local',
        actionType,
        target,
        status,
        details,
        createdAtIso: new Date().toISOString()
      };
      setActivityLogs((prev) => [localRecord, ...prev].slice(0, 50));

      if (user) {
        try {
          await createActivityLog(user.uid, { actionType, target, status, details });
        } catch (err) {
          console.error('Activity log sync failed:', err instanceof Error ? err.message : String(err));
        }
      }
    },
    [user]
  );

  const signInGoogle = useCallback(async () => {
    await signInWithGoogle();
    setPage('dashboard');
  }, []);

  const signOut = useCallback(async () => {
    await signOutGoogle();
    setActivityLogs([]);
    setSpeedHistory([]);
    setDeviceAliases({});
  }, []);

  const updateSessionTimeout = useCallback(
    async (minutes: number) => {
      const clamped = Math.min(1440, Math.max(5, Math.round(minutes)));
      setUserProfile((prev) => (prev ? { ...prev, sessionTimeoutMinutes: clamped } : prev));
      if (user) {
        await updateUserPreferences(user.uid, { sessionTimeoutMinutes: clamped });
      }
    },
    [user]
  );

  const connectRouter = useCallback(
    async (params: {
      rawAddress: string;
      preferredAdapterId: RouterAdapterId | 'auto';
      credentials: RouterCredentials;
      transportMode: TransportMode;
    }) => {
      setRouterConnecting(true);
      setRouterError(null);
      try {
        const session = await connectToRouter(params);
        setRouterSession(session);
        setSeenMacs((prev) => {
          const next = new Set(prev);
          session.devices.forEach((d) => next.add(normalizeMac(d.macAddress)));
          return next;
        });
        await logEvent(
          'router_connect',
          session.routerInfo.gatewayIp,
          'success',
          `${session.routerInfo.vendor} ${session.routerInfo.model} (${session.adapter.id})`
        );
        return true;
      } catch (err) {
        const code: RouterErrorCode = err instanceof RouterError ? err.code : 'ROUTER_OFFLINE';
        setRouterError(code);
        await logEvent('router_connect', params.rawAddress.trim() || 'gateway', 'failure', code);
        return false;
      } finally {
        setRouterConnecting(false);
      }
    },
    [logEvent]
  );

  const refreshRouter = useCallback(async () => {
    if (!routerSession) return;
    try {
      const updated = await refreshRouterSession(routerSession);
      setRouterSession(updated);
    } catch (err) {
      const code: RouterErrorCode = err instanceof RouterError ? err.code : 'SESSION_EXPIRED';
      setRouterError(code);
    }
  }, [routerSession]);

  // Optional auto-refresh when router is connected
  useEffect(() => {
    if (!autoRefresh || !routerSession) return;
    const id = setInterval(() => {
      void refreshRouter();
    }, 15000);
    return () => clearInterval(id);
  }, [autoRefresh, routerSession, refreshRouter]);

  const updateWifi = useCallback(
    async (update: WifiUpdateInput) => {
      if (!routerSession) throw new RouterError('ROUTER_OFFLINE');
      try {
        const updated = await applyRouterWifiUpdate(routerSession, update);
        setRouterSession(updated);
        // Never log password in activity log!
        const actionType: ActivityActionType =
          update.password !== undefined ? 'wifi_password_change' : 'wifi_ssid_change';
        await logEvent(
          actionType,
          `${update.band} · ${update.ssid}`,
          'success',
          `Encryption=${update.encryption}, Enabled=${update.enabled !== false}`
        );
      } catch (err) {
        const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
        setRouterError(code);
        await logEvent('wifi_settings_change', `${update.band} · ${update.ssid}`, 'failure', code);
        throw err;
      }
    },
    [routerSession, logEvent]
  );

  const blockDevice = useCallback(
    async (mac: string) => {
      if (!routerSession) throw new RouterError('ROUTER_OFFLINE');
      const norm = normalizeMac(mac);
      try {
        const updated = await blockRouterDevice(routerSession, norm);
        setRouterSession(updated);
        await logEvent('device_block', norm, 'success', 'MAC ACL block applied');
      } catch (err) {
        const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
        await logEvent('device_block', norm, 'failure', code);
        throw err;
      }
    },
    [routerSession, logEvent]
  );

  const unblockDevice = useCallback(
    async (mac: string) => {
      if (!routerSession) throw new RouterError('ROUTER_OFFLINE');
      const norm = normalizeMac(mac);
      try {
        const updated = await unblockRouterDevice(routerSession, norm);
        setRouterSession(updated);
        await logEvent('device_unblock', norm, 'success', 'MAC ACL block removed');
      } catch (err) {
        const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
        await logEvent('device_unblock', norm, 'failure', code);
        throw err;
      }
    },
    [routerSession, logEvent]
  );

  const rebootRouter = useCallback(async () => {
    if (!routerSession) throw new RouterError('ROUTER_OFFLINE');
    const ip = routerSession.routerInfo.gatewayIp;
    try {
      await rebootConnectedRouter(routerSession);
      await logEvent('router_reboot', ip, 'success', `${routerSession.routerInfo.vendor} reboot command sent`);
      setRouterSession(null);
      setAutoRefresh(false);
    } catch (err) {
      const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
      await logEvent('router_reboot', ip, 'failure', code);
      throw err;
    }
  }, [routerSession, logEvent]);

  const setGuestWifi = useCallback(
    async (enabled: boolean) => {
      if (!routerSession) throw new RouterError('ROUTER_OFFLINE');
      const ip = routerSession.routerInfo.gatewayIp;
      try {
        const updated = await toggleGuestWifi(routerSession, enabled);
        setRouterSession(updated);
        await logEvent('guest_wifi_toggle', ip, 'success', `Guest Wi-Fi ${enabled ? 'enabled' : 'disabled'}`);
      } catch (err) {
        const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
        await logEvent('guest_wifi_toggle', ip, 'failure', code);
        throw err;
      }
    },
    [routerSession, logEvent]
  );

  const setInternetBlocked = useCallback(
    async (blocked: boolean) => {
      if (!routerSession) throw new RouterError('ROUTER_OFFLINE');
      const ip = routerSession.routerInfo.gatewayIp;
      try {
        const updated = await toggleInternetAccess(routerSession, blocked);
        setRouterSession(updated);
        await logEvent(
          'internet_access_toggle',
          ip,
          'success',
          blocked ? 'All WAN internet paused' : 'WAN internet restored'
        );
      } catch (err) {
        const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
        await logEvent('internet_access_toggle', ip, 'failure', code);
        throw err;
      }
    },
    [routerSession, logEvent]
  );

  const disconnectRouter = useCallback(async () => {
    if (!routerSession) return;
    const ip = routerSession.routerInfo.gatewayIp;
    await disconnectRouterSession(routerSession);
    setRouterSession(null);
    setAutoRefresh(false);
    await logEvent('router_disconnect', ip, 'info', 'Session closed cleanly');
  }, [routerSession, logEvent]);

  const recordSpeedTest = useCallback(
    async (measurement: SpeedTestMeasurement) => {
      setSpeedHistory((prev) => [measurement, ...prev].slice(0, 25));
      if (user) {
        try {
          await persistSpeedTest(user.uid, {
            serverName: measurement.serverName,
            downloadMbps: measurement.downloadMbps,
            uploadMbps: measurement.uploadMbps,
            pingMs: measurement.pingMs,
            jitterMs: measurement.jitterMs,
            packetLossPct: measurement.packetLossPct
          });
        } catch (err) {
          console.error('Speed test save failed:', err instanceof Error ? err.message : String(err));
        }
      }
      await logEvent(
        'speed_test',
        measurement.serverName,
        'success',
        `DL ${measurement.downloadMbps} Mbps / UL ${measurement.uploadMbps} Mbps / Ping ${measurement.pingMs} ms`
      );
    },
    [user, logEvent]
  );

  const latestSpeed = speedHistory[0] ?? null;

  const diagnosticsReport = useMemo(
    () =>
      analyzeNetworkDiagnostics({
        latestSpeed,
        speedHistory,
        routerConnected: Boolean(routerSession),
        routerInfo: routerSession?.routerInfo ?? null,
        wifiSettings: routerSession?.wifiSettings ?? null,
        devices: routerSession?.devices ?? []
      }),
    [latestSpeed, speedHistory, routerSession]
  );

  const runDiagnosticsCheck = useCallback(async () => {
    if (routerSession) {
      await refreshRouter();
    }
    await logEvent(
      'diagnostics_run',
      routerSession ? routerSession.routerInfo.gatewayIp : 'local-client',
      'info',
      `Confirmed=${diagnosticsReport.confirmed.length}, Possible=${diagnosticsReport.possible.length}`
    );
  }, [routerSession, refreshRouter, logEvent, diagnosticsReport]);

  const saveDeviceAlias = useCallback(
    async (mac: string, customName: string, trustStatus: 'known' | 'unknown') => {
      const norm = normalizeMac(mac);
      const record: DeviceAliasRecord = {
        macAddress: norm,
        customName: customName.trim().slice(0, 80),
        trustStatus
      };
      setDeviceAliases((prev) => ({ ...prev, [norm]: record }));
      if (user) {
        await upsertDeviceAlias(user.uid, record);
      }
    },
    [user]
  );

  return (
    <AppContext.Provider
      value={{
        page,
        setPage,
        theme,
        toggleTheme,
        setTheme,
        changeLanguage,
        user,
        authReady,
        userProfile,
        signInGoogle,
        signOut,
        updateSessionTimeout,
        routerSession,
        routerConnecting,
        routerError,
        clearRouterError: () => setRouterError(null),
        connectRouter,
        refreshRouter,
        updateWifi,
        blockDevice,
        unblockDevice,
        rebootRouter,
        setGuestWifi,
        setInternetBlocked,
        disconnectRouter,
        autoRefresh,
        setAutoRefresh,
        speedHistory,
        latestSpeed,
        recordSpeedTest,
        diagnosticsReport,
        runDiagnosticsCheck,
        activityLogs,
        logEvent,
        deviceAliases,
        seenMacs,
        saveDeviceAlias
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
