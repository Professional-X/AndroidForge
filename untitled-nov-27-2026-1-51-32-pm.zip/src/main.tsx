import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { isNativeAndroidApp } from './native/androidBridge';
import './index.css';

if (typeof window !== 'undefined' && 'serviceWorker' in navigator && !isNativeAndroidApp()) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => undefined);
  });
}

createRoot(document.getElementById('root')!).render(<App />);
