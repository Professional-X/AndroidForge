import { lookupMacVendor, normalizeMac } from '../../utils/networkSecurity';
import {
  ConnectedDevice,
  ProbeSnapshot,
  RouterAdapter,
  RouterConnectionContext,
  RouterCredentials,
  RouterError,
  RouterInfo,
  WifiSettings,
  WifiUpdateInput
} from '../types';
import { tryParseJson } from '../xmlUtils';

interface TpLinkJsonResponse {
  errorcode?: string | number;
  data?: Record<string, unknown>;
  result?: Record<string, unknown>;
  stok?: string;
}

export const tpLinkAdapter: RouterAdapter = {
  id: 'tp-link',
  vendor: 'TP-Link',
  supportedModels: ['Archer C6 / C7 / C80 / AX10 / AX50', 'TL-WR840N / TL-WR940N', 'Deco / TD-W8961N'],
  firmwareHints: ['TP-Link LuCI stok JSON API', 'TP-Link Web CGI'],
  authMethod: 'LuCI /cgi-bin/luci stok session token',
  defaultGateways: ['192.168.0.1', '192.168.1.1', 'tplinkwifi.net'],
  capabilities: {
    readRouterInfo: true,
    readWifiSettings: true,
    writeWifiSettings: true,
    readWifiPassword: true,
    dualBand24: true,
    dualBand5: true,
    toggleWifiRadio: true,
    listDevices: true,
    blockMacDevice: true,
    unblockMacDevice: true,
    readSignalStats: false,
    readChannelInfo: true,
    rebootRouter: true,
    guestWifi: true,
    blockAllInternet: true,
    supportedEncryptions: ['WPA2-PSK', 'WPA/WPA2-PSK', 'WPA3-SAE', 'OPEN']
  },

  detectScore(probe: ProbeSnapshot): number {
    const body = probe.rootBody.toLowerCase();
    let score = 0;
    if (body.includes('tp-link') || body.includes('tplink') || body.includes('archer')) score += 60;
    if (body.includes('/cgi-bin/luci') || body.includes('stok=')) score += 30;
    return score;
  },

  async connect(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({ method: 'GET', path: '/' });
    if (res.status === 0 || res.status >= 500) {
      throw new RouterError('ROUTER_OFFLINE');
    }
  },

  async authenticate(ctx: RouterConnectionContext, creds: RouterCredentials): Promise<void> {
    const payload = new URLSearchParams({
      operation: 'login',
      username: creds.username.trim() || 'admin',
      password: creds.password
    }).toString();

    const res = await ctx.transport({
      method: 'POST',
      path: '/cgi-bin/luci/;stok=/login?form=login',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: payload
    });

    const parsed = tryParseJson<TpLinkJsonResponse>(res.body);
    const stok = parsed?.result?.stok || parsed?.data?.stok || parsed?.stok;
    if (res.status === 401 || res.status === 403 || (parsed?.errorcode && String(parsed.errorcode) !== '0')) {
      throw new RouterError('INVALID_CREDENTIALS');
    }
    if (typeof stok === 'string' && stok.length > 0) {
      ctx.sessionState.stok = stok;
    } else if (res.body.toLowerCase().includes('unauthorized') || res.body.toLowerCase().includes('incorrect')) {
      throw new RouterError('INVALID_CREDENTIALS');
    }
  },

  async getRouterInfo(ctx: RouterConnectionContext): Promise<RouterInfo> {
    const stok = ctx.sessionState.stok || '';
    const path = stok ? `/cgi-bin/luci/;stok=${stok}/admin/status?form=all` : '/cgi-bin/luci/admin/status?form=all';
    const res = await ctx.transport({ method: 'GET', path });
    if (res.status === 401 || res.status === 403) throw new RouterError('SESSION_EXPIRED');

    const json = tryParseJson<TpLinkJsonResponse>(res.body);
    const info = (json?.result || json?.data || {}) as Record<string, unknown>;
    return {
      vendor: 'TP-Link',
      model: String(info.model || info.device_name || 'TP-Link Router'),
      firmwareVersion: info.firmware_version ? String(info.firmware_version) : null,
      gatewayIp: new URL(ctx.baseUrl).hostname,
      wanConnected: typeof info.wan_status === 'string' ? info.wan_status.toLowerCase() === 'connected' : null,
      uptimeSeconds: typeof info.uptime === 'number' ? info.uptime : null,
      signalStrengthDbm: null,
      channelCongestionScore: null
    };
  },

  async getWifiSettings(ctx: RouterConnectionContext): Promise<WifiSettings> {
    const stok = ctx.sessionState.stok || '';
    const base = stok ? `/cgi-bin/luci/;stok=${stok}/admin/wireless` : '/cgi-bin/luci/admin/wireless';
    const [res24, res5] = await Promise.all([
      ctx.transport({ method: 'GET', path: `${base}?form=wireless_2g` }),
      ctx.transport({ method: 'GET', path: `${base}?form=wireless_5g` }).catch(() => null)
    ]);

    if (res24.status === 401 || res24.status === 403) throw new RouterError('SESSION_EXPIRED');

    const j24 = tryParseJson<TpLinkJsonResponse>(res24.body);
    const d24 = (j24?.result || j24?.data || {}) as Record<string, unknown>;
    const j5 = res5 ? tryParseJson<TpLinkJsonResponse>(res5.body) : null;
    const d5 = j5 ? ((j5.result || j5.data || {}) as Record<string, unknown>) : null;

    return {
      band24: {
        band: '2.4GHz',
        enabled: d24.enable !== 'off' && d24.enable !== false,
        ssid: String(d24.ssid || ''),
        password: typeof d24.psk_key === 'string' ? d24.psk_key : typeof d24.password === 'string' ? d24.password : null,
        encryption: String(d24.encryption || 'WPA2-PSK'),
        channel: String(d24.channel || 'auto')
      },
      band5: d5 && d5.ssid
        ? {
            band: '5GHz',
            enabled: d5.enable !== 'off' && d5.enable !== false,
            ssid: String(d5.ssid || ''),
            password: typeof d5.psk_key === 'string' ? d5.psk_key : typeof d5.password === 'string' ? d5.password : null,
            encryption: String(d5.encryption || 'WPA2-PSK'),
            channel: String(d5.channel || 'auto')
          }
        : null
    };
  },

  async updateWifiSettings(ctx: RouterConnectionContext, update: WifiUpdateInput): Promise<void> {
    const stok = ctx.sessionState.stok || '';
    const form = update.band === '5GHz' ? 'wireless_5g' : 'wireless_2g';
    const path = stok ? `/cgi-bin/luci/;stok=${stok}/admin/wireless?form=${form}` : `/cgi-bin/luci/admin/wireless?form=${form}`;

    const body = new URLSearchParams({
      operation: 'write',
      enable: update.enabled === false ? 'off' : 'on',
      ssid: update.ssid,
      encryption: update.encryption,
      ...(update.password !== undefined ? { psk_key: update.password } : {}),
      ...(update.channel ? { channel: update.channel } : {})
    }).toString();

    const res = await ctx.transport({
      method: 'POST',
      path,
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body
    });
    const parsed = tryParseJson<TpLinkJsonResponse>(res.body);
    if (res.status >= 400 || (parsed?.errorcode && String(parsed.errorcode) !== '0')) {
      throw new RouterError('SETTINGS_APPLY_FAILED');
    }
  },

  async getConnectedDevices(ctx: RouterConnectionContext) {
    const stok = ctx.sessionState.stok || '';
    const clientPath = stok ? `/cgi-bin/luci/;stok=${stok}/admin/dhcps?form=client` : '/cgi-bin/luci/admin/dhcps?form=client';
    const aclPath = stok ? `/cgi-bin/luci/;stok=${stok}/admin/access_control?form=black_list` : '/cgi-bin/luci/admin/access_control?form=black_list';

    const [clientRes, aclRes] = await Promise.all([
      ctx.transport({ method: 'GET', path: clientPath }),
      ctx.transport({ method: 'GET', path: aclPath }).catch(() => null)
    ]);

    if (clientRes.status === 401 || clientRes.status === 403) throw new RouterError('SESSION_EXPIRED');

    const blockedSet = new Set<string>();
    const aclJson = aclRes ? tryParseJson<{ data?: Array<{ mac?: string }>; result?: Array<{ mac?: string }> }>(aclRes.body) : null;
    const aclList = aclJson?.data || aclJson?.result || [];
    if (Array.isArray(aclList)) {
      aclList.forEach((entry) => {
        if (entry.mac) blockedSet.add(normalizeMac(entry.mac));
      });
    }

    const clientJson = tryParseJson<{
      data?: Array<{ name?: string; ipaddr?: string; macaddr?: string; leasetime?: string; conn_type?: string }>;
      result?: Array<{ name?: string; ipaddr?: string; macaddr?: string; leasetime?: string; conn_type?: string }>;
    }>(clientRes.body);
    const list = clientJson?.data || clientJson?.result || [];
    const connected: ConnectedDevice[] = Array.isArray(list)
      ? list
          .filter((item) => Boolean(item.macaddr))
          .map((item, idx) => {
            const mac = normalizeMac(item.macaddr!);
            const connRaw = (item.conn_type || '').toLowerCase();
            const connectionType: ConnectedDevice['connectionType'] = connRaw.includes('5g')
              ? 'Wi-Fi 5GHz'
              : connRaw.includes('2.4') || connRaw.includes('wifi')
              ? 'Wi-Fi 2.4GHz'
              : connRaw.includes('eth') || connRaw.includes('wire')
              ? 'Ethernet'
              : 'Unknown';
            return {
              id: mac,
              hostname: item.name || `Client-${idx + 1}`,
              ipAddress: item.ipaddr || '',
              macAddress: mac,
              vendor: lookupMacVendor(mac),
              connectionType,
              lastSeen: item.leasetime || null,
              status: blockedSet.has(mac) ? 'blocked' : 'online'
            };
          })
      : [];

    return { connected, blockedMacs: Array.from(blockedSet) };
  },

  async blockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const stok = ctx.sessionState.stok || '';
    const path = stok ? `/cgi-bin/luci/;stok=${stok}/admin/access_control?form=black_list` : '/cgi-bin/luci/admin/access_control?form=black_list';
    const res = await ctx.transport({
      method: 'POST',
      path,
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ operation: 'insert', mac: normalizeMac(macAddress) }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async unblockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const stok = ctx.sessionState.stok || '';
    const path = stok ? `/cgi-bin/luci/;stok=${stok}/admin/access_control?form=black_list` : '/cgi-bin/luci/admin/access_control?form=black_list';
    const res = await ctx.transport({
      method: 'POST',
      path,
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ operation: 'remove', mac: normalizeMac(macAddress) }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async rebootRouter(ctx: RouterConnectionContext): Promise<void> {
    const stok = ctx.sessionState.stok || '';
    const path = stok ? `/cgi-bin/luci/;stok=${stok}/admin/system?form=reboot` : '/cgi-bin/luci/admin/system?form=reboot';
    const res = await ctx.transport({
      method: 'POST',
      path,
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ operation: 'write' }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async getGuestWifiEnabled(ctx: RouterConnectionContext): Promise<boolean | null> {
    const stok = ctx.sessionState.stok || '';
    const path = stok ? `/cgi-bin/luci/;stok=${stok}/admin/wireless?form=guest_2g` : '/cgi-bin/luci/admin/wireless?form=guest_2g';
    const res = await ctx.transport({ method: 'GET', path }).catch(() => null);
    if (!res || res.status >= 400) return null;
    const json = tryParseJson<TpLinkJsonResponse>(res.body);
    const data = (json?.result || json?.data) as Record<string, unknown> | undefined;
    if (!data || data.enable === undefined) return null;
    return data.enable !== 'off' && data.enable !== false;
  },

  async setGuestWifiEnabled(ctx: RouterConnectionContext, enabled: boolean): Promise<void> {
    const stok = ctx.sessionState.stok || '';
    const path = stok ? `/cgi-bin/luci/;stok=${stok}/admin/wireless?form=guest_2g` : '/cgi-bin/luci/admin/wireless?form=guest_2g';
    const res = await ctx.transport({
      method: 'POST',
      path,
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ operation: 'write', enable: enabled ? 'on' : 'off' }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async setInternetAccessPaused(ctx: RouterConnectionContext, paused: boolean): Promise<void> {
    const stok = ctx.sessionState.stok || '';
    const path = stok ? `/cgi-bin/luci/;stok=${stok}/admin/network?form=wan_ipv4` : '/cgi-bin/luci/admin/network?form=wan_ipv4';
    const res = await ctx.transport({
      method: 'POST',
      path,
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ operation: paused ? 'disconnect' : 'connect' }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async disconnect(ctx: RouterConnectionContext): Promise<void> {
    const stok = ctx.sessionState.stok || '';
    const path = stok ? `/cgi-bin/luci/;stok=${stok}/admin/system?form=logout` : '/cgi-bin/luci/admin/system?form=logout';
    await ctx.transport({ method: 'POST', path }).catch(() => undefined);
  }
};
