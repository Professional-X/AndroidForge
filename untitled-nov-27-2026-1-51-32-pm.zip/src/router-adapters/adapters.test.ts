import test from 'node:test';
import assert from 'node:assert/strict';
import { detectBestAdapter, getAdapterById, ROUTER_ADAPTERS } from './registry';
import { HttpRequestOptions, HttpResponse, RouterConnectionContext, RouterError } from './types';

test('registry exposes 11 independent router adapters including HG8145X6-10 and generic fallback', () => {
  assert.equal(ROUTER_ADAPTERS.length, 11);
  assert.equal(getAdapterById('huawei-hg8145x6-10').vendor, 'Huawei');
  assert.equal(getAdapterById('huawei-hg8145x6-10').defaultGateways[0], '192.168.100.1');
  assert.equal(getAdapterById('huawei').vendor, 'Huawei');
  assert.equal(getAdapterById('tp-link').vendor, 'TP-Link');
  assert.equal(getAdapterById('zte').vendor, 'ZTE');
  assert.equal(getAdapterById('nokia').vendor, 'Nokia');
  assert.equal(getAdapterById('generic').capabilities.writeWifiSettings, false);
});

test('detectBestAdapter identifies Huawei OptiXstar HG8145X6-10 vs HiLink XML vs TP-Link vs unrecognized gateway', () => {
  const hgMatch = detectBestAdapter({
    rootStatus: 200,
    rootHeaders: {},
    rootBody: '<title>OptiXstar HG8145X6-10</title>',
    ontProbeBody: '8f1c9a2b3d4e5f60'
  });
  assert.equal(hgMatch.adapter.id, 'huawei-hg8145x6-10');

  const huaweiMatch = detectBestAdapter({
    rootStatus: 200,
    rootHeaders: {},
    rootBody: '<title>Huawei Mobile WiFi</title>',
    extraProbeBody: '<response><SesInfo>abc</SesInfo><TokInfo>123</TokInfo></response>'
  });
  assert.equal(huaweiMatch.adapter.id, 'huawei');

  const tpLinkMatch = detectBestAdapter({
    rootStatus: 200,
    rootHeaders: {},
    rootBody: '<script>var stok="/cgi-bin/luci";</script><title>TP-Link Archer C6</title>'
  });
  assert.equal(tpLinkMatch.adapter.id, 'tp-link');

  const unknownMatch = detectBestAdapter({
    rootStatus: 200,
    rootHeaders: {},
    rootBody: '<html><body>Custom ISP Modem XYZ-9000</body></html>'
  });
  assert.equal(unknownMatch.adapter.id, 'generic');
});

test('Huawei adapter parses Wi-Fi settings, connected devices, and blocks/unblocks MACs cleanly', async () => {
  const calls: HttpRequestOptions[] = [];
  const transport = async (req: HttpRequestOptions): Promise<HttpResponse> => {
    calls.push(req);
    if (req.path === '/api/webserver/SesTokInfo') {
      return {
        status: 200,
        headers: {},
        body: '<response><SesInfo>SessionID=xyz</SesInfo><TokInfo>tok123</TokInfo></response>'
      };
    }
    if (req.path === '/api/wlan/multi-basic-settings' && req.method === 'GET') {
      return {
        status: 200,
        headers: {},
        body: '<response><Ssid><WifiEnable>1</WifiEnable><WifiSsid>Home_Fiber</WifiSsid><WifiWpaPreSharedKey>SecretPass88</WifiWpaPreSharedKey><WifiAuthmode>WPA2-PSK</WifiAuthmode><WifiChannel>6</WifiChannel></Ssid></response>'
      };
    }
    if (req.path === '/api/wlan/host-list') {
      return {
        status: 200,
        headers: {},
        body: '<response><Hosts><Host><HostName>MacBook</HostName><IpAddress>192.168.8.101</IpAddress><MacAddress>a4:83:e7:11:22:33</MacAddress><InterfaceType>5G</InterfaceType><AssociatedTime>420</AssociatedTime></Host></Hosts></response>'
      };
    }
    if (req.path === '/api/wlan/mac-filter' && req.method === 'GET') {
      return { status: 200, headers: {}, body: '<response><WifiMacFilterStatus>0</WifiMacFilterStatus></response>' };
    }
    return { status: 200, headers: {}, body: '<response>OK</response>' };
  };

  const ctx: RouterConnectionContext = {
    baseUrl: 'http://192.168.8.1',
    adapterId: 'huawei',
    transport,
    sessionState: {}
  };

  const adapter = getAdapterById('huawei');
  const wifi = await adapter.getWifiSettings(ctx);
  assert.equal(wifi.band24?.ssid, 'Home_Fiber');
  assert.equal(wifi.band24?.password, 'SecretPass88');

  const devices = await adapter.getConnectedDevices(ctx);
  assert.equal(devices.connected.length, 1);
  assert.equal(devices.connected[0].vendor, 'Apple');
  assert.equal(devices.connected[0].connectionType, 'Wi-Fi 5GHz');

  await adapter.blockDevice(ctx, 'a4:83:e7:11:22:33');
  const blockCall = calls.find((c) => c.path === '/api/wlan/mac-filter' && c.method === 'POST');
  assert.ok(blockCall?.body?.includes('A4:83:E7:11:22:33'));
});

test('Generic adapter refuses unsupported control actions with UNSUPPORTED_MODEL', async () => {
  const ctx: RouterConnectionContext = {
    baseUrl: 'http://192.168.1.1',
    adapterId: 'generic',
    transport: async () => ({ status: 200, headers: {}, body: '<html>Unknown</html>' }),
    sessionState: {}
  };
  const generic = getAdapterById('generic');
  await assert.rejects(() => generic.connect(ctx), (err: unknown) => err instanceof RouterError && err.code === 'UNSUPPORTED_MODEL');
  await assert.rejects(
    () => generic.updateWifiSettings(ctx, { band: '2.4GHz', ssid: 'Test', encryption: 'WPA2-PSK' }),
    (err: unknown) => err instanceof RouterError && err.code === 'UNSUPPORTED_MODEL'
  );
  await assert.rejects(
    () => generic.rebootRouter!(ctx),
    (err: unknown) => err instanceof RouterError && err.code === 'UNSUPPORTED_MODEL'
  );
  await assert.rejects(
    () => generic.setGuestWifiEnabled!(ctx, true),
    (err: unknown) => err instanceof RouterError && err.code === 'UNSUPPORTED_MODEL'
  );
  await assert.rejects(
    () => generic.setInternetAccessPaused!(ctx, true),
    (err: unknown) => err instanceof RouterError && err.code === 'UNSUPPORTED_MODEL'
  );
});

test('Huawei adapter executes reboot, guest Wi-Fi toggle, and WAN internet pause protocols', async () => {
  const calls: HttpRequestOptions[] = [];
  const transport = async (req: HttpRequestOptions): Promise<HttpResponse> => {
    calls.push(req);
    if (req.path === '/api/webserver/SesTokInfo') {
      return {
        status: 200,
        headers: {},
        body: '<response><SesInfo>SessionID=xyz</SesInfo><TokInfo>tok456</TokInfo></response>'
      };
    }
    return { status: 200, headers: {}, body: '<response>OK</response>' };
  };
  const ctx: RouterConnectionContext = {
    baseUrl: 'http://192.168.8.1',
    adapterId: 'huawei',
    transport,
    sessionState: {}
  };
  const huawei = getAdapterById('huawei');
  await huawei.rebootRouter!(ctx);
  await huawei.setGuestWifiEnabled!(ctx, true);
  await huawei.setInternetAccessPaused!(ctx, true);

  assert.ok(calls.some((c) => c.path === '/api/device/control' && c.body?.includes('<Control>1</Control>')));
  assert.ok(calls.some((c) => c.path === '/api/wlan/guest-settings' && c.body?.includes('<WifiEnable>1</WifiEnable>')));
  assert.ok(calls.some((c) => c.path === '/api/dialup/mobile-dataswitch' && c.body?.includes('<dataswitch>0</dataswitch>')));
});

test('Huawei OptiXstar HG8145X6-10 independent adapter parses ONT fields honestly, avoids HiLink calls, and enforces read-back verification', async () => {
  const calls: HttpRequestOptions[] = [];
  let wlanSsid = 'Home_ONT_2G';
  let rejectVerifyUpdate = false;

  const transport = async (req: HttpRequestOptions): Promise<HttpResponse> => {
    calls.push(req);
    if (req.path === '/api/webserver/SesTokInfo') {
      return { status: 404, headers: {}, body: 'Not Found' };
    }
    if (req.path === '/asp/GetRandCount.asp') {
      return { status: 200, headers: {}, body: '\uFEFF8f1c9a2b3d4e5f60' };
    }
    if (req.path === '/login.cgi' && req.method === 'POST') {
      if (req.body?.includes('d3JvbmdwYXNz')) {
        return { status: 200, headers: {}, body: '<script>var ErrCode="login_fail";</script>' };
      }
      return { status: 200, headers: {}, body: '<input type="hidden" id="hwonttoken" value="next_ont_tok_99" />' };
    }
    if (req.path === '/html/ssmp/devinfo/devinfo.asp') {
      return {
        status: 200,
        headers: {},
        body: '<script>var ModelName = "OptiXstar HG8145X6-10"; var SoftwareVersion = "V5R023C00S174"; var HardwareVersion = "2C6D.A"; var RxPower = "-19.4 dBm";</script>'
      };
    }
    if (req.path === '/html/bbsp/waninfo/waninfo.asp') {
      return { status: 200, headers: {}, body: 'var wanStatus = "Connected";' };
    }
    if (req.path === '/html/amp/wlanbasic/set.cgi' && req.method === 'POST') {
      if (!rejectVerifyUpdate) {
        const params = new URLSearchParams(req.body || '');
        wlanSsid = params.get('x.SSID') || wlanSsid;
      }
      return { status: 200, headers: {}, body: 'OK' };
    }
    if (req.path === '/html/amp/wlaninfo/wlaninfo.asp') {
      return {
        status: 200,
        headers: {},
        body: `
          <script>
            new stWlan("InternetGatewayDevice.LANDevice.1.WLANConfiguration.1","ath0","1","${wlanSsid}","0","11i","AES","MyOntPass24","Auto","6");
            new stWlan("InternetGatewayDevice.LANDevice.1.WLANConfiguration.5","ath4","1","Home_ONT_5G","0","WPA3","AES","********","Auto","36");
          </script>
        `
      };
    }
    if (req.path === '/html/bbsp/common/GetLanUserDevInfo.asp') {
      return {
        status: 200,
        headers: {},
        body: `
          <script>
            new USERDev("InternetGatewayDevice.LANDevice.1.Hosts.Host.1","Pixel-8","192.168.100.12","A4:83:E7:22:33:44","SSID5","Online");
          </script>
        `
      };
    }
    return { status: 200, headers: {}, body: 'OK' };
  };

  const detected = detectBestAdapter({
    rootStatus: 200,
    rootHeaders: {},
    rootBody: '<title>OptiXstar HG8145X6-10</title>',
    ontProbeBody: '8f1c9a2b3d4e5f60'
  });
  assert.equal(detected.adapter.id, 'huawei-hg8145x6-10');
  assert.equal(detected.adapter.defaultGateways[0], '192.168.100.1');

  const ctx: RouterConnectionContext = {
    baseUrl: 'http://192.168.100.1',
    adapterId: 'huawei-hg8145x6-10',
    transport,
    sessionState: {}
  };

  const hgAdapter = getAdapterById('huawei-hg8145x6-10');
  await hgAdapter.connect(ctx);
  assert.equal(ctx.sessionState.subprotocol, 'ont-asp');
  assert.equal(calls.some((c) => c.path.includes('/api/webserver/')), false);

  // Bad password rejected with INVALID_CREDENTIALS
  await assert.rejects(
    () => hgAdapter.authenticate(ctx, { username: 'admin', password: 'wrongpass' }),
    (err: unknown) => err instanceof RouterError && err.code === 'INVALID_CREDENTIALS'
  );

  // Valid password authenticates
  await hgAdapter.authenticate(ctx, { username: 'admin', password: 'AdminValidPass' });
  const info = await hgAdapter.getRouterInfo(ctx);
  assert.equal(info.model, 'OptiXstar HG8145X6-10');
  assert.equal(info.firmwareVersion, 'V5R023C00S174');
  assert.equal(info.hardwareVersion, '2C6D.A');
  assert.equal(info.wanConnected, true);
  assert.equal(info.signalStrengthDbm, -19);

  const wifi = await hgAdapter.getWifiSettings(ctx);
  assert.equal(wifi.band24?.ssid, 'Home_ONT_2G');
  assert.equal(wifi.band24?.password, 'MyOntPass24');
  assert.equal(wifi.band5?.ssid, 'Home_ONT_5G');
  assert.equal(wifi.band5?.password, null); // Masked ******** is NEVER exposed as real password

  // Read-back verification failure throws SETTINGS_APPLY_FAILED instead of silent false success
  rejectVerifyUpdate = true;
  await assert.rejects(
    () =>
      hgAdapter.updateWifiSettings(ctx, {
        band: '2.4GHz',
        enabled: true,
        ssid: 'NeverSavedSSID',
        encryption: 'WPA2-PSK',
        channel: '6'
      }),
    (err: unknown) => err instanceof RouterError && err.code === 'SETTINGS_APPLY_FAILED'
  );

  const devs = await hgAdapter.getConnectedDevices(ctx);
  assert.equal(devs.connected.length, 1);
  assert.equal(devs.connected[0].hostname, 'Pixel-8');
  assert.equal(devs.connected[0].connectionType, 'Wi-Fi 5GHz');

  // Reboot invokes ONT reset.cgi
  await hgAdapter.rebootRouter!(ctx);
  assert.ok(calls.some((c) => c.path.includes('/html/ssmp/reset/set.cgi') && c.body?.includes('X_HW_Token')));

  // Unsupported WAN toggle throws UNSUPPORTED_MODEL honestly instead of faking
  await assert.rejects(
    () => hgAdapter.setInternetAccessPaused!(ctx, true),
    (err: unknown) => err instanceof RouterError && err.code === 'UNSUPPORTED_MODEL'
  );
});

test('HG8145X6-10 adapter returns null instead of inventing values when devinfo fields are absent', async () => {
  const ctx: RouterConnectionContext = {
    baseUrl: 'http://192.168.100.1',
    adapterId: 'huawei-hg8145x6-10',
    transport: async (req) => {
      if (req.path === '/html/ssmp/devinfo/devinfo.asp') {
        return { status: 200, headers: {}, body: '<html><body>Minimal devinfo</body></html>' };
      }
      if (req.path === '/html/bbsp/waninfo/waninfo.asp') {
        return { status: 404, headers: {}, body: 'Not Found' };
      }
      return { status: 200, headers: {}, body: 'OK' };
    },
    sessionState: { hwToken: 'tok123456' }
  };

  const info = await getAdapterById('huawei-hg8145x6-10').getRouterInfo(ctx);
  assert.equal(info.model, null);
  assert.equal(info.firmwareVersion, null);
  assert.equal(info.hardwareVersion, null);
  assert.equal(info.uptimeSeconds, null);
  assert.equal(info.wanConnected, null);
  assert.equal(info.signalStrengthDbm, null);
});

test('Huawei and HG8145X6-10 adapters distinguish online, offline, and blocked devices without marking Offline as Online', async () => {
  const userDevHtml = `
    <script>
      new USERDev("InternetGatewayDevice.LANDevice.1.Hosts.Host.1","Active-Phone","192.168.100.12","A4:83:E7:22:33:44","SSID5","Online");
      new USERDev("InternetGatewayDevice.LANDevice.1.Hosts.Host.2","Sleep-Laptop","192.168.100.15","70:4D:7B:11:22:33","LAN1","Offline");
      new USERDev("InternetGatewayDevice.LANDevice.1.Hosts.Host.3","Banned-Tablet","192.168.100.19","CC:2D:E0:44:55:66","SSID1","Online");
      new USERDev("InternetGatewayDevice.LANDevice.1.Hosts.Host.4","Banned-Offline","192.168.100.20","18:FE:34:77:88:99","SSID1","Offline");
    </script>
  `;
  const macFilterHtml = `
    <script>
      var blocked1 = "CC:2D:E0:44:55:66";
      var blocked2 = "18:FE:34:77:88:99";
    </script>
  `;

  const transport = async (req: HttpRequestOptions): Promise<HttpResponse> => {
    if (req.path === '/html/bbsp/common/GetLanUserDevInfo.asp') {
      return { status: 200, headers: {}, body: userDevHtml };
    }
    if (req.path === '/html/bbsp/macfilter/macfilter.asp') {
      return { status: 200, headers: {}, body: macFilterHtml };
    }
    return { status: 200, headers: {}, body: 'OK' };
  };

  for (const id of ['huawei-hg8145x6-10', 'huawei'] as const) {
    const ctx: RouterConnectionContext = {
      baseUrl: 'http://192.168.100.1',
      adapterId: id,
      transport,
      sessionState: { subprotocol: 'ont-asp', hwToken: 'tok123456' }
    };
    const { connected, blockedMacs } = await getAdapterById(id).getConnectedDevices(ctx);
    assert.equal(connected.length, 4);
    assert.deepEqual(
      connected.map((d) => [d.hostname, d.status]),
      [
        ['Active-Phone', 'online'],
        ['Sleep-Laptop', 'offline'],
        ['Banned-Tablet', 'blocked'],
        ['Banned-Offline', 'blocked']
      ]
    );
    assert.equal(blockedMacs.length, 2);
  }
});
