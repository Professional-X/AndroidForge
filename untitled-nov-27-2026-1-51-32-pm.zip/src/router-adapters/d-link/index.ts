import { lookupMacVendor, normalizeMac } from '../../utils/networkSecurity';
import {
  ConnectedDevice,
  ProbeSnapshot,
  RouterAdapter,
  RouterConnectionContext,
  RouterCredentials,
  RouterError,
  RouterInfo,
  WifiSettings,
  WifiUpdateInput
} from '../types';
import { escapeXml, extractXmlBlocks, extractXmlTag } from '../xmlUtils';

function buildHnapEnvelope(action: string, innerXml: string): string {
  return `<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><${action} xmlns="http://purenetworks.com/HNAP1/">${innerXml}</${action}></soap:Body></soap:Envelope>`;
}

export const dlinkAdapter: RouterAdapter = {
  id: 'd-link',
  vendor: 'D-Link',
  supportedModels: ['DIR-842 / DIR-878 / DIR-882', 'DIR-X1860 / EXO Series', 'DSL-2750U'],
  firmwareHints: ['HNAP1 SOAP API', 'D-Link Web UI'],
  authMethod: 'HNAP1 Challenge-Response SOAP',
  defaultGateways: ['192.168.0.1', '192.168.1.1', 'dlinkrouter.local'],
  capabilities: {
    readRouterInfo: true,
    readWifiSettings: true,
    writeWifiSettings: true,
    readWifiPassword: true,
    dualBand24: true,
    dualBand5: true,
    toggleWifiRadio: true,
    listDevices: true,
    blockMacDevice: true,
    unblockMacDevice: true,
    readSignalStats: false,
    readChannelInfo: true,
    rebootRouter: true,
    guestWifi: true,
    blockAllInternet: false,
    supportedEncryptions: ['WPA2-PSK', 'WPA/WPA2-PSK', 'OPEN']
  },

  detectScore(probe: ProbeSnapshot): number {
    const body = probe.rootBody.toLowerCase();
    let score = 0;
    if (body.includes('d-link') || body.includes('dlink') || body.includes('hnap')) score += 70;
    return score;
  },

  async connect(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({ method: 'GET', path: '/HNAP1/' });
    if (res.status === 0 || res.status >= 500) throw new RouterError('ROUTER_OFFLINE');
  },

  async authenticate(ctx: RouterConnectionContext, creds: RouterCredentials): Promise<void> {
    const body = buildHnapEnvelope(
      'Login',
      `<Action>request</Action><Username>${escapeXml(creds.username.trim() || 'Admin')}</Username><LoginPassword>${escapeXml(creds.password)}</LoginPassword><Captcha></Captcha>`
    );
    const res = await ctx.transport({
      method: 'POST',
      path: '/HNAP1/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': '"http://purenetworks.com/HNAP1/Login"'
      },
      body
    });
    const loginResult = extractXmlTag(res.body, 'LoginResult');
    if (res.status === 401 || loginResult === 'FAILED') {
      throw new RouterError('INVALID_CREDENTIALS');
    }
    const challenge = extractXmlTag(res.body, 'Challenge');
    if (challenge) ctx.sessionState.challenge = challenge;
  },

  async getRouterInfo(ctx: RouterConnectionContext): Promise<RouterInfo> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/HNAP1/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': '"http://purenetworks.com/HNAP1/GetDeviceSettings"'
      },
      body: buildHnapEnvelope('GetDeviceSettings', '')
    });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    return {
      vendor: 'D-Link',
      model: extractXmlTag(res.body, 'ModelName') || 'D-Link Router',
      firmwareVersion: extractXmlTag(res.body, 'FirmwareVersion'),
      gatewayIp: new URL(ctx.baseUrl).hostname,
      wanConnected: null,
      uptimeSeconds: null,
      signalStrengthDbm: null,
      channelCongestionScore: null
    };
  },

  async getWifiSettings(ctx: RouterConnectionContext): Promise<WifiSettings> {
    const res24 = await ctx.transport({
      method: 'POST',
      path: '/HNAP1/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': '"http://purenetworks.com/HNAP1/GetWLanRadioSettings"'
      },
      body: buildHnapEnvelope('GetWLanRadioSettings', '<RadioID>RADIO_2.4GHz</RadioID>')
    });
    if (res24.status === 401) throw new RouterError('SESSION_EXPIRED');
    const sec24 = await ctx.transport({
      method: 'POST',
      path: '/HNAP1/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': '"http://purenetworks.com/HNAP1/GetWLanRadioSecurity"'
      },
      body: buildHnapEnvelope('GetWLanRadioSecurity', '<RadioID>RADIO_2.4GHz</RadioID>')
    }).catch(() => null);

    return {
      band24: {
        band: '2.4GHz',
        enabled: extractXmlTag(res24.body, 'Enabled') !== 'false',
        ssid: extractXmlTag(res24.body, 'SSID') || '',
        password: sec24 ? extractXmlTag(sec24.body, 'Key') : null,
        encryption: sec24 ? extractXmlTag(sec24.body, 'Type') || 'WPA2-PSK' : 'WPA2-PSK',
        channel: extractXmlTag(res24.body, 'Channel') || '0'
      },
      band5: null
    };
  },

  async updateWifiSettings(ctx: RouterConnectionContext, update: WifiUpdateInput): Promise<void> {
    const radioId = update.band === '5GHz' ? 'RADIO_5GHz' : 'RADIO_2.4GHz';
    const res = await ctx.transport({
      method: 'POST',
      path: '/HNAP1/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': '"http://purenetworks.com/HNAP1/SetWLanRadioSettings"'
      },
      body: buildHnapEnvelope(
        'SetWLanRadioSettings',
        `<RadioID>${radioId}</RadioID><Enabled>${update.enabled !== false}</Enabled><SSID>${escapeXml(update.ssid)}</SSID><Channel>${escapeXml(update.channel || '0')}</Channel>`
      )
    });
    if (res.status >= 400 || extractXmlTag(res.body, 'SetWLanRadioSettingsResult') === 'ERROR') {
      throw new RouterError('SETTINGS_APPLY_FAILED');
    }
    if (update.password !== undefined) {
      await ctx.transport({
        method: 'POST',
        path: '/HNAP1/',
        headers: {
          'Content-Type': 'text/xml; charset=utf-8',
          'SOAPAction': '"http://purenetworks.com/HNAP1/SetWLanRadioSecurity"'
        },
        body: buildHnapEnvelope(
          'SetWLanRadioSecurity',
          `<RadioID>${radioId}</RadioID><Enabled>${update.encryption !== 'OPEN'}</Enabled><Type>${escapeXml(update.encryption)}</Type><Key>${escapeXml(update.password)}</Key>`
        )
      });
    }
  },

  async getConnectedDevices(ctx: RouterConnectionContext) {
    const res = await ctx.transport({
      method: 'POST',
      path: '/HNAP1/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': '"http://purenetworks.com/HNAP1/GetClientInfo"'
      },
      body: buildHnapEnvelope('GetClientInfo', '')
    });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const blocks = extractXmlBlocks(res.body, 'ClientInfo');
    const connected: ConnectedDevice[] = blocks
      .map((block, idx) => {
        const rawMac = extractXmlTag(block, 'MacAddress') || '';
        const mac = normalizeMac(rawMac);
        if (!mac) return null;
        return {
          id: mac,
          hostname: extractXmlTag(block, 'DeviceName') || `Client-${idx + 1}`,
          ipAddress: extractXmlTag(block, 'IPv4Address') || '',
          macAddress: mac,
          vendor: lookupMacVendor(mac),
          connectionType: (extractXmlTag(block, 'Type') || '').includes('5G') ? 'Wi-Fi 5GHz' : 'Wi-Fi',
          lastSeen: null,
          status: 'online'
        } as ConnectedDevice;
      })
      .filter((d): d is ConnectedDevice => d !== null);
    return { connected, blockedMacs: [] };
  },

  async blockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/HNAP1/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': '"http://purenetworks.com/HNAP1/SetMACFilters2"'
      },
      body: buildHnapEnvelope(
        'SetMACFilters2',
        `<Enabled>true</Enabled><IsAllowList>false</IsAllowList><MACList><MACInfo><MacAddress>${escapeXml(normalizeMac(macAddress))}</MacAddress></MACInfo></MACList>`
      )
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async unblockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/HNAP1/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': '"http://purenetworks.com/HNAP1/SetMACFilters2"'
      },
      body: buildHnapEnvelope('SetMACFilters2', `<Enabled>false</Enabled><RemoveMac>${escapeXml(normalizeMac(macAddress))}</RemoveMac>`)
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async rebootRouter(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/HNAP1/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': '"http://purenetworks.com/HNAP1/Reboot"'
      },
      body: buildHnapEnvelope('Reboot', '')
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async setGuestWifiEnabled(ctx: RouterConnectionContext, enabled: boolean): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/HNAP1/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': '"http://purenetworks.com/HNAP1/SetGuestZoneRouterSettings"'
      },
      body: buildHnapEnvelope(
        'SetGuestZoneRouterSettings',
        `<RadioID>RADIO_2.4GHz</RadioID><Enabled>${enabled ? 'true' : 'false'}</Enabled>`
      )
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async disconnect(ctx: RouterConnectionContext): Promise<void> {
    await ctx.transport({
      method: 'POST',
      path: '/HNAP1/',
      headers: { 'SOAPAction': '"http://purenetworks.com/HNAP1/Logout"' },
      body: buildHnapEnvelope('Logout', '')
    }).catch(() => undefined);
  }
};
