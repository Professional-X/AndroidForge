import { lookupMacVendor, normalizeMac } from '../../utils/networkSecurity';
import {
  ConnectedDevice,
  ProbeSnapshot,
  RouterAdapter,
  RouterConnectionContext,
  RouterCredentials,
  RouterError,
  RouterInfo,
  WifiSettings,
  WifiUpdateInput
} from '../types';
import { tryParseJson } from '../xmlUtils';

export const tendaAdapter: RouterAdapter = {
  id: 'tenda',
  vendor: 'Tenda',
  supportedModels: ['AC6 / AC8 / AC10 / AC23', 'F3 / N301 / TX3 / RX3'],
  firmwareHints: ['Tenda GoAhead /goform/ API'],
  authMethod: '/login/Auth Form Cookie',
  defaultGateways: ['192.168.0.1', 'tendawifi.com'],
  capabilities: {
    readRouterInfo: true,
    readWifiSettings: true,
    writeWifiSettings: true,
    readWifiPassword: true,
    dualBand24: true,
    dualBand5: true,
    toggleWifiRadio: true,
    listDevices: true,
    blockMacDevice: true,
    unblockMacDevice: true,
    readSignalStats: false,
    readChannelInfo: true,
    rebootRouter: true,
    guestWifi: true,
    blockAllInternet: false,
    supportedEncryptions: ['WPA2-PSK', 'WPA/WPA2-PSK', 'OPEN']
  },

  detectScore(probe: ProbeSnapshot): number {
    const body = probe.rootBody.toLowerCase();
    return body.includes('tenda') || body.includes('tendawifi') || body.includes('/goform/') ? 70 : 0;
  },

  async connect(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({ method: 'GET', path: '/' });
    if (res.status === 0 || res.status >= 500) throw new RouterError('ROUTER_OFFLINE');
  },

  async authenticate(ctx: RouterConnectionContext, creds: RouterCredentials): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/login/Auth',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        username: creds.username.trim() || 'admin',
        password: btoa(creds.password)
      }).toString()
    });
    if (res.status === 401 || res.body.includes('password_error') || res.body.includes('login.html')) {
      throw new RouterError('INVALID_CREDENTIALS');
    }
  },

  async getRouterInfo(ctx: RouterConnectionContext): Promise<RouterInfo> {
    const res = await ctx.transport({ method: 'GET', path: '/goform/getStatus' });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const json = tryParseJson<Record<string, unknown>>(res.body) || {};
    return {
      vendor: 'Tenda',
      model: String(json.deviceModel || 'Tenda Router'),
      firmwareVersion: json.firmwareVersion ? String(json.firmwareVersion) : null,
      gatewayIp: new URL(ctx.baseUrl).hostname,
      wanConnected: json.wanStatus === 'Connected' ? true : null,
      uptimeSeconds: null,
      signalStrengthDbm: null,
      channelCongestionScore: null
    };
  },

  async getWifiSettings(ctx: RouterConnectionContext): Promise<WifiSettings> {
    const res = await ctx.transport({ method: 'GET', path: '/goform/getWlanInfo' });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const json = tryParseJson<Record<string, unknown>>(res.body) || {};
    return {
      band24: {
        band: '2.4GHz',
        enabled: json.wifiEn !== 'false' && json.wifiEn !== '0',
        ssid: String(json.wifiSSID || ''),
        password: typeof json.wifiPwd === 'string' ? json.wifiPwd : null,
        encryption: String(json.wifiSecurityMode || 'WPA2-PSK'),
        channel: String(json.wifiChannel || '0')
      },
      band5: json.wifi5gSSID
        ? {
            band: '5GHz',
            enabled: json.wifi5gEn !== 'false' && json.wifi5gEn !== '0',
            ssid: String(json.wifi5gSSID || ''),
            password: typeof json.wifi5gPwd === 'string' ? json.wifi5gPwd : null,
            encryption: String(json.wifi5gSecurityMode || 'WPA2-PSK'),
            channel: String(json.wifi5gChannel || '0')
          }
        : null
    };
  },

  async updateWifiSettings(ctx: RouterConnectionContext, update: WifiUpdateInput): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/goform/WifiBasicSet',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        band: update.band === '5GHz' ? '5G' : '2.4G',
        wifiEn: update.enabled === false ? 'false' : 'true',
        wifiSSID: update.ssid,
        wifiSecurityMode: update.encryption,
        ...(update.password !== undefined ? { wifiPwd: update.password } : {}),
        ...(update.channel ? { wifiChannel: update.channel } : {})
      }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async getConnectedDevices(ctx: RouterConnectionContext) {
    const res = await ctx.transport({ method: 'GET', path: '/goform/getOnlineList' });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const json = tryParseJson<Array<{ devName?: string; ip?: string; mac?: string; linkType?: string; isBlocked?: boolean }>>(res.body);
    const list = Array.isArray(json) ? json : [];
    const blockedMacs: string[] = [];
    const connected: ConnectedDevice[] = list
      .filter((d) => Boolean(d.mac))
      .map((d, idx) => {
        const mac = normalizeMac(d.mac!);
        if (d.isBlocked) blockedMacs.push(mac);
        return {
          id: mac,
          hostname: d.devName || `Device-${idx + 1}`,
          ipAddress: d.ip || '',
          macAddress: mac,
          vendor: lookupMacVendor(mac),
          connectionType: d.linkType === '5G' ? 'Wi-Fi 5GHz' : d.linkType === '2.4G' ? 'Wi-Fi 2.4GHz' : 'Unknown',
          lastSeen: null,
          status: d.isBlocked ? 'blocked' : 'online'
        };
      });
    return { connected, blockedMacs };
  },

  async blockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/goform/setMacFilter',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ action: 'add', mac: normalizeMac(macAddress) }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async unblockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/goform/setMacFilter',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ action: 'del', mac: normalizeMac(macAddress) }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async rebootRouter(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/goform/SysToolReboot',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ action: 'reboot' }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async setGuestWifiEnabled(ctx: RouterConnectionContext, enabled: boolean): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/goform/WifiGuestSet',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ guestEn: enabled ? '1' : '0' }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async disconnect(ctx: RouterConnectionContext): Promise<void> {
    await ctx.transport({ method: 'GET', path: '/login/loginOut' }).catch(() => undefined);
  }
};
