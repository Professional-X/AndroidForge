import { lookupMacVendor, normalizeMac } from '../../utils/networkSecurity';
import {
  ConnectedDevice,
  ProbeSnapshot,
  RouterAdapter,
  RouterConnectionContext,
  RouterCredentials,
  RouterError,
  RouterInfo,
  WifiSettings,
  WifiUpdateInput
} from '../types';
import { tryParseJson } from '../xmlUtils';

export const fiberhomeAdapter: RouterAdapter = {
  id: 'fiberhome',
  vendor: 'FiberHome',
  supportedModels: ['HG6245D / HG6245N', 'AN5506-04-F / SR1041Y'],
  firmwareHints: ['FiberHome /cgi-bin/ajax JSON RPC'],
  authMethod: 'FiberHome Session Token (/cgi-bin/ajax)',
  defaultGateways: ['192.168.1.1', '192.168.100.1'],
  capabilities: {
    readRouterInfo: true,
    readWifiSettings: true,
    writeWifiSettings: true,
    readWifiPassword: true,
    dualBand24: true,
    dualBand5: true,
    toggleWifiRadio: true,
    listDevices: true,
    blockMacDevice: true,
    unblockMacDevice: true,
    readSignalStats: false,
    readChannelInfo: true,
    rebootRouter: true,
    guestWifi: false,
    blockAllInternet: false,
    supportedEncryptions: ['WPA2-PSK', 'WPA/WPA2-PSK', 'OPEN']
  },

  detectScore(probe: ProbeSnapshot): number {
    const body = probe.rootBody.toLowerCase();
    return body.includes('fiberhome') || body.includes('hg6245') || body.includes('an5506') ? 75 : 0;
  },

  async connect(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({ method: 'GET', path: '/' });
    if (res.status === 0 || res.status >= 500) throw new RouterError('ROUTER_OFFLINE');
  },

  async authenticate(ctx: RouterConnectionContext, creds: RouterCredentials): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/cgi-bin/ajax',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ajaxmethod: 'do_login',
        username: creds.username.trim() || 'admin',
        login_password: creds.password
      })
    });
    const json = tryParseJson<{ login_result?: number; sessionid?: string }>(res.body);
    if (res.status === 401 || json?.login_result === 0) {
      throw new RouterError('INVALID_CREDENTIALS');
    }
    if (json?.sessionid) ctx.sessionState.sessionId = json.sessionid;
  },

  async getRouterInfo(ctx: RouterConnectionContext): Promise<RouterInfo> {
    const res = await ctx.transport({
      method: 'GET',
      path: '/cgi-bin/ajax?ajaxmethod=get_device_info'
    });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const json = tryParseJson<Record<string, unknown>>(res.body) || {};
    return {
      vendor: 'FiberHome',
      model: String(json.ModelName || 'FiberHome ONT'),
      firmwareVersion: json.SoftwareVersion ? String(json.SoftwareVersion) : null,
      gatewayIp: new URL(ctx.baseUrl).hostname,
      wanConnected: json.WanStatus === 'Up' ? true : null,
      uptimeSeconds: null,
      signalStrengthDbm: null,
      channelCongestionScore: null
    };
  },

  async getWifiSettings(ctx: RouterConnectionContext): Promise<WifiSettings> {
    const res = await ctx.transport({
      method: 'GET',
      path: '/cgi-bin/ajax?ajaxmethod=get_wl_status'
    });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const json = tryParseJson<Record<string, unknown>>(res.body) || {};
    return {
      band24: {
        band: '2.4GHz',
        enabled: json.enable24 !== 0,
        ssid: String(json.ssid24 || ''),
        password: typeof json.psk24 === 'string' ? json.psk24 : null,
        encryption: String(json.auth24 || 'WPA2-PSK'),
        channel: String(json.channel24 || '0')
      },
      band5: json.ssid5
        ? {
            band: '5GHz',
            enabled: json.enable5 !== 0,
            ssid: String(json.ssid5 || ''),
            password: typeof json.psk5 === 'string' ? json.psk5 : null,
            encryption: String(json.auth5 || 'WPA2-PSK'),
            channel: String(json.channel5 || '0')
          }
        : null
    };
  },

  async updateWifiSettings(ctx: RouterConnectionContext, update: WifiUpdateInput): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/cgi-bin/ajax',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ajaxmethod: 'set_wl_cfg',
        band: update.band,
        enable: update.enabled === false ? 0 : 1,
        ssid: update.ssid,
        auth: update.encryption,
        ...(update.password !== undefined ? { psk: update.password } : {}),
        ...(update.channel ? { channel: update.channel } : {})
      })
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async getConnectedDevices(ctx: RouterConnectionContext) {
    const res = await ctx.transport({ method: 'GET', path: '/cgi-bin/ajax?ajaxmethod=get_lan_devices' });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const json = tryParseJson<{ devices?: Array<{ name?: string; ip?: string; mac?: string; blocked?: boolean }> }>(res.body);
    const blockedMacs: string[] = [];
    const connected: ConnectedDevice[] = (json?.devices || [])
      .filter((d) => Boolean(d.mac))
      .map((d, idx) => {
        const mac = normalizeMac(d.mac!);
        if (d.blocked) blockedMacs.push(mac);
        return {
          id: mac,
          hostname: d.name || `Client-${idx + 1}`,
          ipAddress: d.ip || '',
          macAddress: mac,
          vendor: lookupMacVendor(mac),
          connectionType: 'Unknown',
          lastSeen: null,
          status: d.blocked ? 'blocked' : 'online'
        };
      });
    return { connected, blockedMacs };
  },

  async blockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/cgi-bin/ajax',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ajaxmethod: 'set_mac_filter', action: 'block', mac: normalizeMac(macAddress) })
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async unblockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/cgi-bin/ajax',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ajaxmethod: 'set_mac_filter', action: 'unblock', mac: normalizeMac(macAddress) })
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async rebootRouter(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/cgi-bin/ajax',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ajaxmethod: 'do_reboot' })
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async disconnect(ctx: RouterConnectionContext): Promise<void> {
    await ctx.transport({ method: 'GET', path: '/cgi-bin/ajax?ajaxmethod=do_logout' }).catch(() => undefined);
  }
};
