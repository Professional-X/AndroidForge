import { lookupMacVendor, normalizeMac } from '../../utils/networkSecurity';
import {
  ConnectedDevice,
  ProbeSnapshot,
  RouterAdapter,
  RouterCapabilities,
  RouterConnectionContext,
  RouterCredentials,
  RouterError,
  RouterInfo,
  WifiBandConfig,
  WifiSettings,
  WifiUpdateInput
} from '../types';

function utf8ToBase64(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let binary = '';
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary);
}

function cleanRandToken(raw: string): string {
  const cleaned = raw.replace(/^\uFEFF/, '').trim().replace(/^["']|["']$/g, '');
  if (!cleaned || cleaned.includes('<html') || cleaned.includes('<HTML') || cleaned.length < 6) {
    return '';
  }
  const line = cleaned.split(/\r?\n/)[0]?.trim() || '';
  return /^[A-Za-z0-9_-]{6,128}$/.test(line) ? line : '';
}

function extractOntHiddenToken(html: string): string {
  const match =
    html.match(/(?:hwonttoken|onttoken|X_HW_Token)[^>]*value=["']([A-Za-z0-9_-]{6,128})["']/i) ||
    html.match(/var\s+(?:onttoken|hwToken)\s*=\s*["']([A-Za-z0-9_-]{6,128})["']/i);
  return match?.[1] || '';
}

async function fetchOntRandToken(ctx: RouterConnectionContext): Promise<string> {
  const res = await ctx.transport({ method: 'GET', path: '/asp/GetRandCount.asp' }).catch(() => null);
  if (res && res.status >= 200 && res.status < 400) {
    const token = cleanRandToken(res.body) || extractOntHiddenToken(res.body);
    if (token) {
      ctx.sessionState.hwToken = token;
      return token;
    }
  }
  return ctx.sessionState.hwToken || '';
}

function detectOntAuthRejection(status: number, body: string): boolean {
  if (status === 401 || status === 403) return true;
  const lower = body.toLowerCase();
  return (
    lower.includes('errcode') ||
    lower.includes('login_fail') ||
    lower.includes('failtimes') ||
    lower.includes('password is wrong') ||
    lower.includes('invalid password') ||
    lower.includes('wrong password') ||
    lower.includes('user or password') ||
    (lower.includes('action="/login.cgi"') && !lower.includes('devinfo'))
  );
}

function detectOntSessionExpired(status: number, body: string): boolean {
  if (status === 401 || status === 403) return true;
  const lower = body.toLowerCase();
  return (
    lower.includes('action="/login.cgi"') ||
    lower.includes('top.location.replace') ||
    (lower.includes('getrandcount.asp') && lower.includes('submitform'))
  );
}

function splitQuotedArgs(rawArgs: string): string[] {
  const out: string[] = [];
  const re = /"((?:\\.|[^"\\])*)"|'((?:\\.|[^'\\])*)'|([^,\s]+)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(rawArgs)) !== null) {
    out.push(m[1] ?? m[2] ?? m[3] ?? '');
  }
  return out;
}

function parseOntUptimeSeconds(body: string): number | null {
  const numMatch = body.match(/(?:SysUpTime|SystemUpTime|UpTime)\s*[:=]\s*["']?(\d+)(?:\s*s(?:ec)?)?["']?/i);
  if (numMatch) {
    const sec = Number(numMatch[1]);
    return Number.isFinite(sec) && sec >= 0 ? sec : null;
  }
  const hmsMatch = body.match(/(?:SysUpTime|UpTime)\s*[:=]\s*["'](?:(\d+)\s*d(?:ays?)?[,\s]*)?(\d{1,2}):(\d{2}):(\d{2})["']/i);
  if (hmsMatch) {
    const days = Number(hmsMatch[1] || 0);
    const hrs = Number(hmsMatch[2] || 0);
    const mins = Number(hmsMatch[3] || 0);
    const secs = Number(hmsMatch[4] || 0);
    return days * 86400 + hrs * 3600 + mins * 60 + secs;
  }
  return null;
}

function parseOntWlanEntries(body: string): WifiSettings {
  const configs: WifiBandConfig[] = [];
  const stWlanRe = /new\s+stWlan\s*\(([^)]+)\)/gi;
  let m: RegExpExecArray | null;
  while ((m = stWlanRe.exec(body)) !== null) {
    const args = splitQuotedArgs(m[1]);
    const domain = args[0] || '';
    const nameOrIface = (args[1] || '').toLowerCase();
    const enabled = args[2] !== '0' && args[2]?.toLowerCase() !== 'false';
    const ssid = args[3] || args[1] || '';
    const beacon = (args[5] || '').toUpperCase();
    const channelArg = args.find(
      (a) => /^(auto|\d{1,3})$/i.test(a) && (a.toLowerCase() === 'auto' || (Number(a) > 0 && Number(a) <= 165))
    );
    const is5 =
      domain.includes('.5') ||
      domain.includes('.2') ||
      nameOrIface.includes('5g') ||
      nameOrIface.includes('wl1') ||
      nameOrIface.includes('ath4') ||
      configs.length === 1;

    const encryption =
      beacon.includes('WPA3') || beacon.includes('SAE')
        ? 'WPA3-SAE'
        : beacon.includes('11I') || beacon.includes('WPA2')
        ? 'WPA2-PSK'
        : beacon.includes('NONE') || beacon === 'BASIC'
        ? 'OPEN'
        : 'WPA/WPA2-PSK';

    const rawKey = args.find(
      (a, idx) => idx >= 6 && idx <= 9 && a.length >= 8 && !/^(WPA|Basic|11i|AES|TKIP)/i.test(a)
    );
    const password = rawKey && !/^\*+$/.test(rawKey) ? rawKey : null;

    if (ssid || domain) {
      configs.push({
        band: is5 ? '5GHz' : '2.4GHz',
        enabled,
        ssid,
        password,
        encryption,
        channel: channelArg || 'Auto'
      });
    }
  }

  return {
    band24: configs.find((c) => c.band === '2.4GHz') ?? null,
    band5: configs.find((c) => c.band === '5GHz') ?? null
  };
}

function parseOntLanDevices(body: string, blockedSet: Set<string>): ConnectedDevice[] {
  const devices: ConnectedDevice[] = [];
  const seenMacs = new Set<string>();
  const userDevRe = /new\s+USERDev\s*\(([^)]+)\)/gi;
  let m: RegExpExecArray | null;
  let idx = 0;

  while ((m = userDevRe.exec(body)) !== null) {
    idx += 1;
    const args = splitQuotedArgs(m[1]);
    const macCandidate = args.find((a) => /^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$/.test(a));
    if (!macCandidate) continue;
    const mac = normalizeMac(macCandidate);
    if (seenMacs.has(mac)) continue;
    seenMacs.add(mac);

    const ip = args.find((a) => /^(\d{1,3}\.){3}\d{1,3}$/.test(a)) || '';
    const portArg = args.find((a) => /^(SSID|LAN|Wi-Fi|ETH)/i.test(a)) || '';
    const stateArg = args.find((a) => /^(Online|Offline)$/i.test(a)) || 'Online';
    const hostnameCandidate = args.find(
      (a) =>
        a &&
        a !== macCandidate &&
        a !== ip &&
        a !== portArg &&
        a !== stateArg &&
        !/^InternetGatewayDevice\./i.test(a) &&
        !/^\d+$/.test(a)
    );

    const lowerPort = portArg.toLowerCase();
    const connectionType: ConnectedDevice['connectionType'] =
      lowerPort.includes('lan') || lowerPort.includes('eth')
        ? 'Ethernet'
        : lowerPort.includes('5') || lowerPort.includes('ssid5') || lowerPort.includes('ssid6')
        ? 'Wi-Fi 5GHz'
        : lowerPort.includes('ssid') || lowerPort.includes('wi')
        ? 'Wi-Fi 2.4GHz'
        : 'Wi-Fi';

    const status: ConnectedDevice['status'] = blockedSet.has(mac)
      ? 'blocked'
      : stateArg.toLowerCase() === 'offline'
      ? 'offline'
      : 'online';

    devices.push({
      id: mac,
      hostname: hostnameCandidate || mac,
      ipAddress: ip,
      macAddress: mac,
      vendor: lookupMacVendor(mac),
      connectionType,
      lastSeen: stateArg,
      status
    });
  }

  return devices;
}

export async function probeHg8145x6RuntimeCapabilities(
  ctx: RouterConnectionContext
): Promise<Partial<RouterCapabilities>> {
  const [wlanBasicRes, macRes, guestRes, resetRes] = await Promise.all([
    ctx.transport({ method: 'GET', path: '/html/amp/wlanbasic/WlanBasic.asp' }).catch(() => null),
    ctx.transport({ method: 'GET', path: '/html/bbsp/macfilter/macfilter.asp' }).catch(() => null),
    ctx.transport({ method: 'GET', path: '/html/amp/wlanbasic/WlanGuest.asp' }).catch(() => null),
    ctx.transport({ method: 'GET', path: '/html/ssmp/reset/reset.asp' }).catch(() => null)
  ]);

  const wlanEditable = Boolean(
    wlanBasicRes &&
      wlanBasicRes.status >= 200 &&
      wlanBasicRes.status < 400 &&
      !detectOntSessionExpired(wlanBasicRes.status, wlanBasicRes.body) &&
      (wlanBasicRes.body.includes('stWlan') || wlanBasicRes.body.toLowerCase().includes('wlan'))
  );

  const macSupported = Boolean(
    macRes &&
      macRes.status >= 200 &&
      macRes.status < 400 &&
      !detectOntSessionExpired(macRes.status, macRes.body) &&
      !macRes.body.toLowerCase().includes('404')
  );

  const guestSupported = Boolean(
    guestRes &&
      guestRes.status >= 200 &&
      guestRes.status < 400 &&
      !detectOntSessionExpired(guestRes.status, guestRes.body) &&
      guestRes.body.toLowerCase().includes('guest')
  );

  const rebootSupported = Boolean(
    resetRes &&
      resetRes.status >= 200 &&
      resetRes.status < 400 &&
      !detectOntSessionExpired(resetRes.status, resetRes.body) &&
      !resetRes.body.toLowerCase().includes('404')
  );

  return {
    writeWifiSettings: wlanEditable,
    blockMacDevice: macSupported,
    unblockMacDevice: macSupported,
    guestWifi: guestSupported,
    rebootRouter: rebootSupported,
    blockAllInternet: false
  };
}

/**
 * Independent Router Adapter specifically engineered for Huawei OptiXstar HG8145X6-10
 * (GPON ONT, DZTELCOM, Target Firmware V5R023C00S174, Hardware 2C6D.A).
 * Uses ONLY Huawei ONT ASP/CGI endpoints — NEVER falls back to HiLink XML APIs or fabricated data.
 */
export const huaweiHg8145x6Adapter: RouterAdapter = {
  id: 'huawei-hg8145x6-10',
  vendor: 'Huawei',
  supportedModels: [
    'OptiXstar HG8145X6-10 (GPON ONT · DZTELCOM · V5R023C00S174 · HW 2C6D.A)'
  ],
  firmwareHints: ['V5R023C00S174 (GPON ONT ASP/CGI)', 'Hardware 2C6D.A · DZTELCOM'],
  authMethod: 'ONT Challenge Token (/asp/GetRandCount.asp) + /login.cgi (Strict No-HiLink)',
  defaultGateways: ['192.168.100.1'],
  capabilities: {
    readRouterInfo: true,
    readWifiSettings: true,
    writeWifiSettings: true,
    readWifiPassword: true,
    dualBand24: true,
    dualBand5: true,
    toggleWifiRadio: true,
    listDevices: true,
    blockMacDevice: true,
    unblockMacDevice: true,
    readSignalStats: true,
    readChannelInfo: true,
    rebootRouter: true,
    guestWifi: true,
    blockAllInternet: false,
    supportedEncryptions: ['WPA2-PSK', 'WPA/WPA2-PSK', 'WPA3-SAE', 'OPEN']
  },

  detectScore(probe: ProbeSnapshot): number {
    const body = probe.rootBody.toLowerCase();
    const extra = (probe.extraProbeBody || '').toLowerCase();
    const ont = (probe.ontProbeBody || '').trim();

    // If HiLink XML SesTokInfo is explicitly active, defer to standard Huawei HiLink adapter
    if (extra.includes('<sesinfo>') && extra.includes('<tokinfo>')) {
      return 0;
    }

    let score = 0;
    if (body.includes('hg8145x6')) score += 90;
    if (body.includes('optixstar') || body.includes('hg8145')) score += 65;
    if (body.includes('dztelcom')) score += 45;
    if (body.includes('getrandcount.asp') || body.includes('x_hw_token') || body.includes('hwonttoken')) {
      score += 55;
    }
    if (cleanRandToken(ont)) score += 75;
    return score;
  },

  async connect(ctx: RouterConnectionContext): Promise<void> {
    const [ontToken, rootRes] = await Promise.all([
      fetchOntRandToken(ctx),
      ctx.transport({ method: 'GET', path: '/' }).catch(() => null)
    ]);

    if (ontToken) {
      ctx.sessionState.subprotocol = 'ont-asp';
      return;
    }

    if (rootRes && rootRes.status >= 200 && rootRes.status < 400) {
      const lower = rootRes.body.toLowerCase();
      if (
        lower.includes('optixstar') ||
        lower.includes('hg8145') ||
        lower.includes('login.cgi') ||
        lower.includes('x_hw_token') ||
        lower.includes('hwonttoken')
      ) {
        ctx.sessionState.subprotocol = 'ont-asp';
        const hidden = extractOntHiddenToken(rootRes.body);
        if (hidden) ctx.sessionState.hwToken = hidden;
        return;
      }
    }

    throw new RouterError(
      'UNSUPPORTED_MODEL',
      'Huawei OptiXstar HG8145X6-10 ONT ASP/CGI authentication interface did not respond'
    );
  },

  async authenticate(ctx: RouterConnectionContext, creds: RouterCredentials): Promise<void> {
    const username = creds.username.trim() || 'admin';
    const randToken = await fetchOntRandToken(ctx);
    const encodedPass = utf8ToBase64(creds.password);

    const formBody = new URLSearchParams({
      UserName: username,
      PassWord: encodedPass,
      Language: 'english',
      'x.X_HW_Token': randToken
    }).toString();

    const loginRes = await ctx.transport({
      method: 'POST',
      path: '/login.cgi',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: formBody
    });

    if (detectOntAuthRejection(loginRes.status, loginRes.body)) {
      throw new RouterError('INVALID_CREDENTIALS', 'HG8145X6-10 /login.cgi rejected credentials');
    }

    const nextHidden = extractOntHiddenToken(loginRes.body);
    if (nextHidden) {
      ctx.sessionState.hwToken = nextHidden;
    } else {
      await fetchOntRandToken(ctx).catch(() => '');
    }

    // Confirm valid authenticated session by probing a protected ONT endpoint
    const sessionProbe = await ctx
      .transport({ method: 'GET', path: '/html/ssmp/devinfo/devinfo.asp' })
      .catch(() => null);
    if (sessionProbe && detectOntSessionExpired(sessionProbe.status, sessionProbe.body)) {
      throw new RouterError('INVALID_CREDENTIALS', 'HG8145X6-10 did not establish a valid session cookie');
    }
    ctx.sessionState.subprotocol = 'ont-asp';
  },

  async getRouterInfo(ctx: RouterConnectionContext): Promise<RouterInfo> {
    const [devRes, wanRes] = await Promise.all([
      ctx.transport({ method: 'GET', path: '/html/ssmp/devinfo/devinfo.asp' }),
      ctx.transport({ method: 'GET', path: '/html/bbsp/waninfo/waninfo.asp' }).catch(() => null)
    ]);

    if (detectOntSessionExpired(devRes.status, devRes.body)) {
      throw new RouterError('SESSION_EXPIRED');
    }

    const modelMatch =
      devRes.body.match(/(?:ModelName|ProductName)\s*[:=]\s*["']([^"']+)["']/i) ||
      devRes.body.match(/new\s+stDevInfo\s*\([^)]*"([^"]*HG8145[^"]*)"/i);
    const swMatch = devRes.body.match(/(?:SoftwareVersion|SoftVer)\s*[:=]\s*["']([^"']+)["']/i);
    const hwMatch = devRes.body.match(/(?:HardwareVersion|HardVer|BoardVersion|PCBVersion)\s*[:=]\s*["']([^"']+)["']/i);
    const vendorMatch = devRes.body.match(/(?:Manufacturer|VendorName)\s*[:=]\s*["']([^"']+)["']/i);
    const rxPowerMatch = devRes.body.match(/(?:RxPower|OpticalPower|RSSI)\s*[:=]\s*["']?(-?\d+(?:\.\d+)?)\s*(?:dBm)?/i);
    const speedMatch = devRes.body.match(/(?:MaxBitRate|DownstreamRate|LinkRate)\s*[:=]\s*["']?(\d+(?:\.\d+)?)\s*(?:Mbps)?/i);

    const wanBody = (wanRes?.body || '').toLowerCase();
    const wanConnected =
      wanRes && !detectOntSessionExpired(wanRes.status, wanRes.body) && wanRes.status < 400
        ? wanBody.includes('connected') && !wanBody.includes('disconnected')
          ? true
          : wanBody.includes('disconnected')
          ? false
          : null
        : null;

    const parsedRssi = rxPowerMatch ? Math.round(Number(rxPowerMatch[1])) : null;
    const parsedLinkSpeed = speedMatch ? Math.round(Number(speedMatch[1])) : null;
    const devType =
      devRes.body.match(/(?:DeviceType)\s*[:=]\s*["']([^"']+)["']/i)?.[1]?.trim() ||
      (/gpon|ont/i.test(devRes.body) ? 'GPON ONT' : null);

    // Strictly return only actually parsed values — never fabricate model/firmware/hardware!
    return {
      vendor: vendorMatch?.[1]?.trim() || 'Huawei',
      model: modelMatch?.[1]?.trim() || null,
      firmwareVersion: swMatch?.[1]?.trim() || null,
      hardwareVersion: hwMatch?.[1]?.trim() || null,
      deviceType: devType,
      gatewayIp: new URL(ctx.baseUrl).hostname,
      wanConnected,
      uptimeSeconds: parseOntUptimeSeconds(devRes.body),
      signalStrengthDbm: parsedRssi !== null && Number.isFinite(parsedRssi) ? parsedRssi : null,
      linkSpeedMbps: parsedLinkSpeed !== null && Number.isFinite(parsedLinkSpeed) ? parsedLinkSpeed : null,
      channelCongestionScore: null
    };
  },

  async getWifiSettings(ctx: RouterConnectionContext): Promise<WifiSettings> {
    const wlanRes = await ctx.transport({ method: 'GET', path: '/html/amp/wlaninfo/wlaninfo.asp' });
    if (detectOntSessionExpired(wlanRes.status, wlanRes.body)) {
      throw new RouterError('SESSION_EXPIRED');
    }
    const parsed = parseOntWlanEntries(wlanRes.body);
    if (parsed.band24 || parsed.band5) return parsed;

    const basicRes = await ctx.transport({ method: 'GET', path: '/html/amp/wlanbasic/WlanBasic.asp' }).catch(() => null);
    if (basicRes && detectOntSessionExpired(basicRes.status, basicRes.body)) {
      throw new RouterError('SESSION_EXPIRED');
    }
    if (basicRes && basicRes.status < 400) {
      return parseOntWlanEntries(basicRes.body);
    }
    return { band24: null, band5: null };
  },

  async updateWifiSettings(ctx: RouterConnectionContext, update: WifiUpdateInput): Promise<void> {
    const token = await fetchOntRandToken(ctx);
    const wlanInst =
      update.band === '5GHz'
        ? 'InternetGatewayDevice.LANDevice.1.WLANConfiguration.5'
        : 'InternetGatewayDevice.LANDevice.1.WLANConfiguration.1';

    const form = new URLSearchParams({
      'x.Enable': update.enabled === false ? '0' : '1',
      'x.SSID': update.ssid,
      'x.BeaconType': update.encryption === 'OPEN' ? 'Basic' : update.encryption === 'WPA3-SAE' ? 'WPA3-SAE' : '11i',
      'x.X_HW_Token': token
    });
    if (update.password !== undefined) {
      form.set('y.PreSharedKey', update.password);
    }
    if (update.channel && update.channel !== 'Auto') {
      form.set('x.Channel', update.channel);
    }

    const res = await ctx.transport({
      method: 'POST',
      path: `/html/amp/wlanbasic/set.cgi?x=${encodeURIComponent(wlanInst)}&y=${encodeURIComponent(`${wlanInst}.PreSharedKey.1`)}`,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: form.toString()
    });

    if (detectOntSessionExpired(res.status, res.body)) {
      throw new RouterError('SESSION_EXPIRED');
    }
    if (res.status >= 400 || detectOntAuthRejection(res.status, res.body)) {
      throw new RouterError('SETTINGS_APPLY_FAILED', 'HG8145X6-10 rejected Wi-Fi configuration payload');
    }

    // Confirm change really applied on the modem (no silent failure)
    const verify = await this.getWifiSettings(ctx);
    const verifiedBand = update.band === '5GHz' ? verify.band5 : verify.band24;
    if (!verifiedBand || verifiedBand.ssid !== update.ssid) {
      throw new RouterError(
        'SETTINGS_APPLY_FAILED',
        'Router did not confirm updated Wi-Fi SSID on verification read-back'
      );
    }
  },

  async getConnectedDevices(ctx: RouterConnectionContext) {
    const [lanRes, macRes] = await Promise.all([
      ctx.transport({ method: 'GET', path: '/html/bbsp/common/GetLanUserDevInfo.asp' }),
      ctx.transport({ method: 'GET', path: '/html/bbsp/macfilter/macfilter.asp' }).catch(() => null)
    ]);
    if (detectOntSessionExpired(lanRes.status, lanRes.body)) {
      throw new RouterError('SESSION_EXPIRED');
    }

    const blockedSet = new Set<string>();
    if (macRes && macRes.status < 400 && !detectOntSessionExpired(macRes.status, macRes.body)) {
      const matches = macRes.body.match(/([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}/g) || [];
      matches.forEach((m) => blockedSet.add(normalizeMac(m)));
    }
    const connected = parseOntLanDevices(lanRes.body, blockedSet);
    return { connected, blockedMacs: Array.from(blockedSet) };
  },

  async blockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const mac = normalizeMac(macAddress);
    const token = await fetchOntRandToken(ctx);
    const res = await ctx.transport({
      method: 'POST',
      path: '/html/bbsp/macfilter/add.cgi?x=InternetGatewayDevice.X_HW_Security.MacFilter',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        'x.SourceMACAddress': mac,
        'x.X_HW_Token': token
      }).toString()
    });
    if (detectOntSessionExpired(res.status, res.body)) {
      throw new RouterError('SESSION_EXPIRED');
    }
    if (res.status >= 400 || detectOntAuthRejection(res.status, res.body)) {
      throw new RouterError('SETTINGS_APPLY_FAILED', 'HG8145X6-10 MAC filter block rejected');
    }

    const check = await this.getConnectedDevices(ctx);
    if (!check.blockedMacs.includes(mac)) {
      throw new RouterError('SETTINGS_APPLY_FAILED', 'Router MAC ACL read-back did not confirm device block');
    }
  },

  async unblockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const mac = normalizeMac(macAddress);
    const token = await fetchOntRandToken(ctx);
    const res = await ctx.transport({
      method: 'POST',
      path: '/html/bbsp/macfilter/del.cgi',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        'x.SourceMACAddress': mac,
        'x.X_HW_Token': token
      }).toString()
    });
    if (detectOntSessionExpired(res.status, res.body)) {
      throw new RouterError('SESSION_EXPIRED');
    }
    if (res.status >= 400 || detectOntAuthRejection(res.status, res.body)) {
      throw new RouterError('SETTINGS_APPLY_FAILED', 'HG8145X6-10 MAC filter unblock rejected');
    }

    const check = await this.getConnectedDevices(ctx);
    if (check.blockedMacs.includes(mac)) {
      throw new RouterError('SETTINGS_APPLY_FAILED', 'Router MAC ACL read-back still lists device as blocked');
    }
  },

  async rebootRouter(ctx: RouterConnectionContext): Promise<void> {
    const token = await fetchOntRandToken(ctx);
    const res = await ctx.transport({
      method: 'POST',
      path: '/html/ssmp/reset/set.cgi?x=InternetGatewayDevice.X_HW_DEBUG.SMP.DM.ResetBoard',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ 'x.X_HW_Token': token }).toString()
    });
    if (detectOntSessionExpired(res.status, res.body)) {
      throw new RouterError('SESSION_EXPIRED');
    }
    if (res.status >= 400 || detectOntAuthRejection(res.status, res.body)) {
      throw new RouterError('SETTINGS_APPLY_FAILED', 'HG8145X6-10 reboot command rejected');
    }
  },

  async getGuestWifiEnabled(ctx: RouterConnectionContext): Promise<boolean | null> {
    const res = await ctx.transport({ method: 'GET', path: '/html/amp/wlanbasic/WlanGuest.asp' }).catch(() => null);
    if (!res || res.status >= 400 || detectOntSessionExpired(res.status, res.body)) return null;
    const m = res.body.match(/guestWifiEnable\s*[:=]\s*["']?([01])/i);
    return m ? m[1] === '1' : null;
  },

  async setGuestWifiEnabled(ctx: RouterConnectionContext, enabled: boolean): Promise<void> {
    const probe = await ctx.transport({ method: 'GET', path: '/html/amp/wlanbasic/WlanGuest.asp' }).catch(() => null);
    if (!probe) {
      throw new RouterError('UNSUPPORTED_MODEL', 'Guest Wi-Fi endpoint is not exposed on this ONT firmware');
    }
    if (detectOntSessionExpired(probe.status, probe.body)) {
      throw new RouterError('SESSION_EXPIRED');
    }
    if (probe.status === 404 || !probe.body.toLowerCase().includes('guest')) {
      throw new RouterError('UNSUPPORTED_MODEL', 'Guest Wi-Fi endpoint is not exposed on this ONT firmware');
    }

    const token = await fetchOntRandToken(ctx);
    const res = await ctx.transport({
      method: 'POST',
      path: '/html/amp/wlanbasic/set.cgi?x=InternetGatewayDevice.LANDevice.1.WLANConfiguration.2',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        'x.Enable': enabled ? '1' : '0',
        'x.X_HW_Token': token
      }).toString()
    });
    if (detectOntSessionExpired(res.status, res.body)) {
      throw new RouterError('SESSION_EXPIRED');
    }
    if (res.status >= 400 || detectOntAuthRejection(res.status, res.body)) {
      throw new RouterError('SETTINGS_APPLY_FAILED', 'HG8145X6-10 guest Wi-Fi toggle rejected');
    }

    const verified = await this.getGuestWifiEnabled?.(ctx);
    if (verified !== null && verified !== enabled) {
      throw new RouterError('SETTINGS_APPLY_FAILED', 'Guest Wi-Fi state did not update on verification read-back');
    }
  },

  async getInternetAccessPaused(): Promise<boolean | null> {
    return null;
  },

  async setInternetAccessPaused(): Promise<void> {
    throw new RouterError('UNSUPPORTED_MODEL', 'WAN internet pause is not exposed on Huawei OptiXstar HG8145X6-10');
  },

  async disconnect(ctx: RouterConnectionContext): Promise<void> {
    const token = ctx.sessionState.hwToken || '';
    await ctx
      .transport({
        method: 'POST',
        path: '/logout.cgi',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: token ? new URLSearchParams({ 'x.X_HW_Token': token }).toString() : ''
      })
      .catch(() => undefined);
  }
};
