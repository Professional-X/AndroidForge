import React, { useMemo, useState } from 'react';
import { Ban, CheckCircle2, RefreshCw, Router, Search } from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { useApp } from '../context/AppContext';
import { useI18n } from '../i18n';
import { ConnectedDevice, RouterError } from '../router-adapters/types';
import { getEffectiveCapabilities } from '../services/routerConnection';
import { normalizeMac } from '../utils/networkSecurity';

type DeviceFilter = 'all' | 'known' | 'unknown' | 'new' | 'blocked';
type DeviceSort = 'name' | 'ip' | 'status';

export const Devices: React.FC = () => {
  const {
    routerSession,
    refreshRouter,
    blockDevice,
    unblockDevice,
    deviceAliases,
    seenMacs,
    saveDeviceAlias,
    setPage
  } = useApp();
  const { t } = useI18n();

  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<DeviceFilter>('all');
  const [sortBy, setSortBy] = useState<DeviceSort>('name');
  const [selectedMac, setSelectedMac] = useState<string | null>(null);
  const [customNameInput, setCustomNameInput] = useState('');
  const [blockTarget, setBlockTarget] = useState<ConnectedDevice | null>(null);
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const devicesList = useMemo(() => {
    if (!routerSession) return [];
    const merged: ConnectedDevice[] = [...routerSession.devices];
    const presentMacs = new Set(merged.map((d) => normalizeMac(d.macAddress)));

    // Include blocked MACs from router ACL that are currently offline
    for (const blockedMac of routerSession.blockedMacs) {
      const norm = normalizeMac(blockedMac);
      if (!presentMacs.has(norm)) {
        merged.push({
          id: norm,
          hostname: norm,
          ipAddress: '—',
          macAddress: norm,
          vendor: null,
          connectionType: 'Unknown',
          lastSeen: null,
          status: 'blocked'
        });
      }
    }

    const q = searchQuery.trim().toLowerCase();
    return merged
      .filter((d) => {
        const mac = normalizeMac(d.macAddress);
        const alias = deviceAliases[mac];
        const trust = alias?.trustStatus ?? 'unknown';
        const isNew = !seenMacs.has(mac);

        if (filter === 'blocked' && d.status !== 'blocked') return false;
        if (filter === 'known' && trust !== 'known') return false;
        if (filter === 'unknown' && trust !== 'unknown') return false;
        if (filter === 'new' && !isNew) return false;

        if (!q) return true;
        const displayName = (alias?.customName || d.hostname).toLowerCase();
        return (
          displayName.includes(q) ||
          d.ipAddress.toLowerCase().includes(q) ||
          mac.toLowerCase().includes(q) ||
          (d.vendor || '').toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        if (sortBy === 'ip') return a.ipAddress.localeCompare(b.ipAddress, undefined, { numeric: true });
        if (sortBy === 'status') return a.status.localeCompare(b.status);
        const nameA = deviceAliases[normalizeMac(a.macAddress)]?.customName || a.hostname;
        const nameB = deviceAliases[normalizeMac(b.macAddress)]?.customName || b.hostname;
        return nameA.localeCompare(nameB);
      });
  }, [routerSession, searchQuery, filter, sortBy, deviceAliases, seenMacs]);

  if (!routerSession) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-[#102B49] dark:text-[#EAF1F8]">{t('devices.title')}</h1>
        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-8 text-center space-y-4">
          <p className="text-sm text-[#526A84] dark:text-[#93ACC6]">{t('devices.requiresConnection')}</p>
          <button
            type="button"
            onClick={() => setPage('router-connection')}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-sm font-medium"
          >
            <Router className="w-4 h-4" aria-hidden="true" />
            <span>{t('nav.routerConnection')}</span>
          </button>
        </div>
      </div>
    );
  }

  const selectedDevice = devicesList.find((d) => normalizeMac(d.macAddress) === selectedMac) ?? null;
  const canBlock = getEffectiveCapabilities(routerSession).blockMacDevice;

  const handleSelectDevice = (d: ConnectedDevice) => {
    const mac = normalizeMac(d.macAddress);
    setSelectedMac(mac);
    setCustomNameInput(deviceAliases[mac]?.customName || d.hostname);
    setFeedback(null);
  };

  const handleSaveName = async (d: ConnectedDevice, trustStatus?: 'known' | 'unknown') => {
    const mac = normalizeMac(d.macAddress);
    const currentTrust = trustStatus ?? deviceAliases[mac]?.trustStatus ?? 'known';
    const nameToSave = customNameInput.trim() || d.hostname || mac;
    await saveDeviceAlias(mac, nameToSave, currentTrust);
  };

  const handleConfirmBlock = async () => {
    if (!blockTarget) return;
    setBusy(true);
    setFeedback(null);
    try {
      await blockDevice(blockTarget.macAddress);
      setBlockTarget(null);
      setFeedback({ type: 'success', text: t('devices.blockSuccess') });
    } catch (err) {
      setBlockTarget(null);
      const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
      setFeedback({ type: 'error', text: t(`router.errors.${code}`) });
    } finally {
      setBusy(false);
    }
  };

  const handleUnblock = async (d: ConnectedDevice) => {
    setBusy(true);
    setFeedback(null);
    try {
      await unblockDevice(d.macAddress);
      setFeedback({ type: 'success', text: t('devices.unblockSuccess') });
    } catch (err) {
      const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
      setFeedback({ type: 'error', text: t(`router.errors.${code}`) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#102B49] dark:text-[#EAF1F8] tracking-tight">
            {t('devices.title')}
          </h1>
          <p className="text-sm text-[#526A84] dark:text-[#93ACC6] mt-1">{t('devices.description')}</p>
        </div>
        <button
          type="button"
          onClick={() => void refreshRouter()}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] text-sm font-medium text-[#102B49] dark:text-[#EAF1F8] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44] whitespace-nowrap shrink-0"
        >
          <RefreshCw className="w-4 h-4" aria-hidden="true" />
          <span>{t('app.refresh')}</span>
        </button>
      </div>

      {feedback && (
        <div
          className={`p-4 rounded-xl text-sm border ${
            feedback.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
              : 'bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-800 text-red-800 dark:text-red-200'
          }`}
        >
          {feedback.text}
        </div>
      )}

      {/* Search, Filter & Sort Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-[#526A84] absolute inset-y-0 start-3.5 my-auto pointer-events-none" aria-hidden="true" />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('devices.searchPlaceholder')}
            aria-label={t('app.search')}
            className="w-full ps-10 pe-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#112033] text-sm text-[#102B49] dark:text-[#EAF1F8] focus:outline-none focus:ring-2 focus:ring-[#3989C9]"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex flex-wrap items-center gap-1 p-1 rounded-xl bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F]">
            {(
              [
                ['all', 'devices.filterAll'],
                ['known', 'devices.filterKnown'],
                ['unknown', 'devices.filterUnknown'],
                ['new', 'devices.filterNew'],
                ['blocked', 'devices.filterBlocked']
              ] as Array<[DeviceFilter, string]>
            ).map(([id, key]) => (
              <button
                key={id}
                type="button"
                onClick={() => setFilter(id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                  filter === id
                    ? 'bg-[#174C78] text-white'
                    : 'text-[#526A84] dark:text-[#93ACC6] hover:text-[#102B49] dark:hover:text-white'
                }`}
              >
                {t(key)}
              </button>
            ))}
          </div>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as DeviceSort)}
            aria-label={t('devices.sortBy')}
            className="px-3.5 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#112033] text-xs font-medium text-[#102B49] dark:text-[#EAF1F8]"
          >
            <option value="name">{t('devices.sortName')}</option>
            <option value="ip">{t('devices.sortIp')}</option>
            <option value="status">{t('devices.sortStatus')}</option>
          </select>
        </div>
      </div>

      {/* Devices Grid + Selected Inspector */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl overflow-hidden">
          {devicesList.length === 0 ? (
            <p className="p-8 text-center text-sm text-[#526A84] dark:text-[#93ACC6]">
              {t('devices.noDevicesFound')}
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-[#F4F7FB] dark:bg-[#0B1522] text-xs text-[#526A84] dark:text-[#93ACC6]">
                  <tr>
                    <th className="px-4 py-3 text-start font-medium">{t('devices.deviceName')}</th>
                    <th className="px-4 py-3 text-start font-medium">{t('devices.ipAddress')}</th>
                    <th className="px-4 py-3 text-start font-medium">{t('devices.macAddress')}</th>
                    <th className="px-4 py-3 text-start font-medium">{t('devices.connectionType')}</th>
                    <th className="px-4 py-3 text-start font-medium">{t('devices.status')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#DCE5F0] dark:divide-[#1F354F]">
                  {devicesList.map((d) => {
                    const mac = normalizeMac(d.macAddress);
                    const alias = deviceAliases[mac];
                    const isSelected = selectedMac === mac;
                    const trust = alias?.trustStatus ?? 'unknown';
                    const isNew = !seenMacs.has(mac);

                    return (
                      <tr
                        key={mac}
                        onClick={() => handleSelectDevice(d)}
                        className={`cursor-pointer transition-colors ${
                          isSelected
                            ? 'bg-[#F4F7FB] dark:bg-[#172B42]'
                            : 'hover:bg-[#F4F7FB]/60 dark:hover:bg-[#172B42]/40'
                        }`}
                      >
                        <td className="px-4 py-3">
                          <div className="font-medium text-[#102B49] dark:text-[#EAF1F8]">
                            {alias?.customName || d.hostname}
                          </div>
                          <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">
                            {d.vendor || t('app.unknown')} · {trust === 'known' ? t('devices.statusKnown') : t('devices.statusUnknown')}
                            {isNew ? ` · ${t('devices.statusNew')}` : ''}
                          </div>
                        </td>
                        <td className="px-4 py-3 font-mono-tabular text-xs text-[#102B49] dark:text-[#EAF1F8]">
                          {d.ipAddress || '—'}
                        </td>
                        <td className="px-4 py-3 font-mono-tabular text-xs text-[#526A84] dark:text-[#93ACC6]">
                          {mac}
                        </td>
                        <td className="px-4 py-3 text-xs text-[#526A84] dark:text-[#93ACC6]">
                          {d.connectionType}
                        </td>
                        <td className="px-4 py-3 text-xs font-medium whitespace-nowrap">
                          <span
                            className={
                              d.status === 'blocked'
                                ? 'text-red-600 dark:text-red-400'
                                : d.status === 'offline'
                                ? 'text-[#526A84] dark:text-[#93ACC6]'
                                : 'text-emerald-600 dark:text-emerald-400'
                            }
                          >
                            {d.status === 'blocked'
                              ? t('devices.statusBlocked')
                              : d.status === 'offline'
                              ? t('devices.statusOffline')
                              : t('devices.statusOnline')}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Selected Device Details & Actions Panel */}
        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-5 h-fit">
          {!selectedDevice ? (
            <p className="text-sm text-[#526A84] dark:text-[#93ACC6] text-center py-8">
              {t('devices.description')}
            </p>
          ) : (
            <>
              <div className="space-y-1 border-b border-[#DCE5F0] dark:border-[#1F354F] pb-4">
                <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                  {deviceAliases[normalizeMac(selectedDevice.macAddress)]?.customName || selectedDevice.hostname}
                </h2>
                <div className="text-xs font-mono-tabular text-[#526A84] dark:text-[#93ACC6]">
                  {selectedDevice.ipAddress || '—'} · {normalizeMac(selectedDevice.macAddress)}
                </div>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between gap-2">
                  <span className="text-[#526A84] dark:text-[#93ACC6]">{t('devices.vendor')}</span>
                  <span className="font-medium text-[#102B49] dark:text-[#EAF1F8]">
                    {selectedDevice.vendor || t('app.unknown')}
                  </span>
                </div>
                <div className="flex justify-between gap-2">
                  <span className="text-[#526A84] dark:text-[#93ACC6]">{t('devices.connectionType')}</span>
                  <span className="font-medium text-[#102B49] dark:text-[#EAF1F8]">
                    {selectedDevice.connectionType}
                  </span>
                </div>
                <div className="flex justify-between gap-2">
                  <span className="text-[#526A84] dark:text-[#93ACC6]">{t('devices.lastSeen')}</span>
                  <span className="font-mono-tabular text-[#102B49] dark:text-[#EAF1F8]">
                    {selectedDevice.lastSeen || t('app.unavailable')}
                  </span>
                </div>
              </div>

              {/* Custom Device Name */}
              <div className="space-y-2 pt-2 border-t border-[#DCE5F0] dark:border-[#1F354F]">
                <label htmlFor="custom-device-name" className="block text-xs font-medium text-[#102B49] dark:text-[#EAF1F8]">
                  {t('devices.customNameLabel')}
                </label>
                <div className="flex gap-2">
                  <input
                    id="custom-device-name"
                    type="text"
                    value={customNameInput}
                    onChange={(e) => setCustomNameInput(e.target.value)}
                    maxLength={80}
                    className="flex-1 px-3 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-xs text-[#102B49] dark:text-[#EAF1F8]"
                  />
                  <button
                    type="button"
                    onClick={() => void handleSaveName(selectedDevice)}
                    className="px-3.5 py-2 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-xs font-medium whitespace-nowrap"
                  >
                    {t('devices.saveName')}
                  </button>
                </div>

                <div className="flex gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => void handleSaveName(selectedDevice, 'known')}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] text-xs font-medium text-[#102B49] dark:text-[#EAF1F8] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44]"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{t('devices.markKnown')}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleSaveName(selectedDevice, 'unknown')}
                    className="flex-1 px-3 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] text-xs font-medium text-[#526A84] dark:text-[#93ACC6] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44]"
                  >
                    {t('devices.markUnknown')}
                  </button>
                </div>
              </div>

              {/* Block / Unblock Control */}
              <div className="pt-3 border-t border-[#DCE5F0] dark:border-[#1F354F] space-y-2">
                {!canBlock ? (
                  <p className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('devices.blockUnsupported')}</p>
                ) : selectedDevice.status === 'blocked' ? (
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => void handleUnblock(selectedDevice)}
                    className="w-full px-4 py-2.5 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-sm font-medium transition-colors"
                  >
                    {t('devices.unblockDevice')}
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => setBlockTarget(selectedDevice)}
                    className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-medium transition-colors"
                  >
                    <Ban className="w-4 h-4" aria-hidden="true" />
                    <span>{t('devices.blockDevice')}</span>
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      </div>

      <ConfirmModal
        open={Boolean(blockTarget)}
        title={t('devices.blockConfirmTitle')}
        bodyText={t('devices.blockConfirmBody')}
        warningText={t('devices.macSpoofWarning')}
        summaryItems={
          blockTarget
            ? [
                {
                  label: t('devices.deviceName'),
                  value: deviceAliases[normalizeMac(blockTarget.macAddress)]?.customName || blockTarget.hostname
                },
                { label: t('devices.macAddress'), value: normalizeMac(blockTarget.macAddress) },
                { label: t('devices.ipAddress'), value: blockTarget.ipAddress || '—' }
              ]
            : []
        }
        confirmLabel={t('devices.blockDevice')}
        danger
        busy={busy}
        onConfirm={() => void handleConfirmBlock()}
        onCancel={() => setBlockTarget(null)}
      />
    </div>
  );
};
