import React, { useState } from 'react';
import { ShieldCheck, Wifi } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useI18n } from '../i18n';

export const Login: React.FC = () => {
  const { signInGoogle, setPage } = useApp();
  const { t } = useI18n();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGoogleSignIn = async () => {
    setBusy(true);
    setError(null);
    try {
      await signInGoogle();
    } catch {
      setError(t('login.loginError'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-[70vh] flex items-center justify-center py-8">
      <div className="w-full max-w-md bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-8 space-y-6">
        <div className="space-y-2 text-center">
          <div className="w-12 h-12 mx-auto rounded-2xl bg-[#102B49] flex items-center justify-center">
            <Wifi className="w-6 h-6 text-[#3989C9]" aria-hidden="true" />
          </div>
          <h1 className="text-xl font-bold text-[#102B49] dark:text-[#EAF1F8]">{t('login.title')}</h1>
          <p className="text-sm text-[#526A84] dark:text-[#93ACC6] leading-relaxed">{t('login.subtitle')}</p>
        </div>

        {error && (
          <div className="p-3.5 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300">
            {error}
          </div>
        )}

        <div className="space-y-3">
          <button
            type="button"
            onClick={() => void handleGoogleSignIn()}
            disabled={busy}
            className="w-full py-3 px-4 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-sm font-semibold transition-colors disabled:opacity-60"
          >
            {busy ? t('app.loading') : t('login.googleButton')}
          </button>

          <button
            type="button"
            onClick={() => setPage('router-connection')}
            className="w-full py-2.5 px-4 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] text-[#102B49] dark:text-[#EAF1F8] text-xs font-medium hover:bg-[#F4F7FB] dark:hover:bg-[#182C44] transition-colors"
          >
            {t('login.continueLocal')}
          </button>
        </div>

        <ul className="space-y-2 pt-4 border-t border-[#DCE5F0] dark:border-[#1F354F] text-xs text-[#526A84] dark:text-[#93ACC6]">
          {[t('login.securityBullet1'), t('login.securityBullet2'), t('login.securityBullet3')].map((bullet) => (
            <li key={bullet} className="flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-[#3989C9] shrink-0 mt-0.5" aria-hidden="true" />
              <span>{bullet}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
