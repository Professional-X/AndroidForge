import React, { useEffect, useState } from 'react';
import { Check, Copy, Eye, EyeOff, Router, Save } from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { useApp } from '../context/AppContext';
import { useI18n } from '../i18n';
import { RouterError, WifiBandConfig } from '../router-adapters/types';
import { getEffectiveCapabilities } from '../services/routerConnection';
import { validateSsid, validateWifiPassword } from '../utils/networkSecurity';

export const WiFiSettings: React.FC = () => {
  const { routerSession, updateWifi, setPage } = useApp();
  const { t } = useI18n();

  const [selectedBand, setSelectedBand] = useState<'2.4GHz' | '5GHz'>('2.4GHz');
  const [ssid, setSsid] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [enabled, setEnabled] = useState(true);
  const [encryption, setEncryption] = useState('WPA2-PSK');
  const [channel, setChannel] = useState('0');

  const [confirmOpen, setConfirmOpen] = useState(false);
  const [applying, setApplying] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [copied, setCopied] = useState(false);

  const activeBandConfig: WifiBandConfig | null = routerSession
    ? selectedBand === '5GHz'
      ? routerSession.wifiSettings.band5
      : routerSession.wifiSettings.band24
    : null;

  useEffect(() => {
    if (!routerSession) return;
    if (selectedBand === '5GHz' && !routerSession.wifiSettings.band5 && routerSession.wifiSettings.band24) {
      setSelectedBand('2.4GHz');
      return;
    }
    if (activeBandConfig) {
      setSsid(activeBandConfig.ssid);
      setPassword(activeBandConfig.password ?? '');
      setEnabled(activeBandConfig.enabled);
      setEncryption(activeBandConfig.encryption);
      setChannel(activeBandConfig.channel || '0');
    }
  }, [routerSession, selectedBand, activeBandConfig]);

  if (!routerSession) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-[#102B49] dark:text-[#EAF1F8]">{t('wifi.title')}</h1>
        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-8 text-center space-y-4">
          <p className="text-sm text-[#526A84] dark:text-[#93ACC6]">{t('wifi.requiresConnection')}</p>
          <button
            type="button"
            onClick={() => setPage('router-connection')}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-sm font-medium"
          >
            <Router className="w-4 h-4" aria-hidden="true" />
            <span>{t('nav.routerConnection')}</span>
          </button>
        </div>
      </div>
    );
  }

  const caps = getEffectiveCapabilities(routerSession);
  if (!caps.writeWifiSettings && !caps.readWifiSettings) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-[#102B49] dark:text-[#EAF1F8]">{t('wifi.title')}</h1>
        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 text-sm text-[#526A84] dark:text-[#93ACC6]">
          {t('wifi.readOnlyAdapter')}
        </div>
      </div>
    );
  }

  const hasChanges =
    activeBandConfig !== null &&
    (ssid !== activeBandConfig.ssid ||
      enabled !== activeBandConfig.enabled ||
      encryption !== activeBandConfig.encryption ||
      channel !== (activeBandConfig.channel || '0') ||
      (password !== '' && password !== (activeBandConfig.password ?? '')));

  const handleRequestSave = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    if (!validateSsid(ssid)) {
      setFeedback({ type: 'error', text: t('wifi.validationSsid') });
      return;
    }

    const passwordProvided = password.length > 0;
    if (passwordProvided && !validateWifiPassword(password, encryption)) {
      setFeedback({ type: 'error', text: t('wifi.validationPassword') });
      return;
    }

    if (!hasChanges) {
      setFeedback({ type: 'error', text: t('wifi.noPendingChanges') });
      return;
    }

    setConfirmOpen(true);
  };

  const handleConfirmApply = async () => {
    setApplying(true);
    setFeedback(null);
    try {
      await updateWifi({
        band: selectedBand,
        enabled: caps.toggleWifiRadio ? enabled : undefined,
        ssid: ssid.trim(),
        password: password.length > 0 ? password : undefined,
        encryption,
        channel: caps.readChannelInfo ? channel : undefined
      });
      setConfirmOpen(false);
      setFeedback({ type: 'success', text: t('wifi.applySuccess') });
    } catch (err) {
      setConfirmOpen(false);
      const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
      setFeedback({ type: 'error', text: `${t('wifi.applyError')}: ${t(`router.errors.${code}`)}` });
    } finally {
      setApplying(false);
    }
  };

  const handleCopyCredentials = async () => {
    try {
      const text = password ? `SSID: ${ssid}\nPassword: ${password}` : `SSID: ${ssid}`;
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Ignore clipboard failure
    }
  };

  const summaryItems = [
    { label: t('wifi.ssidLabel'), value: ssid },
    { label: t('wifi.encryptionLabel'), value: encryption },
    ...(password ? [{ label: t('wifi.passwordLabel'), value: '••••••••' }] : []),
    ...(caps.toggleWifiRadio ? [{ label: t('wifi.radioEnabled'), value: enabled ? t('app.on') : t('app.off') }] : []),
    ...(caps.readChannelInfo ? [{ label: t('wifi.channelLabel'), value: channel === '0' ? t('wifi.autoChannel') : channel }] : [])
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-[#102B49] dark:text-[#EAF1F8] tracking-tight">
          {t('wifi.title')}
        </h1>
        <p className="text-sm text-[#526A84] dark:text-[#93ACC6] mt-1">{t('wifi.description')}</p>
      </div>

      {/* Band Segmented Switcher (only bands exposed by adapter) */}
      <div className="inline-flex p-1 rounded-xl bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F]">
        {routerSession.wifiSettings.band24 && (
          <button
            type="button"
            onClick={() => setSelectedBand('2.4GHz')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
              selectedBand === '2.4GHz'
                ? 'bg-[#174C78] text-white'
                : 'text-[#526A84] dark:text-[#93ACC6] hover:text-[#102B49] dark:hover:text-white'
            }`}
          >
            {t('wifi.band24Tab')}
          </button>
        )}
        {routerSession.wifiSettings.band5 && (
          <button
            type="button"
            onClick={() => setSelectedBand('5GHz')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
              selectedBand === '5GHz'
                ? 'bg-[#174C78] text-white'
                : 'text-[#526A84] dark:text-[#93ACC6] hover:text-[#102B49] dark:hover:text-white'
            }`}
          >
            {t('wifi.band5Tab')}
          </button>
        )}
      </div>

      <form
        onSubmit={handleRequestSave}
        className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-5 max-w-3xl"
      >
        {feedback && (
          <div
            className={`p-4 rounded-xl text-sm border ${
              feedback.type === 'success'
                ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
                : 'bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-800 text-red-800 dark:text-red-200'
            }`}
          >
            {feedback.text}
          </div>
        )}

        <div className="space-y-1.5">
          <label htmlFor="wifi-ssid" className="block text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
            {t('wifi.ssidLabel')}
          </label>
          <input
            id="wifi-ssid"
            type="text"
            value={ssid}
            onChange={(e) => setSsid(e.target.value)}
            maxLength={32}
            disabled={!caps.writeWifiSettings}
            placeholder={t('wifi.ssidPlaceholder')}
            className="w-full px-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm text-[#102B49] dark:text-[#EAF1F8] focus:outline-none focus:ring-2 focus:ring-[#3989C9]"
          />
        </div>

        <div className="space-y-1.5">
          <label htmlFor="wifi-password" className="block text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
            {t('wifi.passwordLabel')}
          </label>
          <div className="relative">
            <input
              id="wifi-password"
              type={showPass ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              maxLength={63}
              disabled={!caps.writeWifiSettings || encryption === 'OPEN'}
              placeholder={t('wifi.passwordPlaceholder')}
              className="w-full pe-10 ps-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] focus:outline-none focus:ring-2 focus:ring-[#3989C9]"
            />
            <button
              type="button"
              onClick={() => setShowPass(!showPass)}
              aria-label={showPass ? t('wifi.hidePassword') : t('wifi.showPassword')}
              className="absolute inset-y-0 end-0 px-3 flex items-center text-[#526A84] hover:text-[#102B49] dark:hover:text-white"
            >
              {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          {!caps.readWifiPassword && (
            <p className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('wifi.passwordHiddenByRouter')}</p>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label htmlFor="wifi-enc" className="block text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
              {t('wifi.encryptionLabel')}
            </label>
            <select
              id="wifi-enc"
              value={encryption}
              onChange={(e) => setEncryption(e.target.value)}
              disabled={!caps.writeWifiSettings}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm text-[#102B49] dark:text-[#EAF1F8] focus:outline-none focus:ring-2 focus:ring-[#3989C9]"
            >
              {(caps.supportedEncryptions.length > 0 ? caps.supportedEncryptions : ['WPA2-PSK']).map((mode) => (
                <option key={mode} value={mode}>
                  {mode}
                </option>
              ))}
            </select>
          </div>

          {caps.readChannelInfo && (
            <div className="space-y-1.5">
              <label htmlFor="wifi-channel" className="block text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
                {t('wifi.channelLabel')}
              </label>
              <select
                id="wifi-channel"
                value={channel}
                onChange={(e) => setChannel(e.target.value)}
                disabled={!caps.writeWifiSettings}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] focus:outline-none focus:ring-2 focus:ring-[#3989C9]"
              >
                <option value="0">{t('wifi.autoChannel')}</option>
                {(selectedBand === '5GHz'
                  ? ['36', '40', '44', '48', '149', '153', '157', '161']
                  : ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11']
                ).map((ch) => (
                  <option key={ch} value={ch}>
                    {ch}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {caps.toggleWifiRadio && (
          <label className="flex items-center gap-3 cursor-pointer text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
            <input
              type="checkbox"
              checked={enabled}
              onChange={(e) => setEnabled(e.target.checked)}
              disabled={!caps.writeWifiSettings}
              className="w-4 h-4 rounded border-[#DCE5F0] text-[#174C78] focus:ring-[#3989C9]"
            />
            <span>{t('wifi.radioEnabled')}</span>
          </label>
        )}

        <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-[#DCE5F0] dark:border-[#1F354F]">
          <button
            type="button"
            onClick={() => void handleCopyCredentials()}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] text-sm font-medium text-[#102B49] dark:text-[#EAF1F8] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44] whitespace-nowrap"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? t('app.copied') : t('wifi.copyCredentials')}</span>
          </button>

          {caps.writeWifiSettings && (
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-sm font-medium transition-colors whitespace-nowrap"
            >
              <Save className="w-4 h-4" aria-hidden="true" />
              <span>{t('wifi.saveChanges')}</span>
            </button>
          )}
        </div>
      </form>

      <ConfirmModal
        open={confirmOpen}
        title={t('wifi.confirmTitle')}
        warningText={t('wifi.confirmWarning')}
        bodyText={t('wifi.confirmSummary')}
        summaryItems={summaryItems}
        confirmLabel={t('wifi.applyNow')}
        busy={applying}
        onConfirm={() => void handleConfirmApply()}
        onCancel={() => setConfirmOpen(false)}
      />
    </div>
  );
};
