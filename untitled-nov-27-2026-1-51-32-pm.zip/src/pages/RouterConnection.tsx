import React, { useEffect, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Copy,
  Download,
  ExternalLink,
  Eye,
  EyeOff,
  KeyRound,
  RefreshCw,
  RotateCcw,
  Router,
  ShieldCheck,
  Smartphone,
  Terminal,
  Trash2,
  WifiOff,
  XCircle
} from 'lucide-react';
import connectorScriptRaw from '../../local-connector/server.mjs?raw';
import { COMMON_ROUTER_GATEWAYS, HUAWEI_DEFAULT_GATEWAY } from '../core/fallbackManager';
import { useApp } from '../context/AppContext';
import { useI18n } from '../i18n';
import { nativeOpenExternalPortal } from '../native/androidBridge';
import { ROUTER_ADAPTERS } from '../router-adapters/registry';
import { ConnectionMethodId, MethodAttemptStatus, RouterAdapterId } from '../router-adapters/types';
import { registerRelayEnrollment, TransportMode } from '../services/routerConnection';
import { SimulationScenario } from '../simulation/huaweiSimulator';
import {
  clearSavedRouterCredentials,
  hasSavedRouterCredentials,
  loadEncryptedRouterCredentials,
  saveEncryptedRouterCredentials
} from '../utils/cryptoStore';
import { validateRouterAddress } from '../utils/networkSecurity';

type ModeSelection = 'auto_fallback' | TransportMode;

export const RouterConnection: React.FC = () => {
  const {
    isNativeAndroid,
    nativeEnv,
    refreshNativeEnvironment,
    simulationMode,
    setSimulationMode,
    simulationScenario,
    setSimulationScenario,
    triggerSimulatedSessionExpiry,
    routerSession,
    routerConnecting,
    routerError,
    clearRouterError,
    connectorHealth,
    refreshConnectorStatus,
    connectionDiagnostics,
    lanBridgeUrl,
    setLanBridgeUrl,
    refreshConnectionEnvironment,
    probeRouterConnection,
    connectRouterWithFallback,
    connectRouter,
    disconnectRouter,
    setPage
  } = useApp();
  const { t, language } = useI18n();

  const [modeSelection, setModeSelection] = useState<ModeSelection>('auto_fallback');
  const [routerAddress, setRouterAddress] = useState(HUAWEI_DEFAULT_GATEWAY);
  const [autoDiscoverGateways, setAutoDiscoverGateways] = useState(false);
  const [adapterId, setAdapterId] = useState<RouterAdapterId | 'auto'>('auto');
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [saveCreds, setSaveCreds] = useState(false);
  const [hasSaved, setHasSaved] = useState(false);
  const [noticeKey, setNoticeKey] = useState<string | null>(null);
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [relayEnrollment, setRelayEnrollment] = useState<{
    agentId: string;
    relayToken: string;
    expiresAtIso: string;
  } | null>(null);
  const [copiedRelay, setCopiedRelay] = useState(false);

  const onlineNow = typeof navigator !== 'undefined' ? navigator.onLine : true;
  const localeStr = language === 'ar' ? 'ar-EG' : language === 'fr' ? 'fr-FR' : 'en-US';

  const formatTime = (iso?: string | null) => {
    if (!iso) return '--';
    try {
      return new Intl.DateTimeFormat(localeStr, {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      }).format(new Date(iso));
    } catch {
      return iso;
    }
  };

  useEffect(() => {
    void hasSavedRouterCredentials().then(setHasSaved);
    if (!isNativeAndroid) {
      void refreshConnectorStatus();
    }
    void refreshConnectionEnvironment();
  }, [isNativeAndroid, refreshConnectorStatus, refreshConnectionEnvironment]);

  const handleLoadSaved = async () => {
    const saved = await loadEncryptedRouterCredentials();
    if (saved) {
      setRouterAddress(saved.routerUrl);
      setAdapterId((saved.adapterId as RouterAdapterId | 'auto') || 'auto');
      setUsername(saved.username);
      setPassword(saved.password);
      setSaveCreds(true);
    }
  };

  const handleDeleteSaved = async () => {
    await clearSavedRouterCredentials();
    setHasSaved(false);
    setPassword('');
    setNoticeKey('router.deletedSavedNotice');
  };

  const handleConnect = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setNoticeKey(null);
    clearRouterError();

    const validated = validateRouterAddress(routerAddress);
    if (!validated.valid) {
      setNoticeKey('router.errors.INVALID_ROUTER_ADDRESS');
      return;
    }

    let connectedOk = false;

    if (!isNativeAndroid && (modeSelection === 'simulation' || simulationMode)) {
      connectedOk = await connectRouter({
        rawAddress: routerAddress,
        preferredAdapterId: adapterId === 'auto' ? 'huawei-hg8145x6-10' : adapterId,
        credentials: { username, password },
        transportMode: 'simulation',
        simulationScenario
      });
    } else if (isNativeAndroid) {
      if (modeSelection === 'auto_fallback') {
        const result = await connectRouterWithFallback({
          rawAddress: routerAddress,
          autoDiscoverGateways,
          preferredAdapterId: adapterId,
          credentials: { username, password }
        });
        connectedOk = result.ok;
      } else {
        connectedOk = await connectRouter({
          rawAddress: routerAddress,
          preferredAdapterId: adapterId,
          credentials: { username, password },
          transportMode: 'native_bridge'
        });
      }
    } else if (modeSelection === 'auto_fallback') {
      const result = await connectRouterWithFallback({
        rawAddress: routerAddress,
        autoDiscoverGateways,
        preferredAdapterId: adapterId,
        credentials: { username, password },
        lanBridgeUrl
      });
      connectedOk = result.ok;
    } else {
      connectedOk = await connectRouter({
        rawAddress: routerAddress,
        preferredAdapterId: adapterId,
        credentials: { username, password },
        transportMode: modeSelection
      });
    }

    if (connectedOk) {
      if (saveCreds) {
        await saveEncryptedRouterCredentials({
          routerUrl: validated.normalizedUrl,
          adapterId,
          username,
          password,
          savedAt: new Date().toISOString()
        });
        setHasSaved(true);
      }
      setPage('dashboard');
    }
  };

  const handleProbeConnection = async () => {
    setNoticeKey(null);
    clearRouterError();
    const validated = validateRouterAddress(routerAddress);
    if (!validated.valid) {
      setNoticeKey('router.errors.INVALID_ROUTER_ADDRESS');
      return;
    }
    await probeRouterConnection({
      rawAddress: routerAddress,
      autoDiscoverGateways,
      lanBridgeUrl
    });
  };

  const handleEnrollRelay = async () => {
    const res = await registerRelayEnrollment('LAN Relay Companion', routerAddress);
    if (res) {
      setRelayEnrollment(res);
    }
  };

  const handleDownloadConnector = () => {
    const blob = new Blob([connectorScriptRaw], { type: 'text/javascript;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'server.mjs';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopyCmd = async () => {
    try {
      await navigator.clipboard.writeText(t('router.connectorCommand'));
      setCopiedCmd(true);
      setTimeout(() => setCopiedCmd(false), 1800);
    } catch {
      // Ignore clipboard failure
    }
  };

  const handleCopyRelay = async () => {
    if (!relayEnrollment) return;
    try {
      await navigator.clipboard.writeText(
        `AGENT_ID=${relayEnrollment.agentId} RELAY_TOKEN=${relayEnrollment.relayToken}`
      );
      setCopiedRelay(true);
      setTimeout(() => setCopiedRelay(false), 1800);
    } catch {
      // Ignore clipboard failure
    }
  };

  const renderMethodStatus = (status: MethodAttemptStatus) => {
    if (status === 'succeeded') {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400">
          <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>{t('router.statuses.succeeded')}</span>
        </span>
      );
    }
    if (status === 'failed') {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-red-600 dark:text-red-400">
          <XCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>{t('router.statuses.failed')}</span>
        </span>
      );
    }
    if (status === 'skipped') {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 dark:text-amber-400">
          <AlertTriangle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>{t('router.statuses.skipped')}</span>
        </span>
      );
    }
    return (
      <span className="text-xs text-[#526A84] dark:text-[#93ACC6]">
        {t('router.statuses.not_tested')}
      </span>
    );
  };

  const renderMethodName = (methodId: ConnectionMethodId) => {
    return t(`router.methods.${methodId}`);
  };

  const showAndroidLastResort =
    !isNativeAndroid &&
    !routerSession &&
    connectionDiagnostics.state === 'failed' &&
    connectionDiagnostics.authState !== 'rejected' &&
    connectionDiagnostics.methodResults.some(
      (r) => r.methodId === 'android_companion' && r.status === 'failed'
    );

  const safeGatewayHref = validateRouterAddress(routerAddress).valid
    ? validateRouterAddress(routerAddress).normalizedUrl
    : `http://${HUAWEI_DEFAULT_GATEWAY}`;

  const tokenStatusText = !connectionDiagnostics.coreSession
    ? t('router.tokenUnavailable')
    : connectionDiagnostics.coreSession.status === 'renewed'
    ? t('router.tokenRenewed')
    : connectionDiagnostics.coreSession.status === 'revoked'
    ? t('router.tokenRevoked')
    : t('router.tokenActive');

  return (
    <div className="space-y-6">
      {/* Page Title & Action Strip */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#102B49] dark:text-[#EAF1F8] tracking-tight">
            {t('router.title')}
          </h1>
          <p className="text-sm text-[#526A84] dark:text-[#93ACC6] mt-1">
            {t('router.description')}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => void handleProbeConnection()}
            disabled={routerConnecting}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#112033] text-xs font-medium text-[#102B49] dark:text-[#EAF1F8] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44] transition-colors disabled:opacity-60 whitespace-nowrap"
          >
            <Activity className="w-3.5 h-3.5 text-[#3989C9]" aria-hidden="true" />
            <span>{t('router.checkConnectionButton')}</span>
          </button>

          <button
            type="button"
            onClick={() => void handleConnect()}
            disabled={routerConnecting}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#112033] text-xs font-medium text-[#102B49] dark:text-[#EAF1F8] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44] transition-colors disabled:opacity-60 whitespace-nowrap"
          >
            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{t('router.retryButton')}</span>
          </button>

          {routerSession && (
            <button
              type="button"
              onClick={() => void disconnectRouter()}
              className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-medium transition-colors whitespace-nowrap"
            >
              {t('router.disconnectButton')}
            </button>
          )}
        </div>
      </div>

      {/* Connection Center Overview KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-1.5">
          <div className="text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
            {t('router.connectionStatusLabel')}
          </div>
          <div
            className={`text-base font-semibold ${
              routerSession || connectionDiagnostics.state === 'connected'
                ? 'text-emerald-700 dark:text-emerald-400'
                : connectionDiagnostics.state === 'failed' ||
                  connectionDiagnostics.state === 'login_failed' ||
                  connectionDiagnostics.state === 'data_read_failed'
                ? 'text-red-600 dark:text-red-400'
                : connectionDiagnostics.state === 'modem_reachable' ||
                  connectionDiagnostics.state === 'authenticated'
                ? 'text-[#174C78] dark:text-[#6BB3EB]'
                : 'text-[#102B49] dark:text-[#EAF1F8]'
            }`}
          >
            {routerSession
              ? t('router.statuses.connected')
              : t(`router.statuses.${connectionDiagnostics.state}`)}
          </div>
          <div className="text-xs text-[#526A84] dark:text-[#93ACC6] font-mono-tabular">
            {routerSession ? routerSession.routerInfo.gatewayIp : connectionDiagnostics.targetGateway}
          </div>
        </div>

        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-1.5">
          <div className="text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
            {t('router.activeMethodLabel')}
          </div>
          <div className="text-sm font-semibold text-[#102B49] dark:text-[#EAF1F8] truncate">
            {routerSession
              ? renderMethodName(routerSession.connectionMethod)
              : connectionDiagnostics.activeMethod
              ? renderMethodName(connectionDiagnostics.activeMethod)
              : isNativeAndroid
              ? renderMethodName('android_native_bridge')
              : t('app.unavailable')}
          </div>
          <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">
            {t('router.authStateLabel')}:{' '}
            <span className="font-medium text-[#102B49] dark:text-[#EAF1F8]">
              {t(`router.statuses.${connectionDiagnostics.authState}`)}
            </span>
          </div>
        </div>

        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-1.5">
          <div className="text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
            {t('router.latencyLabel')}
          </div>
          <div className="text-base font-semibold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8]">
            {connectionDiagnostics.lastLatencyMs !== null
              ? `${connectionDiagnostics.lastLatencyMs} ms`
              : '--'}
          </div>
          <div className="text-xs text-[#526A84] dark:text-[#93ACC6] truncate">
            {t('router.serverTopologyLabel')}:{' '}
            {connectionDiagnostics.serverTopology === 'local-lan'
              ? t('router.topologyLocalLan')
              : connectionDiagnostics.serverTopology === 'cloud-hosted'
              ? t('router.topologyCloudHosted')
              : t('app.unknown')}
          </div>
        </div>

        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-1.5">
          <div className="text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
            {isNativeAndroid ? t('router.nativeBannerTitle') : t('router.coreSessionLabel')}
          </div>
          <div className="text-sm font-semibold text-[#102B49] dark:text-[#EAF1F8] flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-[#3989C9] shrink-0" aria-hidden="true" />
            <span className="truncate">
              {isNativeAndroid ? t('router.nativeDirectBadge') : tokenStatusText}
            </span>
          </div>
          <div className="text-xs text-[#526A84] dark:text-[#93ACC6] flex items-center gap-1.5">
            {!onlineNow && <WifiOff className="w-3.5 h-3.5 text-amber-600 shrink-0" aria-hidden="true" />}
            <span className="truncate">
              {onlineNow ? t('router.offlineLanReady') : t('router.lanOffline')}
            </span>
          </div>
        </div>
      </div>

      {/* Main Connection Form + Bridges Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <form
          onSubmit={(e) => void handleConnect(e)}
          className="lg:col-span-2 bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-5"
        >
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-[#DCE5F0] dark:border-[#1F354F]">
            <span className="text-xs font-medium text-[#174C78] dark:text-[#6BB3EB] font-mono-tabular">
              {t('router.targetHardwareBadge')}
            </span>
            <span className="text-xs text-[#526A84] dark:text-[#93ACC6]">
              {isNativeAndroid
                ? t('router.nativeDirectBadge')
                : connectorHealth.reachable && connectorHealth.authVerified
                ? t('router.connectorRunning')
                : t('router.connectorStopped')}
            </span>
          </div>

          {routerSession && (
            <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
              <div className="text-sm text-emerald-900 dark:text-emerald-200 font-medium">
                {t('dashboard.connectedTo')}: {routerSession.routerInfo.vendor} {routerSession.routerInfo.model ?? t('app.unavailable')} ({routerSession.routerInfo.gatewayIp}) · {renderMethodName(routerSession.connectionMethod)}
              </div>
            </div>
          )}

          {(routerError || noticeKey) && (
            <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800/60 text-sm text-red-800 dark:text-red-200">
              {routerError ? t(`router.errors.${routerError}`) : noticeKey ? t(noticeKey) : ''}
            </div>
          )}

          {hasSaved && (
            <div className="p-4 rounded-xl bg-[#F4F7FB] dark:bg-[#0B1522] border border-[#DCE5F0] dark:border-[#1F354F] flex flex-wrap items-center justify-between gap-3">
              <span className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('router.savedNotice')}</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => void handleLoadSaved()}
                  className="px-3 py-1.5 rounded-lg bg-[#174C78] hover:bg-[#102B49] text-white text-xs font-medium whitespace-nowrap"
                >
                  {t('router.useSavedButton')}
                </button>
                <button
                  type="button"
                  onClick={() => void handleDeleteSaved()}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-red-300 dark:border-red-800 text-red-700 dark:text-red-300 text-xs font-medium hover:bg-red-50 dark:hover:bg-red-950/40 whitespace-nowrap"
                >
                  <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{t('router.deleteSavedButton')}</span>
                </button>
              </div>
            </div>
          )}

          {isNativeAndroid && (
            <div className="p-4 rounded-xl bg-[#EAF3FB] dark:bg-[#172B42] border border-[#3989C9]/40 space-y-2.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-[#102B49] dark:text-white">
                  <Smartphone className="w-4 h-4 text-[#174C78] dark:text-[#6BB3EB]" aria-hidden="true" />
                  <span>{t('router.nativeBannerTitle')}</span>
                </div>
                <button
                  type="button"
                  onClick={() => void refreshNativeEnvironment()}
                  className="p-1.5 rounded-lg border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#112033] text-[#526A84] hover:text-[#102B49] dark:hover:text-white"
                  aria-label={t('app.refresh')}
                >
                  <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
                </button>
              </div>
              <p className="text-xs text-[#526A84] dark:text-[#C6D6E7] leading-relaxed">
                {t('router.nativeBannerBody')}
              </p>
              <div className="flex flex-wrap items-center gap-4 text-xs text-[#102B49] dark:text-[#EAF1F8]">
                <span>
                  {t('router.nativeSsidLabel')}:{' '}
                  <strong className="font-mono-tabular">
                    {nativeEnv?.wifiConnected ? nativeEnv.ssid || 'Wi-Fi' : t('router.nativeWifiDisconnected')}
                  </strong>
                </span>
                <span>
                  {t('router.nativeGatewayLabel')}:{' '}
                  <strong className="font-mono-tabular">
                    {nativeEnv?.gatewayIp || HUAWEI_DEFAULT_GATEWAY}
                  </strong>
                </span>
                {nativeEnv?.gatewayIp && (
                  <button
                    type="button"
                    onClick={() => setRouterAddress(nativeEnv.gatewayIp!)}
                    className="px-2.5 py-1 rounded-lg bg-[#174C78] hover:bg-[#102B49] text-white text-[11px] font-medium"
                  >
                    {t('router.nativeUseGatewayBtn')}
                  </button>
                )}
              </div>
            </div>
          )}

          {!isNativeAndroid && (
            <div className="p-4 rounded-xl bg-[#F4F7FB] dark:bg-[#0B1522] border border-[#DCE5F0] dark:border-[#1F354F] space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <label className="flex items-center gap-2.5 cursor-pointer text-xs font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                  <input
                    type="checkbox"
                    checked={simulationMode}
                    onChange={(e) => {
                      const next = e.target.checked;
                      setSimulationMode(next);
                      if (next) {
                        setModeSelection('simulation');
                        if (!password) setPassword('admin');
                      } else if (modeSelection === 'simulation') {
                        setModeSelection('auto_fallback');
                      }
                    }}
                    className="w-4 h-4 rounded border-[#DCE5F0] text-[#174C78] focus:ring-[#3989C9]"
                  />
                  <span>{t('router.simulationToggle')}</span>
                </label>
                {routerSession?.transportMode === 'simulation' && (
                  <button
                    type="button"
                    onClick={() => void triggerSimulatedSessionExpiry()}
                    className="px-2.5 py-1 rounded-lg border border-amber-400 dark:border-amber-700 text-amber-800 dark:text-amber-300 text-[11px] font-medium hover:bg-amber-100 dark:hover:bg-amber-950/40"
                  >
                    {t('router.simulationExpireBtn')}
                  </button>
                )}
              </div>
              <p className="text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed">
                {t('router.simulationBody')} {t('router.simulationHint')}
              </p>
              {simulationMode && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div className="space-y-1">
                    <label htmlFor="sim-scenario" className="block text-[11px] font-medium text-[#526A84] dark:text-[#93ACC6]">
                      {t('router.simulationScenarioLabel')}
                    </label>
                    <select
                      id="sim-scenario"
                      value={simulationScenario}
                      onChange={(e) => setSimulationScenario(e.target.value as SimulationScenario)}
                      className="w-full px-3 py-2 rounded-lg border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#112033] text-xs text-[#102B49] dark:text-[#EAF1F8]"
                    >
                      <option value="normal">{t('router.simulationScenarios.normal')}</option>
                      <option value="invalid_credentials">{t('router.simulationScenarios.invalid_credentials')}</option>
                      <option value="session_expired">{t('router.simulationScenarios.session_expired')}</option>
                    </select>
                  </div>
                  <div className="flex items-end">
                    <button
                      type="button"
                      onClick={() => void handleConnect()}
                      disabled={routerConnecting}
                      className="w-full px-3.5 py-2 rounded-lg bg-[#174C78] hover:bg-[#102B49] text-white text-xs font-medium transition-colors"
                    >
                      {t('router.simulationConnectBtn')}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Connection Mode Selector */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
              {t('router.connectionMode')}
            </label>
            <div className={`grid grid-cols-1 ${isNativeAndroid ? 'sm:grid-cols-2' : 'sm:grid-cols-3'} gap-3`}>
              {(isNativeAndroid
                ? (['auto_fallback', 'native_bridge'] as const)
                : (['auto_fallback', 'direct', 'connector'] as const)
              ).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => {
                    setSimulationMode(false);
                    setModeSelection(mode);
                  }}
                  className={`p-3 rounded-xl border text-start text-xs font-medium transition-colors ${
                    modeSelection === mode
                      ? 'border-[#174C78] dark:border-[#3989C9] bg-[#EAF3FB] dark:bg-[#172B42] text-[#102B49] dark:text-white'
                      : 'border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-[#526A84] dark:text-[#93ACC6]'
                  }`}
                >
                  {mode === 'auto_fallback'
                    ? isNativeAndroid
                      ? t('router.modeNativeBridge')
                      : t('router.modeAuto')
                    : mode === 'native_bridge'
                    ? t('router.nativeDirectBadge')
                    : mode === 'direct'
                    ? t('router.modeDirect')
                    : t('router.modeConnector')}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label htmlFor="router-ip" className="block text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
                {t('router.routerIpLabel')}
              </label>
              <input
                id="router-ip"
                type="text"
                value={routerAddress}
                onChange={(e) => setRouterAddress(e.target.value)}
                placeholder={HUAWEI_DEFAULT_GATEWAY}
                required
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] focus:outline-none focus:ring-2 focus:ring-[#3989C9]"
              />
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                <span className="text-[11px] text-[#526A84] dark:text-[#93ACC6] me-1">
                  {t('router.quickPresetsLabel')}:
                </span>
                {COMMON_ROUTER_GATEWAYS.map((gw) => (
                  <button
                    key={gw}
                    type="button"
                    onClick={() => setRouterAddress(gw)}
                    className={`px-2 py-0.5 rounded-md border text-[11px] font-mono-tabular transition-colors ${
                      routerAddress.trim() === gw
                        ? 'border-[#174C78] bg-[#EAF3FB] text-[#102B49] dark:border-[#3989C9] dark:bg-[#172B42] dark:text-white'
                        : 'border-[#DCE5F0] dark:border-[#1F354F] text-[#526A84] dark:text-[#93ACC6] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44]'
                    }`}
                  >
                    {gw}
                  </button>
                ))}
              </div>
              <p className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('router.routerIpHint')}</p>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="router-adapter" className="block text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
                {t('router.adapterLabel')}
              </label>
              <select
                id="router-adapter"
                value={adapterId}
                onChange={(e) => setAdapterId(e.target.value as RouterAdapterId | 'auto')}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm text-[#102B49] dark:text-[#EAF1F8] focus:outline-none focus:ring-2 focus:ring-[#3989C9]"
              >
                <option value="auto">{t('router.autoDetect')}</option>
                {ROUTER_ADAPTERS.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.id === 'huawei-hg8145x6-10'
                      ? 'Huawei OptiXstar HG8145X6-10 (GPON ONT · DZTELCOM)'
                      : a.id === 'huawei'
                      ? 'Huawei (HiLink / Generic ONT)'
                      : `${a.vendor} (${a.id})`}
                  </option>
                ))}
              </select>

              <label className="flex items-start gap-2 pt-2 cursor-pointer text-xs text-[#526A84] dark:text-[#93ACC6]">
                <input
                  type="checkbox"
                  checked={autoDiscoverGateways}
                  onChange={(e) => setAutoDiscoverGateways(e.target.checked)}
                  className="mt-0.5 w-3.5 h-3.5 rounded border-[#DCE5F0] text-[#174C78] focus:ring-[#3989C9]"
                />
                <span>{t('router.autoDiscoverLabel')}</span>
              </label>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label htmlFor="router-user" className="block text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
                {t('router.usernameLabel')}
              </label>
              <input
                id="router-user"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder={t('router.usernamePlaceholder')}
                autoComplete="username"
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm text-[#102B49] dark:text-[#EAF1F8] focus:outline-none focus:ring-2 focus:ring-[#3989C9]"
              />
            </div>

            <div className="space-y-1.5">
              <label htmlFor="router-pass" className="block text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
                {t('router.passwordLabel')}
              </label>
              <div className="relative">
                <input
                  id="router-pass"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={t('router.passwordPlaceholder')}
                  autoComplete="current-password"
                  className="w-full pe-10 ps-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm text-[#102B49] dark:text-[#EAF1F8] focus:outline-none focus:ring-2 focus:ring-[#3989C9]"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? t('wifi.hidePassword') : t('wifi.showPassword')}
                  className="absolute inset-y-0 end-0 px-3 flex items-center text-[#526A84] hover:text-[#102B49] dark:hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#F4F7FB] dark:bg-[#0B1522] border border-[#DCE5F0] dark:border-[#1F354F] space-y-1.5">
            <label className="flex items-center gap-2.5 cursor-pointer text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
              <input
                type="checkbox"
                checked={saveCreds}
                onChange={(e) => setSaveCreds(e.target.checked)}
                className="w-4 h-4 rounded border-[#DCE5F0] text-[#174C78] focus:ring-[#3989C9]"
              />
              <span>{t('router.saveCredentialsLabel')}</span>
            </label>
            <p className="text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed">
              {t('router.saveCredentialsNote')}
            </p>
          </div>

          {/* Collapsible Advanced Bridge & Cloud Relay Settings (Web browser only — never shown in Android APK) */}
          {!isNativeAndroid && (
            <div className="border border-[#DCE5F0] dark:border-[#1F354F] rounded-xl overflow-hidden">
              <button
                type="button"
                onClick={() => setShowAdvanced(!showAdvanced)}
                aria-expanded={showAdvanced}
                className="w-full px-4 py-3 bg-[#F4F7FB] dark:bg-[#0B1522] flex items-center justify-between text-xs font-medium text-[#102B49] dark:text-[#EAF1F8]"
              >
                <span>{t('router.advancedOptionsTitle')}</span>
                {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              {showAdvanced && (
                <div className="p-4 space-y-4 bg-white dark:bg-[#112033]">
                  <div className="space-y-1.5">
                    <label htmlFor="lan-bridge-url" className="block text-xs font-medium text-[#102B49] dark:text-[#EAF1F8]">
                      {t('router.lanBridgeLabel')}
                    </label>
                    <input
                      id="lan-bridge-url"
                      type="url"
                      value={lanBridgeUrl}
                      onChange={(e) => setLanBridgeUrl(e.target.value)}
                      placeholder="http://192.168.100.50:3000"
                      className="w-full px-3 py-2 rounded-lg border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-xs font-mono-tabular text-[#102B49] dark:text-[#EAF1F8]"
                    />
                    <p className="text-[11px] text-[#526A84] dark:text-[#93ACC6]">{t('router.lanBridgeHint')}</p>
                  </div>

                  <div className="pt-2 border-t border-[#DCE5F0] dark:border-[#1F354F] space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-xs font-medium text-[#102B49] dark:text-[#EAF1F8]">
                        {t('router.relaySetupTitle')}
                      </span>
                      <button
                        type="button"
                        onClick={() => void handleEnrollRelay()}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#DCE5F0] dark:border-[#1F354F] text-xs font-medium text-[#174C78] dark:text-[#6BB3EB] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44]"
                      >
                        <KeyRound className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>{t('router.relayEnrollButton')}</span>
                      </button>
                    </div>
                    {relayEnrollment && (
                      <div className="p-3 rounded-lg bg-[#0B1522] text-[#EAF1F8] text-[11px] space-y-1.5">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-mono-tabular truncate">Agent: {relayEnrollment.agentId}</span>
                          <button
                            type="button"
                            onClick={() => void handleCopyRelay()}
                            className="inline-flex items-center gap-1 px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-white"
                          >
                            {copiedRelay ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                            <span>{copiedRelay ? t('app.copied') : t('app.copy')}</span>
                          </button>
                        </div>
                        <p className="text-[#93ACC6]">{t('router.relayEnrolledNote')}</p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="flex flex-wrap items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => void handleProbeConnection()}
              disabled={routerConnecting}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] text-xs font-medium text-[#102B49] dark:text-[#EAF1F8] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44] transition-colors disabled:opacity-60 whitespace-nowrap"
            >
              <Activity className="w-4 h-4 text-[#3989C9]" aria-hidden="true" />
              <span>{t('router.checkConnectionButton')}</span>
            </button>

            <button
              type="submit"
              disabled={routerConnecting}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-sm font-medium transition-colors disabled:opacity-60 whitespace-nowrap"
            >
              <Router className="w-4 h-4" aria-hidden="true" />
              <span>
                {routerConnecting
                  ? t('app.loading')
                  : modeSelection === 'auto_fallback' && !isNativeAndroid
                  ? t('router.connectAutoButton')
                  : t('router.connectButton')}
              </span>
            </button>
          </div>
        </form>

        {/* Sidebar Context Card: Android Kotlin Runtime inside APK OR Optional Local Connector on Web */}
        {isNativeAndroid ? (
          <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                {t('router.nativeSidebarTitle')}
              </h2>
              <button
                type="button"
                onClick={() => void refreshNativeEnvironment()}
                aria-label={t('app.refresh')}
                className="p-1.5 rounded-lg border border-[#DCE5F0] dark:border-[#1F354F] text-[#526A84] hover:text-[#102B49] dark:hover:text-white"
              >
                <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            </div>

            <p className="text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed">
              {t('router.nativeSidebarBody')}
            </p>

            <div className="p-4 rounded-xl bg-[#F4F7FB] dark:bg-[#0B1522] border border-[#DCE5F0] dark:border-[#1F354F] space-y-2.5 text-xs">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[#526A84] dark:text-[#93ACC6]">{t('router.nativeSsidLabel')}</span>
                <span className="font-mono-tabular font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                  {nativeEnv?.wifiConnected ? nativeEnv.ssid || 'Wi-Fi' : t('router.nativeWifiDisconnected')}
                </span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-[#526A84] dark:text-[#93ACC6]">{t('router.nativeGatewayLabel')}</span>
                <span className="font-mono-tabular font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                  {nativeEnv?.gatewayIp || HUAWEI_DEFAULT_GATEWAY}
                </span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-[#526A84] dark:text-[#93ACC6]">{t('router.nativeLocalIpLabel')}</span>
                <span className="font-mono-tabular font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                  {nativeEnv?.localIp || '--'}
                </span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-[#526A84] dark:text-[#93ACC6]">{t('router.nativeLinkSpeedLabel')}</span>
                <span dir="ltr" className="font-mono-tabular font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                  {nativeEnv?.wifiLinkSpeedMbps ? `${nativeEnv.wifiLinkSpeedMbps} Mbps` : '--'}
                </span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-[#526A84] dark:text-[#93ACC6]">{t('router.nativeFreqLabel')}</span>
                <span dir="ltr" className="font-mono-tabular font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                  {nativeEnv?.wifiFrequencyMhz ? `${nativeEnv.wifiFrequencyMhz} MHz` : '--'}
                </span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-[#526A84] dark:text-[#93ACC6]">{t('router.nativeRssiLabel')}</span>
                <span dir="ltr" className="font-mono-tabular font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                  {nativeEnv?.wifiRssiDbm ? `${nativeEnv.wifiRssiDbm} dBm` : '--'}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => nativeOpenExternalPortal(safeGatewayHref)}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] text-xs font-medium text-[#102B49] dark:text-[#EAF1F8] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44] transition-colors whitespace-nowrap"
            >
              <ExternalLink className="w-4 h-4" aria-hidden="true" />
              <span>{t('router.openGatewayDirectly')}</span>
            </button>
          </div>
        ) : (
          <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                {t('router.connectorInstructionsTitle')}
              </h2>
              <button
                type="button"
                onClick={() => void refreshConnectorStatus()}
                aria-label={t('router.checkConnector')}
                className="p-1.5 rounded-lg border border-[#DCE5F0] dark:border-[#1F354F] text-[#526A84] hover:text-[#102B49] dark:hover:text-white"
              >
                <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            </div>

            <p className="text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed">
              {t('router.connectorInstructionsBody')}
            </p>

            <div className="p-3 rounded-xl bg-[#0B1522] text-[#EAF1F8] font-mono-tabular text-xs flex items-center justify-between gap-2">
              <code className="truncate">{t('router.connectorCommand')}</code>
              <button
                type="button"
                onClick={() => void handleCopyCmd()}
                aria-label={t('app.copy')}
                className="p-1.5 rounded-lg hover:bg-white/10 text-white shrink-0"
              >
                {copiedCmd ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            <div className="flex flex-col gap-2">
              <button
                type="button"
                onClick={() => setPage('local-connector')}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-xs font-medium transition-colors whitespace-nowrap"
              >
                <Terminal className="w-4 h-4" aria-hidden="true" />
                <span>{t('router.openConnectorSetup')}</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadConnector}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] text-xs font-medium text-[#102B49] dark:text-[#EAF1F8] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44] transition-colors whitespace-nowrap"
              >
                <Download className="w-4 h-4" aria-hidden="true" />
                <span>{t('router.downloadConnector')}</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Android Native Troubleshooting Card when local modem unreachable */}
      {isNativeAndroid && !routerSession && connectionDiagnostics.state === 'failed' && (
        <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <Smartphone className="w-5 h-5 text-amber-700 dark:text-amber-400 shrink-0 mt-0.5" aria-hidden="true" />
            <div className="space-y-1">
              <h2 className="text-sm font-semibold text-amber-950 dark:text-amber-200">
                {t('router.nativeTroubleshootTitle')}
              </h2>
              <p className="text-xs text-amber-900/90 dark:text-amber-300 leading-relaxed max-w-3xl">
                {t('router.nativeTroubleshootBody')}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => nativeOpenExternalPortal(safeGatewayHref)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-medium whitespace-nowrap shrink-0"
          >
            <span>{t('router.openGatewayDirectly')}</span>
            <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
          </button>
        </div>
      )}

      {/* Android Companion (Web-only Last Resort) Guidance Card */}
      {showAndroidLastResort && (
        <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <Smartphone className="w-5 h-5 text-amber-700 dark:text-amber-400 shrink-0 mt-0.5" aria-hidden="true" />
            <div className="space-y-1">
              <h2 className="text-sm font-semibold text-amber-950 dark:text-amber-200">
                {t('router.androidLastResortTitle')}
              </h2>
              <p className="text-xs text-amber-900/90 dark:text-amber-300 leading-relaxed max-w-3xl">
                {t('router.androidLastResortBody')}
              </p>
            </div>
          </div>
          <a
            href={safeGatewayHref}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-medium whitespace-nowrap shrink-0"
          >
            <span>{t('router.openGatewayDirectly')}</span>
            <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
          </a>
        </div>
      )}

      {/* Connection Pipeline Matrix */}
      <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-[#DCE5F0] dark:border-[#1F354F] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
              {isNativeAndroid ? t('router.nativeMethodsTitle') : t('router.methodsTitle')}
            </h2>
            <p className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-0.5">
              {isNativeAndroid ? t('router.nativeMethodsSubtitle') : t('router.methodsSubtitle')}
            </p>
          </div>
          {connectionDiagnostics.checkedAtIso && (
            <span className="text-xs text-[#526A84] dark:text-[#93ACC6] font-mono-tabular">
              {formatTime(connectionDiagnostics.checkedAtIso)}
            </span>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-start text-sm">
            <thead className="bg-[#F4F7FB] dark:bg-[#0B1522] text-xs text-[#526A84] dark:text-[#93ACC6]">
              <tr>
                <th className="px-5 py-3 text-start font-medium">{t('router.methodCol')}</th>
                <th className="px-5 py-3 text-start font-medium">{t('router.statusCol')}</th>
                <th className="px-5 py-3 text-start font-medium">{t('router.reasonCol')}</th>
                <th className="px-5 py-3 text-end font-medium">{t('router.latencyCol')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#DCE5F0] dark:divide-[#1F354F]">
              {connectionDiagnostics.methodResults.map((row) => (
                <tr key={row.methodId} className="hover:bg-[#F4F7FB]/60 dark:hover:bg-[#172B42]/50">
                  <td className="px-5 py-3 font-medium text-[#102B49] dark:text-[#EAF1F8] whitespace-nowrap">
                    {renderMethodName(row.methodId)}
                  </td>
                  <td className="px-5 py-3 whitespace-nowrap">
                    {renderMethodStatus(row.status)}
                  </td>
                  <td className="px-5 py-3 text-xs text-[#526A84] dark:text-[#93ACC6]">
                    {row.errorCode
                      ? t(`router.errors.${row.errorCode}`)
                      : row.technicalSummary || '--'}
                  </td>
                  <td className="px-5 py-3 text-end text-xs font-mono-tabular text-[#526A84] dark:text-[#93ACC6] whitespace-nowrap">
                    {row.status === 'not_tested' ? '--' : `${row.latencyMs} ms`}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Connection Attempts Log */}
      <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-[#DCE5F0] dark:border-[#1F354F]">
          <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
            {t('router.attemptsLogTitle')}
          </h2>
        </div>

        {connectionDiagnostics.attemptsLog.length === 0 ? (
          <div className="p-6 text-xs text-[#526A84] dark:text-[#93ACC6]">
            {t('router.noAttemptsYet')}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-start text-xs">
              <thead className="bg-[#F4F7FB] dark:bg-[#0B1522] text-[#526A84] dark:text-[#93ACC6]">
                <tr>
                  <th className="px-5 py-2.5 text-start font-medium">{t('activity.date')}</th>
                  <th className="px-5 py-2.5 text-start font-medium">{t('dashboard.routerIp')}</th>
                  <th className="px-5 py-2.5 text-start font-medium">{t('router.methodCol')}</th>
                  <th className="px-5 py-2.5 text-start font-medium">{t('router.statusCol')}</th>
                  <th className="px-5 py-2.5 text-start font-medium">{t('activity.details')}</th>
                  <th className="px-5 py-2.5 text-end font-medium">{t('router.latencyCol')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#DCE5F0] dark:divide-[#1F354F]">
                {connectionDiagnostics.attemptsLog.slice(0, 15).map((entry) => (
                  <tr key={entry.id} className="hover:bg-[#F4F7FB]/60 dark:hover:bg-[#172B42]/50">
                    <td className="px-5 py-2.5 font-mono-tabular text-[#526A84] dark:text-[#93ACC6] whitespace-nowrap">
                      {formatTime(entry.timestampIso)}
                    </td>
                    <td className="px-5 py-2.5 font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] whitespace-nowrap">
                      {entry.gatewayIp}
                    </td>
                    <td className="px-5 py-2.5 text-[#102B49] dark:text-[#EAF1F8] whitespace-nowrap">
                      {renderMethodName(entry.methodId)}
                    </td>
                    <td className="px-5 py-2.5 whitespace-nowrap">
                      {renderMethodStatus(entry.status)}
                    </td>
                    <td className="px-5 py-2.5 text-[#526A84] dark:text-[#93ACC6] truncate max-w-xs">
                      {entry.errorCode ? t(`router.errors.${entry.errorCode}`) : entry.detail}
                    </td>
                    <td className="px-5 py-2.5 text-end font-mono-tabular text-[#526A84] dark:text-[#93ACC6] whitespace-nowrap">
                      {entry.latencyMs} ms
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Router Adapters Registry Table */}
      <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-[#DCE5F0] dark:border-[#1F354F]">
          <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
            {t('router.supportedAdaptersTitle')}
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-start text-sm">
            <thead className="bg-[#F4F7FB] dark:bg-[#0B1522] text-xs text-[#526A84] dark:text-[#93ACC6]">
              <tr>
                <th className="px-5 py-3 text-start font-medium">{t('router.adapterLabel')}</th>
                <th className="px-5 py-3 text-start font-medium">{t('router.modelsLabel')}</th>
                <th className="px-5 py-3 text-start font-medium">{t('router.authLabel')}</th>
                <th className="px-5 py-3 text-start font-medium">{t('router.capabilitiesLabel')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#DCE5F0] dark:divide-[#1F354F]">
              {ROUTER_ADAPTERS.map((adapter) => (
                <tr key={adapter.id} className="hover:bg-[#F4F7FB]/60 dark:hover:bg-[#172B42]/50">
                  <td className="px-5 py-3.5 font-medium text-[#102B49] dark:text-[#EAF1F8] whitespace-nowrap">
                    {adapter.vendor}
                  </td>
                  <td className="px-5 py-3.5 text-xs text-[#526A84] dark:text-[#93ACC6]">
                    {adapter.supportedModels.join(' · ')}
                  </td>
                  <td className="px-5 py-3.5 text-xs text-[#526A84] dark:text-[#93ACC6]">
                    {adapter.authMethod}
                  </td>
                  <td className="px-5 py-3.5 text-xs font-mono-tabular text-[#102B49] dark:text-[#EAF1F8]">
                    {adapter.capabilities.writeWifiSettings
                      ? `${t('app.supported')} (Wi-Fi · MAC ACL)`
                      : t('app.unsupported')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
