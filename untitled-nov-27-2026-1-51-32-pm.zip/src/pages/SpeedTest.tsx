import React, { useRef, useState } from 'react';
import { CheckCircle2, Play, RotateCcw, Square } from 'lucide-react';
import { SpeedGauge } from '../components/SpeedGauge';
import { useApp } from '../context/AppContext';
import { useI18n } from '../i18n';
import {
  DOWNLOAD_PHASE_TARGET_MS,
  runLiveSpeedTest,
  SpeedTestPhase,
  SpeedTestProgress,
  UPLOAD_PHASE_TARGET_MS
} from '../services/speedTest';

const INITIAL_PROGRESS: SpeedTestProgress = {
  phase: 'idle',
  progressPct: 0,
  elapsedSec: 0,
  phaseElapsedSec: 0,
  phaseTargetSec: 0,
  liveMbps: 0,
  liveDownloadMbps: null,
  liveUploadMbps: null,
  pingMs: null,
  jitterMs: null,
  packetLossPct: null,
  downloadMbps: null,
  uploadMbps: null,
  bytesTransferred: 0,
  sampleCount: 0
};

const STAGE_ORDER: Array<{ id: Exclude<SpeedTestPhase, 'idle' | 'cancelled' | 'error'>; key: string }> = [
  { id: 'preparing', key: 'speed.steps.preparing' },
  { id: 'ping', key: 'speed.steps.ping' },
  { id: 'download', key: 'speed.steps.download' },
  { id: 'upload', key: 'speed.steps.upload' },
  { id: 'calculating', key: 'speed.steps.calculating' },
  { id: 'done', key: 'speed.steps.done' }
];

export const SpeedTest: React.FC = () => {
  const { speedHistory, latestSpeed, recordSpeedTest, routerSession, nativeEnv } = useApp();
  const { t, language } = useI18n();

  const [progress, setProgress] = useState<SpeedTestProgress>(INITIAL_PROGRESS);
  const [statusBanner, setStatusBanner] = useState<{ type: 'error' | 'info' | 'success'; text: string } | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const running =
    progress.phase === 'preparing' ||
    progress.phase === 'ping' ||
    progress.phase === 'download' ||
    progress.phase === 'upload' ||
    progress.phase === 'calculating';

  const startTest = async () => {
    if (running) return;
    setStatusBanner(null);
    setProgress({
      ...INITIAL_PROGRESS,
      phase: 'preparing',
      progressPct: 2
    });
    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const result = await runLiveSpeedTest((p) => setProgress(p), controller.signal);
      await recordSpeedTest(result);
      setStatusBanner({ type: 'success', text: t('speed.completedNotice') });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'SERVER_UNREACHABLE';
      if (msg === 'ABORTED') {
        setProgress((prev) => ({
          ...prev,
          phase: 'cancelled',
          liveMbps: 0
        }));
        setStatusBanner({ type: 'info', text: t('speed.errorCancelled') });
        return;
      }
      setProgress((prev) => ({ ...prev, phase: 'error', liveMbps: 0 }));
      setStatusBanner({
        type: 'error',
        text:
          msg === 'INTERNET_OFFLINE'
            ? t('speed.errorOffline')
            : msg === 'CONNECTION_DROPPED'
            ? t('speed.errorDropped')
            : t('speed.errorServer')
      });
    } finally {
      abortRef.current = null;
    }
  };

  const cancelTest = () => {
    if (!running || !abortRef.current) return;
    abortRef.current.abort();
  };

  const phaseText =
    progress.phase === 'preparing'
      ? t('speed.phasePreparing')
      : progress.phase === 'ping'
      ? t('speed.phasePing')
      : progress.phase === 'download'
      ? t('speed.phaseDownload')
      : progress.phase === 'upload'
      ? t('speed.phaseUpload')
      : progress.phase === 'calculating'
      ? t('speed.phaseCalculating')
      : progress.phase === 'done'
      ? t('speed.phaseDone')
      : progress.phase === 'cancelled'
      ? t('speed.phaseCancelled')
      : progress.phase === 'error'
      ? t('speed.phaseError')
      : t('speed.phaseIdle');

  const activeStageIndex = STAGE_ORDER.findIndex((s) => s.id === progress.phase);
  const transferredMb = (progress.bytesTransferred / (1024 * 1024)).toFixed(1);
  const totalMinSec = Math.round((DOWNLOAD_PHASE_TARGET_MS + UPLOAD_PHASE_TARGET_MS) / 1000);

  const chartPoints = [...speedHistory].slice(0, 10).reverse();
  const maxChartMbps = Math.max(20, ...chartPoints.map((p) => Math.max(p.downloadMbps, p.uploadMbps)));
  const localeStr = language === 'ar' ? 'ar-EG' : language === 'fr' ? 'fr-FR' : 'en-US';

  const displayDownload =
    progress.phase === 'done'
      ? progress.downloadMbps
      : running && progress.liveDownloadMbps !== null && progress.phase !== 'download'
      ? progress.liveDownloadMbps
      : null;

  const displayUpload = progress.phase === 'done' ? progress.uploadMbps : null;

  return (
    <div className="space-y-6">
      {/* Page Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#102B49] dark:text-[#EAF1F8] tracking-tight">
            {t('speed.title')}
          </h1>
          <p className="text-sm text-[#526A84] dark:text-[#93ACC6] mt-1">{t('speed.description')}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          {running && (
            <button
              type="button"
              onClick={cancelTest}
              className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl border border-red-300 dark:border-red-800 bg-white dark:bg-[#112033] text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-950/30 text-sm font-semibold transition-colors whitespace-nowrap"
            >
              <Square className="w-4 h-4" aria-hidden="true" />
              <span>{t('speed.cancelTest')}</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => void startTest()}
            disabled={running}
            className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-sm font-semibold transition-colors disabled:opacity-60 whitespace-nowrap"
          >
            {progress.phase === 'done' || progress.phase === 'cancelled' || progress.phase === 'error' ? (
              <RotateCcw className="w-4 h-4" aria-hidden="true" />
            ) : (
              <Play className="w-4 h-4" aria-hidden="true" />
            )}
            <span>
              {running
                ? t('speed.testing')
                : progress.phase === 'done' || progress.phase === 'cancelled' || progress.phase === 'error'
                ? t('speed.retest')
                : t('speed.startTest')}
            </span>
          </button>
        </div>
      </div>

      {/* Status Banner */}
      {statusBanner && (
        <div
          className={`p-4 rounded-xl border text-sm flex items-center gap-2.5 ${
            statusBanner.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
              : statusBanner.type === 'error'
              ? 'bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-800 text-red-800 dark:text-red-200'
              : 'bg-[#EAF3FB] dark:bg-[#172B42] border-[#3989C9]/40 text-[#102B49] dark:text-[#EAF1F8]'
          }`}
        >
          {statusBanner.type === 'success' && <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />}
          <span>{statusBanner.text}</span>
        </div>
      )}

      {/* 6-Stage Progress Pipeline + Timer + Data Usage */}
      <section className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="font-semibold text-[#102B49] dark:text-[#EAF1F8]">{phaseText}</div>
          <div className="flex flex-wrap items-center gap-4 font-mono-tabular text-[#526A84] dark:text-[#93ACC6]">
            <span>
              {t('speed.elapsedLabel')}: <strong className="text-[#102B49] dark:text-[#EAF1F8]">{progress.elapsedSec.toFixed(1)}s</strong>
              {progress.phaseTargetSec > 0 && ` (${progress.phaseElapsedSec.toFixed(1)}s / ${progress.phaseTargetSec.toFixed(0)}s)`}
            </span>
            <span>
              {t('speed.dataUsedLabel')}: <strong className="text-[#102B49] dark:text-[#EAF1F8]">{transferredMb} MB</strong>
            </span>
            <span>
              {t('speed.progressLabel')}: <strong className="text-[#102B49] dark:text-[#EAF1F8]">{progress.progressPct}%</strong>
            </span>
          </div>
        </div>

        <div className="w-full h-2 rounded-lg bg-[#E9EFF7] dark:bg-[#0B1522] overflow-hidden">
          <div
            className="h-full bg-[#174C78] dark:bg-[#3989C9] transition-[width] duration-200"
            style={{ width: `${Math.max(0, Math.min(100, progress.progressPct))}%` }}
          />
        </div>

        <ol className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2" aria-label={t('speed.progressLabel')}>
          {STAGE_ORDER.map((stage, idx) => {
            const isCompleted =
              progress.phase === 'done' || (activeStageIndex !== -1 && idx < activeStageIndex);
            const isActive = progress.phase === stage.id;
            return (
              <li
                key={stage.id}
                className={`px-3 py-2 rounded-xl border text-xs font-medium flex items-center gap-2 transition-colors ${
                  isActive
                    ? 'border-[#174C78] dark:border-[#3989C9] bg-[#EAF3FB] dark:bg-[#172B42] text-[#102B49] dark:text-white'
                    : isCompleted
                    ? 'border-emerald-200 dark:border-emerald-800/60 bg-emerald-50/70 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-300'
                    : 'border-[#DCE5F0] dark:border-[#1F354F] bg-[#F8FAFD] dark:bg-[#0B1522] text-[#526A84] dark:text-[#93ACC6]'
                }`}
              >
                <span className="font-mono-tabular text-[11px] opacity-80">{idx + 1}.</span>
                <span className="truncate">{t(stage.key)}</span>
              </li>
            );
          })}
        </ol>

        <p className="text-xs text-[#526A84] dark:text-[#93ACC6]">
          {t('speed.dataUsageNotice').replace('{seconds}', String(totalMinSec))}
        </p>
      </section>

      {/* Gauge + Live / Final Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 flex flex-col items-center justify-center">
          <SpeedGauge
            valueMbps={progress.liveMbps}
            maxScaleMbps={Math.max(100, Math.ceil((progress.liveMbps || 100) / 50) * 50)}
            label={
              progress.phase === 'upload'
                ? t('speed.upload')
                : progress.phase === 'download'
                ? t('speed.download')
                : t('speed.liveCurrentLabel')
            }
            phaseLabel={phaseText}
            active={running}
          />
          <div className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-2 text-center">
            {t('speed.serverLabel')}: {t('speed.serverCloudflare')}
          </div>
        </div>

        <div className="lg:col-span-2 grid grid-cols-2 sm:grid-cols-3 gap-4 content-start">
          <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5">
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('speed.download')}</div>
            <div className="text-2xl font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] mt-1">
              {displayDownload !== null ? displayDownload.toFixed(2) : '—'}
            </div>
            <div className="text-xs text-[#3989C9] mt-0.5">{t('speed.mbps')}</div>
          </div>

          <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5">
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('speed.upload')}</div>
            <div className="text-2xl font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] mt-1">
              {displayUpload !== null
                ? displayUpload.toFixed(2)
                : running && progress.phase === 'upload' && progress.liveUploadMbps !== null
                ? progress.liveUploadMbps.toFixed(2)
                : '—'}
            </div>
            <div className="text-xs text-[#3989C9] mt-0.5">{t('speed.mbps')}</div>
          </div>

          <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5">
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('speed.ping')}</div>
            <div className="text-2xl font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] mt-1">
              {progress.pingMs !== null ? progress.pingMs.toFixed(1) : '—'}
            </div>
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-0.5">{t('speed.ms')}</div>
          </div>

          <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5">
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('speed.jitter')}</div>
            <div className="text-2xl font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] mt-1">
              {progress.jitterMs !== null ? progress.jitterMs.toFixed(1) : '—'}
            </div>
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-0.5">{t('speed.ms')}</div>
          </div>

          <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 col-span-2 sm:col-span-2">
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('speed.packetLoss')}</div>
            <div className="text-2xl font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] mt-1">
              {progress.packetLossPct !== null ? `${progress.packetLossPct.toFixed(1)}%` : '—'}
            </div>
            <p className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-2 leading-relaxed">
              {t('speed.disclaimer')}
            </p>
          </div>
        </div>
      </div>

      {/* Honest Separation: External Internet vs. Modem Link Rate vs. Phone Wi-Fi Link */}
      <section className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-4">
        <h2 className="text-sm font-semibold text-[#102B49] dark:text-[#EAF1F8]">
          {t('speed.rateComparisonTitle')}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-[#F4F7FB] dark:bg-[#0B1522] border border-[#DCE5F0] dark:border-[#1F354F] space-y-1">
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('speed.externalTitle')}</div>
            <div className="text-base font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8]">
              {latestSpeed
                ? `${latestSpeed.downloadMbps.toFixed(1)} / ${latestSpeed.uploadMbps.toFixed(1)} ${t('speed.mbps')}`
                : t('app.notTested')}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#F4F7FB] dark:bg-[#0B1522] border border-[#DCE5F0] dark:border-[#1F354F] space-y-1">
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('speed.modemWanRateTitle')}</div>
            <div className="text-base font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8]">
              {routerSession?.routerInfo.linkSpeedMbps != null
                ? `${routerSession.routerInfo.linkSpeedMbps} ${t('speed.mbps')}`
                : t('app.unavailable')}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#F4F7FB] dark:bg-[#0B1522] border border-[#DCE5F0] dark:border-[#1F354F] space-y-1">
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('speed.phoneWifiRateTitle')}</div>
            <div className="text-base font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8]">
              {nativeEnv?.wifiLinkSpeedMbps != null
                ? `${nativeEnv.wifiLinkSpeedMbps} ${t('speed.mbps')}`
                : t('app.unavailable')}
            </div>
            {nativeEnv?.wifiFrequencyMhz != null && (
              <div className="text-[11px] font-mono-tabular text-[#526A84] dark:text-[#93ACC6]">
                {t('speed.phoneFreqLabel')}: {nativeEnv.wifiFrequencyMhz} MHz
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Trend Chart + History Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
              {t('speed.trendTitle')}
            </h2>
            <div className="flex items-center gap-4 text-xs text-[#526A84] dark:text-[#93ACC6]">
              <span className="inline-flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-[#174C78] dark:bg-[#6BB3EB] inline-block" aria-hidden="true" />
                {t('speed.download')}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-[#3989C9] inline-block" aria-hidden="true" />
                {t('speed.upload')}
              </span>
            </div>
          </div>

          {chartPoints.length === 0 ? (
            <p className="text-sm text-[#526A84] dark:text-[#93ACC6] py-8 text-center">
              {t('speed.noHistory')}
            </p>
          ) : (
            <svg viewBox="0 0 460 180" className="w-full h-44" role="img" aria-label={t('speed.trendTitle')}>
              {[0.25, 0.5, 0.75, 1].map((frac) => (
                <line
                  key={frac}
                  x1="36"
                  x2="444"
                  y1={150 - frac * 120}
                  y2={150 - frac * 120}
                  stroke="currentColor"
                  strokeDasharray="3 3"
                  className="text-[#DCE5F0] dark:text-[#1F354F]"
                />
              ))}
              {chartPoints.length > 1 && (
                <>
                  <polyline
                    fill="none"
                    stroke="#174C78"
                    strokeWidth="2.5"
                    points={chartPoints
                      .map((p, i) => {
                        const x = 36 + (i / (chartPoints.length - 1)) * 408;
                        const y = 150 - (p.downloadMbps / maxChartMbps) * 120;
                        return `${x},${y}`;
                      })
                      .join(' ')}
                  />
                  <polyline
                    fill="none"
                    stroke="#3989C9"
                    strokeWidth="2.5"
                    points={chartPoints
                      .map((p, i) => {
                        const x = 36 + (i / (chartPoints.length - 1)) * 408;
                        const y = 150 - (p.uploadMbps / maxChartMbps) * 120;
                        return `${x},${y}`;
                      })
                      .join(' ')}
                  />
                </>
              )}
              {chartPoints.map((p, i) => {
                const x = chartPoints.length === 1 ? 240 : 36 + (i / (chartPoints.length - 1)) * 408;
                const yd = 150 - (p.downloadMbps / maxChartMbps) * 120;
                const yu = 150 - (p.uploadMbps / maxChartMbps) * 120;
                return (
                  <g key={p.id}>
                    <circle cx={x} cy={yd} r="4" fill="#174C78" />
                    <circle cx={x} cy={yu} r="4" fill="#3989C9" />
                  </g>
                );
              })}
            </svg>
          )}
        </div>

        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-[#DCE5F0] dark:border-[#1F354F]">
            <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
              {t('speed.historyTitle')}
            </h2>
          </div>
          {speedHistory.length === 0 ? (
            <p className="text-sm text-[#526A84] dark:text-[#93ACC6] p-6">{t('speed.noHistory')}</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-[#F4F7FB] dark:bg-[#0B1522] text-xs text-[#526A84] dark:text-[#93ACC6]">
                  <tr>
                    <th className="px-4 py-2.5 text-start font-medium">{t('activity.date')}</th>
                    <th className="px-4 py-2.5 text-end font-medium">{t('speed.download')}</th>
                    <th className="px-4 py-2.5 text-end font-medium">{t('speed.upload')}</th>
                    <th className="px-4 py-2.5 text-end font-medium">{t('speed.ping')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#DCE5F0] dark:divide-[#1F354F] font-mono-tabular text-xs">
                  {speedHistory.slice(0, 8).map((row) => (
                    <tr key={row.id}>
                      <td className="px-4 py-2.5 text-[#526A84] dark:text-[#93ACC6]">
                        {new Intl.DateTimeFormat(localeStr, {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        }).format(new Date(row.measuredAtIso))}
                      </td>
                      <td className="px-4 py-2.5 text-end font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                        {row.downloadMbps.toFixed(1)} {t('speed.mbps')}
                      </td>
                      <td className="px-4 py-2.5 text-end text-[#102B49] dark:text-[#EAF1F8]">
                        {row.uploadMbps.toFixed(1)} {t('speed.mbps')}
                      </td>
                      <td className="px-4 py-2.5 text-end text-[#526A84] dark:text-[#93ACC6]">
                        {row.pingMs.toFixed(1)} {t('speed.ms')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
