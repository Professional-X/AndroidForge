import React from 'react';
import { AlertCircle, RefreshCw, Router } from 'lucide-react';
import { HomeMapDiagram } from '../components/HomeMapDiagram';
import { QuickActionsPanel } from '../components/QuickActionsPanel';
import { useApp } from '../context/AppContext';
import { useI18n } from '../i18n';

export const Dashboard: React.FC = () => {
  const {
    setPage,
    routerSession,
    refreshRouter,
    autoRefresh,
    setAutoRefresh,
    latestSpeed,
    activityLogs,
    diagnosticsReport,
    nativeEnv
  } = useApp();
  const { t, language } = useI18n();

  const localeStr = language === 'ar' ? 'ar-EG' : language === 'fr' ? 'fr-FR' : 'en-US';

  const formatUptime = (seconds?: number | null) => {
    if (typeof seconds !== 'number' || seconds < 0) return t('app.unavailable');
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    return `${hrs}h ${mins}m`;
  };

  const formatTime = (iso?: string | null) => {
    if (!iso) return t('app.never');
    try {
      return new Intl.DateTimeFormat(localeStr, {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      }).format(new Date(iso));
    } catch {
      return iso;
    }
  };

  const ssidDisplay =
    routerSession?.wifiSettings.band24?.ssid ||
    routerSession?.wifiSettings.band5?.ssid ||
    null;

  const activeDevicesCount = routerSession
    ? routerSession.devices.filter((d) => d.status === 'online').length
    : null;

  const wanConnected = routerSession?.routerInfo.wanConnected;

  return (
    <div className="space-y-6">
      {/* Header row with refresh controls */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#102B49] dark:text-[#EAF1F8] tracking-tight">
            {t('dashboard.title')}
          </h1>
          <p className="text-sm text-[#526A84] dark:text-[#93ACC6] mt-1">
            {t('dashboard.description')}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <span className="text-xs text-[#526A84] dark:text-[#93ACC6]">
            {t('app.lastUpdated')}:{' '}
            <span className="font-mono-tabular">{formatTime(routerSession?.lastUpdatedIso || latestSpeed?.measuredAtIso)}</span>
          </span>

          {routerSession && (
            <>
              <button
                type="button"
                onClick={() => setAutoRefresh(!autoRefresh)}
                aria-pressed={autoRefresh}
                className={`px-3 py-2 rounded-xl text-xs font-medium border transition-colors whitespace-nowrap ${
                  autoRefresh
                    ? 'bg-[#174C78] text-white border-[#174C78]'
                    : 'bg-white dark:bg-[#112033] text-[#102B49] dark:text-[#EAF1F8] border-[#DCE5F0] dark:border-[#1F354F]'
                }`}
              >
                {t('app.autoRefresh')}: {autoRefresh ? t('app.on') : t('app.off')}
              </button>

              <button
                type="button"
                onClick={() => void refreshRouter()}
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] text-xs font-medium text-[#102B49] dark:text-[#EAF1F8] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44] transition-colors whitespace-nowrap"
              >
                <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{t('app.refresh')}</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Router Disconnected Callout */}
      {!routerSession && (
        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
              {t('dashboard.connectBannerTitle')}
            </h2>
            <p className="text-sm text-[#526A84] dark:text-[#93ACC6] max-w-2xl">
              {t('dashboard.connectBannerBody')}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setPage('router-connection')}
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-sm font-medium transition-colors whitespace-nowrap shrink-0"
          >
            <Router className="w-4 h-4" aria-hidden="true" />
            <span>{t('dashboard.connectBannerCta')}</span>
          </button>
        </div>
      )}

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-2">
          <div className="text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
            {t('dashboard.routerStatus')}
          </div>
          <div className="text-lg font-semibold text-[#102B49] dark:text-[#EAF1F8] truncate">
            {routerSession
              ? `${routerSession.routerInfo.vendor} ${routerSession.routerInfo.model ?? t('app.unavailable')}`
              : t('app.notConnected')}
          </div>
          <div className="text-xs text-[#526A84] dark:text-[#93ACC6] truncate">
            {t('dashboard.routerIp')}:{' '}
            <span className="font-mono-tabular">
              {routerSession ? routerSession.routerInfo.gatewayIp : t('app.unavailable')}
            </span>
            {routerSession && ` · ${t(`router.methods.${routerSession.connectionMethod}`)}`}
          </div>
          {routerSession && (
            <div className="text-[11px] text-[#526A84] dark:text-[#93ACC6] font-mono-tabular truncate">
              {t('dashboard.firmwareLabel')}: {routerSession.routerInfo.firmwareVersion ?? t('app.unavailable')} ·{' '}
              {t('dashboard.hardwareLabel')}: {routerSession.routerInfo.hardwareVersion ?? t('app.unavailable')} ·{' '}
              {t('dashboard.uptimeLabel')}: {formatUptime(routerSession.routerInfo.uptimeSeconds)}
            </div>
          )}
        </div>

        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-2">
          <div className="text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
            {t('dashboard.wifiName')}
          </div>
          <div className="text-lg font-semibold text-[#102B49] dark:text-[#EAF1F8] truncate">
            {ssidDisplay || nativeEnv?.ssid || t('app.unavailable')}
          </div>
          <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">
            {t('dashboard.internetStatus')}:{' '}
            <span
              className={
                wanConnected === true
                  ? 'text-emerald-600 dark:text-emerald-400 font-medium'
                  : wanConnected === false
                  ? 'text-red-600 dark:text-red-400 font-medium'
                  : 'text-[#526A84] dark:text-[#93ACC6] font-medium'
              }
            >
              {wanConnected === true
                ? t('dashboard.internetOnline')
                : wanConnected === false
                ? t('dashboard.internetOffline')
                : t('dashboard.wanUnverified')}
            </span>
          </div>
        </div>

        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-2">
          <div className="text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
            {t('dashboard.downloadSpeed')} / {t('dashboard.uploadSpeed')}
          </div>
          {latestSpeed ? (
            <>
              <div className="text-lg font-semibold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8]">
                {latestSpeed.downloadMbps.toFixed(1)} / {latestSpeed.uploadMbps.toFixed(1)} {t('speed.mbps')}
              </div>
              <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">
                <span className="font-mono-tabular">Ping {latestSpeed.pingMs} {t('speed.ms')}</span> · {latestSpeed.serverName}
              </div>
            </>
          ) : (
            <>
              <div className="text-lg font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                {t('app.notTested')}
              </div>
              <button
                type="button"
                onClick={() => setPage('speed-test')}
                className="text-xs font-medium text-[#3989C9] hover:underline"
              >
                {t('dashboard.runSpeedTestHint')}
              </button>
            </>
          )}
        </div>

        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-2">
          <div className="text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
            {t('dashboard.connectedDevices')}
          </div>
          <div className={`text-lg font-semibold text-[#102B49] dark:text-[#EAF1F8] ${activeDevicesCount !== null ? 'font-mono-tabular' : ''}`}>
            {activeDevicesCount !== null ? activeDevicesCount : t('app.unavailable')}
          </div>
          <div className="text-xs text-[#526A84] dark:text-[#93ACC6] space-y-0.5">
            <div>
              {t('dashboard.signalQuality')}:{' '}
              <span className="font-mono-tabular">
                {routerSession?.routerInfo.signalStrengthDbm != null
                  ? `${routerSession.routerInfo.signalStrengthDbm} dBm`
                  : nativeEnv?.wifiRssiDbm != null
                  ? `${nativeEnv.wifiRssiDbm} dBm`
                  : t('app.unavailable')}
              </span>
            </div>
            {nativeEnv?.wifiConnected && (
              <div>
                {t('dashboard.phoneWifiLink')}:{' '}
                <span className="font-mono-tabular">
                  {nativeEnv.wifiLinkSpeedMbps != null ? `${nativeEnv.wifiLinkSpeedMbps} Mbps` : t('app.unavailable')}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Radio Bands & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-4">
          <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
            {t('dashboard.band24')} / {t('dashboard.band5')}
          </h2>

          <div className="divide-y divide-[#DCE5F0] dark:divide-[#1F354F]">
            <div className="py-3 flex items-center justify-between gap-4 text-sm">
              <span className="text-[#526A84] dark:text-[#93ACC6]">{t('dashboard.band24')}</span>
              <span className="font-medium text-[#102B49] dark:text-[#EAF1F8]">
                {routerSession?.wifiSettings.band24
                  ? `${routerSession.wifiSettings.band24.enabled ? t('dashboard.bandEnabled') : t('dashboard.bandDisabled')} · ${routerSession.wifiSettings.band24.ssid}`
                  : t('dashboard.bandUnsupported')}
              </span>
            </div>
            <div className="py-3 flex items-center justify-between gap-4 text-sm">
              <span className="text-[#526A84] dark:text-[#93ACC6]">{t('dashboard.band5')}</span>
              <span className="font-medium text-[#102B49] dark:text-[#EAF1F8]">
                {routerSession?.wifiSettings.band5
                  ? `${routerSession.wifiSettings.band5.enabled ? t('dashboard.bandEnabled') : t('dashboard.bandDisabled')} · ${routerSession.wifiSettings.band5.ssid}`
                  : t('dashboard.bandUnsupported')}
              </span>
            </div>
          </div>
        </div>

        <QuickActionsPanel />
      </div>

      {/* Home Map Connection Diagram */}
      <HomeMapDiagram />

      {/* Network Alerts & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
              {t('dashboard.networkAlerts')}
            </h2>
            <button
              type="button"
              onClick={() => setPage('diagnostics')}
              className="text-xs font-medium text-[#3989C9] hover:underline whitespace-nowrap"
            >
              {t('nav.diagnostics')}
            </button>
          </div>

          {diagnosticsReport.confirmed.length === 0 && diagnosticsReport.possible.length === 0 ? (
            <p className="text-sm text-[#526A84] dark:text-[#93ACC6] py-3">
              {t('dashboard.noAlerts')}
            </p>
          ) : (
            <div className="divide-y divide-[#DCE5F0] dark:divide-[#1F354F]">
              {[...diagnosticsReport.confirmed, ...diagnosticsReport.possible].slice(0, 4).map((alert) => (
                <div key={alert.id} className="py-3 flex items-start gap-3">
                  <AlertCircle
                    className={`w-4 h-4 mt-0.5 shrink-0 ${
                      alert.category === 'confirmed' ? 'text-red-600 dark:text-red-400' : 'text-amber-600 dark:text-amber-400'
                    }`}
                    aria-hidden="true"
                  />
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
                      {t(alert.titleKey)}
                    </div>
                    <div className="text-xs text-[#526A84] dark:text-[#93ACC6] font-mono-tabular">
                      {alert.evidenceText}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
              {t('dashboard.recentActivity')}
            </h2>
            <button
              type="button"
              onClick={() => setPage('activity-log')}
              className="text-xs font-medium text-[#3989C9] hover:underline whitespace-nowrap"
            >
              {t('nav.activityLog')}
            </button>
          </div>

          {activityLogs.length === 0 ? (
            <p className="text-sm text-[#526A84] dark:text-[#93ACC6] py-3">
              {t('dashboard.noActivity')}
            </p>
          ) : (
            <div className="divide-y divide-[#DCE5F0] dark:divide-[#1F354F]">
              {activityLogs.slice(0, 5).map((item) => (
                <div key={item.id} className="py-2.5 flex items-center justify-between gap-3 text-sm">
                  <div className="min-w-0">
                    <div className="font-medium text-[#102B49] dark:text-[#EAF1F8] truncate">
                      {t(`activity.actions.${item.actionType}`)}
                    </div>
                    <div className="text-xs text-[#526A84] dark:text-[#93ACC6] truncate font-mono-tabular">
                      {item.target} · {t(`activity.statuses.${item.status}`)}
                    </div>
                  </div>
                  <span className="text-xs text-[#526A84] dark:text-[#93ACC6] font-mono-tabular shrink-0">
                    {formatTime(item.createdAtIso)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
