import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Layers, PenLine, Plus, Redo2, RotateCcw, Router, Undo2 } from 'lucide-react';
import { FloorPlanAnalysisReport } from '../components/floor-plan/FloorPlanAnalysisReport';
import { FloorPlanCanvas } from '../components/floor-plan/FloorPlanCanvas';
import { RoomInspectorAndMeasure } from '../components/floor-plan/RoomInspectorAndMeasure';
import { SketchToPlanModal } from '../components/floor-plan/SketchToPlanModal';
import { useApp } from '../context/AppContext';
import { useI18n } from '../i18n';
import {
  DeviceSignalSnapshot,
  readDeviceSignalSnapshot,
  subscribeNetworkChanges
} from '../services/networkSignalInfo';
import {
  addRoomToFloor,
  analyzeHomeSurvey,
  applyFloorLayoutTemplate,
  clampProjectScenariosToFloors,
  createDefaultSurveyProject,
  deleteRoomFromFloor,
  FloorLayoutHistory,
  FloorLayoutTemplate,
  FloorPlan,
  getLatestRoomMeasurement,
  HeatmapMetric,
  HomeSurveyProject,
  pushFloorHistory,
  redoFloorHistory,
  renameRoomOnFloor,
  resizeRoomAndReflow,
  RoomCategory,
  RoomMeasurementRecord,
  RoomResizeResult,
  RouterPlacement,
  RouterScenarioId,
  setFloorRoomCount,
  setProjectFloorCount,
  SketchOrganizedPlanResult,
  undoFloorHistory
} from '../utils/floorPlanEngine';
import { loadSurveyProject, saveSurveyProject } from '../utils/floorPlanStore';

export const FloorPlanSurvey: React.FC = () => {
  const { theme, routerSession } = useApp();
  const { t } = useI18n();

  const [project, setProject] = useState<HomeSurveyProject>(() => createDefaultSurveyProject());
  const [loaded, setLoaded] = useState(false);
  const [history, setHistory] = useState<FloorLayoutHistory>(() => ({
    past: [],
    present: [],
    future: []
  }));
  const [heatmapMetric, setHeatmapMetric] = useState<HeatmapMetric>('download');
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(null);
  const [selectedSegmentId, setSelectedSegmentId] = useState<string | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const [resizeNotice, setResizeNotice] = useState<RoomResizeResult | null>(null);
  const [externalRenameRoomId, setExternalRenameRoomId] = useState<string | null>(null);
  const [sketchModalOpen, setSketchModalOpen] = useState(false);

  const [lastNetChangeIso, setLastNetChangeIso] = useState<string | null>(null);
  const [signalSnapshot, setSignalSnapshot] = useState<DeviceSignalSnapshot>(() =>
    readDeviceSignalSnapshot()
  );

  useEffect(() => {
    let active = true;
    void loadSurveyProject().then((stored) => {
      if (!active) return;
      setProject(stored);
      setHistory({ past: [], present: stored.floors, future: [] });
      const firstFloor = stored.floors.find((f) => f.id === stored.activeFloorId) ?? stored.floors[0];
      setSelectedRoomId(firstFloor?.rooms[0]?.id ?? null);
      setLoaded(true);
    });
    return () => {
      active = false;
    };
  }, []);

  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (!loaded) return;
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = setTimeout(() => {
      void saveSurveyProject(project);
    }, 100);
    return () => {
      if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    };
  }, [project, loaded]);

  useEffect(() => {
    const refresh = () => {
      setSignalSnapshot(
        readDeviceSignalSnapshot({
          routerReportedRssiDbm: routerSession?.routerInfo.signalStrengthDbm ?? null,
          lastChangeIso: lastNetChangeIso
        })
      );
    };
    refresh();
    return subscribeNetworkChanges(() => {
      const nowIso = new Date().toISOString();
      setLastNetChangeIso(nowIso);
      setSignalSnapshot(
        readDeviceSignalSnapshot({
          routerReportedRssiDbm: routerSession?.routerInfo.signalStrengthDbm ?? null,
          lastChangeIso: nowIso
        })
      );
    });
  }, [routerSession?.routerInfo.signalStrengthDbm, lastNetChangeIso]);

  const activeFloor = useMemo(
    () => project.floors.find((f) => f.id === project.activeFloorId) ?? project.floors[0],
    [project.floors, project.activeFloorId]
  );

  const activeScenario = project.scenarios[project.activeScenarioId];

  const selectedRoom = useMemo(
    () => activeFloor.rooms.find((r) => r.id === selectedRoomId) ?? null,
    [activeFloor.rooms, selectedRoomId]
  );

  const report = useMemo(() => analyzeHomeSurvey(project), [project]);

  const commitProjectWithFloors = (
    nextFloors: FloorPlan[],
    overrideActiveFloorId?: string
  ) => {
    setHistory((h) => pushFloorHistory(h, nextFloors));
    setProject((prev) =>
      clampProjectScenariosToFloors({
        ...prev,
        floors: nextFloors,
        activeFloorId: overrideActiveFloorId ?? prev.activeFloorId
      })
    );
  };

  const handleFloorCountChange = (count: number) => {
    setResizeNotice(null);
    const nextProject = setProjectFloorCount(project, count);
    setHistory((h) => pushFloorHistory(h, nextProject.floors));
    setProject(nextProject);
    const active = nextProject.floors.find((f) => f.id === nextProject.activeFloorId) ?? nextProject.floors[0];
    setSelectedRoomId(active?.rooms[0]?.id ?? null);
    setSelectedSegmentId(null);
  };

  const handleRoomCountChange = (count: number) => {
    setResizeNotice(null);
    const nextFloors = project.floors.map((f) =>
      f.id === activeFloor.id ? setFloorRoomCount(f, count) : f
    );
    commitProjectWithFloors(nextFloors);
    const updatedActive = nextFloors.find((f) => f.id === activeFloor.id);
    if (updatedActive && !updatedActive.rooms.some((r) => r.id === selectedRoomId)) {
      setSelectedRoomId(updatedActive.rooms[0]?.id ?? null);
    }
  };

  const handleAddSingleRoom = () => {
    if (activeFloor.rooms.length >= 16) return;
    setResizeNotice(null);
    let createdId: string | null = null;
    const nextFloors = project.floors.map((f) => {
      if (f.id !== activeFloor.id) return f;
      const res = addRoomToFloor(f, `${t('survey.defaultNewRoom')} ${f.rooms.length + 1}`);
      createdId = res.addedRoom?.id ?? null;
      return res.floor;
    });
    commitProjectWithFloors(nextFloors);
    if (createdId) {
      setSelectedRoomId(createdId);
      setSelectedSegmentId(null);
    }
  };

  const handleTemplateChange = (template: FloorLayoutTemplate) => {
    setResizeNotice(null);
    const nextFloors = project.floors.map((f) =>
      f.id === activeFloor.id ? applyFloorLayoutTemplate(f, template, f.includeCorridor) : f
    );
    commitProjectWithFloors(nextFloors);
  };

  const handleCorridorToggle = (includeCorridor: boolean) => {
    setResizeNotice(null);
    const nextFloors = project.floors.map((f) =>
      f.id === activeFloor.id ? applyFloorLayoutTemplate(f, f.layoutTemplate, includeCorridor) : f
    );
    commitProjectWithFloors(nextFloors);
  };

  const handleFloorNameChange = (name: string) => {
    const nextFloors = project.floors.map((f) =>
      f.id === activeFloor.id ? { ...f, name: name.slice(0, 40) } : f
    );
    setProject((prev) => ({ ...prev, floors: nextFloors }));
  };

  const handleUndo = () => {
    setResizeNotice(null);
    const nextH = undoFloorHistory(history);
    if (nextH === history) return;
    setHistory(nextH);
    setProject((prev) =>
      clampProjectScenariosToFloors({
        ...prev,
        floors: nextH.present,
        activeFloorId: nextH.present.some((f) => f.id === prev.activeFloorId)
          ? prev.activeFloorId
          : nextH.present[0].id
      })
    );
  };

  const handleRedo = () => {
    setResizeNotice(null);
    const nextH = redoFloorHistory(history);
    if (nextH === history) return;
    setHistory(nextH);
    setProject((prev) =>
      clampProjectScenariosToFloors({
        ...prev,
        floors: nextH.present,
        activeFloorId: nextH.present.some((f) => f.id === prev.activeFloorId)
          ? prev.activeFloorId
          : nextH.present[0].id
      })
    );
  };

  const handleResetLayout = () => {
    setResizeNotice(null);
    const fresh = createDefaultSurveyProject();
    setProject(fresh);
    setHistory({ past: [], present: fresh.floors, future: [] });
    setSelectedRoomId(fresh.floors[0].rooms[0]?.id ?? null);
    setSelectedSegmentId(null);
    setConfirmReset(false);
    void saveSurveyProject(fresh);
  };

  const handleMoveRouter = (partial: Partial<RouterPlacement>) => {
    setProject((prev) => ({
      ...prev,
      scenarios: {
        ...prev.scenarios,
        [prev.activeScenarioId]: {
          ...prev.scenarios[prev.activeScenarioId],
          routerPlacement: {
            ...prev.scenarios[prev.activeScenarioId].routerPlacement,
            ...partial
          }
        }
      }
    }));
  };

  const handleRenameRoom = (roomId: string, nextName: string, nextCategory?: RoomCategory) => {
    const nextFloors = project.floors.map((f) =>
      f.id === activeFloor.id ? renameRoomOnFloor(f, roomId, nextName, nextCategory) : f
    );
    commitProjectWithFloors(nextFloors);
  };

  const handleResizeRoomWithHistory = (roomId: string, nextWidthM: number, nextHeightM: number) => {
    let lastResult: RoomResizeResult | null = null;
    const nextFloors = project.floors.map((f) => {
      if (f.id !== activeFloor.id) return f;
      const res = resizeRoomAndReflow(f, roomId, nextWidthM, nextHeightM);
      lastResult = res;
      return res.floor;
    });
    if (lastResult) {
      setResizeNotice((lastResult as RoomResizeResult).reason === 'none' ? null : lastResult);
    }
    commitProjectWithFloors(nextFloors);
  };

  const handleResizeRoomLive = (roomId: string, widthM: number, heightM: number) => {
    let capturedNotice: RoomResizeResult | null = null;
    setProject((prev) => {
      const nextFloors = prev.floors.map((f) => {
        if (f.id !== activeFloor.id) return f;
        const res = resizeRoomAndReflow(f, roomId, widthM, heightM);
        capturedNotice = res.reason === 'none' ? null : res;
        return res.floor;
      });
      queueMicrotask(() => {
        setResizeNotice(capturedNotice);
      });
      return clampProjectScenariosToFloors({
        ...prev,
        floors: nextFloors
      });
    });
  };

  const handleDeleteRoom = (roomId: string) => {
    if (activeFloor.rooms.length <= 1) return;
    setResizeNotice(null);
    const nextFloors = project.floors.map((f) =>
      f.id === activeFloor.id ? deleteRoomFromFloor(f, roomId) : f
    );
    commitProjectWithFloors(nextFloors);
    const remaining = nextFloors.find((f) => f.id === activeFloor.id)?.rooms ?? [];
    setSelectedRoomId(remaining[0]?.id ?? null);
  };

  const handleSaveMeasurement = (record: RoomMeasurementRecord) => {
    setProject((prev) => {
      const next: HomeSurveyProject = {
        ...prev,
        measurements: [record, ...prev.measurements]
      };
      void saveSurveyProject(next);
      return next;
    });
  };

  const handleDeleteRoomMeasurements = (roomId: string) => {
    setProject((prev) => ({
      ...prev,
      measurements: prev.measurements.filter(
        (m) => !(m.roomId === roomId && m.scenarioId === prev.activeScenarioId)
      )
    }));
  };

  const handleClearAllMeasurements = () => {
    setProject((prev) => ({ ...prev, measurements: [] }));
  };

  const handleClearExternalRename = useCallback(() => {
    setExternalRenameRoomId(null);
  }, []);

  const handleApplySketchPlan = (result: SketchOrganizedPlanResult) => {
    setResizeNotice(null);
    const nextFloors = project.floors.map((f) => (f.id === activeFloor.id ? result.floor : f));
    setHistory((h) => pushFloorHistory(h, nextFloors));
    setProject((prev) => {
      const updatedScenarios = { ...prev.scenarios };
      if (result.routerMeters) {
        const sid = prev.activeScenarioId;
        updatedScenarios[sid] = {
          ...updatedScenarios[sid],
          routerPlacement: {
            ...updatedScenarios[sid].routerPlacement,
            floorId: result.floor.id,
            x: result.routerMeters.x,
            y: result.routerMeters.y
          }
        };
      }
      return clampProjectScenariosToFloors({
        ...prev,
        floors: nextFloors,
        activeFloorId: result.floor.id,
        scenarios: updatedScenarios
      });
    });
    setSelectedRoomId(result.floor.rooms[0]?.id ?? null);
    setSelectedSegmentId(null);
  };

  return (
    <div className="space-y-6 min-w-0">
      {/* Header & Smart Home Structure Controls */}
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-zinc-950 dark:text-zinc-50">
              {t('survey.pageTitle')}
            </h1>
            <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-400 mt-1">
              {t('survey.pageSubtitle')}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setSketchModalOpen(true)}
              data-testid="open-sketch-modal-btn"
              className="inline-flex items-center gap-1.5 px-3.5 min-h-[38px] rounded-xl border border-zinc-900 dark:border-zinc-100 bg-zinc-50 dark:bg-zinc-950 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-950 dark:text-zinc-50 text-xs font-semibold"
            >
              <PenLine className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t('survey.sketch.openBtn')}</span>
            </button>

            <button
              type="button"
              onClick={handleAddSingleRoom}
              disabled={activeFloor.rooms.length >= 16}
              data-testid="add-room-btn"
              className="inline-flex items-center gap-1.5 px-3.5 min-h-[38px] rounded-xl bg-zinc-900 dark:bg-zinc-100 hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-zinc-900 text-xs font-semibold disabled:opacity-40"
            >
              <Plus className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t('survey.addRoomBtn')}</span>
            </button>

            <button
              type="button"
              onClick={handleUndo}
              disabled={history.past.length === 0}
              data-testid="undo-layout-btn"
              className="inline-flex items-center gap-1.5 px-3 min-h-[38px] rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-zinc-900 dark:text-zinc-100 hover:border-zinc-400 disabled:opacity-40"
            >
              <Undo2 className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t('survey.undoBtn')}</span>
            </button>
            <button
              type="button"
              onClick={handleRedo}
              disabled={history.future.length === 0}
              data-testid="redo-layout-btn"
              className="inline-flex items-center gap-1.5 px-3 min-h-[38px] rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-zinc-900 dark:text-zinc-100 hover:border-zinc-400 disabled:opacity-40"
            >
              <Redo2 className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t('survey.redoBtn')}</span>
            </button>

            {!confirmReset ? (
              <button
                type="button"
                onClick={() => setConfirmReset(true)}
                data-testid="reset-layout-btn"
                className="inline-flex items-center gap-1.5 px-3 min-h-[38px] rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-red-600 dark:text-red-400 hover:border-red-400"
              >
                <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{t('survey.resetLayoutBtn')}</span>
              </button>
            ) : (
              <div className="inline-flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={handleResetLayout}
                  className="px-3 min-h-[38px] rounded-xl bg-red-600 text-white text-xs font-medium"
                >
                  {t('app.confirm')}
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  className="px-3 min-h-[38px] rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-medium"
                >
                  {t('app.cancel')}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Floors, Rooms Count, Layout Template, Scenario & Heatmap Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-3 border-t border-zinc-200 dark:border-zinc-800">
          <div>
            <label htmlFor="floor-count-select" className="block text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-1">
              {t('survey.floorCountLabel')}
            </label>
            <select
              id="floor-count-select"
              data-testid="floor-count-select"
              value={project.floors.length}
              onChange={(e) => handleFloorCountChange(Number(e.target.value))}
              className="w-full px-3 min-h-[40px] rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-xs font-medium text-zinc-950 dark:text-zinc-50"
            >
              {[1, 2, 3, 4, 5, 6].map((n) => (
                <option key={n} value={n}>
                  {n} {t('survey.floorsUnit')}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="room-count-select" className="block text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-1">
              {t('survey.roomsOnFloorLabel')} ({activeFloor.name})
            </label>
            <select
              id="room-count-select"
              data-testid="room-count-select"
              value={activeFloor.rooms.length}
              onChange={(e) => handleRoomCountChange(Number(e.target.value))}
              className="w-full px-3 min-h-[40px] rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-xs font-medium text-zinc-950 dark:text-zinc-50"
            >
              {Array.from({ length: 16 }, (_, idx) => idx + 1).map((n) => (
                <option key={n} value={n}>
                  {n} {t('survey.roomsUnit')}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="layout-template-select" className="block text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-1">
              {t('survey.layoutTemplateLabel')}
            </label>
            <select
              id="layout-template-select"
              data-testid="layout-template-select"
              value={activeFloor.layoutTemplate}
              onChange={(e) => handleTemplateChange(e.target.value as FloorLayoutTemplate)}
              className="w-full px-3 min-h-[40px] rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-xs font-medium text-zinc-950 dark:text-zinc-50"
            >
              <option value="grid">{t('survey.templateGrid')}</option>
              <option value="corridor">{t('survey.templateCorridor')}</option>
              <option value="l-shape">{t('survey.templateLShape')}</option>
              <option value="open-suite">{t('survey.templateOpenSuite')}</option>
              <option value="custom-sketch">{t('survey.templateCustomSketch')}</option>
            </select>
          </div>

          <div>
            <label htmlFor="scenario-select" className="block text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-1">
              {t('survey.scenarioLabel')}
            </label>
            <select
              id="scenario-select"
              data-testid="scenario-select"
              value={project.activeScenarioId}
              onChange={(e) =>
                setProject((prev) => ({ ...prev, activeScenarioId: e.target.value as RouterScenarioId }))
              }
              className="w-full px-3 min-h-[40px] rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-xs font-medium text-zinc-950 dark:text-zinc-50"
            >
              <option value="original">{t('survey.scenarioOriginal')}</option>
              <option value="alt-a">{t('survey.scenarioAltA')}</option>
              <option value="alt-b">{t('survey.scenarioAltB')}</option>
            </select>
          </div>

          <div>
            <label htmlFor="heatmap-metric-select" className="block text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-1">
              {t('survey.heatmapMetricLabel')}
            </label>
            <select
              id="heatmap-metric-select"
              data-testid="heatmap-metric-select"
              value={heatmapMetric}
              onChange={(e) => setHeatmapMetric(e.target.value as HeatmapMetric)}
              className="w-full px-3 min-h-[40px] rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-xs font-medium text-zinc-950 dark:text-zinc-50"
            >
              <option value="download">{t('survey.metricDownload')}</option>
              <option value="upload">{t('survey.metricUpload')}</option>
              <option value="ping">{t('survey.metricPing')}</option>
              <option value="jitter">{t('survey.metricJitter')}</option>
              <option value="signal">{t('survey.metricSignal')}</option>
            </select>
          </div>
        </div>

        {/* Multi-Floor Tabs + Floor Name + Corridor Toggle + Approximate Coverage Toggle */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex flex-wrap items-center gap-1.5" role="tablist" aria-label={t('survey.floorTabsLabel')}>
            {project.floors.map((fl) => {
              const isAct = fl.id === activeFloor.id;
              const hasRouter = activeScenario.routerPlacement.floorId === fl.id;
              return (
                <button
                  key={fl.id}
                  type="button"
                  role="tab"
                  aria-selected={isAct}
                  data-testid={`floor-tab-${fl.index}`}
                  onClick={() => {
                    setResizeNotice(null);
                    setProject((prev) => ({ ...prev, activeFloorId: fl.id }));
                    setSelectedRoomId(fl.rooms[0]?.id ?? null);
                    setSelectedSegmentId(null);
                  }}
                  className={`inline-flex items-center gap-1.5 px-3 min-h-[38px] rounded-xl text-xs font-medium transition-colors ${
                    isAct
                      ? 'bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900'
                      : 'bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-800 hover:border-zinc-400'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{fl.name}</span>
                  <span className="font-mono-tabular opacity-75">({fl.rooms.length})</span>
                  {hasRouter && <Router className="w-3 h-3" aria-label={t('homeMap.routerPin')} />}
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-1.5">
              <label htmlFor="active-floor-name" className="text-xs text-zinc-600 dark:text-zinc-400">
                {t('survey.floorNameLabel')}:
              </label>
              <input
                id="active-floor-name"
                type="text"
                value={activeFloor.name}
                onChange={(e) => handleFloorNameChange(e.target.value)}
                className="px-2.5 min-h-[34px] rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-xs font-medium text-zinc-950 dark:text-zinc-50 w-32"
              />
            </div>

            <label className="inline-flex items-center gap-2 text-xs text-zinc-700 dark:text-zinc-300 cursor-pointer">
              <input
                type="checkbox"
                data-testid="corridor-toggle"
                checked={activeFloor.includeCorridor}
                onChange={(e) => handleCorridorToggle(e.target.checked)}
                className="rounded border-zinc-300"
              />
              <span>{t('survey.corridorToggle')}</span>
            </label>

            <label className="inline-flex items-center gap-2 text-xs text-zinc-700 dark:text-zinc-300 cursor-pointer">
              <input
                type="checkbox"
                checked={activeScenario.routerPlacement.showApproxCoverage}
                onChange={(e) => handleMoveRouter({ showApproxCoverage: e.target.checked })}
                className="rounded border-zinc-300"
              />
              <span>{t('survey.showApproxCoverageToggle')}</span>
            </label>
          </div>
        </div>

        <div className="text-xs text-zinc-500 dark:text-zinc-400">
          {t('survey.autoLayoutHint')}
        </div>
      </div>

      {/* Main Workspace: Adaptive Floor Plan + Room Inspector & Real Measurement */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-5 items-start">
        <div className="xl:col-span-7 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 space-y-4 min-w-0">
          <FloorPlanCanvas
            floor={activeFloor}
            allFloors={project.floors}
            activeScenarioId={project.activeScenarioId}
            routerPlacement={activeScenario.routerPlacement}
            measurements={project.measurements}
            heatmapMetric={heatmapMetric}
            selectedRoomId={selectedRoomId}
            selectedSegmentId={selectedSegmentId}
            isDark={theme === 'dark'}
            resizeNotice={resizeNotice}
            externalRenameRoomId={externalRenameRoomId}
            onClearExternalRename={handleClearExternalRename}
            onSelectRoom={setSelectedRoomId}
            onSelectSegment={setSelectedSegmentId}
            onUpdateFloorWithHistory={(updater) => {
              const nextFloors = project.floors.map((f) => (f.id === activeFloor.id ? updater(f) : f));
              commitProjectWithFloors(nextFloors);
            }}
            onUpdateFloorLive={(updater) => {
              setProject((prev) => ({
                ...prev,
                floors: prev.floors.map((f) => (f.id === activeFloor.id ? updater(f) : f))
              }));
            }}
            onCommitFloorHistorySnapshot={(beforeDragFloor) => {
              const previousSnapshot = project.floors.map((f) =>
                f.id === beforeDragFloor.id ? beforeDragFloor : f
              );
              setHistory((h) => ({
                past: [...h.past.slice(-29), previousSnapshot],
                present: project.floors,
                future: []
              }));
            }}
            onResizeRoomLive={handleResizeRoomLive}
            onRenameRoom={handleRenameRoom}
            onMoveRouter={handleMoveRouter}
          />

          {/* Quick Room Selector Strip */}
          <div className="pt-3 border-t border-zinc-200 dark:border-zinc-800 space-y-2">
            <div className="text-xs font-medium text-zinc-600 dark:text-zinc-400">
              {t('survey.quickRoomListLabel')}
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {activeFloor.rooms.map((rm) => {
                const latest = getLatestRoomMeasurement(
                  project.measurements,
                  rm.id,
                  project.activeScenarioId
                );
                const isSel = rm.id === selectedRoomId;
                return (
                  <button
                    key={rm.id}
                    type="button"
                    data-testid={`quick-room-btn-${rm.id}`}
                    onClick={() => {
                      setSelectedRoomId(rm.id);
                      setSelectedSegmentId(null);
                    }}
                    className={`px-3 py-2.5 rounded-xl border text-start text-xs transition-colors ${
                      isSel
                        ? 'border-zinc-900 dark:border-zinc-100 bg-zinc-100 dark:bg-zinc-800 text-zinc-950 dark:text-zinc-50'
                        : 'border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 hover:border-zinc-400'
                    }`}
                  >
                    <div className="font-semibold truncate">{rm.name}</div>
                    <div className="font-mono-tabular text-[11px] text-zinc-500 dark:text-zinc-400 mt-0.5 flex items-center justify-between gap-1">
                      <span>
                        {latest
                          ? `↓${latest.downloadMbps.toFixed(1)} Mbps · ${latest.pingMs.toFixed(0)}ms`
                          : t('survey.unmeasuredShort')}
                      </span>
                      <span>
                        {rm.width.toFixed(1)}×{rm.height.toFixed(1)}
                        {t('survey.metersUnit')}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="xl:col-span-5 min-w-0">
          <RoomInspectorAndMeasure
            floor={activeFloor}
            room={selectedRoom}
            scenarioId={project.activeScenarioId}
            measurements={project.measurements}
            signalSnapshot={signalSnapshot}
            resizeNotice={resizeNotice}
            onRenameRoom={handleRenameRoom}
            onRequestRenameModal={(roomId) => setExternalRenameRoomId(roomId)}
            onResizeRoom={handleResizeRoomWithHistory}
            onDeleteRoom={handleDeleteRoom}
            onSaveMeasurement={handleSaveMeasurement}
            onDeleteRoomMeasurements={handleDeleteRoomMeasurements}
          />
        </div>
      </div>

      {/* Analysis, Signal Separation, Scenario Comparison, Floor Comparison & Report */}
      <FloorPlanAnalysisReport
        project={project}
        report={report}
        signalSnapshot={signalSnapshot}
        onSelectScenario={(sid) => setProject((prev) => ({ ...prev, activeScenarioId: sid }))}
        onClearAllMeasurements={handleClearAllMeasurements}
      />

      <SketchToPlanModal
        open={sketchModalOpen}
        activeFloor={activeFloor}
        onClose={() => setSketchModalOpen(false)}
        onApplyPlan={handleApplySketchPlan}
      />
    </div>
  );
};
