import assert from 'node:assert/strict';
import test from 'node:test';
import { formatConnectionSummary, readDeviceSignalSnapshot } from './networkSignalInfo';

test('readDeviceSignalSnapshot never fabricates browser RSSI or Wi-Fi frequency band', () => {
  const snapshot = readDeviceSignalSnapshot();
  assert.equal(snapshot.browserRssiAvailable, false);
  assert.equal(snapshot.browserRssiDbm, null);
  assert.equal(snapshot.browserFrequencyBandAvailable, false);
  assert.equal(snapshot.browserFrequencyBand, 'unknown');
  assert.equal(snapshot.routerReportedRssiDbm, null);
});

test('readDeviceSignalSnapshot keeps optional router-reported RSSI separate when provided', () => {
  const snapshot = readDeviceSignalSnapshot({
    routerReportedRssiDbm: -58,
    lastChangeIso: '2026-11-25T09:00:00.000Z'
  });
  assert.equal(snapshot.browserRssiAvailable, false);
  assert.equal(snapshot.browserRssiDbm, null);
  assert.equal(snapshot.routerReportedRssiDbm, -58);
  assert.equal(snapshot.lastChangeIso, '2026-11-25T09:00:00.000Z');
  assert.match(formatConnectionSummary(snapshot), /online/);
});
