import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  User
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  getFirestore,
  limit,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { LanguageCode } from '../i18n';
import { macToDocId, normalizeMac } from '../utils/networkSecurity';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write'
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email
        })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}
void testConnection();

export type ThemeMode = 'light' | 'dark';

export interface UserProfileData {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  language: LanguageCode;
  theme: ThemeMode;
  sessionTimeoutMinutes: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export type ActivityActionType =
  | 'wifi_ssid_change'
  | 'wifi_password_change'
  | 'wifi_settings_change'
  | 'device_block'
  | 'device_unblock'
  | 'speed_test'
  | 'diagnostics_run'
  | 'router_connect'
  | 'router_disconnect'
  | 'router_reboot'
  | 'guest_wifi_toggle'
  | 'internet_access_toggle';

export interface ActivityLogRecord {
  id: string;
  userId: string;
  actionType: ActivityActionType;
  target: string;
  status: 'success' | 'failure' | 'info';
  details: string;
  createdAtIso: string;
}

export interface StoredSpeedTest {
  id: string;
  userId: string;
  serverName: string;
  downloadMbps: number;
  uploadMbps: number;
  pingMs: number;
  jitterMs: number;
  packetLossPct: number;
  createdAtIso: string;
}

export interface DeviceAliasRecord {
  macAddress: string;
  customName: string;
  trustStatus: 'known' | 'unknown';
}

export async function signInWithGoogle(): Promise<User> {
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });
  const result = await signInWithPopup(auth, provider);
  return result.user;
}

export async function signOutGoogle(): Promise<void> {
  await signOut(auth);
}

export function subscribeAuthState(cb: (user: User | null) => void): () => void {
  return onAuthStateChanged(auth, cb);
}

export async function ensureUserProfile(
  user: User,
  defaults: { language: LanguageCode; theme: ThemeMode }
): Promise<UserProfileData> {
  const path = `users/${user.uid}`;
  const ref = doc(db, 'users', user.uid);
  try {
    const snap = await getDoc(ref);
    if (snap.exists()) {
      return snap.data() as UserProfileData;
    }
    const profile: Record<string, unknown> = {
      uid: user.uid,
      email: (user.email || '').slice(0, 254),
      displayName: (user.displayName || 'Advanced Wi-Fi User').slice(0, 120),
      language: defaults.language,
      theme: defaults.theme,
      sessionTimeoutMinutes: 30,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };
    if (user.photoURL) {
      profile.photoURL = user.photoURL.slice(0, 512);
    }
    await setDoc(ref, profile);
    return {
      uid: user.uid,
      email: String(profile.email),
      displayName: String(profile.displayName),
      photoURL: user.photoURL || undefined,
      language: defaults.language,
      theme: defaults.theme,
      sessionTimeoutMinutes: 30
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function updateUserPreferences(
  userId: string,
  updates: Partial<Pick<UserProfileData, 'language' | 'theme' | 'sessionTimeoutMinutes' | 'displayName'>>
): Promise<void> {
  const path = `users/${userId}`;
  try {
    const payload: Record<string, unknown> = {
      updatedAt: serverTimestamp()
    };
    if (updates.language) payload.language = updates.language;
    if (updates.theme) payload.theme = updates.theme;
    if (typeof updates.sessionTimeoutMinutes === 'number') {
      payload.sessionTimeoutMinutes = Math.min(1440, Math.max(5, Math.round(updates.sessionTimeoutMinutes)));
    }
    if (updates.displayName && updates.displayName.trim().length > 0) {
      payload.displayName = updates.displayName.trim().slice(0, 120);
    }
    await updateDoc(doc(db, 'users', userId), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function createActivityLog(
  userId: string,
  entry: Omit<ActivityLogRecord, 'id' | 'userId' | 'createdAtIso'>
): Promise<void> {
  const logId = `log_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const path = `users/${userId}/activity_logs/${logId}`;
  try {
    await setDoc(doc(db, 'users', userId, 'activity_logs', logId), {
      userId,
      actionType: entry.actionType,
      target: entry.target.trim().slice(0, 160) || 'router',
      status: entry.status,
      details: entry.details.slice(0, 400),
      createdAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function fetchActivityLogs(userId: string): Promise<ActivityLogRecord[]> {
  const path = `users/${userId}/activity_logs`;
  try {
    const q = query(collection(db, 'users', userId, 'activity_logs'), orderBy('createdAt', 'desc'), limit(50));
    const snap = await getDocs(q);
    return snap.docs.map((d) => {
      const data = d.data();
      const ts = data.createdAt instanceof Timestamp ? data.createdAt.toDate().toISOString() : new Date().toISOString();
      return {
        id: d.id,
        userId: String(data.userId),
        actionType: data.actionType as ActivityActionType,
        target: String(data.target),
        status: data.status as 'success' | 'failure' | 'info',
        details: String(data.details),
        createdAtIso: ts
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function persistSpeedTest(
  userId: string,
  testResult: Omit<StoredSpeedTest, 'id' | 'userId' | 'createdAtIso'>
): Promise<void> {
  const testId = `st_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const path = `users/${userId}/speed_tests/${testId}`;
  try {
    await setDoc(doc(db, 'users', userId, 'speed_tests', testId), {
      userId,
      serverName: testResult.serverName.slice(0, 120),
      downloadMbps: testResult.downloadMbps,
      uploadMbps: testResult.uploadMbps,
      pingMs: testResult.pingMs,
      jitterMs: testResult.jitterMs,
      packetLossPct: testResult.packetLossPct,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function fetchSpeedTests(userId: string): Promise<StoredSpeedTest[]> {
  const path = `users/${userId}/speed_tests`;
  try {
    const q = query(collection(db, 'users', userId, 'speed_tests'), orderBy('createdAt', 'desc'), limit(25));
    const snap = await getDocs(q);
    return snap.docs.map((d) => {
      const data = d.data();
      const ts = data.createdAt instanceof Timestamp ? data.createdAt.toDate().toISOString() : new Date().toISOString();
      return {
        id: d.id,
        userId: String(data.userId),
        serverName: String(data.serverName),
        downloadMbps: Number(data.downloadMbps),
        uploadMbps: Number(data.uploadMbps),
        pingMs: Number(data.pingMs),
        jitterMs: Number(data.jitterMs),
        packetLossPct: Number(data.packetLossPct),
        createdAtIso: ts
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function upsertDeviceAlias(userId: string, alias: DeviceAliasRecord): Promise<void> {
  const mac = normalizeMac(alias.macAddress);
  const macKey = macToDocId(mac);
  const path = `users/${userId}/device_aliases/${macKey}`;
  try {
    const ref = doc(db, 'users', userId, 'device_aliases', macKey);
    const existing = await getDoc(ref);
    const safeName = alias.customName.trim().slice(0, 80) || mac;
    if (existing.exists()) {
      await updateDoc(ref, {
        customName: safeName,
        trustStatus: alias.trustStatus,
        updatedAt: serverTimestamp()
      });
    } else {
      await setDoc(ref, {
        userId,
        macAddress: mac,
        customName: safeName,
        trustStatus: alias.trustStatus,
        updatedAt: serverTimestamp()
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function fetchDeviceAliases(userId: string): Promise<Record<string, DeviceAliasRecord>> {
  const path = `users/${userId}/device_aliases`;
  try {
    const snap = await getDocs(collection(db, 'users', userId, 'device_aliases'));
    const map: Record<string, DeviceAliasRecord> = {};
    snap.docs.forEach((d) => {
      const data = d.data();
      const mac = normalizeMac(String(data.macAddress || ''));
      if (mac) {
        map[mac] = {
          macAddress: mac,
          customName: String(data.customName || ''),
          trustStatus: data.trustStatus === 'known' ? 'known' : 'unknown'
        };
      }
    });
    return map;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function removeDeviceAlias(userId: string, macAddress: string): Promise<void> {
  const macKey = macToDocId(macAddress);
  const path = `users/${userId}/device_aliases/${macKey}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'device_aliases', macKey));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
