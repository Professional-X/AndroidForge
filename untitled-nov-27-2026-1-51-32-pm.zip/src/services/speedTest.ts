export type SpeedTestPhase =
  | 'idle'
  | 'preparing'
  | 'ping'
  | 'download'
  | 'upload'
  | 'calculating'
  | 'done'
  | 'cancelled'
  | 'error';

export const MIN_DOWNLOAD_MEASURE_MS = 15_000;
export const MIN_UPLOAD_MEASURE_MS = 15_000;
export const WARMUP_EXCLUDE_MS = 1_500;
export const DOWNLOAD_PHASE_TARGET_MS = WARMUP_EXCLUDE_MS + MIN_DOWNLOAD_MEASURE_MS;
export const UPLOAD_PHASE_TARGET_MS = WARMUP_EXCLUDE_MS + MIN_UPLOAD_MEASURE_MS;

export interface SpeedTestMeasurement {
  id: string;
  serverName: string;
  downloadMbps: number;
  uploadMbps: number;
  pingMs: number;
  jitterMs: number;
  packetLossPct: number;
  measuredAtIso: string;
  downloadDurationSec?: number;
  uploadDurationSec?: number;
  totalBytesTransferred?: number;
}

export interface ThroughputSample {
  offsetMs: number;
  bytesDelta: number;
  intervalMs: number;
}

export interface SpeedTestProgress {
  phase: SpeedTestPhase;
  progressPct: number;
  elapsedSec: number;
  phaseElapsedSec: number;
  phaseTargetSec: number;
  liveMbps: number;
  liveDownloadMbps: number | null;
  liveUploadMbps: number | null;
  pingMs: number | null;
  jitterMs: number | null;
  packetLossPct: number | null;
  downloadMbps: number | null;
  uploadMbps: number | null;
  bytesTransferred: number;
  sampleCount: number;
}

export function computeMbps(bytes: number, elapsedMs: number): number {
  if (bytes <= 0 || elapsedMs <= 0) return 0;
  const bits = bytes * 8;
  const seconds = elapsedMs / 1000;
  return Number((bits / seconds / 1_000_000).toFixed(2));
}

export function computeLatencyStats(
  samplesMs: number[],
  totalProbes: number
): { pingMs: number; jitterMs: number; packetLossPct: number } {
  const failed = Math.max(0, totalProbes - samplesMs.length);
  const packetLossPct = totalProbes > 0 ? Number(((failed / totalProbes) * 100).toFixed(1)) : 0;

  if (samplesMs.length === 0) {
    return { pingMs: 0, jitterMs: 0, packetLossPct: 100 };
  }

  const sorted = [...samplesMs].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  const pingMs = Number(
    (sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid]).toFixed(1)
  );

  let diffSum = 0;
  for (let i = 1; i < samplesMs.length; i++) {
    diffSum += Math.abs(samplesMs[i] - samplesMs[i - 1]);
  }
  const jitterMs = samplesMs.length > 1 ? Number((diffSum / (samplesMs.length - 1)).toFixed(1)) : 0;

  return { pingMs, jitterMs, packetLossPct };
}

/**
 * Selects the next HTTP transfer chunk size dynamically based on the user's current
 * link throughput so slow links remain responsive and fast links do not waste data.
 */
export function chooseAdaptiveChunkBytes(
  recentMbps: number | null,
  targetChunkSec: number,
  minBytes: number,
  maxBytes: number,
  defaultBytes: number
): number {
  if (recentMbps === null || !Number.isFinite(recentMbps) || recentMbps <= 0) {
    return defaultBytes;
  }
  const bytesPerSec = (recentMbps * 1_000_000) / 8;
  const desired = Math.round(bytesPerSec * targetChunkSec);
  return Math.max(minBytes, Math.min(maxBytes, desired));
}

/**
 * Computes steady-state throughput from multiple interval samples, excluding initial
 * TCP ramp-up warmup and trimming extreme edge spikes when sufficient samples exist.
 */
export function computeSteadyStateThroughput(
  samples: ThroughputSample[],
  warmupExcludeMs: number = WARMUP_EXCLUDE_MS
): { averageMbps: number; minMbps: number; maxMbps: number; usedSampleCount: number } {
  if (samples.length === 0) {
    return { averageMbps: 0, minMbps: 0, maxMbps: 0, usedSampleCount: 0 };
  }

  const steady = samples.filter((s) => s.offsetMs >= warmupExcludeMs && s.bytesDelta > 0 && s.intervalMs > 0);
  const pool = steady.length >= 2 ? steady : samples.filter((s) => s.bytesDelta > 0 && s.intervalMs > 0);
  if (pool.length === 0) {
    return { averageMbps: 0, minMbps: 0, maxMbps: 0, usedSampleCount: 0 };
  }

  const rates = pool
    .map((s) => computeMbps(s.bytesDelta, s.intervalMs))
    .filter((r) => Number.isFinite(r) && r >= 0)
    .sort((a, b) => a - b);

  if (rates.length === 0) {
    return { averageMbps: 0, minMbps: 0, maxMbps: 0, usedSampleCount: 0 };
  }

  // Trim bottom 10% and top 10% when we have at least 5 steady-state samples to mitigate edge effects
  let trimmed = rates;
  if (rates.length >= 5) {
    const trimCount = Math.max(1, Math.floor(rates.length * 0.1));
    trimmed = rates.slice(trimCount, rates.length - trimCount);
  }

  const sum = trimmed.reduce((acc, v) => acc + v, 0);
  return {
    averageMbps: Number((sum / trimmed.length).toFixed(2)),
    minMbps: rates[0],
    maxMbps: rates[rates.length - 1],
    usedSampleCount: trimmed.length
  };
}

const CLOUDFLARE_DOWN = 'https://speed.cloudflare.com/__down';
const CLOUDFLARE_UP = 'https://speed.cloudflare.com/__up';

function uploadChunkWithProgress(
  url: string,
  payload: Uint8Array,
  signal: AbortSignal,
  onByteDelta: (deltaBytes: number, nowMs: number) => void
): Promise<void> {
  if (typeof XMLHttpRequest === 'undefined') {
    return fetch(url, {
      method: 'POST',
      body: payload as unknown as BodyInit,
      cache: 'no-store',
      signal
    }).then((res) => {
      if (!res.ok) throw new Error('SERVER_UNREACHABLE');
      onByteDelta(payload.byteLength, performance.now());
    });
  }

  return new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    let lastLoaded = 0;
    let settled = false;

    const cleanup = () => {
      signal.removeEventListener('abort', onAbort);
    };

    const fail = (err: Error) => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(err);
    };

    const onAbort = () => {
      try {
        xhr.abort();
      } catch {
        // Ignore abort errors
      }
      fail(new Error('ABORTED'));
    };

    if (signal.aborted) {
      fail(new Error('ABORTED'));
      return;
    }

    signal.addEventListener('abort', onAbort, { once: true });

    xhr.open('POST', url, true);
    xhr.timeout = 18_000;

    xhr.upload.onprogress = (ev) => {
      if (settled) return;
      const loaded = Math.min(payload.byteLength, ev.loaded || 0);
      const delta = loaded - lastLoaded;
      if (delta > 0) {
        lastLoaded = loaded;
        onByteDelta(delta, performance.now());
      }
    };

    xhr.onload = () => {
      if (settled) return;
      settled = true;
      cleanup();
      if (xhr.status >= 200 && xhr.status < 300) {
        const remaining = payload.byteLength - lastLoaded;
        if (remaining > 0) {
          onByteDelta(remaining, performance.now());
        }
        resolve();
      } else {
        reject(new Error('SERVER_UNREACHABLE'));
      }
    };

    xhr.onerror = () => fail(new Error('CONNECTION_DROPPED'));
    xhr.ontimeout = () => fail(new Error('SERVER_UNREACHABLE'));
    xhr.onabort = () => fail(new Error('ABORTED'));

    xhr.send(payload as unknown as XMLHttpRequestBodyInit);
  });
}

export async function runLiveSpeedTest(
  onProgress: (progress: SpeedTestProgress) => void,
  externalSignal?: AbortSignal
): Promise<SpeedTestMeasurement> {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    throw new Error('INTERNET_OFFLINE');
  }

  const runController = new AbortController();
  let droppedOffline = false;

  const onExternalAbort = () => runController.abort();
  const onOffline = () => {
    droppedOffline = true;
    runController.abort();
  };

  if (externalSignal) {
    if (externalSignal.aborted) {
      throw new Error('ABORTED');
    }
    externalSignal.addEventListener('abort', onExternalAbort, { once: true });
  }
  if (typeof window !== 'undefined') {
    window.addEventListener('offline', onOffline);
  }

  const checkAbort = () => {
    if (droppedOffline || (typeof navigator !== 'undefined' && navigator.onLine === false)) {
      throw new Error('CONNECTION_DROPPED');
    }
    if (externalSignal?.aborted || runController.signal.aborted) {
      throw new Error('ABORTED');
    }
  };

  const testStartMs = performance.now();
  let totalBytesTransferred = 0;
  let totalSampleCount = 0;

  const emit = (partial: Omit<SpeedTestProgress, 'elapsedSec' | 'bytesTransferred' | 'sampleCount'>) => {
    onProgress({
      ...partial,
      elapsedSec: Number(((performance.now() - testStartMs) / 1000).toFixed(1)),
      bytesTransferred: totalBytesTransferred,
      sampleCount: totalSampleCount
    });
  };

  try {
    // Stage 1: Preparing (Handshake & pre-connect, not included in Ping/Download/Upload timing)
    emit({
      phase: 'preparing',
      progressPct: 3,
      phaseElapsedSec: 0,
      phaseTargetSec: 0,
      liveMbps: 0,
      liveDownloadMbps: null,
      liveUploadMbps: null,
      pingMs: null,
      jitterMs: null,
      packetLossPct: null,
      downloadMbps: null,
      uploadMbps: null
    });

    checkAbort();
    const prepController = new AbortController();
    const prepTimer = setTimeout(() => prepController.abort(), 5000);
    const onRunAbortPrep = () => prepController.abort();
    runController.signal.addEventListener('abort', onRunAbortPrep, { once: true });
    try {
      const prepRes = await fetch(`${CLOUDFLARE_DOWN}?bytes=0&cb=${Date.now()}_prep`, {
        cache: 'no-store',
        signal: prepController.signal
      });
      await prepRes.arrayBuffer();
      if (!prepRes.ok) throw new Error('SERVER_UNREACHABLE');
    } catch (err) {
      checkAbort();
      throw err instanceof Error && err.message === 'SERVER_UNREACHABLE'
        ? err
        : new Error('SERVER_UNREACHABLE');
    } finally {
      clearTimeout(prepTimer);
      runController.signal.removeEventListener('abort', onRunAbortPrep);
    }

    // Stage 2: Ping Test (10 sequential RTT probes)
    const totalProbes = 10;
    const rttSamples: number[] = [];

    for (let i = 0; i < totalProbes; i++) {
      checkAbort();
      emit({
        phase: 'ping',
        progressPct: Math.round(5 + (i / totalProbes) * 10),
        phaseElapsedSec: Number((i * 0.2).toFixed(1)),
        phaseTargetSec: 0,
        liveMbps: 0,
        liveDownloadMbps: null,
        liveUploadMbps: null,
        pingMs: rttSamples.length ? computeLatencyStats(rttSamples, i).pingMs : null,
        jitterMs: rttSamples.length > 1 ? computeLatencyStats(rttSamples, i).jitterMs : null,
        packetLossPct: null,
        downloadMbps: null,
        uploadMbps: null
      });

      const probeController = new AbortController();
      const timer = setTimeout(() => probeController.abort(), 3500);
      const onRunAbortProbe = () => probeController.abort();
      runController.signal.addEventListener('abort', onRunAbortProbe, { once: true });
      const probeStart = performance.now();
      try {
        const res = await fetch(`${CLOUDFLARE_DOWN}?bytes=0&cb=${Date.now()}_${i}`, {
          cache: 'no-store',
          signal: probeController.signal
        });
        await res.arrayBuffer();
        const elapsed = performance.now() - probeStart;
        if (res.ok) rttSamples.push(elapsed);
      } catch {
        checkAbort();
      } finally {
        clearTimeout(timer);
        runController.signal.removeEventListener('abort', onRunAbortProbe);
      }
    }

    if (rttSamples.length === 0) {
      throw new Error('SERVER_UNREACHABLE');
    }

    const { pingMs, jitterMs, packetLossPct } = computeLatencyStats(rttSamples, totalProbes);

    // Stage 3: Download Test (>= 15 seconds steady-state + 1.5s warmup = 16.5s real transfer)
    const downSamples: ThroughputSample[] = [];
    const downStart = performance.now();
    let recentDownMbps: number | null = null;
    let bucketDownBytes = 0;
    let bucketDownStart = downStart;

    emit({
      phase: 'download',
      progressPct: 15,
      phaseElapsedSec: 0,
      phaseTargetSec: Number((DOWNLOAD_PHASE_TARGET_MS / 1000).toFixed(0)),
      liveMbps: 0,
      liveDownloadMbps: 0,
      liveUploadMbps: null,
      pingMs,
      jitterMs,
      packetLossPct,
      downloadMbps: null,
      uploadMbps: null
    });

    while (performance.now() - downStart < DOWNLOAD_PHASE_TARGET_MS) {
      checkAbort();
      const remainingMs = DOWNLOAD_PHASE_TARGET_MS - (performance.now() - downStart);
      const targetSec = Math.max(0.7, Math.min(2.0, remainingMs / 1000));
      const chunkBytes = chooseAdaptiveChunkBytes(
        recentDownMbps,
        targetSec,
        150_000,
        8_000_000,
        600_000
      );

      const chunkController = new AbortController();
      const chunkTimeout = setTimeout(() => chunkController.abort(), 14_000);
      const onRunAbortDown = () => chunkController.abort();
      runController.signal.addEventListener('abort', onRunAbortDown, { once: true });

      try {
        const res = await fetch(`${CLOUDFLARE_DOWN}?bytes=${chunkBytes}&cb=${Date.now()}`, {
          cache: 'no-store',
          signal: chunkController.signal
        });
        if (!res.ok) throw new Error('SERVER_UNREACHABLE');

        if (res.body) {
          const reader = res.body.getReader();
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            checkAbort();
            if (value) {
              totalBytesTransferred += value.byteLength;
              bucketDownBytes += value.byteLength;
              const now = performance.now();
              const intervalMs = now - bucketDownStart;
              const elapsedDown = now - downStart;

              if (intervalMs >= 400) {
                const instMbps = computeMbps(bucketDownBytes, intervalMs);
                recentDownMbps = instMbps;
                downSamples.push({
                  offsetMs: elapsedDown,
                  bytesDelta: bucketDownBytes,
                  intervalMs
                });
                totalSampleCount += 1;
                bucketDownBytes = 0;
                bucketDownStart = now;

                const downFrac = Math.min(1, elapsedDown / DOWNLOAD_PHASE_TARGET_MS);
                emit({
                  phase: 'download',
                  progressPct: Math.round(15 + downFrac * 40),
                  phaseElapsedSec: Number((elapsedDown / 1000).toFixed(1)),
                  phaseTargetSec: Number((DOWNLOAD_PHASE_TARGET_MS / 1000).toFixed(1)),
                  liveMbps: instMbps,
                  liveDownloadMbps: instMbps,
                  liveUploadMbps: null,
                  pingMs,
                  jitterMs,
                  packetLossPct,
                  downloadMbps: null,
                  uploadMbps: null
                });
              }

              if (elapsedDown >= DOWNLOAD_PHASE_TARGET_MS) {
                await reader.cancel().catch(() => undefined);
                break;
              }
            }
          }
        } else {
          const buf = await res.arrayBuffer();
          totalBytesTransferred += buf.byteLength;
          bucketDownBytes += buf.byteLength;
        }
      } catch (err) {
        checkAbort();
        // Flush any bytes downloaded before timeout/error if partial data arrived
        if (bucketDownBytes > 0) {
          const now = performance.now();
          downSamples.push({
            offsetMs: now - downStart,
            bytesDelta: bucketDownBytes,
            intervalMs: Math.max(100, now - bucketDownStart)
          });
          bucketDownBytes = 0;
          bucketDownStart = now;
        }
        if (err instanceof Error && err.message === 'SERVER_UNREACHABLE') {
          throw err;
        }
        throw new Error('CONNECTION_DROPPED');
      } finally {
        clearTimeout(chunkTimeout);
        runController.signal.removeEventListener('abort', onRunAbortDown);
      }
    }

    if (bucketDownBytes > 0) {
      const now = performance.now();
      const intervalMs = Math.max(150, now - bucketDownStart);
      downSamples.push({
        offsetMs: now - downStart,
        bytesDelta: bucketDownBytes,
        intervalMs
      });
      totalSampleCount += 1;
    }

    const downloadElapsedSec = Number(((performance.now() - downStart) / 1000).toFixed(1));
    const downloadStats = computeSteadyStateThroughput(downSamples, WARMUP_EXCLUDE_MS);
    const downloadMbps = downloadStats.averageMbps;

    // Stage 4: Upload Test (>= 15 seconds steady-state + 1.5s warmup = 16.5s real transfer)
    const upSamples: ThroughputSample[] = [];
    const upStart = performance.now();
    // Seed initial upload estimate modestly from download/4 so slow asymmetric DSL doesn't stall
    let recentUpMbps: number | null = downloadMbps > 0 ? Math.max(0.5, downloadMbps * 0.25) : null;
    let bucketUpBytes = 0;
    let bucketUpStart = upStart;

    emit({
      phase: 'upload',
      progressPct: 55,
      phaseElapsedSec: 0,
      phaseTargetSec: Number((UPLOAD_PHASE_TARGET_MS / 1000).toFixed(1)),
      liveMbps: 0,
      liveDownloadMbps: downloadMbps,
      liveUploadMbps: 0,
      pingMs,
      jitterMs,
      packetLossPct,
      downloadMbps: null,
      uploadMbps: null
    });

    while (performance.now() - upStart < UPLOAD_PHASE_TARGET_MS) {
      checkAbort();
      const remainingMs = UPLOAD_PHASE_TARGET_MS - (performance.now() - upStart);
      const targetSec = Math.max(0.7, Math.min(2.0, remainingMs / 1000));
      const chunkBytes = chooseAdaptiveChunkBytes(
        recentUpMbps,
        targetSec,
        64_000,
        3_000_000,
        256_000
      );

      const payload = new Uint8Array(chunkBytes);
      // Fill non-zero deterministic pattern to avoid HTTP proxy zero-compression artifacts
      for (let i = 0; i < payload.length; i += 64) {
        payload[i] = (i * 31 + 7) & 0xff;
      }

      const chunkController = new AbortController();
      const onRunAbortUp = () => chunkController.abort();
      runController.signal.addEventListener('abort', onRunAbortUp, { once: true });

      try {
        await uploadChunkWithProgress(
          `${CLOUDFLARE_UP}?cb=${Date.now()}`,
          payload,
          chunkController.signal,
          (deltaBytes, now) => {
            totalBytesTransferred += deltaBytes;
            bucketUpBytes += deltaBytes;
            const intervalMs = now - bucketUpStart;
            const elapsedUp = now - upStart;

            if (intervalMs >= 400) {
              const instMbps = computeMbps(bucketUpBytes, intervalMs);
              recentUpMbps = instMbps;
              upSamples.push({
                offsetMs: elapsedUp,
                bytesDelta: bucketUpBytes,
                intervalMs
              });
              totalSampleCount += 1;
              bucketUpBytes = 0;
              bucketUpStart = now;

              const upFrac = Math.min(1, elapsedUp / UPLOAD_PHASE_TARGET_MS);
              emit({
                phase: 'upload',
                progressPct: Math.round(55 + upFrac * 40),
                phaseElapsedSec: Number((elapsedUp / 1000).toFixed(1)),
                phaseTargetSec: Number((UPLOAD_PHASE_TARGET_MS / 1000).toFixed(1)),
                liveMbps: instMbps,
                liveDownloadMbps: downloadMbps,
                liveUploadMbps: instMbps,
                pingMs,
                jitterMs,
                packetLossPct,
                downloadMbps: null,
                uploadMbps: null
              });
            }
          }
        );
      } catch (err) {
        checkAbort();
        if (err instanceof Error && err.message === 'SERVER_UNREACHABLE') {
          throw err;
        }
        throw new Error('CONNECTION_DROPPED');
      } finally {
        runController.signal.removeEventListener('abort', onRunAbortUp);
      }
    }

    if (bucketUpBytes > 0) {
      const now = performance.now();
      const intervalMs = Math.max(150, now - bucketUpStart);
      upSamples.push({
        offsetMs: now - upStart,
        bytesDelta: bucketUpBytes,
        intervalMs
      });
      totalSampleCount += 1;
    }

    const uploadElapsedSec = Number(((performance.now() - upStart) / 1000).toFixed(1));

    // Stage 5: Calculating Results (Aggregate steady-state samples)
    emit({
      phase: 'calculating',
      progressPct: 97,
      phaseElapsedSec: 0,
      phaseTargetSec: 0,
      liveMbps: downloadMbps,
      liveDownloadMbps: downloadMbps,
      liveUploadMbps: recentUpMbps ?? 0,
      pingMs,
      jitterMs,
      packetLossPct,
      downloadMbps: null,
      uploadMbps: null
    });

    const uploadStats = computeSteadyStateThroughput(upSamples, WARMUP_EXCLUDE_MS);
    const uploadMbps = uploadStats.averageMbps;

    // Stage 6: Completed — reveal final results only after completion
    emit({
      phase: 'done',
      progressPct: 100,
      phaseElapsedSec: 0,
      phaseTargetSec: 0,
      liveMbps: downloadMbps,
      liveDownloadMbps: downloadMbps,
      liveUploadMbps: uploadMbps,
      pingMs,
      jitterMs,
      packetLossPct,
      downloadMbps,
      uploadMbps
    });

    return {
      id: `st_${Date.now()}`,
      serverName: 'Cloudflare Edge',
      downloadMbps,
      uploadMbps,
      pingMs,
      jitterMs,
      packetLossPct,
      measuredAtIso: new Date().toISOString(),
      downloadDurationSec: downloadElapsedSec,
      uploadDurationSec: uploadElapsedSec,
      totalBytesTransferred
    };
  } finally {
    if (externalSignal) {
      externalSignal.removeEventListener('abort', onExternalAbort);
    }
    if (typeof window !== 'undefined') {
      window.removeEventListener('offline', onOffline);
    }
  }
}
