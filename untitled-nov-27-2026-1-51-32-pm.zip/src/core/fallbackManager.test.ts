import test from 'node:test';
import assert from 'node:assert/strict';
import {
  CONNECTION_METHOD_ORDER,
  discoverGatewayCandidates,
  runMultiMethodFallback
} from './fallbackManager.ts';
import { ConnectionMethodId } from '../router-adapters/types.ts';

test('discoverGatewayCandidates prioritizes user IP, validates RFC1918, and includes Huawei 192.168.100.1', () => {
  const single = discoverGatewayCandidates('192.168.100.55', false);
  assert.equal(single.length, 1);
  assert.equal(single[0].ipOrHost, '192.168.100.55');

  const autoList = discoverGatewayCandidates('192.168.100.55', true);
  assert.ok(autoList.some((g) => g.ipOrHost === '192.168.100.1'));
  assert.ok(autoList.some((g) => g.ipOrHost === '192.168.1.1'));
  assert.ok(autoList.some((g) => g.ipOrHost === '192.168.8.1'));

  // Public IP rejected cleanly
  const blocked = discoverGatewayCandidates('8.8.8.8', false);
  assert.equal(blocked.some((g) => g.ipOrHost === '8.8.8.8'), false);
});

test('runMultiMethodFallback tries in strict order and stops on first winning method without extra calls', async () => {
  const attempted: ConnectionMethodId[] = [];
  const res = await runMultiMethodFallback(
    {
      rawAddress: '192.168.100.1',
      preferredAdapterId: 'auto',
      credentials: { username: 'admin', password: 'SuperSecretRouterPassword1' },
      mode: 'connect'
    },
    {
      executeMethod: async ({ methodId }) => {
        attempted.push(methodId);
        if (methodId === 'direct_browser') {
          return { ok: false, latencyMs: 12, errorCode: 'MIXED_CONTENT_HTTPS' };
        }
        if (methodId === 'router_api') {
          return { ok: false, latencyMs: 15, errorCode: 'CORS_BLOCKED' };
        }
        if (methodId === 'local_connector') {
          return {
            ok: true,
            latencyMs: 38,
            technicalSummary: 'Huawei OptiXstar HG8145X6-10',
            session: { connected: true }
          };
        }
        throw new Error('Should not execute later methods after success');
      }
    }
  );

  assert.equal(res.ok, true);
  assert.equal(res.winningMethod, 'local_connector');
  assert.deepEqual(attempted, ['direct_browser', 'router_api', 'local_connector']);
  assert.equal(res.diagnostics.activeMethod, 'local_connector');
  assert.equal(res.diagnostics.authState, 'authenticated');
  assert.equal(
    res.diagnostics.methodResults.find((r) => r.methodId === 'lan_hosted_connector')?.status,
    'not_tested'
  );
  // Password must NEVER appear in diagnostic logs
  assert.equal(JSON.stringify(res.diagnostics).includes('SuperSecretRouterPassword1'), false);
});

test('runMultiMethodFallback stops immediately on INVALID_CREDENTIALS without slamming fallback transports', async () => {
  const attempted: ConnectionMethodId[] = [];
  const res = await runMultiMethodFallback(
    {
      rawAddress: '192.168.100.1',
      preferredAdapterId: 'huawei',
      credentials: { username: 'admin', password: 'WrongPassword123' },
      mode: 'connect'
    },
    {
      executeMethod: async ({ methodId }) => {
        attempted.push(methodId);
        if (methodId === 'direct_browser') {
          return {
            ok: false,
            latencyMs: 22,
            errorCode: 'INVALID_CREDENTIALS',
            technicalSummary: 'ONT /login.cgi rejected password=WrongPassword123'
          };
        }
        throw new Error('Fallback must halt on INVALID_CREDENTIALS');
      }
    }
  );

  assert.equal(res.ok, false);
  assert.deepEqual(attempted, ['direct_browser']);
  assert.equal(res.diagnostics.lastErrorCode, 'INVALID_CREDENTIALS');
  assert.equal(res.diagnostics.authState, 'rejected');
  assert.equal(JSON.stringify(res.diagnostics).includes('WrongPassword123'), false);
});

test('runMultiMethodFallback reaches Android Companion ONLY as 6th last resort and works offline on LAN', async () => {
  const attempted: ConnectionMethodId[] = [];
  const res = await runMultiMethodFallback(
    {
      rawAddress: '192.168.100.1',
      preferredAdapterId: 'auto',
      credentials: { username: 'admin', password: 'admin' },
      mode: 'connect'
    },
    {
      getRuntimeInfo: async () => ({
        serverTopology: 'cloud-hosted',
        coreSession: null,
        isAndroid: true,
        isNavigatorOnline: false // Offline external internet MUST NOT block local LAN probing
      }),
      executeMethod: async ({ methodId }) => {
        attempted.push(methodId);
        const map: Partial<
          Record<
            ConnectionMethodId,
            | 'MIXED_CONTENT_HTTPS'
            | 'ROUTER_API_UNSUPPORTED'
            | 'CONNECTOR_NOT_FOUND'
            | 'CLOUD_ISOLATED_FROM_LAN'
            | 'RELAY_AGENT_OFFLINE'
            | 'ANDROID_COMPANION_REQUIRED'
          >
        > = {
          direct_browser: 'MIXED_CONTENT_HTTPS',
          router_api: 'ROUTER_API_UNSUPPORTED',
          local_connector: 'CONNECTOR_NOT_FOUND',
          lan_hosted_connector: 'CLOUD_ISOLATED_FROM_LAN',
          secure_cloud_relay: 'RELAY_AGENT_OFFLINE',
          android_companion: 'ANDROID_COMPANION_REQUIRED'
        };
        return {
          ok: false,
          skipped: methodId === 'lan_hosted_connector',
          latencyMs: 10,
          errorCode: map[methodId]
        };
      }
    }
  );

  assert.equal(res.ok, false);
  assert.deepEqual(attempted, CONNECTION_METHOD_ORDER);
  assert.equal(res.diagnostics.state, 'failed');
  assert.equal(res.diagnostics.offlineLanCapable, true);
  assert.equal(
    res.diagnostics.methodResults.find((m) => m.methodId === 'android_companion')?.errorCode,
    'ANDROID_COMPANION_REQUIRED'
  );
});

test('runMultiMethodFallback enforces ONLY android_native_bridge inside Android APK (no Local Connector or Cloud Relay)', async () => {
  const attempted: ConnectionMethodId[] = [];
  const res = await runMultiMethodFallback(
    {
      rawAddress: '192.168.100.1',
      preferredAdapterId: 'huawei-hg8145x6-10',
      credentials: { username: 'admin', password: 'admin' },
      mode: 'connect',
      preferNativeAndroidBridge: true
    },
    {
      getRuntimeInfo: async () => ({
        serverTopology: 'local-lan',
        coreSession: null,
        isAndroid: true,
        isNativeAndroidApp: true,
        isNavigatorOnline: false
      }),
      executeMethod: async ({ methodId }) => {
        attempted.push(methodId);
        if (methodId === 'android_native_bridge') {
          return {
            ok: false,
            latencyMs: 14,
            errorCode: 'ROUTER_OFFLINE',
            technicalSummary: 'Modem port unreachable over Android Wi-Fi'
          };
        }
        throw new Error(`APK mode must NEVER invoke web/relay/connector method: ${methodId}`);
      }
    }
  );

  assert.equal(res.ok, false);
  assert.deepEqual(attempted, ['android_native_bridge']);
  assert.deepEqual(
    res.diagnostics.methodResults.map((m) => m.methodId),
    ['android_native_bridge']
  );
  assert.equal(res.diagnostics.state, 'failed');
  assert.equal(res.diagnostics.lastErrorCode, 'ROUTER_OFFLINE');
});

test('runMultiMethodFallback marks HTTP probe success as modem_reachable (never connected) and separates login_failed vs data_read_failed', async () => {
  const probeRes = await runMultiMethodFallback(
    {
      rawAddress: '192.168.100.1',
      preferredAdapterId: 'auto',
      credentials: { username: '', password: '' },
      mode: 'probe',
      preferNativeAndroidBridge: true
    },
    {
      getRuntimeInfo: async () => ({
        serverTopology: 'local-lan',
        coreSession: null,
        isAndroid: true,
        isNativeAndroidApp: true
      }),
      executeMethod: async () => ({
        ok: true,
        latencyMs: 9,
        technicalSummary: 'HTTP 200 reachable'
      })
    }
  );
  assert.equal(probeRes.ok, true);
  assert.equal(probeRes.diagnostics.state, 'modem_reachable');
  assert.equal(probeRes.diagnostics.authState, 'unauthenticated');

  const badCredsRes = await runMultiMethodFallback(
    {
      rawAddress: '192.168.100.1',
      preferredAdapterId: 'huawei-hg8145x6-10',
      credentials: { username: 'admin', password: 'bad' },
      mode: 'connect',
      preferNativeAndroidBridge: true
    },
    {
      getRuntimeInfo: async () => ({
        serverTopology: 'local-lan',
        coreSession: null,
        isAndroid: true,
        isNativeAndroidApp: true
      }),
      executeMethod: async () => ({
        ok: false,
        latencyMs: 15,
        errorCode: 'INVALID_CREDENTIALS'
      })
    }
  );
  assert.equal(badCredsRes.ok, false);
  assert.equal(badCredsRes.diagnostics.state, 'login_failed');
  assert.equal(badCredsRes.diagnostics.authState, 'rejected');

  const dataFailRes = await runMultiMethodFallback(
    {
      rawAddress: '192.168.100.1',
      preferredAdapterId: 'huawei-hg8145x6-10',
      credentials: { username: 'admin', password: 'admin' },
      mode: 'connect',
      preferNativeAndroidBridge: true
    },
    {
      getRuntimeInfo: async () => ({
        serverTopology: 'local-lan',
        coreSession: null,
        isAndroid: true,
        isNativeAndroidApp: true
      }),
      executeMethod: async () => ({
        ok: false,
        latencyMs: 18,
        errorCode: 'DATA_READ_FAILED'
      })
    }
  );
  assert.equal(dataFailRes.ok, false);
  assert.equal(dataFailRes.diagnostics.state, 'data_read_failed');
  assert.equal(dataFailRes.diagnostics.authState, 'authenticated');
  assert.equal(dataFailRes.diagnostics.lastErrorCode, 'DATA_READ_FAILED');
});

