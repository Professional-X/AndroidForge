import {
  ConnectionAttemptLogEntry,
  ConnectionDiagnosticsState,
  ConnectionMethodId,
  CoreTokenSessionInfo,
  GatewayCandidate,
  MethodAttemptResult,
  RouterAdapterId,
  RouterCredentials,
  RouterError,
  RouterErrorCode
} from '../router-adapters/types';
import { sanitizeDiagnosticText, validateRouterAddress } from '../utils/networkSecurity';

export const CONNECTION_METHOD_ORDER: ConnectionMethodId[] = [
  'direct_browser',
  'router_api',
  'local_connector',
  'lan_hosted_connector',
  'secure_cloud_relay',
  'android_companion'
];

export function getEffectiveMethodOrder(preferNativeAndroidBridge = false): ConnectionMethodId[] {
  return preferNativeAndroidBridge ? ['android_native_bridge'] : [...CONNECTION_METHOD_ORDER];
}

export const HUAWEI_DEFAULT_GATEWAY = '192.168.100.1';
export const COMMON_ROUTER_GATEWAYS = ['192.168.100.1', '192.168.1.1', '192.168.8.1', '192.168.0.1'];

export function discoverGatewayCandidates(
  rawPrimaryAddress?: string,
  includeDefaults = false
): GatewayCandidate[] {
  const candidates: GatewayCandidate[] = [];
  const seen = new Set<string>();

  const pushCandidate = (ipOrHost: string, source: GatewayCandidate['source']) => {
    const check = validateRouterAddress(ipOrHost);
    if (!check.valid || seen.has(check.normalizedUrl)) return;
    seen.add(check.normalizedUrl);
    candidates.push({
      ipOrHost: check.host,
      normalizedUrl: check.normalizedUrl,
      source
    });
  };

  if (rawPrimaryAddress && rawPrimaryAddress.trim()) {
    pushCandidate(rawPrimaryAddress, 'user_input');
  }

  if (includeDefaults || candidates.length === 0) {
    pushCandidate(HUAWEI_DEFAULT_GATEWAY, 'huawei_default');
    for (const gw of COMMON_ROUTER_GATEWAYS) {
      if (gw !== HUAWEI_DEFAULT_GATEWAY) {
        pushCandidate(gw, 'common_gateway');
      }
    }
  }

  return candidates;
}

export function detectAndroidEnvironment(userAgent?: string): boolean {
  const ua =
    userAgent ??
    (typeof navigator !== 'undefined' && typeof navigator.userAgent === 'string'
      ? navigator.userAgent
      : '');
  return /android/i.test(ua);
}

export function isHttpsPageToHttpTarget(targetUrl: string, currentProtocol?: string): boolean {
  const proto =
    currentProtocol ??
    (typeof window !== 'undefined' && window.location ? window.location.protocol : 'http:');
  return proto === 'https:' && targetUrl.toLowerCase().startsWith('http://');
}

export interface MethodExecutionOutcome<TSession = unknown> {
  ok: boolean;
  latencyMs: number;
  errorCode?: RouterErrorCode;
  technicalSummary?: string;
  skipped?: boolean;
  session?: TSession;
}

export interface FallbackRunnerDependencies<TSession = unknown> {
  executeMethod: (params: {
    methodId: ConnectionMethodId;
    gateway: GatewayCandidate;
    mode: 'probe' | 'connect';
    preferredAdapterId: RouterAdapterId | 'auto';
    credentials: RouterCredentials;
    lanBridgeUrl?: string;
  }) => Promise<MethodExecutionOutcome<TSession>>;
  getRuntimeInfo?: () => Promise<{
    serverTopology: 'local-lan' | 'cloud-hosted' | 'unknown';
    coreSession: CoreTokenSessionInfo | null;
    isAndroid?: boolean;
    isNativeAndroidApp?: boolean;
    isNavigatorOnline?: boolean;
  }>;
  nowIso?: () => string;
}

export interface FallbackExecutionOptions {
  rawAddress: string;
  autoDiscoverGateways?: boolean;
  preferredAdapterId: RouterAdapterId | 'auto';
  credentials: RouterCredentials;
  mode: 'probe' | 'connect';
  preferNativeAndroidBridge?: boolean;
  lanBridgeUrl?: string;
  priorAttemptsLog?: ConnectionAttemptLogEntry[];
}

export interface FallbackExecutionResult<TSession = unknown> {
  ok: boolean;
  winningMethod: ConnectionMethodId | null;
  winningGateway: GatewayCandidate | null;
  session: TSession | null;
  diagnostics: ConnectionDiagnosticsState;
}

export function createInitialDiagnosticsState(targetGateway = HUAWEI_DEFAULT_GATEWAY): ConnectionDiagnosticsState {
  return {
    state: 'idle',
    targetGateway,
    activeMethod: null,
    authState: 'unauthenticated',
    lastLatencyMs: null,
    serverTopology: 'unknown',
    coreSession: null,
    methodResults: CONNECTION_METHOD_ORDER.map((methodId) => ({
      methodId,
      status: 'not_tested',
      latencyMs: 0,
      gatewayIp: targetGateway,
      checkedAtIso: ''
    })),
    discoveredGateways: discoverGatewayCandidates(targetGateway, true),
    attemptsLog: [],
    lastErrorCode: null,
    offlineLanCapable: true,
    checkedAtIso: null
  };
}

export async function runMultiMethodFallback<TSession = unknown>(
  options: FallbackExecutionOptions,
  deps: FallbackRunnerDependencies<TSession>
): Promise<FallbackExecutionResult<TSession>> {
  const nowIso = deps.nowIso ?? (() => new Date().toISOString());
  const validated = validateRouterAddress(options.rawAddress);
  if (!validated.valid) {
    const ts = nowIso();
    return {
      ok: false,
      winningMethod: null,
      winningGateway: null,
      session: null,
      diagnostics: {
        ...createInitialDiagnosticsState(options.rawAddress.trim() || HUAWEI_DEFAULT_GATEWAY),
        state: 'failed',
        lastErrorCode: 'INVALID_ROUTER_ADDRESS',
        checkedAtIso: ts
      }
    };
  }

  const runtime = deps.getRuntimeInfo
    ? await deps.getRuntimeInfo()
    : {
        serverTopology: 'unknown' as const,
        coreSession: null,
        isAndroid: detectAndroidEnvironment(),
        isNativeAndroidApp: false,
        isNavigatorOnline: typeof navigator !== 'undefined' ? navigator.onLine : true
      };

  const useNativeBridge = Boolean(options.preferNativeAndroidBridge || runtime.isNativeAndroidApp);
  const effectiveOrder = getEffectiveMethodOrder(useNativeBridge);

  const discoveredGateways = discoverGatewayCandidates(
    options.rawAddress,
    Boolean(options.autoDiscoverGateways)
  );
  const primaryGateway = discoveredGateways[0];

  const methodResultsMap = new Map<ConnectionMethodId, MethodAttemptResult>();
  for (const methodId of effectiveOrder) {
    methodResultsMap.set(methodId, {
      methodId,
      status: 'not_tested',
      latencyMs: 0,
      gatewayIp: primaryGateway.ipOrHost,
      checkedAtIso: ''
    });
  }

  const newLogs: ConnectionAttemptLogEntry[] = [];
  const appendLog = (
    gatewayIp: string,
    methodId: ConnectionMethodId,
    status: MethodAttemptResult['status'],
    latencyMs: number,
    errorCode?: RouterErrorCode,
    detail = ''
  ) => {
    newLogs.push({
      id: `att_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      timestampIso: nowIso(),
      gatewayIp,
      methodId,
      mode: options.mode,
      status,
      latencyMs,
      errorCode,
      detail: sanitizeDiagnosticText(detail || errorCode || status, [options.credentials.password])
    });
  };

  let winningMethod: ConnectionMethodId | null = null;
  let winningGateway: GatewayCandidate | null = null;
  let winningSession: TSession | null = null;
  let lastErrorCode: RouterErrorCode | null = null;
  let stoppedDueToBadCredentials = false;
  let stoppedDueToDataReadFailure = false;

  const primaryMethods: ConnectionMethodId[] = useNativeBridge
    ? ['android_native_bridge']
    : [
        'direct_browser',
        'router_api',
        'local_connector',
        'lan_hosted_connector',
        'secure_cloud_relay'
      ];

  // Try methods sequentially on primary gateway (and discovered gateways only if autoDiscoverGateways enabled)
  const gatewaysToTry = options.autoDiscoverGateways ? discoveredGateways : [primaryGateway];

  gatewayLoop: for (const gateway of gatewaysToTry) {
    for (const methodId of primaryMethods) {
      let outcome: MethodExecutionOutcome<TSession>;
      try {
        outcome = await deps.executeMethod({
          methodId,
          gateway,
          mode: options.mode,
          preferredAdapterId: options.preferredAdapterId,
          credentials: options.credentials,
          lanBridgeUrl: options.lanBridgeUrl
        });
      } catch (err) {
        const code: RouterErrorCode = err instanceof RouterError ? err.code : 'ROUTER_OFFLINE';
        outcome = {
          ok: false,
          latencyMs: 0,
          errorCode: code,
          technicalSummary: err instanceof Error ? err.message : code
        };
      }

      const checkedAtIso = nowIso();
      if (outcome.ok) {
        methodResultsMap.set(methodId, {
          methodId,
          status: 'succeeded',
          latencyMs: outcome.latencyMs,
          gatewayIp: gateway.ipOrHost,
          technicalSummary: sanitizeDiagnosticText(outcome.technicalSummary || 'Connected cleanly', [
            options.credentials.password
          ]),
          checkedAtIso
        });
        appendLog(
          gateway.ipOrHost,
          methodId,
          'succeeded',
          outcome.latencyMs,
          undefined,
          outcome.technicalSummary || 'Connected cleanly'
        );
        winningMethod = methodId;
        winningGateway = gateway;
        winningSession = outcome.session ?? null;
        break gatewayLoop;
      }

      const status: MethodAttemptResult['status'] = outcome.skipped ? 'skipped' : 'failed';
      const errCode = outcome.errorCode ?? 'ROUTER_OFFLINE';
      lastErrorCode = errCode;

      methodResultsMap.set(methodId, {
        methodId,
        status,
        latencyMs: outcome.latencyMs,
        gatewayIp: gateway.ipOrHost,
        errorCode: errCode,
        technicalSummary: sanitizeDiagnosticText(outcome.technicalSummary || errCode, [
          options.credentials.password
        ]),
        checkedAtIso
      });
      appendLog(
        gateway.ipOrHost,
        methodId,
        status,
        outcome.latencyMs,
        errCode,
        outcome.technicalSummary || errCode
      );

      // CRITICAL: If router responded and explicitly rejected admin credentials or failed data read after auth,
      // stop fallback immediately so we report the exact modem stage failure accurately.
      if (errCode === 'INVALID_CREDENTIALS') {
        stoppedDueToBadCredentials = true;
        break gatewayLoop;
      }
      if (errCode === 'DATA_READ_FAILED') {
        stoppedDueToDataReadFailure = true;
        break gatewayLoop;
      }
    }
  }

  // Method 6: Android Companion (Web-only Last Resort — never executed when inside Native Android APK)
  if (!useNativeBridge && !winningMethod && !stoppedDueToBadCredentials && !stoppedDueToDataReadFailure) {
    const androidOutcome = await deps.executeMethod({
      methodId: 'android_companion',
      gateway: primaryGateway,
      mode: options.mode,
      preferredAdapterId: options.preferredAdapterId,
      credentials: options.credentials,
      lanBridgeUrl: options.lanBridgeUrl
    });

    const checkedAtIso = nowIso();
    const errCode = androidOutcome.errorCode ?? 'ANDROID_COMPANION_REQUIRED';
    if (androidOutcome.ok) {
      methodResultsMap.set('android_companion', {
        methodId: 'android_companion',
        status: 'succeeded',
        latencyMs: androidOutcome.latencyMs,
        gatewayIp: primaryGateway.ipOrHost,
        technicalSummary: androidOutcome.technicalSummary,
        checkedAtIso
      });
      appendLog(primaryGateway.ipOrHost, 'android_companion', 'succeeded', androidOutcome.latencyMs);
      winningMethod = 'android_companion';
      winningGateway = primaryGateway;
      winningSession = androidOutcome.session ?? null;
    } else {
      const status: MethodAttemptResult['status'] = androidOutcome.skipped ? 'skipped' : 'failed';
      methodResultsMap.set('android_companion', {
        methodId: 'android_companion',
        status,
        latencyMs: androidOutcome.latencyMs,
        gatewayIp: primaryGateway.ipOrHost,
        errorCode: errCode,
        technicalSummary: sanitizeDiagnosticText(
          androidOutcome.technicalSummary ||
            (runtime.isAndroid
              ? 'All web transports blocked; open router URL directly on Android Wi-Fi or host app on LAN.'
              : 'All 5 primary connection methods could not reach the router.'),
          [options.credentials.password]
        ),
        checkedAtIso
      });
      appendLog(
        primaryGateway.ipOrHost,
        'android_companion',
        status,
        androidOutcome.latencyMs,
        errCode,
        androidOutcome.technicalSummary || errCode
      );
      lastErrorCode = lastErrorCode ?? errCode;
    }
  }

  const combinedLogs = [...newLogs.reverse(), ...(options.priorAttemptsLog ?? [])].slice(0, 40);
  const winningLatency = winningMethod ? methodResultsMap.get(winningMethod)?.latencyMs ?? null : null;

  const resolvedState: ConnectionDiagnosticsState['state'] = winningMethod
    ? options.mode === 'probe'
      ? 'modem_reachable'
      : 'connected'
    : stoppedDueToBadCredentials
    ? 'login_failed'
    : stoppedDueToDataReadFailure
    ? 'data_read_failed'
    : 'failed';

  return {
    ok: Boolean(winningMethod),
    winningMethod,
    winningGateway,
    session: winningSession,
    diagnostics: {
      state: resolvedState,
      targetGateway: (winningGateway ?? primaryGateway).ipOrHost,
      activeMethod: winningMethod,
      authState: winningMethod
        ? options.mode === 'probe'
          ? 'unauthenticated'
          : 'authenticated'
        : stoppedDueToBadCredentials
        ? 'rejected'
        : stoppedDueToDataReadFailure
        ? 'authenticated'
        : 'unauthenticated',
      lastLatencyMs: winningLatency,
      serverTopology: runtime.serverTopology,
      coreSession: runtime.coreSession,
      methodResults: effectiveOrder.map((id) => methodResultsMap.get(id)!),
      discoveredGateways,
      attemptsLog: combinedLogs,
      lastErrorCode: winningMethod
        ? null
        : stoppedDueToBadCredentials
        ? 'INVALID_CREDENTIALS'
        : stoppedDueToDataReadFailure
        ? 'DATA_READ_FAILED'
        : lastErrorCode,
      offlineLanCapable: true,
      checkedAtIso: nowIso()
    }
  };
}
