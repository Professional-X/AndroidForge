import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import ar from '../locales/ar.json';
import en from '../locales/en.json';
import fr from '../locales/fr.json';

export type LanguageCode = 'ar' | 'en' | 'fr';

const DICTS = { ar, en, fr } as const;
const LANG_STORAGE_KEY = 'aw_ui_language';

function getNested(obj: unknown, path: string): string {
  const parts = path.split('.');
  let current: unknown = obj;
  for (const part of parts) {
    if (current && typeof current === 'object' && part in (current as Record<string, unknown>)) {
      current = (current as Record<string, unknown>)[part];
    } else {
      return path;
    }
  }
  return typeof current === 'string' ? current : path;
}

interface I18nContextValue {
  language: LanguageCode;
  dir: 'rtl' | 'ltr';
  setLanguage: (lang: LanguageCode) => void;
  t: (key: string) => string;
}

const I18nContext = createContext<I18nContextValue | null>(null);

export const I18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<LanguageCode>(() => {
    try {
      const saved = localStorage.getItem(LANG_STORAGE_KEY);
      if (saved === 'ar' || saved === 'en' || saved === 'fr') return saved;
    } catch {
      // Ignore storage access failures
    }
    return 'ar';
  });

  const dir: 'rtl' | 'ltr' = language === 'ar' ? 'rtl' : 'ltr';

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = dir;
    try {
      localStorage.setItem(LANG_STORAGE_KEY, language);
    } catch {
      // Ignore storage write errors
    }
  }, [language, dir]);

  const setLanguage = useCallback((lang: LanguageCode) => {
    setLanguageState(lang);
  }, []);

  const t = useCallback(
    (key: string) => getNested(DICTS[language], key),
    [language]
  );

  return React.createElement(
    I18nContext.Provider,
    { value: { language, dir, setLanguage, t } },
    children
  );
};

export function useI18n(): I18nContextValue {
  const ctx = useContext(I18nContext);
  if (!ctx) {
    throw new Error('useI18n must be used within I18nProvider');
  }
  return ctx;
}
