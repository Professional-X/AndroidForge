import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { User } from 'firebase/auth';
import { LanguageCode, useI18n } from '../i18n';
import {
  createInitialDiagnosticsState,
  getEffectiveMethodOrder,
  HUAWEI_DEFAULT_GATEWAY
} from '../core/fallbackManager';
import {
  getNativeEnvironment,
  isNativeAndroidApp,
  NativeAndroidEnv
} from '../native/androidBridge';
import {
  expireSimulatedHuaweiSession,
  resetHuaweiSimulatorState,
  SimulationScenario
} from '../simulation/huaweiSimulator';
import {
  ConnectionDiagnosticsState,
  ConnectionMethodId,
  ModemDiagnosticReport,
  RouterAdapterId,
  RouterCredentials,
  RouterError,
  RouterErrorCode,
  WifiUpdateInput
} from '../router-adapters/types';
import { runModemProtocolDiagnostics } from '../services/routerDiagnostics';
import { analyzeNetworkDiagnostics, DiagnosticsReport } from '../services/diagnostics';
import {
  ActivityActionType,
  ActivityLogRecord,
  createActivityLog,
  DeviceAliasRecord,
  ensureUserProfile,
  fetchActivityLogs,
  fetchDeviceAliases,
  fetchSpeedTests,
  persistSpeedTest,
  signInWithGoogle,
  signOutGoogle,
  subscribeAuthState,
  ThemeMode,
  updateUserPreferences,
  upsertDeviceAlias,
  UserProfileData
} from '../services/firebaseService';
import {
  ActiveRouterSession,
  applyRouterWifiUpdate,
  blockRouterDevice,
  checkLocalConnectorStatus,
  connectToRouter,
  disconnectRouterSession,
  ensureValidCoreToken,
  executeAutoFallbackConnection,
  fetchServerCoreStatus,
  getCoreSessionSnapshot,
  LocalConnectorHealth,
  rebootConnectedRouter,
  refreshRouterSession,
  stopLocalConnector,
  toggleGuestWifi,
  toggleInternetAccess,
  TransportMode,
  unblockRouterDevice
} from '../services/routerConnection';
import { SpeedTestMeasurement } from '../services/speedTest';
import { normalizeMac } from '../utils/networkSecurity';

export type PageId =
  | 'dashboard'
  | 'floor-plan'
  | 'wifi-settings'
  | 'speed-test'
  | 'diagnostics'
  | 'devices'
  | 'activity-log'
  | 'router-connection'
  | 'local-connector'
  | 'account'
  | 'login';

const THEME_STORAGE_KEY = 'aw_ui_theme';

interface AppContextValue {
  page: PageId;
  setPage: (p: PageId) => void;
  navigateBack: () => boolean;
  canNavigateBack: boolean;
  theme: ThemeMode;
  toggleTheme: () => void;
  setTheme: (t: ThemeMode) => void;
  changeLanguage: (lang: LanguageCode) => void;

  user: User | null;
  authReady: boolean;
  userProfile: UserProfileData | null;
  signInGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  updateSessionTimeout: (minutes: number) => Promise<void>;

  isNativeAndroid: boolean;
  nativeEnv: NativeAndroidEnv | null;
  refreshNativeEnvironment: () => Promise<NativeAndroidEnv | null>;
  simulationMode: boolean;
  setSimulationMode: (enabled: boolean) => void;
  simulationScenario: SimulationScenario;
  setSimulationScenario: (scenario: SimulationScenario) => void;
  triggerSimulatedSessionExpiry: () => Promise<void>;

  routerSession: ActiveRouterSession | null;
  routerConnecting: boolean;
  routerError: RouterErrorCode | null;
  clearRouterError: () => void;
  connectorToken: string;
  setConnectorToken: (token: string) => void;
  connectorHealth: LocalConnectorHealth;
  connectorChecking: boolean;
  refreshConnectorStatus: (overrideToken?: string) => Promise<LocalConnectorHealth>;
  stopConnector: () => Promise<boolean>;
  connectionDiagnostics: ConnectionDiagnosticsState;
  lanBridgeUrl: string;
  setLanBridgeUrl: (url: string) => void;
  refreshConnectionEnvironment: () => Promise<void>;
  probeRouterConnection: (params: {
    rawAddress: string;
    autoDiscoverGateways?: boolean;
    lanBridgeUrl?: string;
  }) => Promise<ConnectionDiagnosticsState>;
  connectRouterWithFallback: (params: {
    rawAddress: string;
    autoDiscoverGateways?: boolean;
    preferredAdapterId: RouterAdapterId | 'auto';
    credentials: RouterCredentials;
    lanBridgeUrl?: string;
  }) => Promise<{ ok: boolean; errorCode: RouterErrorCode | null; activeMethod: ConnectionMethodId | null }>;
  connectRouter: (params: {
    rawAddress: string;
    preferredAdapterId: RouterAdapterId | 'auto';
    credentials: RouterCredentials;
    transportMode: TransportMode;
    simulationScenario?: SimulationScenario;
  }) => Promise<boolean>;
  refreshRouter: () => Promise<void>;
  updateWifi: (update: WifiUpdateInput) => Promise<void>;
  blockDevice: (mac: string) => Promise<void>;
  unblockDevice: (mac: string) => Promise<void>;
  rebootRouter: () => Promise<void>;
  setGuestWifi: (enabled: boolean) => Promise<void>;
  setInternetBlocked: (blocked: boolean) => Promise<void>;
  disconnectRouter: () => Promise<void>;
  autoRefresh: boolean;
  setAutoRefresh: (v: boolean) => void;

  speedHistory: SpeedTestMeasurement[];
  latestSpeed: SpeedTestMeasurement | null;
  recordSpeedTest: (m: SpeedTestMeasurement) => Promise<void>;

  diagnosticsReport: DiagnosticsReport;
  runDiagnosticsCheck: () => Promise<void>;
  modemDiagnosticsReport: ModemDiagnosticReport | null;
  runningModemDiagnostics: boolean;
  runModemProtocolCheck: (params?: {
    rawAddress?: string;
    preferredAdapterId?: RouterAdapterId | 'auto';
    credentials?: RouterCredentials;
    transportMode?: TransportMode;
  }) => Promise<ModemDiagnosticReport>;

  activityLogs: ActivityLogRecord[];
  logEvent: (
    actionType: ActivityActionType,
    target: string,
    status: 'success' | 'failure' | 'info',
    details: string
  ) => Promise<void>;

  deviceAliases: Record<string, DeviceAliasRecord>;
  seenMacs: Set<string>;
  saveDeviceAlias: (mac: string, customName: string, trustStatus: 'known' | 'unknown') => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { language, setLanguage } = useI18n();
  const [pageHistory, setPageHistory] = useState<PageId[]>(['dashboard']);
  const page = pageHistory[pageHistory.length - 1] ?? 'dashboard';
  const setPage = useCallback((nextPage: PageId) => {
    setPageHistory((prev) => {
      if (prev[prev.length - 1] === nextPage) return prev;
      if (nextPage === 'dashboard') return ['dashboard'];
      return [...prev, nextPage].slice(-20);
    });
  }, []);
  const navigateBack = useCallback((): boolean => {
    let handled = false;
    setPageHistory((prev) => {
      if (prev.length > 1) {
        handled = true;
        return prev.slice(0, -1);
      }
      if (prev[0] !== 'dashboard') {
        handled = true;
        return ['dashboard'];
      }
      handled = false;
      return prev;
    });
    return handled;
  }, []);

  const [theme, setThemeState] = useState<ThemeMode>(() => {
    try {
      const saved = localStorage.getItem(THEME_STORAGE_KEY);
      if (saved === 'dark' || saved === 'light') return saved;
    } catch {
      // Ignore storage errors
    }
    return 'light';
  });

  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfileData | null>(null);

  const [isNativeAndroid, setIsNativeAndroid] = useState<boolean>(() => isNativeAndroidApp());
  const [nativeEnv, setNativeEnv] = useState<NativeAndroidEnv | null>(null);
  const [simulationModeState, setSimulationModeState] = useState<boolean>(false);
  const [simulationScenario, setSimulationScenario] = useState<SimulationScenario>('normal');

  const simulationMode = isNativeAndroid ? false : simulationModeState;
  const setSimulationMode = useCallback(
    (enabled: boolean) => {
      if (isNativeAndroidApp()) {
        setSimulationModeState(false);
        return;
      }
      setSimulationModeState(enabled);
      if (!enabled) {
        resetHuaweiSimulatorState();
      }
    },
    []
  );

  const [routerSession, setRouterSession] = useState<ActiveRouterSession | null>(null);
  const [routerConnecting, setRouterConnecting] = useState(false);
  const [routerError, setRouterError] = useState<RouterErrorCode | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [connectorToken, setConnectorToken] = useState('');
  const [connectorHealth, setConnectorHealth] = useState<LocalConnectorHealth>({
    reachable: false,
    authVerified: false,
    originBlocked: false
  });
  const [connectorChecking, setConnectorChecking] = useState(false);
  const [lanBridgeUrl, setLanBridgeUrl] = useState('');
  const [connectionDiagnostics, setConnectionDiagnostics] = useState<ConnectionDiagnosticsState>(() => {
    const native = isNativeAndroidApp();
    const base = createInitialDiagnosticsState(HUAWEI_DEFAULT_GATEWAY);
    if (!native) return base;
    return {
      ...base,
      serverTopology: 'local-lan',
      methodResults: getEffectiveMethodOrder(true).map((methodId) => ({
        methodId,
        status: 'not_tested',
        latencyMs: 0,
        gatewayIp: HUAWEI_DEFAULT_GATEWAY,
        checkedAtIso: ''
      }))
    };
  });

  const [speedHistory, setSpeedHistory] = useState<SpeedTestMeasurement[]>([]);
  const [modemDiagnosticsReport, setModemDiagnosticsReport] = useState<ModemDiagnosticReport | null>(null);
  const [runningModemDiagnostics, setRunningModemDiagnostics] = useState(false);
  const [activityLogs, setActivityLogs] = useState<ActivityLogRecord[]>([]);
  const [deviceAliases, setDeviceAliases] = useState<Record<string, DeviceAliasRecord>>({});
  const [seenMacs, setSeenMacs] = useState<Set<string>>(() => new Set());

  // Sync theme class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem(THEME_STORAGE_KEY, theme);
    } catch {
      // Ignore storage errors
    }
  }, [theme]);

  // Subscribe to Firebase Auth
  useEffect(() => {
    const unsub = subscribeAuthState(async (nextUser) => {
      setUser(nextUser);
      if (nextUser) {
        try {
          const profile = await ensureUserProfile(nextUser, { language, theme });
          setUserProfile(profile);
          if (profile.language && profile.language !== language) {
            setLanguage(profile.language);
          }
          if (profile.theme && profile.theme !== theme) {
            setThemeState(profile.theme);
          }

          const [logs, tests, aliases] = await Promise.all([
            fetchActivityLogs(nextUser.uid),
            fetchSpeedTests(nextUser.uid),
            fetchDeviceAliases(nextUser.uid)
          ]);
          setActivityLogs(logs);
          setSpeedHistory(
            tests.map((t) => ({
              id: t.id,
              serverName: t.serverName,
              downloadMbps: t.downloadMbps,
              uploadMbps: t.uploadMbps,
              pingMs: t.pingMs,
              jitterMs: t.jitterMs,
              packetLossPct: t.packetLossPct,
              measuredAtIso: t.createdAtIso
            }))
          );
          setDeviceAliases(aliases);
        } catch (err) {
          console.error('Failed loading user data:', err instanceof Error ? err.message : String(err));
        }
      } else {
        setUserProfile(null);
      }
      setAuthReady(true);
    });
    return () => unsub();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Session idle timeout enforcement when user is signed in
  useEffect(() => {
    if (!user || !userProfile?.sessionTimeoutMinutes) return;
    const timeoutMs = userProfile.sessionTimeoutMinutes * 60 * 1000;
    let timer = setTimeout(() => {
      void signOutGoogle();
    }, timeoutMs);

    const resetTimer = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        void signOutGoogle();
      }, timeoutMs);
    };

    window.addEventListener('pointerdown', resetTimer);
    window.addEventListener('keydown', resetTimer);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('pointerdown', resetTimer);
      window.removeEventListener('keydown', resetTimer);
    };
  }, [user, userProfile?.sessionTimeoutMinutes]);

  const setTheme = useCallback(
    (next: ThemeMode) => {
      setThemeState(next);
      if (user) {
        void updateUserPreferences(user.uid, { theme: next }).catch(() => undefined);
      }
    },
    [user]
  );

  const toggleTheme = useCallback(() => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  }, [theme, setTheme]);

  const changeLanguage = useCallback(
    (lang: LanguageCode) => {
      setLanguage(lang);
      if (user) {
        void updateUserPreferences(user.uid, { language: lang }).catch(() => undefined);
      }
    },
    [setLanguage, user]
  );

  const logEvent = useCallback(
    async (
      actionType: ActivityActionType,
      target: string,
      status: 'success' | 'failure' | 'info',
      details: string
    ) => {
      const localRecord: ActivityLogRecord = {
        id: `local_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        userId: user?.uid || 'local',
        actionType,
        target,
        status,
        details,
        createdAtIso: new Date().toISOString()
      };
      setActivityLogs((prev) => [localRecord, ...prev].slice(0, 50));

      if (user) {
        try {
          await createActivityLog(user.uid, { actionType, target, status, details });
        } catch (err) {
          console.error('Activity log sync failed:', err instanceof Error ? err.message : String(err));
        }
      }
    },
    [user]
  );

  const signInGoogle = useCallback(async () => {
    await signInWithGoogle();
    setPage('dashboard');
  }, []);

  const signOut = useCallback(async () => {
    await signOutGoogle();
    setActivityLogs([]);
    setSpeedHistory([]);
    setDeviceAliases({});
  }, []);

  const updateSessionTimeout = useCallback(
    async (minutes: number) => {
      const clamped = Math.min(1440, Math.max(5, Math.round(minutes)));
      setUserProfile((prev) => (prev ? { ...prev, sessionTimeoutMinutes: clamped } : prev));
      if (user) {
        await updateUserPreferences(user.uid, { sessionTimeoutMinutes: clamped });
      }
    },
    [user]
  );

  const refreshConnectorStatus = useCallback(
    async (overrideToken?: string): Promise<LocalConnectorHealth> => {
      setConnectorChecking(true);
      try {
        const tokenToUse = overrideToken !== undefined ? overrideToken : connectorToken;
        const status = await checkLocalConnectorStatus(tokenToUse);
        setConnectorHealth(status);
        return status;
      } finally {
        setConnectorChecking(false);
      }
    },
    [connectorToken]
  );

  const stopConnector = useCallback(async (): Promise<boolean> => {
    const ok = await stopLocalConnector(connectorToken);
    if (ok) {
      setConnectorHealth({
        reachable: false,
        authVerified: false,
        originBlocked: false,
        checkedAtIso: new Date().toISOString()
      });
    }
    return ok;
  }, [connectorToken]);

  const refreshNativeEnvironment = useCallback(async (): Promise<NativeAndroidEnv | null> => {
    const detected = isNativeAndroidApp();
    setIsNativeAndroid(detected);
    if (!detected) {
      setNativeEnv(null);
      return null;
    }
    setSimulationModeState(false);
    setPageHistory((prev) =>
      prev.map((p) => (p === 'local-connector' ? 'router-connection' : p))
    );
    const env = await getNativeEnvironment();
    setNativeEnv(env);
    return env;
  }, []);

  useEffect(() => {
    void refreshNativeEnvironment();
  }, [refreshNativeEnvironment]);

  const refreshConnectionEnvironment = useCallback(async () => {
    const native = await refreshNativeEnvironment();
    if (native) {
      setConnectionDiagnostics((prev) => ({
        ...prev,
        serverTopology: 'local-lan',
        targetGateway: native.gatewayIp || prev.targetGateway,
        methodResults:
          prev.methodResults[0]?.methodId === 'android_native_bridge'
            ? prev.methodResults
            : getEffectiveMethodOrder(true).map((methodId) => ({
                methodId,
                status: 'not_tested',
                latencyMs: 0,
                gatewayIp: native.gatewayIp || prev.targetGateway,
                checkedAtIso: ''
              }))
      }));
      return;
    }
    const [coreStatus, coreSession] = await Promise.all([
      fetchServerCoreStatus(),
      ensureValidCoreToken()
    ]);
    setConnectionDiagnostics((prev) => ({
      ...prev,
      serverTopology: coreStatus.topology,
      coreSession: coreSession ?? getCoreSessionSnapshot()
    }));
  }, [refreshNativeEnvironment]);

  const probeRouterConnection = useCallback(
    async (params: {
      rawAddress: string;
      autoDiscoverGateways?: boolean;
      lanBridgeUrl?: string;
    }): Promise<ConnectionDiagnosticsState> => {
      setRouterConnecting(true);
      setRouterError(null);
      setConnectionDiagnostics((prev) => ({
        ...prev,
        state: 'probing',
        targetGateway: params.rawAddress.trim() || prev.targetGateway
      }));

      try {
        const result = await executeAutoFallbackConnection({
          rawAddress: params.rawAddress,
          autoDiscoverGateways: params.autoDiscoverGateways,
          preferredAdapterId: 'auto',
          credentials: { username: '', password: '' },
          mode: 'probe',
          connectorToken,
          lanBridgeUrl: params.lanBridgeUrl ?? lanBridgeUrl,
          priorAttemptsLog: connectionDiagnostics.attemptsLog
        });
        const finalDiagnostics: ConnectionDiagnosticsState = {
          ...result.diagnostics,
          state: routerSession ? 'connected' : result.ok ? 'modem_reachable' : 'failed',
          authState: routerSession ? 'authenticated' : result.diagnostics.authState
        };
        setConnectionDiagnostics(finalDiagnostics);
        return finalDiagnostics;
      } finally {
        setRouterConnecting(false);
      }
    },
    [connectorToken, lanBridgeUrl, connectionDiagnostics.attemptsLog, routerSession]
  );

  const connectRouterWithFallback = useCallback(
    async (params: {
      rawAddress: string;
      autoDiscoverGateways?: boolean;
      preferredAdapterId: RouterAdapterId | 'auto';
      credentials: RouterCredentials;
      lanBridgeUrl?: string;
    }) => {
      setRouterConnecting(true);
      setRouterError(null);
      setConnectionDiagnostics((prev) => ({
        ...prev,
        state: 'connecting',
        authState: 'authenticating',
        targetGateway: params.rawAddress.trim() || prev.targetGateway
      }));

      try {
        const result = await executeAutoFallbackConnection({
          rawAddress: params.rawAddress,
          autoDiscoverGateways: params.autoDiscoverGateways,
          preferredAdapterId: params.preferredAdapterId,
          credentials: params.credentials,
          mode: 'connect',
          connectorToken,
          lanBridgeUrl: params.lanBridgeUrl ?? lanBridgeUrl,
          priorAttemptsLog: connectionDiagnostics.attemptsLog,
          onStageChange: (stage) => {
            setConnectionDiagnostics((prev) => ({
              ...prev,
              state: stage,
              authState:
                stage === 'login_failed'
                  ? 'rejected'
                  : stage === 'authenticated' || stage === 'data_read_failed' || stage === 'connected'
                  ? 'authenticated'
                  : prev.authState
            }));
          }
        });

        setConnectionDiagnostics(result.diagnostics);

        if (result.ok && result.session) {
          setRouterSession(result.session);
          setSeenMacs((prev) => {
            const next = new Set(prev);
            result.session!.devices.forEach((d) => next.add(normalizeMac(d.macAddress)));
            return next;
          });
          await logEvent(
            'router_connect',
            result.session.routerInfo.gatewayIp,
            'success',
            `${result.session.routerInfo.vendor} ${result.session.routerInfo.model || 'ONT'} · ${result.winningMethod}`
          );
          return {
            ok: true,
            errorCode: null,
            activeMethod: result.winningMethod
          };
        }

        const errCode: RouterErrorCode = result.diagnostics.lastErrorCode ?? 'ROUTER_OFFLINE';
        setRouterError(errCode);
        await logEvent(
          'router_connect',
          result.diagnostics.targetGateway || 'gateway',
          'failure',
          errCode
        );
        return {
          ok: false,
          errorCode: errCode,
          activeMethod: null
        };
      } finally {
        setRouterConnecting(false);
      }
    },
    [connectorToken, lanBridgeUrl, connectionDiagnostics.attemptsLog, logEvent]
  );

  const connectRouter = useCallback(
    async (params: {
      rawAddress: string;
      preferredAdapterId: RouterAdapterId | 'auto';
      credentials: RouterCredentials;
      transportMode: TransportMode;
      simulationScenario?: SimulationScenario;
    }) => {
      setRouterConnecting(true);
      setRouterError(null);
      setConnectionDiagnostics((prev) => ({
        ...prev,
        state: 'connecting',
        authState: 'authenticating',
        targetGateway: params.rawAddress.trim() || prev.targetGateway
      }));
      const startedAt = Date.now();
      try {
        const session = await connectToRouter({
          ...params,
          connectorToken,
          simulationScenario: params.simulationScenario ?? simulationScenario,
          onStageChange: (stage) => {
            setConnectionDiagnostics((prev) => ({
              ...prev,
              state: stage,
              authState:
                stage === 'login_failed'
                  ? 'rejected'
                  : stage === 'authenticated' || stage === 'data_read_failed' || stage === 'connected'
                  ? 'authenticated'
                  : prev.authState
            }));
          }
        });
        setRouterSession(session);
        setConnectionDiagnostics((prev) => ({
          ...prev,
          state: 'connected',
          targetGateway: session.routerInfo.gatewayIp,
          activeMethod: session.connectionMethod,
          authState: 'authenticated',
          lastLatencyMs: Math.max(1, Date.now() - startedAt),
          lastErrorCode: null,
          checkedAtIso: new Date().toISOString()
        }));
        setSeenMacs((prev) => {
          const next = new Set(prev);
          session.devices.forEach((d) => next.add(normalizeMac(d.macAddress)));
          return next;
        });
        await logEvent(
          'router_connect',
          session.routerInfo.gatewayIp,
          'success',
          `${session.routerInfo.vendor} ${session.routerInfo.model || 'ONT'} (${session.connectionMethod})`
        );
        return true;
      } catch (err) {
        const code: RouterErrorCode = err instanceof RouterError ? err.code : 'ROUTER_OFFLINE';
        const nextState: ConnectionDiagnosticsState['state'] =
          code === 'INVALID_CREDENTIALS'
            ? 'login_failed'
            : code === 'DATA_READ_FAILED'
            ? 'data_read_failed'
            : 'failed';
        setRouterError(code);
        setConnectionDiagnostics((prev) => ({
          ...prev,
          state: nextState,
          authState:
            code === 'INVALID_CREDENTIALS'
              ? 'rejected'
              : code === 'DATA_READ_FAILED'
              ? 'authenticated'
              : 'unauthenticated',
          lastErrorCode: code,
          checkedAtIso: new Date().toISOString()
        }));
        await logEvent('router_connect', params.rawAddress.trim() || 'gateway', 'failure', code);
        return false;
      } finally {
        setRouterConnecting(false);
      }
    },
    [logEvent, connectorToken, simulationScenario]
  );

  const handleSessionExpiryIfNeeded = useCallback(
    (code: RouterErrorCode, targetIp?: string) => {
      if (code !== 'SESSION_EXPIRED') return;
      setRouterSession(null);
      setAutoRefresh(false);
      setRouterError('SESSION_EXPIRED');
      setConnectionDiagnostics((prev) => ({
        ...prev,
        state: 'disconnected',
        activeMethod: null,
        authState: 'unauthenticated',
        lastErrorCode: 'SESSION_EXPIRED',
        checkedAtIso: new Date().toISOString()
      }));
      void logEvent('router_disconnect', targetIp || 'router', 'failure', 'SESSION_EXPIRED');
    },
    [logEvent]
  );

  const refreshRouter = useCallback(async () => {
    if (!routerSession) return;
    try {
      const updated = await refreshRouterSession(routerSession);
      setRouterSession(updated);
    } catch (err) {
      const code: RouterErrorCode = err instanceof RouterError ? err.code : 'SESSION_EXPIRED';
      setRouterError(code);
      handleSessionExpiryIfNeeded(code, routerSession.routerInfo.gatewayIp);
    }
  }, [routerSession, handleSessionExpiryIfNeeded]);

  const triggerSimulatedSessionExpiry = useCallback(async () => {
    if (isNativeAndroidApp() || !routerSession || routerSession.transportMode !== 'simulation') return;
    expireSimulatedHuaweiSession();
    await refreshRouter();
  }, [routerSession, refreshRouter]);

  // Optional auto-refresh when router is connected
  useEffect(() => {
    if (!autoRefresh || !routerSession) return;
    const id = setInterval(() => {
      void refreshRouter();
    }, 15000);
    return () => clearInterval(id);
  }, [autoRefresh, routerSession, refreshRouter]);

  const updateWifi = useCallback(
    async (update: WifiUpdateInput) => {
      if (!routerSession) throw new RouterError('ROUTER_OFFLINE');
      try {
        const updated = await applyRouterWifiUpdate(routerSession, update);
        setRouterSession(updated);
        // Never log password in activity log!
        const actionType: ActivityActionType =
          update.password !== undefined ? 'wifi_password_change' : 'wifi_ssid_change';
        await logEvent(
          actionType,
          `${update.band} · ${update.ssid}`,
          'success',
          `Encryption=${update.encryption}, Enabled=${update.enabled !== false}`
        );
      } catch (err) {
        const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
        setRouterError(code);
        await logEvent('wifi_settings_change', `${update.band} · ${update.ssid}`, 'failure', code);
        handleSessionExpiryIfNeeded(code, routerSession.routerInfo.gatewayIp);
        throw err;
      }
    },
    [routerSession, logEvent, handleSessionExpiryIfNeeded]
  );

  const blockDevice = useCallback(
    async (mac: string) => {
      if (!routerSession) throw new RouterError('ROUTER_OFFLINE');
      const norm = normalizeMac(mac);
      try {
        const updated = await blockRouterDevice(routerSession, norm);
        setRouterSession(updated);
        await logEvent('device_block', norm, 'success', 'MAC ACL block applied');
      } catch (err) {
        const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
        await logEvent('device_block', norm, 'failure', code);
        handleSessionExpiryIfNeeded(code, routerSession.routerInfo.gatewayIp);
        throw err;
      }
    },
    [routerSession, logEvent, handleSessionExpiryIfNeeded]
  );

  const unblockDevice = useCallback(
    async (mac: string) => {
      if (!routerSession) throw new RouterError('ROUTER_OFFLINE');
      const norm = normalizeMac(mac);
      try {
        const updated = await unblockRouterDevice(routerSession, norm);
        setRouterSession(updated);
        await logEvent('device_unblock', norm, 'success', 'MAC ACL block removed');
      } catch (err) {
        const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
        await logEvent('device_unblock', norm, 'failure', code);
        handleSessionExpiryIfNeeded(code, routerSession.routerInfo.gatewayIp);
        throw err;
      }
    },
    [routerSession, logEvent, handleSessionExpiryIfNeeded]
  );

  const rebootRouter = useCallback(async () => {
    if (!routerSession) throw new RouterError('ROUTER_OFFLINE');
    const ip = routerSession.routerInfo.gatewayIp;
    try {
      await rebootConnectedRouter(routerSession);
      await logEvent('router_reboot', ip, 'success', `${routerSession.routerInfo.vendor} reboot command sent`);
      setRouterSession(null);
      setAutoRefresh(false);
    } catch (err) {
      const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
      await logEvent('router_reboot', ip, 'failure', code);
      handleSessionExpiryIfNeeded(code, ip);
      throw err;
    }
  }, [routerSession, logEvent, handleSessionExpiryIfNeeded]);

  const setGuestWifi = useCallback(
    async (enabled: boolean) => {
      if (!routerSession) throw new RouterError('ROUTER_OFFLINE');
      const ip = routerSession.routerInfo.gatewayIp;
      try {
        const updated = await toggleGuestWifi(routerSession, enabled);
        setRouterSession(updated);
        await logEvent('guest_wifi_toggle', ip, 'success', `Guest Wi-Fi ${enabled ? 'enabled' : 'disabled'}`);
      } catch (err) {
        const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
        await logEvent('guest_wifi_toggle', ip, 'failure', code);
        handleSessionExpiryIfNeeded(code, ip);
        throw err;
      }
    },
    [routerSession, logEvent, handleSessionExpiryIfNeeded]
  );

  const setInternetBlocked = useCallback(
    async (blocked: boolean) => {
      if (!routerSession) throw new RouterError('ROUTER_OFFLINE');
      const ip = routerSession.routerInfo.gatewayIp;
      try {
        const updated = await toggleInternetAccess(routerSession, blocked);
        setRouterSession(updated);
        await logEvent(
          'internet_access_toggle',
          ip,
          'success',
          blocked ? 'All WAN internet paused' : 'WAN internet restored'
        );
      } catch (err) {
        const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
        await logEvent('internet_access_toggle', ip, 'failure', code);
        handleSessionExpiryIfNeeded(code, ip);
        throw err;
      }
    },
    [routerSession, logEvent, handleSessionExpiryIfNeeded]
  );

  const disconnectRouter = useCallback(async () => {
    if (!routerSession) return;
    const ip = routerSession.routerInfo.gatewayIp;
    await disconnectRouterSession(routerSession);
    setRouterSession(null);
    setAutoRefresh(false);
    setConnectionDiagnostics((prev) => ({
      ...prev,
      state: 'disconnected',
      activeMethod: null,
      authState: 'unauthenticated',
      coreSession: getCoreSessionSnapshot(),
      checkedAtIso: new Date().toISOString()
    }));
    await logEvent('router_disconnect', ip, 'info', 'Session closed cleanly');
  }, [routerSession, logEvent]);

  const recordSpeedTest = useCallback(
    async (measurement: SpeedTestMeasurement) => {
      setSpeedHistory((prev) => [measurement, ...prev].slice(0, 25));
      if (user) {
        try {
          await persistSpeedTest(user.uid, {
            serverName: measurement.serverName,
            downloadMbps: measurement.downloadMbps,
            uploadMbps: measurement.uploadMbps,
            pingMs: measurement.pingMs,
            jitterMs: measurement.jitterMs,
            packetLossPct: measurement.packetLossPct
          });
        } catch (err) {
          console.error('Speed test save failed:', err instanceof Error ? err.message : String(err));
        }
      }
      await logEvent(
        'speed_test',
        measurement.serverName,
        'success',
        `DL ${measurement.downloadMbps} Mbps / UL ${measurement.uploadMbps} Mbps / Ping ${measurement.pingMs} ms`
      );
    },
    [user, logEvent]
  );

  const latestSpeed = speedHistory[0] ?? null;

  const diagnosticsReport = useMemo(
    () =>
      analyzeNetworkDiagnostics({
        latestSpeed,
        speedHistory,
        routerConnected: Boolean(routerSession),
        routerInfo: routerSession?.routerInfo ?? null,
        wifiSettings: routerSession?.wifiSettings ?? null,
        devices: routerSession?.devices ?? []
      }),
    [latestSpeed, speedHistory, routerSession]
  );

  const runDiagnosticsCheck = useCallback(async () => {
    if (routerSession) {
      await refreshRouter();
    }
    await logEvent(
      'diagnostics_run',
      routerSession ? routerSession.routerInfo.gatewayIp : 'local-client',
      'info',
      `Confirmed=${diagnosticsReport.confirmed.length}, Possible=${diagnosticsReport.possible.length}`
    );
  }, [routerSession, refreshRouter, logEvent, diagnosticsReport]);

  const runModemProtocolCheck = useCallback(
    async (params?: {
      rawAddress?: string;
      preferredAdapterId?: RouterAdapterId | 'auto';
      credentials?: RouterCredentials;
      transportMode?: TransportMode;
    }): Promise<ModemDiagnosticReport> => {
      setRunningModemDiagnostics(true);
      try {
        const resolvedMode: TransportMode =
          params?.transportMode ??
          routerSession?.transportMode ??
          (simulationMode && !isNativeAndroid
            ? 'simulation'
            : isNativeAndroid
            ? 'native_bridge'
            : 'direct');

        const report = await runModemProtocolDiagnostics({
          rawAddress:
            params?.rawAddress?.trim() ||
            routerSession?.routerInfo.gatewayIp ||
            nativeEnv?.gatewayIp ||
            connectionDiagnostics.targetGateway ||
            HUAWEI_DEFAULT_GATEWAY,
          preferredAdapterId:
            params?.preferredAdapterId ??
            routerSession?.adapter.id ??
            'auto',
          credentials:
            params?.credentials ??
            (resolvedMode === 'simulation'
              ? { username: 'admin', password: 'admin' }
              : { username: 'admin', password: '' }),
          transportMode: resolvedMode,
          connectorToken,
          lanBridgeUrl,
          simulationScenario
        });

        setModemDiagnosticsReport(report);
        const passedCount = report.stages.filter(
          (s) => s.outcome === 'passed' || s.outcome === 'supported'
        ).length;
        await logEvent(
          'diagnostics_run',
          report.targetUrl,
          'info',
          `10-stage probe: ${passedCount}/10 passed (${report.transportMode})`
        );
        return report;
      } finally {
        setRunningModemDiagnostics(false);
      }
    },
    [
      routerSession,
      simulationMode,
      isNativeAndroid,
      nativeEnv?.gatewayIp,
      connectionDiagnostics.targetGateway,
      connectorToken,
      lanBridgeUrl,
      simulationScenario,
      logEvent
    ]
  );

  const saveDeviceAlias = useCallback(
    async (mac: string, customName: string, trustStatus: 'known' | 'unknown') => {
      const norm = normalizeMac(mac);
      const record: DeviceAliasRecord = {
        macAddress: norm,
        customName: customName.trim().slice(0, 80),
        trustStatus
      };
      setDeviceAliases((prev) => ({ ...prev, [norm]: record }));
      if (user) {
        await upsertDeviceAlias(user.uid, record);
      }
    },
    [user]
  );

  return (
    <AppContext.Provider
      value={{
        page,
        setPage,
        navigateBack,
        canNavigateBack: pageHistory.length > 1 || page !== 'dashboard',
        theme,
        toggleTheme,
        setTheme,
        changeLanguage,
        user,
        authReady,
        userProfile,
        signInGoogle,
        signOut,
        updateSessionTimeout,
        isNativeAndroid,
        nativeEnv,
        refreshNativeEnvironment,
        simulationMode,
        setSimulationMode,
        simulationScenario,
        setSimulationScenario,
        triggerSimulatedSessionExpiry,
        routerSession,
        routerConnecting,
        routerError,
        clearRouterError: () => setRouterError(null),
        connectorToken,
        setConnectorToken,
        connectorHealth,
        connectorChecking,
        refreshConnectorStatus,
        stopConnector,
        connectionDiagnostics,
        lanBridgeUrl,
        setLanBridgeUrl,
        refreshConnectionEnvironment,
        probeRouterConnection,
        connectRouterWithFallback,
        connectRouter,
        refreshRouter,
        updateWifi,
        blockDevice,
        unblockDevice,
        rebootRouter,
        setGuestWifi,
        setInternetBlocked,
        disconnectRouter,
        autoRefresh,
        setAutoRefresh,
        speedHistory,
        latestSpeed,
        recordSpeedTest,
        diagnosticsReport,
        runDiagnosticsCheck,
        modemDiagnosticsReport,
        runningModemDiagnostics,
        runModemProtocolCheck,
        activityLogs,
        logEvent,
        deviceAliases,
        seenMacs,
        saveDeviceAlias
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
