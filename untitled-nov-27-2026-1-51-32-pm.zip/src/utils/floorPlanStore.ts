import {
  autoArrangeFloorRooms,
  clampRouterToFloor,
  createDefaultSurveyProject,
  DEFAULT_ROOM_H_M,
  DEFAULT_ROOM_W_M,
  FLOOR_MARGIN_M,
  FloorLayoutTemplate,
  FloorPlan,
  FloorRoom,
  HomeSurveyProject,
  MAX_ROOM_M,
  MIN_ROOM_M,
  round1,
  RouterScenarioId,
  updateFloorBoundsAndWalls
} from './floorPlanEngine';

const DB_NAME = 'advanced_wifi_home_surveys';
const DB_VERSION = 1;
const STORE_NAME = 'surveys';
const RECORD_KEY_V2 = 'active_home_survey_v2';
const RECORD_KEY_V1 = 'active_home_survey_v1';
const LS_FALLBACK_KEY_V2 = 'aw_home_survey_project_v2';
const LS_FALLBACK_KEY_V1 = 'aw_home_survey_project_v1';

interface RawV1FloorPlan {
  id: string;
  index: number;
  name: string;
  widthMeters?: number;
  heightMeters?: number;
  rooms: FloorRoom[];
}

interface RawV1SurveyProject {
  version: 1;
  updatedAtIso: string;
  floors: RawV1FloorPlan[];
  activeFloorId: string;
  activeScenarioId: RouterScenarioId;
  scenarios: HomeSurveyProject['scenarios'];
  measurements: HomeSurveyProject['measurements'];
}

export function isValidSurveyProjectV2(candidate: unknown): candidate is HomeSurveyProject {
  if (!candidate || typeof candidate !== 'object') return false;
  const obj = candidate as Partial<HomeSurveyProject>;
  if (obj.version !== 2) return false;
  if (!Array.isArray(obj.floors) || obj.floors.length === 0) return false;
  if (typeof obj.activeFloorId !== 'string' || !obj.activeFloorId) return false;
  if (!obj.scenarios || typeof obj.scenarios !== 'object') return false;
  for (const sid of ['original', 'alt-a', 'alt-b'] as RouterScenarioId[]) {
    if (!obj.scenarios[sid] || !obj.scenarios[sid].routerPlacement) return false;
  }
  if (!Array.isArray(obj.measurements)) return false;
  return obj.floors.every(
    (f) =>
      typeof f.canvasWidth === 'number' &&
      typeof f.canvasHeight === 'number' &&
      Array.isArray(f.rooms) &&
      f.rooms.length > 0
  );
}

export function isValidSurveyProjectV1(candidate: unknown): candidate is RawV1SurveyProject {
  if (!candidate || typeof candidate !== 'object') return false;
  const obj = candidate as Partial<RawV1SurveyProject>;
  if (obj.version !== 1) return false;
  if (!Array.isArray(obj.floors) || obj.floors.length === 0) return false;
  if (typeof obj.activeFloorId !== 'string' || !obj.activeFloorId) return false;
  if (!obj.scenarios || typeof obj.scenarios !== 'object') return false;
  for (const sid of ['original', 'alt-a', 'alt-b'] as RouterScenarioId[]) {
    if (!obj.scenarios[sid] || !obj.scenarios[sid].routerPlacement) return false;
  }
  if (!Array.isArray(obj.measurements)) return false;
  return true;
}

/**
 * Migrates a legacy v1 project (0..100 normalized coords) cleanly to v2 metric adaptive coords
 * while preserving EVERY floor ID, room ID, room name, room category, router scenarios, and measurements.
 */
export function migrateV1ToV2Project(v1: RawV1SurveyProject): HomeSurveyProject {
  const migratedFloors: FloorPlan[] = v1.floors.map((f) => {
    const scaleW = Math.max(8, f.widthMeters ?? 12);
    const scaleH = Math.max(6, f.heightMeters ?? 8);
    const convertedRooms: FloorRoom[] = (f.rooms || []).map((r) => ({
      id: r.id,
      name: r.name,
      category: r.category,
      x: FLOOR_MARGIN_M,
      y: FLOOR_MARGIN_M,
      width: round1(Math.max(MIN_ROOM_M, Math.min(MAX_ROOM_M, ((r.width || 30) / 100) * scaleW || DEFAULT_ROOM_W_M))),
      height: round1(Math.max(MIN_ROOM_M, Math.min(MAX_ROOM_M, ((r.height || 30) / 100) * scaleH || DEFAULT_ROOM_H_M)))
    }));

    const template: FloorLayoutTemplate = 'grid';
    const arranged = autoArrangeFloorRooms(convertedRooms, template, false);
    return updateFloorBoundsAndWalls({
      id: f.id,
      index: f.index,
      name: f.name,
      layoutTemplate: template,
      includeCorridor: false,
      canvasWidth: 12,
      canvasHeight: 8,
      widthMeters: scaleW,
      heightMeters: scaleH,
      rooms: arranged,
      segments: []
    });
  });

  const floorById = new Map(migratedFloors.map((fl) => [fl.id, fl]));
  const nextScenarios = { ...v1.scenarios };
  (['original', 'alt-a', 'alt-b'] as RouterScenarioId[]).forEach((sid) => {
    const sc = nextScenarios[sid];
    const targetFloor = floorById.get(sc.routerPlacement.floorId) ?? migratedFloors[0];
    const rx = round1(((sc.routerPlacement.x ?? 50) / 100) * targetFloor.canvasWidth);
    const ry = round1(((sc.routerPlacement.y ?? 50) / 100) * targetFloor.canvasHeight);
    nextScenarios[sid] = {
      ...sc,
      routerPlacement: clampRouterToFloor(
        {
          floorId: targetFloor.id,
          x: rx,
          y: ry,
          showApproxCoverage: sc.routerPlacement.showApproxCoverage ?? true
        },
        targetFloor
      )
    };
  });

  const activeFloorId = floorById.has(v1.activeFloorId) ? v1.activeFloorId : migratedFloors[0].id;

  return {
    version: 2,
    updatedAtIso: new Date().toISOString(),
    floors: migratedFloors,
    activeFloorId,
    activeScenarioId: v1.activeScenarioId,
    scenarios: nextScenarios,
    measurements: v1.measurements
  };
}

export function normalizeStoredSurveyProject(candidate: unknown): HomeSurveyProject | null {
  if (isValidSurveyProjectV2(candidate)) return candidate;
  if (isValidSurveyProjectV1(candidate)) return migrateV1ToV2Project(candidate);
  return null;
}

function openSurveyDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function idbGet<T>(db: IDBDatabase, key: string): Promise<T | null> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const req = store.get(key);
    req.onsuccess = () => resolve((req.result as T) ?? null);
    req.onerror = () => reject(req.error);
  });
}

function idbPut(db: IDBDatabase, key: string, value: unknown): Promise<void> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.put(value, key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export function loadSurveyProjectSyncFallback(): HomeSurveyProject | null {
  if (typeof localStorage === 'undefined') return null;
  try {
    const rawV2 = localStorage.getItem(LS_FALLBACK_KEY_V2);
    if (rawV2) {
      const normalized = normalizeStoredSurveyProject(JSON.parse(rawV2));
      if (normalized) return normalized;
    }
    const rawV1 = localStorage.getItem(LS_FALLBACK_KEY_V1);
    if (rawV1) {
      const normalized = normalizeStoredSurveyProject(JSON.parse(rawV1));
      if (normalized) return normalized;
    }
    return null;
  } catch {
    return null;
  }
}

export async function loadSurveyProject(): Promise<HomeSurveyProject> {
  const syncFallback = loadSurveyProjectSyncFallback();

  if (typeof indexedDB !== 'undefined') {
    try {
      const db = await openSurveyDb();
      try {
        const storedV2 = await idbGet<unknown>(db, RECORD_KEY_V2);
        const normalizedV2 = normalizeStoredSurveyProject(storedV2);
        if (normalizedV2) return normalizedV2;

        const storedV1 = await idbGet<unknown>(db, RECORD_KEY_V1);
        const normalizedV1 = normalizeStoredSurveyProject(storedV1);
        if (normalizedV1) {
          await idbPut(db, RECORD_KEY_V2, normalizedV1);
          return normalizedV1;
        }
      } finally {
        db.close();
      }
    } catch {
      // Fall back to localStorage or default layout
    }
  }

  return syncFallback ?? createDefaultSurveyProject();
}

export async function saveSurveyProject(project: HomeSurveyProject): Promise<void> {
  const stamped: HomeSurveyProject = {
    ...project,
    version: 2,
    updatedAtIso: new Date().toISOString()
  };

  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.setItem(LS_FALLBACK_KEY_V2, JSON.stringify(stamped));
    } catch {
      // Ignore quota errors
    }
  }

  if (typeof indexedDB !== 'undefined') {
    try {
      const db = await openSurveyDb();
      try {
        await idbPut(db, RECORD_KEY_V2, stamped);
      } finally {
        db.close();
      }
    } catch {
      // localStorage already persisted copy
    }
  }
}

export async function resetSurveyProject(): Promise<HomeSurveyProject> {
  const fresh = createDefaultSurveyProject();
  await saveSurveyProject(fresh);
  return fresh;
}
