// Encrypted local-only vault for optional router credentials using Web Crypto AES-GCM in IndexedDB.
// Never uses localStorage for router passwords and never transmits credentials to remote app databases.

export interface SavedRouterCredentialPayload {
  routerUrl: string;
  adapterId: string;
  username: string;
  password: string;
  savedAt: string;
}

const DB_NAME = 'advanced_wifi_vault';
const DB_VERSION = 1;
const STORE_NAME = 'credentials';
const RECORD_KEY = 'router_vault_v1';
const KEY_RECORD = 'device_wrap_key_v1';

function openVaultDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function idbGet<T>(db: IDBDatabase, key: string): Promise<T | null> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const req = store.get(key);
    req.onsuccess = () => resolve((req.result as T) ?? null);
    req.onerror = () => reject(req.error);
  });
}

function idbPut(db: IDBDatabase, key: string, value: unknown): Promise<void> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.put(value, key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

function idbDelete(db: IDBDatabase, key: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.delete(key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

async function getOrCreateAesKey(db: IDBDatabase): Promise<CryptoKey> {
  const existingKey = await idbGet<CryptoKey>(db, KEY_RECORD);
  if (existingKey) return existingKey;

  const generated = await crypto.subtle.generateKey(
    { name: 'AES-GCM', length: 256 },
    false, // non-extractable CryptoKey stored securely in IndexedDB
    ['encrypt', 'decrypt']
  );
  await idbPut(db, KEY_RECORD, generated);
  return generated;
}

export async function hasSavedRouterCredentials(): Promise<boolean> {
  if (typeof indexedDB === 'undefined') return false;
  try {
    const db = await openVaultDb();
    const record = await idbGet(db, RECORD_KEY);
    db.close();
    return Boolean(record);
  } catch {
    return false;
  }
}

export async function saveEncryptedRouterCredentials(payload: SavedRouterCredentialPayload): Promise<void> {
  if (typeof indexedDB === 'undefined' || !crypto?.subtle) {
    throw new Error('Web Crypto or IndexedDB unavailable');
  }
  const db = await openVaultDb();
  try {
    const key = await getOrCreateAesKey(db);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encoded = new TextEncoder().encode(JSON.stringify(payload));
    const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, encoded);
    await idbPut(db, RECORD_KEY, {
      iv: Array.from(iv),
      ciphertext: Array.from(new Uint8Array(ciphertext)),
      updatedAt: new Date().toISOString()
    });
  } finally {
    db.close();
  }
}

export async function loadEncryptedRouterCredentials(): Promise<SavedRouterCredentialPayload | null> {
  if (typeof indexedDB === 'undefined' || !crypto?.subtle) return null;
  const db = await openVaultDb();
  try {
    const record = await idbGet<{ iv: number[]; ciphertext: number[] }>(db, RECORD_KEY);
    if (!record) return null;
    const key = await idbGet<CryptoKey>(db, KEY_RECORD);
    if (!key) return null;

    const iv = new Uint8Array(record.iv);
    const data = new Uint8Array(record.ciphertext);
    const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, data);
    return JSON.parse(new TextDecoder().decode(decrypted)) as SavedRouterCredentialPayload;
  } catch {
    return null;
  } finally {
    db.close();
  }
}

export async function clearSavedRouterCredentials(): Promise<void> {
  if (typeof indexedDB === 'undefined') return;
  const db = await openVaultDb();
  try {
    await idbDelete(db, RECORD_KEY);
    await idbDelete(db, KEY_RECORD);
  } finally {
    db.close();
  }
}
