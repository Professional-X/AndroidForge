import test from 'node:test';
import assert from 'node:assert/strict';
import {
  isPrivateLanIpv4,
  validateRouterAddress,
  normalizeMac,
  isValidMacAddress,
  lookupMacVendor,
  validateSsid,
  validateWifiPassword,
  sanitizeDiagnosticText
} from './networkSecurity';

test('isPrivateLanIpv4 accepts RFC1918 addresses and rejects public/loopback/link-local', () => {
  assert.equal(isPrivateLanIpv4('192.168.1.1'), true);
  assert.equal(isPrivateLanIpv4('10.0.0.1'), true);
  assert.equal(isPrivateLanIpv4('172.16.0.1'), true);
  assert.equal(isPrivateLanIpv4('172.31.255.254'), true);

  assert.equal(isPrivateLanIpv4('172.32.0.1'), false);
  assert.equal(isPrivateLanIpv4('127.0.0.1'), false);
  assert.equal(isPrivateLanIpv4('169.254.169.254'), false);
  assert.equal(isPrivateLanIpv4('8.8.8.8'), false);
});

test('validateRouterAddress prevents SSRF to metadata, localhost, and public URLs', () => {
  assert.equal(validateRouterAddress('192.168.1.1').valid, true);
  assert.equal(validateRouterAddress('http://192.168.0.1:8080').normalizedUrl, 'http://192.168.0.1:8080');
  assert.equal(validateRouterAddress('tplinkwifi.net').valid, true);

  assert.equal(validateRouterAddress('http://169.254.169.254/latest/meta-data').valid, false);
  assert.equal(validateRouterAddress('http://127.0.0.1:3000').valid, false);
  assert.equal(validateRouterAddress('localhost').valid, false);
  assert.equal(validateRouterAddress('https://google.com').valid, false);
  assert.equal(validateRouterAddress('ftp://192.168.1.1').valid, false);
  assert.equal(validateRouterAddress('http://admin:pass@192.168.1.1').valid, false);
});

test('MAC address normalization and OUI lookup behave deterministically', () => {
  assert.equal(normalizeMac('a4-83-e7-11-22-33'), 'A4:83:E7:11:22:33');
  assert.equal(isValidMacAddress('a4:83:e7:11:22:33'), true);
  assert.equal(isValidMacAddress('invalid-mac'), false);
  assert.equal(lookupMacVendor('a4:83:e7:11:22:33'), 'Apple');
  assert.equal(lookupMacVendor('02:00:00:11:22:33'), null);
});

test('SSID and Wi-Fi password rules validate lengths accurately', () => {
  assert.equal(validateSsid('Home_WiFi'), true);
  assert.equal(validateSsid(''), false);
  assert.equal(validateSsid('A'.repeat(33)), false);

  assert.equal(validateWifiPassword('1234567', 'WPA2-PSK'), false);
  assert.equal(validateWifiPassword('12345678', 'WPA2-PSK'), true);
  assert.equal(validateWifiPassword('', 'OPEN'), true);
});

test('sanitizeDiagnosticText redacts any secret substrings', () => {
  const sanitized = sanitizeDiagnosticText('Auth failed using MySecretPass123 on router', ['MySecretPass123']);
  assert.equal(sanitized.includes('MySecretPass123'), false);
  assert.match(sanitized, /\[REDACTED\]/);
});
