import React from 'react';

interface ErrorBoundaryState {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      message: error.message || 'Unexpected application error'
    };
  }

  componentDidCatch(error: Error) {
    console.error('Application boundary caught error:', error.message);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[#F4F7FB] dark:bg-[#0B1522] p-6">
          <div className="max-w-md w-full bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 text-center space-y-4">
            <h1 className="text-xl font-semibold text-[#102B49] dark:text-[#EAF1F8]">
              Advanced Wi-Fi
            </h1>
            <p className="text-sm text-[#526A84] dark:text-[#93ACC6]">
              {this.state.message}
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-5 py-2.5 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-sm font-medium transition-colors"
            >
              Reload
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
