import React from 'react';
import {
  Activity,
  History,
  LayoutDashboard,
  Laptop,
  LogIn,
  Map,
  Router,
  ShieldAlert,
  Terminal,
  UserCircle2,
  Wifi,
  X
} from 'lucide-react';
import { PageId, useApp } from '../context/AppContext';
import { useI18n } from '../i18n';

interface SidebarProps {
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

const NAV_ITEMS: Array<{ id: PageId; labelKey: string; icon: React.ComponentType<{ className?: string }> }> = [
  { id: 'dashboard', labelKey: 'nav.dashboard', icon: LayoutDashboard },
  { id: 'floor-plan', labelKey: 'nav.floorPlan', icon: Map },
  { id: 'router-connection', labelKey: 'nav.routerConnection', icon: Router },
  { id: 'local-connector', labelKey: 'nav.localConnector', icon: Terminal },
  { id: 'wifi-settings', labelKey: 'nav.wifiSettings', icon: Wifi },
  { id: 'speed-test', labelKey: 'nav.speedTest', icon: Activity },
  { id: 'diagnostics', labelKey: 'nav.diagnostics', icon: ShieldAlert },
  { id: 'devices', labelKey: 'nav.devices', icon: Laptop },
  { id: 'activity-log', labelKey: 'nav.activityLog', icon: History },
  { id: 'account', labelKey: 'nav.account', icon: UserCircle2 }
];

export const Sidebar: React.FC<SidebarProps> = ({ mobileOpen, onCloseMobile }) => {
  const { page, setPage, user, routerSession, isNativeAndroid } = useApp();
  const { t, dir } = useI18n();

  const visibleNavItems = NAV_ITEMS.filter(
    (item) => !(isNativeAndroid && item.id === 'local-connector')
  );

  const handleSelect = (id: PageId) => {
    setPage(id);
    onCloseMobile();
  };

  const navContent = (
    <div className="flex flex-col h-full bg-[#102B49] text-white">
      <div className="px-6 py-5 border-b border-white/10 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-[#174C78] border border-[#3989C9]/40 flex items-center justify-center shrink-0">
            <Wifi className="w-5 h-5 text-[#6BB3EB]" aria-hidden="true" />
          </div>
          <span className="text-base font-bold tracking-tight whitespace-nowrap truncate">
            {t('app.name')}
          </span>
        </div>
        <button
          type="button"
          onClick={onCloseMobile}
          aria-label={t('app.close')}
          className="lg:hidden p-2 rounded-lg text-white/75 hover:text-white hover:bg-white/10"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto" aria-label="Main navigation">
        {visibleNavItems.map((item) => {
          const Icon = item.icon;
          const active = page === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleSelect(item.id)}
              aria-current={active ? 'page' : undefined}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                active
                  ? 'bg-[#174C78] text-white border border-[#3989C9]/40'
                  : 'text-[#C6D6E7] hover:bg-white/8 hover:text-white border border-transparent'
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-[#6BB3EB]' : 'text-[#8DA8C5]'}`} aria-hidden="true" />
              <span className="truncate">{t(item.labelKey)}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-white/10 space-y-3">
        <div className="px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-xs space-y-1">
          <div className="text-[#8DA8C5]">{t('dashboard.routerStatus')}</div>
          <div className="font-medium text-white truncate">
            {routerSession
              ? `${routerSession.routerInfo.vendor} · ${routerSession.routerInfo.gatewayIp}`
              : t('app.notConnected')}
          </div>
        </div>

        {!user && (
          <button
            type="button"
            onClick={() => handleSelect('login')}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#3989C9] hover:bg-[#2F78B3] text-white text-sm font-medium transition-colors whitespace-nowrap"
          >
            <LogIn className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{t('nav.login')}</span>
          </button>
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop persistent sidebar */}
      <aside className="hidden lg:block w-[260px] shrink-0 border-e border-[#DCE5F0] dark:border-[#1F354F]">
        <div className="sticky top-0 h-screen">{navContent}</div>
      </aside>

      {/* Mobile slide-over drawer */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-[1px]"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <div
            className={`relative z-10 w-72 max-w-[85vw] h-full shadow-2xl ${
              dir === 'rtl' ? 'ms-auto' : 'me-auto'
            }`}
          >
            {navContent}
          </div>
        </div>
      )}
    </>
  );
};
