import React from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { useI18n } from '../i18n';

interface ConfirmModalProps {
  open: boolean;
  title: string;
  warningText?: string;
  bodyText?: string;
  summaryItems?: Array<{ label: string; value: string }>;
  confirmLabel: string;
  danger?: boolean;
  busy?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  open,
  title,
  warningText,
  bodyText,
  summaryItems,
  confirmLabel,
  danger = false,
  busy = false,
  onConfirm,
  onCancel
}) => {
  const { t } = useI18n();
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/55 backdrop-blur-[1px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-modal-title"
    >
      <div className="w-full max-w-lg bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl shadow-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-[#DCE5F0] dark:border-[#1F354F] flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <AlertTriangle
              className={`w-5 h-5 shrink-0 ${danger ? 'text-red-600 dark:text-red-400' : 'text-amber-600 dark:text-amber-400'}`}
              aria-hidden="true"
            />
            <h2 id="confirm-modal-title" className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
              {title}
            </h2>
          </div>
          <button
            type="button"
            onClick={onCancel}
            disabled={busy}
            aria-label={t('app.close')}
            className="p-1.5 rounded-lg text-[#526A84] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-4 text-sm text-[#102B49] dark:text-[#EAF1F8]">
          {bodyText && <p className="text-[#526A84] dark:text-[#93ACC6] leading-relaxed">{bodyText}</p>}

          {warningText && (
            <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/35 border border-amber-200 dark:border-amber-800/60 text-amber-900 dark:text-amber-200 text-xs leading-relaxed">
              {warningText}
            </div>
          )}

          {summaryItems && summaryItems.length > 0 && (
            <div className="rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] divide-y divide-[#DCE5F0] dark:divide-[#1F354F]">
              {summaryItems.map((item) => (
                <div key={item.label} className="px-4 py-2.5 flex items-center justify-between gap-4 text-xs">
                  <span className="text-[#526A84] dark:text-[#93ACC6]">{item.label}</span>
                  <span className="font-mono-tabular font-medium text-[#102B49] dark:text-[#EAF1F8] truncate max-w-[60%]">
                    {item.value}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="px-6 py-4 bg-[#F4F7FB] dark:bg-[#0B1522] border-t border-[#DCE5F0] dark:border-[#1F354F] flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            disabled={busy}
            className="px-4 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#112033] text-[#102B49] dark:text-[#EAF1F8] text-sm font-medium hover:bg-[#F4F7FB] dark:hover:bg-[#182C44] transition-colors whitespace-nowrap"
          >
            {t('app.cancel')}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={busy}
            className={`px-4 py-2 rounded-xl text-white text-sm font-medium transition-colors whitespace-nowrap disabled:opacity-60 ${
              danger ? 'bg-red-600 hover:bg-red-700' : 'bg-[#174C78] hover:bg-[#102B49]'
            }`}
          >
            {busy ? t('app.loading') : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
};
