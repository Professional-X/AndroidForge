import React, { useMemo, useRef, useState } from 'react';
import { Compass, Map, Radio, Router, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useI18n } from '../i18n';
import {
  evaluateHomeSignalMap,
  findOptimalRouterPlacement,
  FrequencyBandMode,
  HOME_PRESETS,
  HomePresetId,
  Point2D,
  SignalTier,
  WallMaterial
} from '../utils/homeSignalMap';

const TIER_STYLES: Record<
  SignalTier,
  { stroke: string; fillLight: string; fillDark: string; textClass: string }
> = {
  optimal: {
    stroke: '#16A34A',
    fillLight: '#ECFDF5',
    fillDark: '#064E3B',
    textClass: 'text-emerald-700 dark:text-emerald-300'
  },
  good: {
    stroke: '#3989C9',
    fillLight: '#EFF6FF',
    fillDark: '#0C2A47',
    textClass: 'text-[#174C78] dark:text-[#7CC0F5]'
  },
  fair: {
    stroke: '#D97706',
    fillLight: '#FFFBEB',
    fillDark: '#451A03',
    textClass: 'text-amber-700 dark:text-amber-300'
  },
  weak: {
    stroke: '#DC2626',
    fillLight: '#FEF2F2',
    fillDark: '#450A0A',
    textClass: 'text-red-700 dark:text-red-300'
  }
};

export const HomeMapDiagram: React.FC = () => {
  const { routerSession, theme, setPage } = useApp();
  const { t } = useI18n();
  const svgRef = useRef<SVGSVGElement | null>(null);

  const [presetId, setPresetId] = useState<HomePresetId>('apartment');
  const [bandMode, setBandMode] = useState<FrequencyBandMode>('dual');
  const [wallOverride, setWallOverride] = useState<WallMaterial | 'preset'>('preset');
  const [routerPos, setRouterPos] = useState<Point2D>(HOME_PRESETS.apartment.defaultRouter);
  const [repeaterEnabled, setRepeaterEnabled] = useState(false);
  const [repeaterPos, setRepeaterPos] = useState<Point2D>(HOME_PRESETS.apartment.defaultRepeater);

  const preset = HOME_PRESETS[presetId];

  // Calibrate lightly if live connected router exposes RSSI telemetry
  const txOffsetDb = useMemo(() => {
    const rssi = routerSession?.routerInfo.signalStrengthDbm;
    if (typeof rssi !== 'number' || !Number.isFinite(rssi)) return 0;
    // Clamp realistic calibration adjustment to [-6, +4] dB
    return Math.max(-6, Math.min(4, Math.round((rssi + 55) * 0.25)));
  }, [routerSession?.routerInfo.signalStrengthDbm]);

  const evaluation = useMemo(
    () =>
      evaluateHomeSignalMap({
        preset,
        routerPos,
        bandMode,
        wallMaterialOverride: wallOverride,
        repeaterEnabled,
        repeaterPos,
        txOffsetDb
      }),
    [preset, routerPos, bandMode, wallOverride, repeaterEnabled, repeaterPos, txOffsetDb]
  );

  const handlePresetChange = (nextId: HomePresetId) => {
    setPresetId(nextId);
    setRouterPos(HOME_PRESETS[nextId].defaultRouter);
    setRepeaterPos(HOME_PRESETS[nextId].defaultRepeater);
  };

  const handleOptimizeRouter = () => {
    const best = findOptimalRouterPlacement({
      preset,
      bandMode,
      wallMaterialOverride: wallOverride,
      txOffsetDb
    });
    setRouterPos(best);
  };

  const handleMapClick = (e: React.MouseEvent<SVGSVGElement>) => {
    const svg = svgRef.current;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;
    const xPct = ((e.clientX - rect.left) / rect.width) * 100;
    const yPct = ((e.clientY - rect.top) / rect.height) * 100;
    setRouterPos({
      x: Math.round(Math.max(8, Math.min(92, xPct))),
      y: Math.round(Math.max(10, Math.min(90, yPct)))
    });
  };

  const bestRoomId = evaluation.bestPoints[0]?.roomId;
  const isDark = theme === 'dark';

  return (
    <section
      aria-labelledby="home-map-heading"
      className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-5"
    >
      {/* Header & Controls */}
      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4">
        <div>
          <h2 id="home-map-heading" className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
            {t('homeMap.title')}
          </h2>
          <p className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-0.5 max-w-2xl">
            {t('homeMap.subtitle')}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Floorplan selector */}
          <label className="sr-only" htmlFor="home-map-preset">
            {t('homeMap.layoutLabel')}
          </label>
          <select
            id="home-map-preset"
            value={presetId}
            onChange={(e) => handlePresetChange(e.target.value as HomePresetId)}
            className="px-3 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-[#F4F7FB] dark:bg-[#0B1522] text-xs font-medium text-[#102B49] dark:text-[#EAF1F8]"
          >
            <option value="apartment">{t('homeMap.presetApartment')}</option>
            <option value="single-story">{t('homeMap.presetSingleStory')}</option>
            <option value="workspace">{t('homeMap.presetWorkspace')}</option>
          </select>

          {/* Wall type selector */}
          <label className="sr-only" htmlFor="home-map-walls">
            {t('homeMap.wallLabel')}
          </label>
          <select
            id="home-map-walls"
            value={wallOverride}
            onChange={(e) => setWallOverride(e.target.value as WallMaterial | 'preset')}
            className="px-3 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-[#F4F7FB] dark:bg-[#0B1522] text-xs font-medium text-[#102B49] dark:text-[#EAF1F8]"
          >
            <option value="preset">{t('homeMap.wallPreset')}</option>
            <option value="drywall">{t('homeMap.wallDrywall')}</option>
            <option value="brick">{t('homeMap.wallBrick')}</option>
            <option value="concrete">{t('homeMap.wallConcrete')}</option>
          </select>

          {/* Band segmented control */}
          <div
            role="group"
            aria-label={t('homeMap.bandLabel')}
            className="inline-flex items-center p-1 rounded-xl bg-[#F4F7FB] dark:bg-[#0B1522] border border-[#DCE5F0] dark:border-[#1F354F]"
          >
            {(
              [
                { id: 'dual', label: t('homeMap.bandDual') },
                { id: '5GHz', label: t('homeMap.band5') },
                { id: '2.4GHz', label: t('homeMap.band24') }
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setBandMode(opt.id)}
                aria-pressed={bandMode === opt.id}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                  bandMode === opt.id
                    ? 'bg-[#174C78] text-white'
                    : 'text-[#526A84] dark:text-[#93ACC6] hover:text-[#102B49] dark:hover:text-[#EAF1F8]'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {/* Auto-optimize router position */}
          <button
            type="button"
            onClick={handleOptimizeRouter}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-xs font-medium transition-colors whitespace-nowrap"
          >
            <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{t('homeMap.optimizeRouter')}</span>
          </button>

          {/* Mesh repeater toggle */}
          <button
            type="button"
            onClick={() => setRepeaterEnabled((prev) => !prev)}
            aria-pressed={repeaterEnabled}
            className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border text-xs font-medium transition-colors whitespace-nowrap ${
              repeaterEnabled
                ? 'bg-[#3989C9]/15 border-[#3989C9] text-[#174C78] dark:text-[#7CC0F5]'
                : 'bg-white dark:bg-[#112033] border-[#DCE5F0] dark:border-[#1F354F] text-[#102B49] dark:text-[#EAF1F8] hover:border-[#3989C9]'
            }`}
          >
            <Radio className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{repeaterEnabled ? t('homeMap.meshExtenderOn') : t('homeMap.meshExtenderOff')}</span>
          </button>

          <button
            type="button"
            data-testid="open-full-floorplan-btn"
            onClick={() => setPage('floor-plan')}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#3989C9] bg-[#3989C9]/10 hover:bg-[#3989C9]/20 text-[#174C78] dark:text-[#7CC0F5] text-xs font-semibold transition-colors whitespace-nowrap"
          >
            <Map className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{t('homeMap.openFullAnalyzer')}</span>
          </button>
        </div>
      </div>

      {/* Main Split: 2D Interactive SVG Map + Best Connection Points */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Floorplan Diagram */}
        <div className="lg:col-span-7 flex flex-col justify-between gap-3">
          <div className="relative rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-[#F4F7FB] dark:bg-[#0B1522] overflow-hidden">
            <svg
              ref={svgRef}
              viewBox="0 0 150 100"
              preserveAspectRatio="xMidYMid meet"
              onClick={handleMapClick}
              data-testid="home-map-svg"
              role="img"
              aria-label={t('homeMap.title')}
              className="w-full aspect-[3/2] cursor-crosshair select-none block"
            >
              <defs>
                <pattern id="home-map-grid" width="10" height="10" patternUnits="userSpaceOnUse">
                  <path
                    d="M 10 0 L 0 0 0 10"
                    fill="none"
                    stroke={isDark ? '#1A2D45' : '#E2EBF5'}
                    strokeWidth="0.35"
                  />
                </pattern>
                <radialGradient id="router-signal-glow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#3989C9" stopOpacity="0.30" />
                  <stop offset="55%" stopColor="#3989C9" stopOpacity="0.10" />
                  <stop offset="100%" stopColor="#3989C9" stopOpacity="0" />
                </radialGradient>
                <radialGradient id="mesh-signal-glow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#16A34A" stopOpacity="0.24" />
                  <stop offset="65%" stopColor="#16A34A" stopOpacity="0.06" />
                  <stop offset="100%" stopColor="#16A34A" stopOpacity="0" />
                </radialGradient>
              </defs>

              <rect x="0" y="0" width="150" height="100" fill="url(#home-map-grid)" />

              {/* Outer home perimeter */}
              <rect
                x={4 * 1.5}
                y="6"
                width={92 * 1.5}
                height="88"
                rx="2.5"
                fill={isDark ? '#102033' : '#FFFFFF'}
                stroke={isDark ? '#2B4666' : '#B9CBE0'}
                strokeWidth="0.9"
              />

              {/* Rooms */}
              {preset.rooms.map((room) => {
                const roomEval = evaluation.rooms.find((r) => r.roomId === room.id);
                const style = roomEval ? TIER_STYLES[roomEval.tier] : TIER_STYLES.good;
                const isTopPoint = room.id === bestRoomId;
                const rx = room.x * 1.5;
                const rw = room.width * 1.5;
                const cx = rx + rw / 2;
                const cy = room.y + room.height / 2;
                const isNarrow = room.width < 20;
                return (
                  <g key={room.id}>
                    <rect
                      x={rx}
                      y={room.y}
                      width={rw}
                      height={room.height}
                      fill={isDark ? style.fillDark : style.fillLight}
                      fillOpacity={isDark ? 0.35 : 0.6}
                      stroke={isDark ? '#1F354F' : '#D5E1EE'}
                      strokeWidth="0.5"
                    />
                    <text
                      x={rx + 2.5}
                      y={room.y + 5.8}
                      fontSize={isNarrow ? '3.3' : '3.8'}
                      fontWeight="600"
                      fill={isDark ? '#EAF1F8' : '#102B49'}
                    >
                      {t(room.labelKey)}
                    </text>
                    {roomEval && (
                      <text
                        x={rx + 2.5}
                        y={room.y + 10.6}
                        fontSize={isNarrow ? '2.9' : '3.2'}
                        fontWeight="600"
                        fill={style.stroke}
                      >
                        {roomEval.effectiveRssiDbm} dBm · {roomEval.qualityPct}%
                      </text>
                    )}
                    {isTopPoint && (
                      <circle
                        cx={cx}
                        cy={cy}
                        r="3.8"
                        fill="none"
                        stroke="#16A34A"
                        strokeWidth="0.65"
                        strokeDasharray="1.4 0.9"
                      />
                    )}
                  </g>
                );
              })}

              {/* RF coverage circles around router */}
              <circle
                cx={routerPos.x * 1.5}
                cy={routerPos.y}
                r={bandMode === '5GHz' ? 32 : 44}
                fill="url(#router-signal-glow)"
                pointerEvents="none"
              />
              <circle
                cx={routerPos.x * 1.5}
                cy={routerPos.y}
                r={bandMode === '5GHz' ? 16 : 22}
                fill="none"
                stroke="#3989C9"
                strokeOpacity="0.45"
                strokeWidth="0.5"
                strokeDasharray="1.8 1.8"
                pointerEvents="none"
              />

              {/* Repeater coverage & backhaul link */}
              {repeaterEnabled && (
                <>
                  <circle
                    cx={repeaterPos.x * 1.5}
                    cy={repeaterPos.y}
                    r="30"
                    fill="url(#mesh-signal-glow)"
                    pointerEvents="none"
                  />
                  <line
                    x1={routerPos.x * 1.5}
                    y1={routerPos.y}
                    x2={repeaterPos.x * 1.5}
                    y2={repeaterPos.y}
                    stroke="#16A34A"
                    strokeWidth="0.7"
                    strokeDasharray="1.8 1.4"
                    pointerEvents="none"
                  />
                </>
              )}

              {/* Connection paths from active AP to each room point */}
              {evaluation.rooms.map((r) => {
                const origin = r.servedBy === 'repeater' && repeaterEnabled ? repeaterPos : routerPos;
                const style = TIER_STYLES[r.tier];
                return (
                  <g key={`link-${r.roomId}`} pointerEvents="none">
                    <line
                      x1={origin.x * 1.5}
                      y1={origin.y}
                      x2={r.center.x * 1.5}
                      y2={r.center.y}
                      stroke={style.stroke}
                      strokeOpacity="0.55"
                      strokeWidth="0.55"
                    />
                    <circle
                      cx={r.center.x * 1.5}
                      cy={r.center.y}
                      r="1.9"
                      fill={style.stroke}
                      stroke={isDark ? '#0B1522' : '#FFFFFF'}
                      strokeWidth="0.5"
                    />
                  </g>
                );
              })}

              {/* Structural Walls */}
              {preset.walls.map((wall) => {
                const effectiveMat = wallOverride === 'preset' ? wall.material : wallOverride;
                const width = effectiveMat === 'concrete' ? 1.8 : effectiveMat === 'brick' ? 1.2 : 0.7;
                const color =
                  effectiveMat === 'concrete'
                    ? isDark
                      ? '#8BA6C4'
                      : '#102B49'
                    : effectiveMat === 'brick'
                    ? isDark
                      ? '#5B7B9E'
                      : '#47688A'
                    : isDark
                    ? '#3A5878'
                    : '#8AA4C0';
                return (
                  <line
                    key={wall.id}
                    x1={wall.x1 * 1.5}
                    y1={wall.y1}
                    x2={wall.x2 * 1.5}
                    y2={wall.y2}
                    stroke={color}
                    strokeWidth={width}
                    strokeLinecap="round"
                  />
                );
              })}

              {/* Mesh Repeater Pin */}
              {repeaterEnabled && (
                <g pointerEvents="none">
                  <circle
                    cx={repeaterPos.x * 1.5}
                    cy={repeaterPos.y}
                    r="3.4"
                    fill="#16A34A"
                    stroke="#FFFFFF"
                    strokeWidth="0.8"
                  />
                  <text
                    x={repeaterPos.x * 1.5}
                    y={repeaterPos.y + 6.8}
                    textAnchor="middle"
                    fontSize="3.3"
                    fontWeight="700"
                    fill={isDark ? '#86EFAC' : '#15803D'}
                  >
                    {t('homeMap.repeaterPin')}
                  </text>
                </g>
              )}

              {/* Primary Router Pin */}
              <g pointerEvents="none">
                <circle
                  cx={routerPos.x * 1.5}
                  cy={routerPos.y}
                  r="4.2"
                  fill="#174C78"
                  stroke="#FFFFFF"
                  strokeWidth="0.9"
                />
                <circle cx={routerPos.x * 1.5} cy={routerPos.y} r="1.6" fill="#FFFFFF" />
                <text
                  x={routerPos.x * 1.5}
                  y={routerPos.y + 7.6}
                  textAnchor="middle"
                  fontSize="3.4"
                  fontWeight="700"
                  fill={isDark ? '#7CC0F5' : '#102B49'}
                >
                  {t('homeMap.routerPin')}
                </text>
              </g>
            </svg>
          </div>

          {/* Legend & honest calibration note */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-[#526A84] dark:text-[#93ACC6]">
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-600 inline-block" aria-hidden="true" />
                {t('homeMap.legendStrong')}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-[#3989C9] inline-block" aria-hidden="true" />
                {t('homeMap.legendGood')}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-amber-600 inline-block" aria-hidden="true" />
                {t('homeMap.legendFair')}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-red-600 inline-block" aria-hidden="true" />
                {t('homeMap.legendWeak')}
              </span>
            </div>
          </div>

          <p className="text-xs text-[#526A84] dark:text-[#93ACC6]">
            {t('homeMap.modelNote')}{' '}
            {routerSession?.routerInfo.signalStrengthDbm != null && (
              <span className="font-medium text-[#174C78] dark:text-[#7CC0F5]">
                {t('homeMap.calibratedNote')}
              </span>
            )}
          </p>
        </div>

        {/* Right Panel: Best Connection Points & Per-Room Analysis */}
        <div className="lg:col-span-5 flex flex-col justify-between gap-4">
          {/* Aggregate Coverage Summary */}
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-[#F4F7FB]/70 dark:bg-[#0B1522]/70 p-3.5">
              <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('homeMap.coverageSummary')}</div>
              <div className="text-xl font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] mt-1">
                {evaluation.coverageScorePct}%
              </div>
            </div>
            <div className="rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-[#F4F7FB]/70 dark:bg-[#0B1522]/70 p-3.5">
              <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">{t('homeMap.avgQuality')}</div>
              <div className="text-xl font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] mt-1">
                {evaluation.averageQualityPct}%
              </div>
            </div>
          </div>

          {/* Ranked Best Connection Points */}
          <div className="rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] overflow-hidden flex-1 flex flex-col">
            <div className="px-4 py-3 bg-[#F4F7FB] dark:bg-[#0B1522] border-b border-[#DCE5F0] dark:border-[#1F354F] flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Compass className="w-4 h-4 text-[#3989C9]" aria-hidden="true" />
                <h3 className="text-xs font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                  {t('homeMap.bestPointsTitle')}
                </h3>
              </div>
              <span className="text-xs font-mono-tabular text-[#526A84] dark:text-[#93ACC6]">
                ({routerPos.x}, {routerPos.y})
              </span>
            </div>

            <div className="divide-y divide-[#DCE5F0] dark:divide-[#1F354F]">
              {[...evaluation.rooms]
                .sort((a, b) => b.effectiveRssiDbm - a.effectiveRssiDbm)
                .map((room, idx) => {
                  const style = TIER_STYLES[room.tier];
                  const recLabel =
                    room.recommendedBand === '5GHz'
                      ? t('homeMap.rec5Ghz')
                      : room.recommendedBand === '2.4GHz'
                      ? t('homeMap.rec24Ghz')
                      : t('homeMap.recMesh');
                  return (
                    <div
                      key={room.roomId}
                      className="px-4 py-3 flex items-center justify-between gap-3 text-xs"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-mono-tabular text-[#526A84] dark:text-[#93ACC6]">
                            0{idx + 1}.
                          </span>
                          <span className="font-semibold text-[#102B49] dark:text-[#EAF1F8] truncate">
                            {t(room.labelKey)}
                          </span>
                          {room.servedBy === 'repeater' && repeaterEnabled && (
                            <span className="text-[11px] font-medium text-emerald-700 dark:text-emerald-300">
                              · {t('homeMap.servedByRepeater')}
                            </span>
                          )}
                        </div>
                        <div className="text-[#526A84] dark:text-[#93ACC6] mt-0.5">
                          <span className="font-mono-tabular">
                            {room.distanceMeters} {t('homeMap.distanceLabel')} · {room.wallsCrossed}{' '}
                            {t('homeMap.wallsLabel')}
                          </span>
                          {' · '}
                          <span className={`${style.textClass} whitespace-nowrap`}>{recLabel}</span>
                        </div>
                      </div>

                      <div className="text-end shrink-0">
                        <div className={`font-mono-tabular font-semibold ${style.textClass}`}>
                          {room.effectiveRssiDbm} dBm
                        </div>
                        <div className="font-mono-tabular text-[#526A84] dark:text-[#93ACC6]">
                          {room.qualityPct}%
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => setRouterPos({ x: Math.round(room.center.x), y: Math.round(room.center.y) })}
                        title={`${t('homeMap.routerPin')} → ${t(room.labelKey)}`}
                        aria-label={`${t('homeMap.routerPin')} → ${t(room.labelKey)}`}
                        className="p-1.5 rounded-lg border border-[#DCE5F0] dark:border-[#1F354F] text-[#526A84] dark:text-[#93ACC6] hover:border-[#3989C9] hover:text-[#174C78] dark:hover:text-[#7CC0F5] transition-colors shrink-0"
                      >
                        <Router className="w-3.5 h-3.5" aria-hidden="true" />
                      </button>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
