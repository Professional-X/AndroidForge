import React from 'react';
import { useI18n } from '../i18n';

interface SpeedGaugeProps {
  valueMbps: number;
  maxScaleMbps?: number;
  label: string;
  phaseLabel: string;
  active: boolean;
}

export const SpeedGauge: React.FC<SpeedGaugeProps> = ({
  valueMbps,
  maxScaleMbps = 200,
  label,
  phaseLabel,
  active
}) => {
  const { t } = useI18n();
  const clamped = Math.max(0, Math.min(valueMbps, maxScaleMbps));
  const ratio = clamped / maxScaleMbps;
  const radius = 110;
  const circumference = Math.PI * radius;
  const dashOffset = circumference * (1 - ratio);

  return (
    <div className="flex flex-col items-center justify-center py-4">
      <div className="relative w-72 h-44 flex items-end justify-center">
        <svg viewBox="0 0 260 150" className="w-full h-full overflow-visible" role="img" aria-label={`${label}: ${valueMbps} ${t('speed.mbps')}`}>
          <defs>
            <linearGradient id="awSpeedGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#174C78" />
              <stop offset="100%" stopColor="#3989C9" />
            </linearGradient>
          </defs>
          {/* Background arc */}
          <path
            d="M 20 130 A 110 110 0 0 1 240 130"
            fill="none"
            stroke="currentColor"
            strokeWidth="16"
            strokeLinecap="round"
            className="text-[#DCE5F0] dark:text-[#1F354F]"
          />
          {/* Progress arc */}
          <path
            d="M 20 130 A 110 110 0 0 1 240 130"
            fill="none"
            stroke="url(#awSpeedGrad)"
            strokeWidth="16"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={dashOffset}
            style={{ transition: 'stroke-dashoffset 180ms cubic-bezier(0.16, 1, 0.3, 1)' }}
          />
        </svg>

        <div className="absolute bottom-2 inset-x-0 text-center">
          <div className="text-xs font-medium text-[#526A84] dark:text-[#93ACC6] mb-1">
            {label}
          </div>
          <div className="text-4xl font-bold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] tracking-tight">
            {valueMbps.toFixed(1)}
          </div>
          <div className="text-xs font-semibold text-[#3989C9] mt-0.5">
            {t('speed.mbps')}
          </div>
        </div>
      </div>

      <p className={`mt-3 text-xs font-medium ${active ? 'text-[#3989C9]' : 'text-[#526A84] dark:text-[#93ACC6]'}`}>
        {phaseLabel}
      </p>
    </div>
  );
};
