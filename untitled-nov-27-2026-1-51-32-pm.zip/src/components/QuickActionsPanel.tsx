import React, { useState } from 'react';
import {
  Activity,
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Globe,
  Laptop,
  RotateCw,
  Router,
  ShieldAlert,
  ShieldOff,
  Users,
  Wifi
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useI18n } from '../i18n';
import { RouterError } from '../router-adapters/types';
import { getEffectiveCapabilities } from '../services/routerConnection';
import { ConfirmModal } from './ConfirmModal';

type PendingAction = 'reboot' | 'guest-toggle' | 'internet-toggle' | null;

export const QuickActionsPanel: React.FC = () => {
  const {
    setPage,
    routerSession,
    rebootRouter,
    setGuestWifi,
    setInternetBlocked
  } = useApp();
  const { t } = useI18n();

  const [pendingAction, setPendingAction] = useState<PendingAction>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{
    kind: 'info' | 'success' | 'error';
    textKey: string;
    showConnectCta?: boolean;
  } | null>(null);

  const guestEnabled = routerSession?.guestWifiEnabled ?? false;
  const internetBlocked = routerSession?.internetBlocked ?? false;

  const effectiveCaps = routerSession ? getEffectiveCapabilities(routerSession) : null;
  const canReboot = Boolean(effectiveCaps?.rebootRouter);
  const canGuest = Boolean(effectiveCaps?.guestWifi);
  const canBlockInternet = Boolean(effectiveCaps?.blockAllInternet);

  const handleActionClick = (action: Exclude<PendingAction, null>) => {
    setNotice(null);
    if (!routerSession) {
      setNotice({
        kind: 'info',
        textKey: 'quickActions.requiresRouterNotice',
        showConnectCta: true
      });
      return;
    }

    if (
      (action === 'reboot' && !canReboot) ||
      (action === 'guest-toggle' && !canGuest) ||
      (action === 'internet-toggle' && !canBlockInternet)
    ) {
      setNotice({
        kind: 'info',
        textKey: 'quickActions.unsupportedActionNotice',
        showConnectCta: false
      });
      return;
    }

    setPendingAction(action);
  };

  const handleConfirm = async () => {
    if (!pendingAction) return;
    setBusy(true);
    setNotice(null);
    try {
      if (pendingAction === 'reboot') {
        await rebootRouter();
        setNotice({ kind: 'success', textKey: 'quickActions.rebootSuccess' });
      } else if (pendingAction === 'guest-toggle') {
        const nextEnabled = !guestEnabled;
        await setGuestWifi(nextEnabled);
        setNotice({
          kind: 'success',
          textKey: nextEnabled ? 'quickActions.guestSuccessEnabled' : 'quickActions.guestSuccessDisabled'
        });
      } else if (pendingAction === 'internet-toggle') {
        const nextBlocked = !internetBlocked;
        await setInternetBlocked(nextBlocked);
        setNotice({
          kind: 'success',
          textKey: nextBlocked ? 'quickActions.internetBlockedSuccess' : 'quickActions.internetRestoredSuccess'
        });
      }
      setPendingAction(null);
    } catch (err) {
      const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
      setNotice({
        kind: 'error',
        textKey: `router.errors.${code}`
      });
      setPendingAction(null);
    } finally {
      setBusy(false);
    }
  };

  const modalTitle =
    pendingAction === 'reboot'
      ? t('quickActions.rebootConfirmTitle')
      : pendingAction === 'guest-toggle'
      ? guestEnabled
        ? t('quickActions.guestConfirmTitleDisable')
        : t('quickActions.guestConfirmTitleEnable')
      : internetBlocked
      ? t('quickActions.restoreInternetConfirmTitle')
      : t('quickActions.blockInternetConfirmTitle');

  const modalWarning =
    pendingAction === 'reboot'
      ? t('quickActions.rebootConfirmWarning')
      : pendingAction === 'internet-toggle' && !internetBlocked
      ? t('quickActions.blockInternetWarning')
      : undefined;

  const modalBody =
    pendingAction === 'guest-toggle'
      ? t('quickActions.guestConfirmBody')
      : pendingAction === 'internet-toggle' && internetBlocked
      ? t('quickActions.restoreInternetBody')
      : undefined;

  return (
    <section
      aria-labelledby="quick-actions-heading"
      className="lg:col-span-2 bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-4"
    >
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h2 id="quick-actions-heading" className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
            {t('quickActions.title')}
          </h2>
          <p className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-0.5">
            {t('quickActions.subtitle')}
          </p>
        </div>
        {routerSession && (
          <span className="text-xs text-[#526A84] dark:text-[#93ACC6] font-mono-tabular whitespace-nowrap">
            {routerSession.routerInfo.vendor} · {routerSession.routerInfo.gatewayIp}
          </span>
        )}
      </div>

      {/* Primary hardware quick actions */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* 1. Reboot Router */}
        <button
          type="button"
          onClick={() => handleActionClick('reboot')}
          className="flex flex-col justify-between gap-3 p-4 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-[#F4F7FB]/60 dark:bg-[#0B1522]/60 hover:border-[#3989C9] hover:bg-[#F4F7FB] dark:hover:bg-[#172B42] transition-colors text-start"
        >
          <div className="flex items-center justify-between gap-2 w-full">
            <RotateCw className="w-5 h-5 text-[#174C78] dark:text-[#3989C9] shrink-0" aria-hidden="true" />
            <span className="text-xs text-[#526A84] dark:text-[#93ACC6] whitespace-nowrap">
              {!routerSession
                ? t('quickActions.statusRequiresRouter')
                : canReboot
                ? t('app.supported')
                : t('quickActions.statusUnsupported')}
            </span>
          </div>
          <div>
            <div className="text-sm font-semibold text-[#102B49] dark:text-[#EAF1F8]">
              {t('quickActions.rebootRouter')}
            </div>
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-0.5">
              {t('quickActions.rebootDesc')}
            </div>
          </div>
        </button>

        {/* 2. Guest Wi-Fi Toggle */}
        <button
          type="button"
          onClick={() => handleActionClick('guest-toggle')}
          aria-pressed={routerSession ? guestEnabled : undefined}
          className={`flex flex-col justify-between gap-3 p-4 rounded-xl border transition-colors text-start ${
            routerSession && guestEnabled
              ? 'border-[#3989C9] bg-[#3989C9]/10 dark:bg-[#3989C9]/15'
              : 'border-[#DCE5F0] dark:border-[#1F354F] bg-[#F4F7FB]/60 dark:bg-[#0B1522]/60 hover:border-[#3989C9] hover:bg-[#F4F7FB] dark:hover:bg-[#172B42]'
          }`}
        >
          <div className="flex items-center justify-between gap-2 w-full">
            <Users className="w-5 h-5 text-[#174C78] dark:text-[#3989C9] shrink-0" aria-hidden="true" />
            <span
              className={`text-xs font-medium whitespace-nowrap ${
                routerSession && guestEnabled
                  ? 'text-[#174C78] dark:text-[#7CC0F5]'
                  : 'text-[#526A84] dark:text-[#93ACC6]'
              }`}
            >
              {!routerSession
                ? t('quickActions.statusRequiresRouter')
                : !canGuest
                ? t('quickActions.statusUnsupported')
                : guestEnabled
                ? t('quickActions.guestOn')
                : t('quickActions.guestOff')}
            </span>
          </div>
          <div>
            <div className="text-sm font-semibold text-[#102B49] dark:text-[#EAF1F8]">
              {t('quickActions.guestWifi')}
            </div>
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-0.5">
              {t('quickActions.guestReady')}
            </div>
          </div>
        </button>

        {/* 3. Block All Internet */}
        <button
          type="button"
          onClick={() => handleActionClick('internet-toggle')}
          aria-pressed={routerSession ? internetBlocked : undefined}
          className={`flex flex-col justify-between gap-3 p-4 rounded-xl border transition-colors text-start ${
            routerSession && internetBlocked
              ? 'border-red-500/70 bg-red-50 dark:bg-red-950/30'
              : 'border-[#DCE5F0] dark:border-[#1F354F] bg-[#F4F7FB]/60 dark:bg-[#0B1522]/60 hover:border-[#3989C9] hover:bg-[#F4F7FB] dark:hover:bg-[#172B42]'
          }`}
        >
          <div className="flex items-center justify-between gap-2 w-full">
            {routerSession && internetBlocked ? (
              <Globe className="w-5 h-5 text-red-600 dark:text-red-400 shrink-0" aria-hidden="true" />
            ) : (
              <ShieldOff className="w-5 h-5 text-[#174C78] dark:text-[#3989C9] shrink-0" aria-hidden="true" />
            )}
            <span
              className={`text-xs font-medium whitespace-nowrap ${
                routerSession && internetBlocked
                  ? 'text-red-700 dark:text-red-300'
                  : 'text-[#526A84] dark:text-[#93ACC6]'
              }`}
            >
              {!routerSession
                ? t('quickActions.statusRequiresRouter')
                : !canBlockInternet
                ? t('quickActions.statusUnsupported')
                : internetBlocked
                ? t('quickActions.internetPaused')
                : t('quickActions.internetActive')}
            </span>
          </div>
          <div>
            <div className="text-sm font-semibold text-[#102B49] dark:text-[#EAF1F8]">
              {routerSession && internetBlocked
                ? t('quickActions.restoreInternet')
                : t('quickActions.blockInternet')}
            </div>
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-0.5">
              {routerSession && internetBlocked
                ? t('quickActions.internetPaused')
                : t('quickActions.internetActive')}
            </div>
          </div>
        </button>
      </div>

      {/* Inline honest feedback banner */}
      {notice && (
        <div
          role="status"
          className={`flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl border text-xs ${
            notice.kind === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/60 text-emerald-900 dark:text-emerald-200'
              : notice.kind === 'error'
              ? 'bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-800/60 text-red-900 dark:text-red-200'
              : 'bg-[#F4F7FB] dark:bg-[#0B1522] border-[#DCE5F0] dark:border-[#1F354F] text-[#102B49] dark:text-[#EAF1F8]'
          }`}
        >
          <div className="flex items-center gap-2">
            {notice.kind === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
            ) : (
              <AlertCircle
                className={`w-4 h-4 shrink-0 ${
                  notice.kind === 'error' ? 'text-red-600 dark:text-red-400' : 'text-[#3989C9]'
                }`}
                aria-hidden="true"
              />
            )}
            <span>{t(notice.textKey)}</span>
          </div>
          {notice.showConnectCta && (
            <button
              type="button"
              onClick={() => setPage('router-connection')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#174C78] hover:bg-[#102B49] text-white font-medium transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
            >
              <Router className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t('quickActions.connectNow')}</span>
            </button>
          )}
        </div>
      )}

      {/* Secondary page shortcuts */}
      <div className="pt-3 border-t border-[#DCE5F0] dark:border-[#1F354F]">
        <div className="text-xs font-medium text-[#526A84] dark:text-[#93ACC6] mb-2.5">
          {t('quickActions.shortcutsLabel')}
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {[
            { id: 'wifi-settings' as const, label: t('nav.wifiSettings'), icon: Wifi },
            { id: 'speed-test' as const, label: t('nav.speedTest'), icon: Activity },
            { id: 'devices' as const, label: t('nav.devices'), icon: Laptop },
            { id: 'diagnostics' as const, label: t('nav.diagnostics'), icon: ShieldAlert }
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setPage(item.id)}
                className="flex items-center justify-between gap-2 px-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] hover:border-[#3989C9] hover:bg-[#F4F7FB] dark:hover:bg-[#172B42] transition-colors text-start"
              >
                <span className="flex items-center gap-2 min-w-0">
                  <Icon className="w-4 h-4 text-[#3989C9] shrink-0" aria-hidden="true" />
                  <span className="text-xs font-medium text-[#102B49] dark:text-[#EAF1F8] whitespace-nowrap">
                    {item.label}
                  </span>
                </span>
                <ArrowRight className="w-3.5 h-3.5 text-[#526A84] rtl:rotate-180 shrink-0" aria-hidden="true" />
              </button>
            );
          })}
        </div>
      </div>

      <ConfirmModal
        open={pendingAction !== null}
        title={modalTitle}
        warningText={modalWarning}
        bodyText={modalBody}
        summaryItems={
          routerSession
            ? [
                {
                  label: t('dashboard.routerStatus'),
                  value: `${routerSession.routerInfo.vendor} ${routerSession.routerInfo.model ?? ''}`.trim()
                },
                {
                  label: t('dashboard.routerIp'),
                  value: routerSession.routerInfo.gatewayIp
                }
              ]
            : undefined
        }
        confirmLabel={t('app.confirm')}
        danger={pendingAction === 'reboot' || (pendingAction === 'internet-toggle' && !internetBlocked)}
        busy={busy}
        onConfirm={() => void handleConfirm()}
        onCancel={() => !busy && setPendingAction(null)}
      />
    </section>
  );
};
