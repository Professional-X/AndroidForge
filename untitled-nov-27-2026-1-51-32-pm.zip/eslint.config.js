import firebaseRulesPlugin from '@firebase/eslint-plugin-security-rules';

export default [
  {
    ignores: ['dist/**/*', 'node_modules/**/*', 'local-connector/**/*']
  },
  firebaseRulesPlugin.configs['flat/recommended']
];
