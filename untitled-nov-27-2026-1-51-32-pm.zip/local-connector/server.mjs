#!/usr/bin/env node
/**
 * Advanced Wi-Fi — Local Connector Companion (v2.0.0)
 * Android (Termux) & Desktop compatible, zero external npm dependencies.
 *
 * Bridges browser CORS, HTTPS-to-HTTP Mixed Content, and Private Network Access
 * boundaries cleanly between the Advanced Wi-Fi web app and your local LAN router.
 *
 * Security invariants:
 * - Binds strictly to 127.0.0.1:4890 (never exposed to public/LAN interfaces)
 * - Enforces an explicit Origin allowlist (rejects unauthorized websites with 403)
 * - Requires cryptographic Bearer / X-Connector-Token authentication on control routes
 * - Validates every upstream router target strictly against RFC1918 private LAN ranges
 * - Holds router session cookies strictly in RAM (never persists passwords or cookies)
 */

import crypto from 'node:crypto';
import http from 'node:http';
import os from 'node:os';
import { pathToFileURL, URL } from 'node:url';

export const DEFAULT_PORT = Number(process.env.CONNECTOR_PORT || 4890);
export const HOST = '127.0.0.1';

export const DEFAULT_ALLOWED_ORIGINS = [
  'https://ais-dev-ghnmuzpj6abkrq44vr6qnx-751624632205.europe-west1.run.app',
  'https://ais-pre-ghnmuzpj6abkrq44vr6qnx-751624632205.europe-west1.run.app',
  'http://localhost:3000',
  'http://127.0.0.1:3000',
  'https://localhost:3000',
  'https://127.0.0.1:3000'
];

export const KNOWN_ROUTER_HOSTS = new Set([
  'tplinkwifi.net',
  'tplinklogin.net',
  'mwlogin.net',
  'router.asus.com',
  'www.routerlogin.net',
  'routerlogin.net',
  'tendawifi.com',
  'dlinkrouter.local',
  'fritz.box',
  'myrouter.local',
  'huawei.local'
]);

export function isPrivateLanIpv4(ip) {
  const parts = ip.split('.');
  if (parts.length !== 4) return false;
  const nums = parts.map((p) => (/^\d{1,3}$/.test(p) ? Number(p) : -1));
  if (nums.some((n) => n < 0 || n > 255)) return false;
  const [a, b] = nums;
  return a === 10 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
}

export function validateLanTarget(targetUrl) {
  if (typeof targetUrl !== 'string' || !targetUrl.trim()) return null;
  let parsed;
  try {
    parsed = new URL(targetUrl);
  } catch {
    return null;
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return null;
  if (parsed.username || parsed.password) return null;

  const host = parsed.hostname.toLowerCase();
  if (
    host === 'localhost' ||
    host.startsWith('127.') ||
    host.startsWith('169.254.') ||
    host === '0.0.0.0' ||
    host === '::1' ||
    host === '[::1]' ||
    host.startsWith('fe80:') ||
    host.startsWith('[fe80:')
  ) {
    return null;
  }
  if (!isPrivateLanIpv4(host) && !KNOWN_ROUTER_HOSTS.has(host) && !host.endsWith('.local')) {
    return null;
  }
  return parsed;
}

export function buildAllowedOriginsSet(extraOrigins = []) {
  const envOrigins = String(process.env.CONNECTOR_ALLOWED_ORIGINS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

  const cliOrigins = process.argv
    .filter((arg) => arg.startsWith('--allow-origin='))
    .map((arg) => arg.slice('--allow-origin='.length).trim())
    .filter(Boolean);

  return new Set([...DEFAULT_ALLOWED_ORIGINS, ...envOrigins, ...cliOrigins, ...extraOrigins]);
}

export function isOriginAllowed(origin, allowedSet) {
  if (!origin) return true; // Local CLI tools (curl/Termux) without Origin header
  try {
    const normalized = new URL(origin).origin;
    return allowedSet.has(normalized);
  } catch {
    return false;
  }
}

export function extractTokenFromRequest(req) {
  const headerToken = req.headers['x-connector-token'];
  if (typeof headerToken === 'string' && headerToken.trim()) {
    return headerToken.trim();
  }
  const authHeader = req.headers.authorization;
  if (typeof authHeader === 'string' && authHeader.toLowerCase().startsWith('bearer ')) {
    return authHeader.slice(7).trim();
  }
  return '';
}

export function verifyToken(candidate, expectedToken) {
  if (!candidate || !expectedToken) return false;
  const a = Buffer.from(candidate, 'utf8');
  const b = Buffer.from(expectedToken, 'utf8');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

function resolveInitialToken(providedToken) {
  if (providedToken) return providedToken;
  const cliArg = process.argv.find((arg) => arg.startsWith('--token='));
  if (cliArg) {
    const val = cliArg.slice('--token='.length).trim();
    if (val.length >= 12) return val;
  }
  if (process.env.CONNECTOR_TOKEN && process.env.CONNECTOR_TOKEN.trim().length >= 12) {
    return process.env.CONNECTOR_TOKEN.trim();
  }
  return crypto.randomBytes(24).toString('base64url');
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;
    req.on('data', (chunk) => {
      total += chunk.length;
      if (total > 1024 * 1024) {
        reject(new Error('Payload too large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        const text = Buffer.concat(chunks).toString('utf8');
        resolve(text ? JSON.parse(text) : {});
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
}

function setCorsHeaders(origin, res) {
  if (origin) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Content-Type, Authorization, X-Connector-Token, X-Connector-Session'
  );
  res.setHeader('Access-Control-Allow-Private-Network', 'true');
  res.setHeader('Cache-Control', 'no-store');
}

export function createConnectorServer(options = {}) {
  const token = resolveInitialToken(options.token);
  const allowedOrigins = buildAllowedOriginsSet(options.extraOrigins || []);
  const sessionCookieJar = new Map();
  const startedAt = Date.now();
  const fetchImpl = options.fetchImpl || fetch;

  const server = http.createServer(async (req, res) => {
    const origin = typeof req.headers.origin === 'string' ? req.headers.origin : '';

    if (origin && !isOriginAllowed(origin, allowedOrigins)) {
      res.writeHead(403, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
      res.end(
        JSON.stringify({
          error: 'ORIGIN_NOT_ALLOWED',
          message: 'Origin is not in the Local Connector allowlist.'
        })
      );
      return;
    }

    if (origin) {
      setCorsHeaders(origin, res);
    } else {
      res.setHeader('Cache-Control', 'no-store');
    }

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }

    const requestUrl = (req.url || '/').split('?')[0];
    const providedToken = extractTokenFromRequest(req);
    const isAuthenticated = verifyToken(providedToken, token);

    if (req.method === 'GET' && requestUrl === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(
        JSON.stringify({
          ok: true,
          service: 'advanced-wifi-local-connector',
          version: '2.0.0',
          platform: os.platform(),
          arch: os.arch(),
          nodeVersion: process.version,
          uptimeSec: Math.floor((Date.now() - startedAt) / 1000),
          authRequired: true,
          authVerified: isAuthenticated
        })
      );
      return;
    }

    // All operational/control routes strictly require valid local token authentication
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(
        JSON.stringify({
          error: 'AUTH_REQUIRED',
          message: 'Missing or invalid X-Connector-Token.'
        })
      );
      return;
    }

    if (req.method === 'POST' && requestUrl === '/session/clear') {
      const sessionId = String(req.headers['x-connector-session'] || 'default');
      sessionCookieJar.delete(sessionId);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ cleared: true }));
      return;
    }

    if (req.method === 'POST' && requestUrl === '/shutdown') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ stopping: true }));
      setTimeout(() => {
        server.close(() => {
          if (!options.keepProcessAlive) process.exit(0);
        });
      }, 80);
      return;
    }

    if (req.method === 'POST' && requestUrl === '/proxy') {
      try {
        const body = await readJsonBody(req);
        const targetUrl = validateLanTarget(body.url);
        if (!targetUrl) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'INVALID_ROUTER_ADDRESS' }));
          return;
        }

        const requestedMethod = String(body.method || 'GET').toUpperCase();
        const method = ['GET', 'POST', 'PUT', 'DELETE'].includes(requestedMethod) ? requestedMethod : 'GET';

        const sessionId = String(req.headers['x-connector-session'] || 'default');
        const outgoingHeaders = { ...(body.headers && typeof body.headers === 'object' ? body.headers : {}) };
        const existingCookies = sessionCookieJar.get(sessionId);
        if (existingCookies && !outgoingHeaders.Cookie) {
          outgoingHeaders.Cookie = existingCookies;
        }

        const controller = new AbortController();
        const timeoutMs = Math.min(25000, Math.max(1500, Number(body.timeoutMs || 8000)));
        const timeout = setTimeout(() => controller.abort(), timeoutMs);

        const upstream = await fetchImpl(targetUrl.toString(), {
          method,
          headers: outgoingHeaders,
          body: method !== 'GET' && typeof body.body === 'string' ? body.body : undefined,
          redirect: 'manual',
          signal: controller.signal
        });
        clearTimeout(timeout);

        // Validate redirect target if upstream returns 3xx so redirects cannot escape private LAN
        if (upstream.status >= 300 && upstream.status < 400) {
          const location = upstream.headers.get('location');
          if (location) {
            const nextResolved = new URL(location, targetUrl).toString();
            if (!validateLanTarget(nextResolved)) {
              res.writeHead(400, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ error: 'INVALID_ROUTER_ADDRESS' }));
              return;
            }
          }
        }

        const setCookies = upstream.headers.getSetCookie ? upstream.headers.getSetCookie() : [];
        if (setCookies.length > 0) {
          const cookiePairs = setCookies.map((c) => c.split(';')[0]).join('; ');
          sessionCookieJar.set(sessionId, cookiePairs);
        }

        const responseHeaders = {};
        upstream.headers.forEach((value, key) => {
          if (!['set-cookie', 'content-encoding', 'transfer-encoding'].includes(key.toLowerCase())) {
            responseHeaders[key] = value;
          }
        });

        const responseText = await upstream.text();
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(
          JSON.stringify({
            status: upstream.status,
            headers: responseHeaders,
            body: responseText
          })
        );
      } catch (err) {
        res.writeHead(502, { 'Content-Type': 'application/json' });
        res.end(
          JSON.stringify({
            error: 'ROUTER_OFFLINE',
            message: err instanceof Error ? err.message : 'Upstream connection failed'
          })
        );
      }
      return;
    }

    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Not Found' }));
  });

  return { server, token, allowedOrigins };
}

function isExecutedDirectly() {
  if (!process.argv[1]) return false;
  try {
    return import.meta.url === pathToFileURL(process.argv[1]).href;
  } catch {
    return false;
  }
}

if (isExecutedDirectly()) {
  const { server, token, allowedOrigins } = createConnectorServer();

  server.on('error', (err) => {
    if (err && err.code === 'EADDRINUSE') {
      console.error(`\n[Error] Port ${DEFAULT_PORT} is already in use by another process.`);
      console.error('Stop the previous Local Connector with: pkill -f server.mjs');
      process.exit(1);
    }
    console.error('\n[Error] Failed to start Local Connector:', err?.message || err);
    process.exit(1);
  });

  const shutdown = () => {
    console.log('\nStopping Advanced Wi-Fi Local Connector...');
    server.close(() => process.exit(0));
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  server.listen(DEFAULT_PORT, HOST, () => {
    console.log('============================================================');
    console.log(' Advanced Wi-Fi — Local Connector Companion (v2.0.0)');
    console.log('============================================================');
    console.log(` Status   : Running on http://${HOST}:${DEFAULT_PORT}`);
    console.log(` Platform : ${os.platform()} (${os.arch()}) · Node ${process.version}`);
    console.log(` Auth     : Local Token Required`);
    console.log(` Token    : ${token}`);
    console.log(` Origins  : ${Array.from(allowedOrigins).join(', ')}`);
    console.log('------------------------------------------------------------');
    console.log(' Copy the Token above into "Local Connector Setup" in the app.');
    console.log(' Press Ctrl+C in Termux/terminal to stop this server.');
    console.log('============================================================\n');
  });
}
