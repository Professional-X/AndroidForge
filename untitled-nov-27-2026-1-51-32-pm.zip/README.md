# Advanced Wi-Fi

**Advanced Wi-Fi** is a unified, trilingual (Arabic RTL, English LTR, French LTR) web platform for managing local-network routers, inspecting and updating Wi-Fi settings, measuring real internet throughput, diagnosing network bottlenecks from measured evidence, and controlling connected devices.

## Features
- **9 Complete Views**: Dashboard, Router Connection, Wi-Fi Settings, Speed Test, Diagnostics, Connected Devices, Activity Log, Account, and Login.
- **Modular Router Adapters (`src/router-adapters/`)**: Protocol-specific adapters for Huawei (HiLink XML), TP-Link (LuCI/stok), ZTE (ZXHN Lua), Nokia (ONT CGI), D-Link (HNAP1 SOAP), Tenda (`/goform/`), ASUS (AsusWRT), Netgear (SOAP), FiberHome (`/cgi-bin/ajax`), and an honest Generic probe-only fallback.
- **Real Internet Speed Test (`src/services/speedTest.ts`)**: Live measurements against Cloudflare Edge (`speed.cloudflare.com/__down` and `__up`) for Download (Mbps), Upload (Mbps), Ping (ms), Jitter (ms), and Packet Loss (%).
- **Evidence-Based Network Diagnostics (`src/services/diagnostics.ts`)**: Distinguishes strictly between **Confirmed Issues**, **Possible Causes**, and **Unavailable Checks** based on real measurements.
- **Security & Privacy**:
  - Google Sign-In (OAuth 2.0 / OpenID Connect via Firebase Auth) for profile preferences, custom device aliases, speed history, and non-sensitive activity logs.
  - Strict RFC1918 private LAN validation (`192.168.0.0/16`, `10.0.0.0/8`, `172.16.0.0/12`) blocking loopback, cloud metadata (`169.254.169.254`), and arbitrary public URLs.
  - Optional local router credential storage uses **Web Crypto API (`AES-GCM`)** inside **IndexedDB**—never plaintext `localStorage`, never logged, and never transmitted to remote app databases.

## Browser Constraints & Optional Local Connector
Public HTTPS web applications (including GitHub Pages or Firebase Hosting) cannot send raw cross-origin HTTP requests with router session cookies to `http://192.168.x.x` due to browser **CORS**, **Mixed Content**, and **Private Network Access** protections.

To manage routers that do not allow browser CORS:
1. Ensure Node.js 18+ is installed on a computer connected to the same local Wi-Fi network.
2. Run the optional Local Connector Companion:
   ```bash
   node local-connector/server.mjs
   ```
3. In **Router Connection**, select **Local Connector Companion** (`127.0.0.1:4890`).

## Local Development & Verification
```bash
npm install
npm run dev
```

### Build & Unit Tests
```bash
npm run lint
npm run build
npx --yes tsx --test src/utils/networkSecurity.test.ts src/router-adapters/adapters.test.ts src/services/speedTest.test.ts src/services/diagnostics.test.ts firestore.rules.test.ts
```

## Deployment
- **Static Frontend (e.g., GitHub Pages / Firebase Hosting)**: Run `npm run build` and deploy `dist/`. Note that router communication from static hosting requires either router CORS/same-origin support or running `local-connector/server.mjs` locally on the user's LAN machine.
- **Firestore Rules**: Deploy `firestore.rules` to your Firebase project before production launch and review rules in the Firebase Console.
