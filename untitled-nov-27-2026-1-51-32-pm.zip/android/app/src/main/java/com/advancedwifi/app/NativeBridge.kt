package com.advancedwifi.app

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.nio.charset.Charset
import java.nio.charset.StandardCharsets
import javax.net.ssl.SSLException
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

internal class NativeBridge(
    context: Context,
    private val webView: WebView,
    private val isTrustedOrigin: () -> Boolean
) {
    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor: ExecutorService = Executors.newFixedThreadPool(4) { r ->
        Thread(r, "aw-native-net").apply { isDaemon = true }
    }
    private val destroyed = AtomicBoolean(false)

    // RAM-only session cookie jars keyed by Advanced Wi-Fi sessionId (never written to SharedPreferences or disk)
    private val sessionCookieJars = ConcurrentHashMap<String, ConcurrentHashMap<String, String>>()

    private fun isCallerTrusted(): Boolean = !destroyed.get() && isTrustedOrigin()

    @JavascriptInterface
    fun isNativeAndroid(): Boolean = isCallerTrusted()

    @JavascriptInterface
    fun getEnvironmentJson(): String {
        if (!isCallerTrusted()) return "{}"
        val snapshot = readWifiEnvironment()
        return JSONObject().apply {
            put("isNativeAndroid", true)
            put("appVersion", BuildConfig.VERSION_NAME)
            put("sdkInt", Build.VERSION.SDK_INT)
            put("wifiConnected", snapshot.wifiConnected)
            put("ssid", snapshot.ssid ?: JSONObject.NULL)
            put("gatewayIp", snapshot.gatewayIp ?: JSONObject.NULL)
            put("localIp", snapshot.localIp ?: JSONObject.NULL)
            put("networkBound", snapshot.wifiNetwork != null)
            put("wifiLinkSpeedMbps", snapshot.linkSpeedMbps ?: JSONObject.NULL)
            put("wifiFrequencyMhz", snapshot.frequencyMhz ?: JSONObject.NULL)
            put("wifiRssiDbm", snapshot.rssiDbm ?: JSONObject.NULL)
        }.toString()
    }

    @JavascriptInterface
    fun probeGatewayAsync(requestId: String, rawUrl: String, timeoutMs: Int) {
        if (!isCallerTrusted()) return
        val safeRequestId = requestId.take(80)
        executor.execute {
            val startedAt = System.currentTimeMillis()
            val check = LanSecurityValidator.validateLanTargetUrl(rawUrl)
            if (!check.valid) {
                resolveToWebView(
                    safeRequestId,
                    JSONObject().apply {
                        put("reachable", false)
                        put("latencyMs", 0)
                        put("errorCode", "INVALID_ROUTER_ADDRESS")
                        put("detail", "Blocked target: ${check.reason}")
                    }.toString()
                )
                return@execute
            }

            val clampedTimeout = timeoutMs.coerceIn(1000, 12_000)
            val wifiNetwork = readWifiEnvironment().wifiNetwork
            val resolvedCheck = verifyResolvedLanTarget(check.hostname, wifiNetwork)
            if (resolvedCheck != null) {
                val latency = (System.currentTimeMillis() - startedAt).coerceAtLeast(1L)
                resolveToWebView(
                    safeRequestId,
                    JSONObject().apply {
                        put("reachable", false)
                        put("latencyMs", latency)
                        put("errorCode", resolvedCheck.first)
                        put("detail", resolvedCheck.second)
                    }.toString()
                )
                return@execute
            }

            var conn: HttpURLConnection? = null
            try {
                val url = URL(check.normalizedUrl)
                conn = openBoundConnection(url, wifiNetwork).apply {
                    requestMethod = "GET"
                    connectTimeout = clampedTimeout
                    readTimeout = clampedTimeout
                    instanceFollowRedirects = false
                    useCaches = false
                    setRequestProperty("Accept", "text/html,application/json,*/*")
                    setRequestProperty("Connection", "close")
                }

                val status = conn.responseCode
                val latency = (System.currentTimeMillis() - startedAt).coerceAtLeast(1L)
                resolveToWebView(
                    safeRequestId,
                    JSONObject().apply {
                        put("reachable", true)
                        put("status", status)
                        put("latencyMs", latency)
                    }.toString()
                )
            } catch (e: Exception) {
                val latency = (System.currentTimeMillis() - startedAt).coerceAtLeast(1L)
                resolveToWebView(
                    safeRequestId,
                    JSONObject().apply {
                        put("reachable", false)
                        put("latencyMs", latency)
                        put("errorCode", "ROUTER_OFFLINE")
                        put("detail", describeNetworkException(e))
                    }.toString()
                )
            } finally {
                try {
                    conn?.disconnect()
                } catch (_: Exception) {
                }
            }
        }
    }

    @JavascriptInterface
    fun httpRequestAsync(requestId: String, payloadJson: String) {
        if (!isCallerTrusted()) return
        val safeRequestId = requestId.take(80)
        executor.execute {
            try {
                val payload = JSONObject(payloadJson)
                val sessionId = payload.optString("sessionId", "default").ifBlank { "default" }
                val rawUrl = payload.optString("url", "")
                val method = payload.optString("method", "GET").uppercase(Locale.US)
                val headersObj = payload.optJSONObject("headers")
                val body = if (payload.isNull("body")) null else payload.optString("body", "")
                val timeoutMs = payload.optInt("timeoutMs", 6500).coerceIn(1000, 20_000)

                if (method != "GET" && method != "POST" && method != "PUT") {
                    resolveToWebView(
                        safeRequestId,
                        JSONObject().apply {
                            put("ok", false)
                            put("errorCode", "SETTINGS_APPLY_FAILED")
                            put("detail", "Unsupported HTTP method: $method")
                        }.toString()
                    )
                    return@execute
                }

                val check = LanSecurityValidator.validateLanTargetUrl(rawUrl)
                if (!check.valid) {
                    resolveToWebView(
                        safeRequestId,
                        JSONObject().apply {
                            put("ok", false)
                            put("errorCode", "INVALID_ROUTER_ADDRESS")
                            put("detail", "Target blocked by LAN security policy (${check.reason}).")
                        }.toString()
                    )
                    return@execute
                }

                val responseJson = executeWithManualRedirects(
                    sessionId = sessionId,
                    initialUrl = check.normalizedUrl,
                    initialHostname = check.hostname,
                    initialMethod = method,
                    callerHeaders = headersObj,
                    requestBody = body,
                    timeoutMs = timeoutMs
                )
                resolveToWebView(safeRequestId, responseJson.toString())
            } catch (e: Exception) {
                resolveToWebView(
                    safeRequestId,
                    JSONObject().apply {
                        put("ok", false)
                        put("errorCode", "ROUTER_OFFLINE")
                        put("detail", describeNetworkException(e))
                    }.toString()
                )
            }
        }
    }

    @JavascriptInterface
    fun clearSessionCookies(sessionId: String?) {
        if (!isCallerTrusted()) return
        if (sessionId.isNullOrBlank()) {
            sessionCookieJars.clear()
        } else {
            sessionCookieJars.remove(sessionId)
        }
    }

    @JavascriptInterface
    fun openExternalPortal(rawUrl: String?): Boolean {
        if (!isCallerTrusted()) return false
        val check = LanSecurityValidator.validateLanTargetUrl(rawUrl)
        if (!check.valid) return false
        mainHandler.post {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(check.normalizedUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appContext.startActivity(intent)
            } catch (_: Exception) {
            }
        }
        return true
    }

    fun destroy() {
        destroyed.set(true)
        sessionCookieJars.clear()
        executor.shutdownNow()
    }

    private fun executeWithManualRedirects(
        sessionId: String,
        initialUrl: String,
        initialHostname: String,
        initialMethod: String,
        callerHeaders: JSONObject?,
        requestBody: String?,
        timeoutMs: Int
    ): JSONObject {
        val wifiNetwork = readWifiEnvironment().wifiNetwork
        val jar = sessionCookieJars.getOrPut(sessionId) { ConcurrentHashMap() }

        var currentUrl = initialUrl
        var currentHostname = initialHostname
        var currentMethod = initialMethod
        var currentBody = requestBody
        val maxRedirects = 3

        for (hop in 0..maxRedirects) {
            val resolvedCheck = verifyResolvedLanTarget(currentHostname, wifiNetwork)
            if (resolvedCheck != null) {
                return JSONObject().apply {
                    put("ok", false)
                    put("errorCode", resolvedCheck.first)
                    put("detail", resolvedCheck.second)
                }
            }

            var conn: HttpURLConnection? = null
            try {
                val urlObj = URL(currentUrl)
                conn = openBoundConnection(urlObj, wifiNetwork).apply {
                    requestMethod = currentMethod
                    connectTimeout = timeoutMs
                    readTimeout = timeoutMs
                    instanceFollowRedirects = false
                    useCaches = false
                }

                // Forward caller headers except Hop/Host/Cookie headers managed by the bridge
                var callerCookie: String? = null
                callerHeaders?.keys()?.forEach { key ->
                    val lower = key.lowercase(Locale.US)
                    val value = callerHeaders.optString(key, "")
                    if (lower == "cookie") {
                        callerCookie = value
                    } else if (lower != "host" && lower != "content-length" && value.isNotEmpty()) {
                        conn.setRequestProperty(key, value)
                    }
                }

                val mergedCookie = buildCookieHeader(jar, callerCookie)
                if (!mergedCookie.isNullOrEmpty()) {
                    conn.setRequestProperty("Cookie", mergedCookie)
                }

                if (currentMethod != "GET" && currentBody != null) {
                    val bytes = currentBody.toByteArray(StandardCharsets.UTF_8)
                    conn.doOutput = true
                    conn.setFixedLengthStreamingMode(bytes.size)
                    conn.outputStream.use { out ->
                        out.write(bytes)
                        out.flush()
                    }
                }

                val status = conn.responseCode
                extractAndStoreCookies(jar, conn)

                if (status in listOf(301, 302, 303, 307, 308) && hop < maxRedirects) {
                    val location = conn.getHeaderField("Location")?.trim()
                    if (!location.isNullOrEmpty()) {
                        val nextUrl = URL(urlObj, location).toString()
                        val nextCheck = LanSecurityValidator.validateLanTargetUrl(nextUrl)
                        if (!nextCheck.valid) {
                            return JSONObject().apply {
                                put("ok", false)
                                put("errorCode", "INVALID_ROUTER_ADDRESS")
                                put("detail", "Redirect blocked by LAN policy (${nextCheck.reason}).")
                            }
                        }
                        currentUrl = nextCheck.normalizedUrl
                        currentHostname = nextCheck.hostname
                        if (status == 301 || status == 302 || status == 303) {
                            currentMethod = "GET"
                            currentBody = null
                        }
                        continue
                    }
                }

                val stream = if (status >= 400) conn.errorStream else conn.inputStream
                val charset = resolveResponseCharset(conn.contentType)
                val bodyText = readStreamBounded(stream, maxBytes = 8 * 1024 * 1024, charset = charset)

                val safeHeaders = JSONObject()
                for ((headerName, values) in conn.headerFields) {
                    if (headerName.isNullOrBlank()) continue
                    val lower = headerName.lowercase(Locale.US)
                    if (lower == "set-cookie") continue
                    if (!values.isNullOrEmpty()) {
                        safeHeaders.put(lower, values.joinToString(", "))
                    }
                }

                return JSONObject().apply {
                    put("ok", true)
                    put("status", status)
                    put("headers", safeHeaders)
                    put("body", bodyText)
                }
            } finally {
                try {
                    conn?.disconnect()
                } catch (_: Exception) {
                }
            }
        }

        return JSONObject().apply {
            put("ok", false)
            put("errorCode", "ROUTER_OFFLINE")
            put("detail", "Exceeded maximum redirect hops.")
        }
    }

    private fun verifyResolvedLanTarget(host: String, wifiNetwork: Network?): Pair<String, String>? {
        if (LanSecurityValidator.isPrivateLanIpv4(host)) {
            return null
        }
        return try {
            val resolved = if (wifiNetwork != null) {
                wifiNetwork.getAllByName(host)
            } else {
                InetAddress.getAllByName(host)
            }
            if (resolved.isEmpty()) {
                "ROUTER_OFFLINE" to "Modem hostname resolved to no LAN addresses."
            } else if (resolved.any { !LanSecurityValidator.isResolvedAddressSafe(it) }) {
                "INVALID_ROUTER_ADDRESS" to "Resolved hostname target violates RFC1918 LAN policy."
            } else {
                null
            }
        } catch (e: UnknownHostException) {
            "ROUTER_OFFLINE" to "Could not resolve modem host on Wi-Fi LAN."
        } catch (e: Exception) {
            "ROUTER_OFFLINE" to describeNetworkException(e)
        }
    }

    private fun describeNetworkException(e: Exception): String {
        return when (e) {
            is SocketTimeoutException -> "Timed out waiting for modem HTTP response over Wi-Fi."
            is ConnectException -> "Modem port unreachable or refused connection on local Wi-Fi."
            is UnknownHostException -> "Could not resolve modem address on local Wi-Fi."
            is SSLException -> "TLS handshake failed with local modem."
            else -> LanSecurityValidator.redactSecrets(e.message ?: "Native HTTP connection failed")
        }
    }

    private fun openBoundConnection(url: URL, wifiNetwork: Network?): HttpURLConnection {
        if (wifiNetwork != null) {
            return wifiNetwork.openConnection(url) as HttpURLConnection
        }
        return url.openConnection() as HttpURLConnection
    }

    private fun resolveResponseCharset(contentType: String?): Charset {
        if (!contentType.isNullOrBlank()) {
            val match = Regex("charset\\s*=\\s*[\"']?([A-Za-z0-9._-]+)[\"']?", RegexOption.IGNORE_CASE)
                .find(contentType)
            val candidate = match?.groupValues?.getOrNull(1)?.trim()
            if (!candidate.isNullOrEmpty()) {
                try {
                    if (Charset.isSupported(candidate)) {
                        return Charset.forName(candidate)
                    }
                } catch (_: Exception) {
                }
            }
        }
        return StandardCharsets.UTF_8
    }

    private fun readStreamBounded(
        stream: java.io.InputStream?,
        maxBytes: Int,
        charset: Charset = StandardCharsets.UTF_8
    ): String {
        if (stream == null) return ""
        stream.use { input ->
            val buffer = ByteArrayOutputStream()
            val chunk = ByteArray(8192)
            var total = 0
            while (true) {
                val read = input.read(chunk)
                if (read <= 0) break
                val allowed = (maxBytes - total).coerceAtMost(read)
                if (allowed > 0) {
                    buffer.write(chunk, 0, allowed)
                    total += allowed
                }
                if (total >= maxBytes) break
            }
            return String(buffer.toByteArray(), charset)
        }
    }

    private fun extractAndStoreCookies(
        jar: ConcurrentHashMap<String, String>,
        conn: HttpURLConnection
    ) {
        for ((key, values) in conn.headerFields) {
            if (!key.equals("Set-Cookie", ignoreCase = true) || values == null) continue
            for (rawHeader in values) {
                val firstPair = rawHeader.substringBefore(';').trim()
                val eqIdx = firstPair.indexOf('=')
                if (eqIdx <= 0) continue
                val name = firstPair.substring(0, eqIdx).trim()
                val value = firstPair.substring(eqIdx + 1).trim()
                if (value.isEmpty() || value.equals("deleted", ignoreCase = true)) {
                    jar.remove(name)
                } else {
                    jar[name] = value
                }
            }
        }
    }

    private fun buildCookieHeader(
        jar: ConcurrentHashMap<String, String>,
        callerCookie: String?
    ): String? {
        val merged = LinkedHashMap<String, String>(jar)
        if (!callerCookie.isNullOrBlank()) {
            for (part in callerCookie.split(';')) {
                val trimmed = part.trim()
                val eq = trimmed.indexOf('=')
                if (eq > 0) {
                    val name = trimmed.substring(0, eq).trim()
                    val value = trimmed.substring(eq + 1).trim()
                    merged[name] = value
                }
            }
        }
        if (merged.isEmpty()) return null
        return merged.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    private data class WifiEnvSnapshot(
        val wifiNetwork: Network?,
        val wifiConnected: Boolean,
        val ssid: String?,
        val gatewayIp: String?,
        val localIp: String?,
        val linkSpeedMbps: Int?,
        val frequencyMhz: Int?,
        val rssiDbm: Int?
    )

    private fun readWifiEnvironment(): WifiEnvSnapshot {
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return WifiEnvSnapshot(null, false, null, null, null, null, null, null)

        var selectedNetwork: Network? = null
        var selectedCaps: NetworkCapabilities? = null

        val active = cm.activeNetwork
        if (active != null) {
            val activeCaps = cm.getNetworkCapabilities(active)
            if (activeCaps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) {
                selectedNetwork = active
                selectedCaps = activeCaps
            }
        }

        if (selectedNetwork == null) {
            var fallbackWifi: Network? = null
            var fallbackCaps: NetworkCapabilities? = null

            @Suppress("DEPRECATION")
            for (network in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(network) ?: continue
                if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) continue
                val props = cm.getLinkProperties(network)
                val hasIpv4 = props?.linkAddresses?.any { it.address is Inet4Address && !it.address.isLoopbackAddress } == true
                if (hasIpv4) {
                    selectedNetwork = network
                    selectedCaps = caps
                    break
                }
                if (fallbackWifi == null) {
                    fallbackWifi = network
                    fallbackCaps = caps
                }
            }
            if (selectedNetwork == null) {
                selectedNetwork = fallbackWifi
                selectedCaps = fallbackCaps
            }
        }

        if (selectedNetwork == null) {
            return WifiEnvSnapshot(null, false, null, null, null, null, null, null)
        }

        val linkProps = cm.getLinkProperties(selectedNetwork)
        var gatewayIp: String? = null
        var secondaryGatewayIp: String? = null
        var localIp: String? = null

        if (linkProps != null) {
            for (route in linkProps.routes) {
                val gw = route.gateway
                if (gw is Inet4Address && !gw.isAnyLocalAddress && !gw.isLoopbackAddress) {
                    if (route.isDefaultRoute) {
                        gatewayIp = gw.hostAddress
                        break
                    } else if (secondaryGatewayIp == null) {
                        secondaryGatewayIp = gw.hostAddress
                    }
                }
            }
            if (gatewayIp == null) {
                gatewayIp = secondaryGatewayIp
            }
            for (addr in linkProps.linkAddresses) {
                val inet = addr.address
                if (inet is Inet4Address && !inet.isLoopbackAddress) {
                    localIp = inet.hostAddress
                    break
                }
            }
        }

        if (gatewayIp == null) {
            @Suppress("DEPRECATION")
            val wm = appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            @Suppress("DEPRECATION")
            val rawGw = wm?.dhcpInfo?.gateway ?: 0
            if (rawGw != 0) {
                val candidate = String.format(
                    Locale.US,
                    "%d.%d.%d.%d",
                    rawGw and 0xff,
                    (rawGw shr 8) and 0xff,
                    (rawGw shr 16) and 0xff,
                    (rawGw shr 24) and 0xff
                )
                if (LanSecurityValidator.isPrivateLanIpv4(candidate)) {
                    gatewayIp = candidate
                }
            }
        }

        val wifiInfo = extractSafeWifiInfo(selectedCaps)
        val rawSsid = wifiInfo?.ssid?.trim()?.removeSurrounding("\"")?.trim().orEmpty()
        val ssid = if (rawSsid.isEmpty() || rawSsid.equals("<unknown ssid>", ignoreCase = true)) null else rawSsid
        val linkSpeed = wifiInfo?.linkSpeed?.takeIf { it > 0 }
        val frequency = wifiInfo?.frequency?.takeIf { it > 0 }
        val rssi = wifiInfo?.rssi?.takeIf { it in -120..-1 }

        return WifiEnvSnapshot(
            wifiNetwork = selectedNetwork,
            wifiConnected = true,
            ssid = ssid,
            gatewayIp = gatewayIp,
            localIp = localIp,
            linkSpeedMbps = linkSpeed,
            frequencyMhz = frequency,
            rssiDbm = rssi
        )
    }

    @Suppress("DEPRECATION")
    private fun extractSafeWifiInfo(caps: NetworkCapabilities?): WifiInfo? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val transportInfo = caps?.transportInfo as? WifiInfo
            if (transportInfo != null) return transportInfo
        }
        val wm = appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        return wm?.connectionInfo
    }

    private fun resolveToWebView(requestId: String, payloadJson: String) {
        if (destroyed.get()) return
        val quotedId = JSONObject.quote(requestId)
        val quotedPayload = JSONObject.quote(payloadJson)
        mainHandler.post {
            if (!destroyed.get()) {
                webView.evaluateJavascript(
                    "window.__awNativeResolve && window.__awNativeResolve($quotedId, $quotedPayload);",
                    null
                )
            }
        }
    }
}
