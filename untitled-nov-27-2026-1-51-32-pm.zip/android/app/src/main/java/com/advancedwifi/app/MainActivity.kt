package com.advancedwifi.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.webkit.WebViewAssetLoader
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var splashOverlay: LinearLayout
    private lateinit var errorOverlay: LinearLayout
    private lateinit var errorDetailView: TextView
    private lateinit var retryButton: MaterialButton
    private lateinit var nativeBridge: NativeBridge
    private lateinit var assetLoader: WebViewAssetLoader

    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private var hasCompletedInitialLoad = false
    private var mainFrameLoadFailed = false
    @Volatile
    private var trustedOriginActive = false

    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
            val result = if (uris.isNullOrEmpty()) null else uris.toTypedArray()
            fileUploadCallback?.onReceiveValue(result)
            fileUploadCallback = null
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        webView = findViewById(R.id.mainWebView)
        splashOverlay = findViewById(R.id.splashOverlay)
        errorOverlay = findViewById(R.id.errorOverlay)
        errorDetailView = findViewById(R.id.errorDetailView)
        retryButton = findViewById(R.id.retryButton)

        assetLoader = WebViewAssetLoader.Builder()
            .setDomain(APP_ASSETS_HOST)
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        nativeBridge = NativeBridge(this, webView) { trustedOriginActive }
        configureWebView()
        setupBackNavigation()

        retryButton.setOnClickListener {
            mainFrameLoadFailed = false
            errorOverlay.visibility = View.GONE
            if (!hasCompletedInitialLoad) {
                splashOverlay.visibility = View.VISIBLE
            }
            webView.loadUrl(ENTRY_URL)
        }

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl(ENTRY_URL)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = false
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            useWideViewPort = true
            loadWithOverviewMode = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
        }

        webView.overScrollMode = View.OVER_SCROLL_NEVER
        webView.addJavascriptInterface(nativeBridge, "AdvancedWifiNative")

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback
                return try {
                    val mime = fileChooserParams?.acceptTypes
                        ?.firstOrNull { it.isNotBlank() }
                        ?: "image/*"
                    fileChooserLauncher.launch(mime)
                    true
                } catch (_: Exception) {
                    fileUploadCallback = null
                    false
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val url = request.url
                if (url.scheme == "https" && url.host == APP_ASSETS_HOST) {
                    val rewritten = Uri.Builder()
                        .scheme("https")
                        .authority(APP_ASSETS_HOST)
                        .path("/www" + (if (url.path.isNullOrEmpty() || url.path == "/") "/index.html" else url.path))
                        .build()
                    val direct = assetLoader.shouldInterceptRequest(rewritten)
                    if (direct != null) return direct

                    // SPA client-side route fallback to index.html for extensionless navigation requests
                    val path = url.path.orEmpty()
                    if (request.isForMainFrame && !path.contains('.')) {
                        val fallback = Uri.parse("https://$APP_ASSETS_HOST/www/index.html")
                        return assetLoader.shouldInterceptRequest(fallback)
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest
            ): Boolean {
                val uri = request.url ?: return true
                val scheme = uri.scheme?.lowercase().orEmpty()
                val host = uri.host?.lowercase().orEmpty()

                if (scheme == "https" && host == APP_ASSETS_HOST) {
                    return false
                }

                // Only permit user-initiated navigation to validated local LAN router portals outside WebView
                val lanCheck = LanSecurityValidator.validateLanTargetUrl(uri.toString())
                if (lanCheck.valid) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(lanCheck.normalizedUrl)))
                    } catch (_: Exception) {
                    }
                }
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                mainFrameLoadFailed = false
                trustedOriginActive = url?.startsWith("https://$APP_ASSETS_HOST/") == true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (!mainFrameLoadFailed) {
                    hasCompletedInitialLoad = true
                    errorOverlay.visibility = View.GONE
                    splashOverlay.animate()
                        .alpha(0f)
                        .setDuration(220)
                        .withEndAction {
                            splashOverlay.visibility = View.GONE
                            splashOverlay.alpha = 1f
                        }
                        .start()
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    mainFrameLoadFailed = true
                    splashOverlay.visibility = View.GONE
                    errorDetailView.text = error?.description?.toString()?.takeIf { it.isNotBlank() }
                        ?: getString(R.string.error_message)
                    errorOverlay.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (errorOverlay.visibility == View.VISIBLE) {
                    finish()
                    return
                }
                webView.evaluateJavascript(
                    "(function(){ try { return Boolean(window.__awHandleHardwareBack && window.__awHandleHardwareBack()); } catch(e){ return false; } })();"
                ) { result ->
                    if (result == "true") {
                        return@evaluateJavascript
                    }
                    if (webView.canGoBack()) {
                        webView.goBack()
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        nativeBridge.destroy()
        webView.removeJavascriptInterface("AdvancedWifiNative")
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val APP_ASSETS_HOST = "appassets.androidplatform.net"
        private const val ENTRY_URL = "https://$APP_ASSETS_HOST/index.html"
    }
}
